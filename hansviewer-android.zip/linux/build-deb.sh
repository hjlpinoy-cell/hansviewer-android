#!/bin/bash
# Builds hansviewer_<version>_all.deb into the folder given as $1
set -euo pipefail
OUT="${1:-$PWD}"
HERE="$(cd "$(dirname "$0")" && pwd)"
V=$(grep '^VERSION' "$HERE/hansviewer.py" | cut -d'"' -f2)
R=$(mktemp -d)/hansviewer_${V}_all
mkdir -p "$R/DEBIAN" "$R/usr/bin" "$R/usr/share/hansviewer" "$R/usr/share/applications" \
         "$R/usr/share/icons/hicolor/scalable/apps" "$R/usr/share/doc/hansviewer"
install -m 0755 "$HERE/hansviewer.py" "$R/usr/share/hansviewer/hansviewer.py"
install -m 0644 "$HERE/hansviewer.svg" "$R/usr/share/icons/hicolor/scalable/apps/hansviewer.svg"
printf '#!/bin/sh\nexec python3 /usr/share/hansviewer/hansviewer.py "$@"\n' > "$R/usr/bin/hansviewer"
chmod 0755 "$R/usr/bin/hansviewer"
cat > "$R/usr/share/applications/hansviewer.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=HansViewer $V
GenericName=Image Browser
Comment=Browse, view and edit photos
Exec=hansviewer %f
Icon=hansviewer
Terminal=false
Categories=Graphics;Viewer;Photography;
MimeType=image/jpeg;image/png;image/gif;image/bmp;image/webp;image/tiff;image/x-portable-pixmap;image/svg+xml;
Keywords=photo;picture;image;viewer;slideshow;exif;
DESK
echo "HansViewer - an image browser, viewer and editor for Linux." > "$R/usr/share/doc/hansviewer/copyright"
cat > "$R/DEBIAN/control" <<CTRL
Package: hansviewer
Version: $V
Section: graphics
Priority: optional
Architecture: all
Depends: python3 (>= 3.8), python3-pyqt6, python3-gi, gir1.2-glib-2.0, libglib2.0-bin, libsecret-tools, rclone, fuse3, python3-pil, openssl
Recommends: python3-numpy, avahi-utils
Installed-Size: $(du -sk "$R/usr" | cut -f1)
Maintainer: Hans <hjlpinoy@gmail.com>
Description: fast image browser, viewer and editor
 HansViewer is a photo browser with a folder and device sidebar with
 favourites, a thumbnail grid, an instant full-screen viewer with slideshow,
 sorting by date taken (EXIF), network shares and cloud storage (rclone),
 batch rename, and a built-in editor with crop,
 resize, rotate and colour adjustments.
CTRL
dpkg-deb --root-owner-group --build "$R" "$OUT/hansviewer_${V}_all.deb"
