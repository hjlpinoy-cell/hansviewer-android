#!/usr/bin/env python3
"""
HansViewer - a fast image browser, viewer and editor for Linux,
written with Python and Qt 6.

Usage:
    python3 hansviewer.py [folder-or-image]
    python3 hansviewer.py --install      # add HansViewer to your app menu

Needs:    sudo apt install python3-pyqt6
Optional: sudo apt install python3-numpy python3-pil
          (numpy: brightness/contrast/colour tools; Pillow: EXIF info and
           keeping camera data when saving)

Press F1 in the app for all keyboard shortcuts.
"""
import base64
import hashlib
import http.client
import json
import os
import re
import select
import shutil
import signal
import socket
import ssl
import struct
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import urllib.parse

from PyQt6.QtCore import (QAbstractListModel, QPoint, QBuffer, QByteArray, QDir, QFileSystemWatcher,
                          QEvent, QMimeData, QModelIndex, QObject, QPointF, QRect,
                          QRectF, QRunnable, QSettings, QSize, QStorageInfo,
                          Qt, QThreadPool, QTimer, QUrl, pyqtSignal)
from PyQt6.QtGui import (QAction, QColor, QCursor, QDesktopServices, QFont, QIcon,
                         QImage, QImageIOHandler, QImageReader, QImageWriter,
                         QFontMetrics, QKeySequence, QPainter, QPainterPath, QPalette, QPen,
                         QPixmap, QTransform)
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox,
                             QComboBox, QDialog, QDialogButtonBox,
                             QFileDialog, QFormLayout, QFrame, QGridLayout,
                             QGroupBox, QHBoxLayout, QInputDialog, QLabel,
                             QLineEdit, QListView, QListWidget, QMainWindow,
                             QMenu, QMessageBox, QProgressDialog, QPushButton,
                             QScrollArea, QSizePolicy, QSlider, QSpinBox,
                             QSplitter, QStackedWidget, QStyle, QStyledItemDelegate, QStyleOptionViewItem,
                             QTreeView, QTreeWidget, QTreeWidgetItem,
                             QVBoxLayout, QWidget)

try:
    from PyQt6 import sip
except ImportError:  # very old packaging: fall back to a check that never blocks the app
    class sip:  # noqa: N801
        @staticmethod
        def isdeleted(_obj):
            try:
                _obj.text(0)
                return False
            except RuntimeError:
                return True

try:  # Qt 6.5+ moved QFileSystemModel to QtGui
    from PyQt6.QtGui import QFileSystemModel
except ImportError:
    from PyQt6.QtWidgets import QFileSystemModel

try:  # GIO lets us talk to network connections the way the file manager does
    import gi
    gi.require_version("Gio", "2.0")
    from gi.repository import Gio
except (ImportError, ValueError):
    Gio = None

try:
    import numpy as np
except ImportError:
    np = None

try:
    from PIL import Image as PILImage
except ImportError:
    PILImage = None

APP = "HansViewer"
APP_ID = "hansviewer"
# True when installed from the .deb package (lives under /usr)
SYSTEM_INSTALL = os.path.abspath(__file__).startswith("/usr/")
VERSION = "5.3"
THUMB_MAX = 256  # thumbnails are generated at this size and scaled for display
READ_EXTS = {bytes(f).decode().lower() for f in QImageReader.supportedImageFormats()}
VIDEO_EXTS = {"mp4", "m4v", "mov", "mkv", "avi", "webm", "3gp", "mts", "m2ts", "wmv", "mpg", "mpeg"}
SHOW_VIDEOS = [True]   # Settings → "Show videos" (kept here so background threads can read it)


def media_exts():
    """The file types shown in the thumbnail view: photos, plus videos when switched on."""
    return READ_EXTS | VIDEO_EXTS if SHOW_VIDEOS[0] else READ_EXTS


def is_video(path):
    return os.path.splitext(path)[1][1:].lower() in VIDEO_EXTS
ROLE_DIMS = int(Qt.ItemDataRole.UserRole) + 1
ROLE_PATH = int(Qt.ItemDataRole.UserRole) + 2
ROLE_SERVER = int(Qt.ItemDataRole.UserRole) + 3  # saved server index of a sidebar item
ROLE_MISSING = int(Qt.ItemDataRole.UserRole) + 4  # on-demand folder: no thumbnail made yet
ROLE_SIZE = int(Qt.ItemDataRole.UserRole) + 5
ROLE_REAL = int(Qt.ItemDataRole.UserRole) + 6  # sidebar: the real name under your alias
ROLE_LENGTH = int(Qt.ItemDataRole.UserRole) + 7  # video length text, e.g. "1:23"
ROLE_MONTH = int(Qt.ItemDataRole.UserRole) + 8  # Timeline: "October 2026" on the first photo of a month
NET_FS = {"cifs", "smb3", "smbfs", "nfs", "nfs4", "sshfs", "fuse.sshfs",
          "fuse.rclone", "davfs", "fuse.gvfsd-fuse"}
CACHE_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                         "thumbnails", "large")
CACHE_DIR_NORMAL = os.path.join(os.path.dirname(CACHE_DIR), "normal")  # 128 px, freedesktop spec

# ======================================================================= theme
THEMES = {
    "dark": dict(bg="#17181b", panel="#1f2125", input="#2a2d32", hover="#2c3036",
                 border="#2f3237", text="#e8eaed", muted="#9aa0a8", accent="#4c8dff",
                 accent_soft="rgba(76,141,255,0.22)", card="#24272c", card_hover="#2d3138",
                 scroll="#3a3e45", viewer="#0e0f11"),
    "light": dict(bg="#eef0f3", panel="#fafbfc", input="#ffffff", hover="#e4e8ee",
                  border="#d9dde3", text="#1d2127", muted="#697180", accent="#2f6fed",
                  accent_soft="rgba(47,111,237,0.16)", card="#ffffff", card_hover="#f1f5fb",
                  scroll="#c3c8d0", viewer="#121314"),
}
THEME = dict(THEMES["dark"])

QSS = """
QMainWindow, QDialog { background: %(bg)s; }
QWidget { color: %(text)s; }
QToolBar { background: %(panel)s; border: none; border-bottom: 1px solid %(border)s;
           padding: 5px 8px; spacing: 3px; }
QToolBar::separator { background: %(border)s; width: 1px; margin: 4px 6px; }
QToolButton { background: transparent; border: none; border-radius: 6px; padding: 5px; }
QToolButton:hover { background: %(hover)s; }
QToolButton:checked { background: %(accent_soft)s; }
QLineEdit, QSpinBox, QComboBox { background: %(input)s; border: 1px solid %(border)s;
    border-radius: 6px; padding: 4px 8px; selection-background-color: %(accent)s; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border: 1px solid %(accent)s; }
QComboBox::drop-down { border: none; width: 18px; }
QComboBox QAbstractItemView { background: %(panel)s; border: 1px solid %(border)s;
    selection-background-color: %(accent)s; padding: 4px; }
QTreeView, QTreeWidget, QListWidget { background: %(panel)s; border: none; outline: 0; }
QTreeView::item, QTreeWidget::item { padding: 4px 2px; border-radius: 5px; }
QTreeView::item:hover, QTreeWidget::item:hover { background: %(hover)s; }
QTreeView::item:selected, QTreeWidget::item:selected { background: %(accent_soft)s; color: %(text)s; }
QListView#grid { background: %(bg)s; border: none; outline: 0; }
QSplitter::handle { background: %(border)s; }
QSplitter::handle:horizontal { width: 1px; }
QSplitter::handle:vertical { height: 1px; }
QStatusBar { background: %(panel)s; border-top: 1px solid %(border)s; color: %(muted)s; }
QStatusBar QLabel { color: %(muted)s; padding: 0 6px; }
QMenuBar { background: %(panel)s; padding: 2px; }
QMenuBar::item { padding: 4px 10px; background: transparent; border-radius: 4px; }
QMenuBar::item:selected { background: %(hover)s; }
QMenu { background: %(panel)s; border: 1px solid %(border)s; border-radius: 8px; padding: 6px; }
QMenu::item { padding: 6px 28px 6px 14px; border-radius: 5px; }
QMenu::item:selected { background: %(accent)s; color: white; }
QMenu::item:disabled { color: %(muted)s; }
QMenu::separator { height: 1px; background: %(border)s; margin: 4px 8px; }
QPushButton { background: %(input)s; border: 1px solid %(border)s; border-radius: 6px;
    padding: 6px 12px; }
QPushButton:hover { border-color: %(accent)s; }
QPushButton:pressed { background: %(hover)s; }
QPushButton:checked { background: %(accent_soft)s; border-color: %(accent)s; }
QPushButton:disabled { color: %(muted)s; border-color: %(border)s; }
QPushButton#primary { background: %(accent)s; border-color: %(accent)s; color: white; }
QGroupBox { border: 1px solid %(border)s; border-radius: 8px; margin-top: 16px;
    padding: 12px 8px 8px 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: %(muted)s; }
QSlider::groove:horizontal { height: 4px; background: %(border)s; border-radius: 2px; }
QSlider::sub-page:horizontal { background: %(accent)s; border-radius: 2px; }
QSlider::handle:horizontal { background: #ffffff; border: 1px solid %(border)s; width: 14px;
    height: 14px; margin: -6px 0; border-radius: 8px; }
QScrollBar:vertical { background: transparent; width: 11px; margin: 2px; }
QScrollBar:horizontal { background: transparent; height: 11px; margin: 2px; }
QScrollBar::handle:vertical { background: %(scroll)s; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:horizontal { background: %(scroll)s; border-radius: 4px; min-width: 30px; }
QScrollBar::handle:hover { background: %(muted)s; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: none; }
QScrollArea { border: none; background: transparent; }
QToolTip { background: %(panel)s; color: %(text)s; border: 1px solid %(border)s;
    padding: 4px; border-radius: 4px; }
QLabel#title { font-size: 15px; font-weight: bold; }
QLabel#muted { color: %(muted)s; }
QWidget#previewPane { background: %(panel)s; }
QFrame#banner { background: %(accent_soft)s; border-bottom: 1px solid %(border)s; }
QWidget#toolsPanel { background: %(panel)s; }
"""


def apply_theme(app, name):
    THEME.clear()
    THEME.update(THEMES.get(name, THEMES["dark"]))
    t = THEME
    app.setStyle("Fusion")
    pal = QPalette()
    roles = {
        QPalette.ColorRole.Window: t["bg"], QPalette.ColorRole.WindowText: t["text"],
        QPalette.ColorRole.Base: t["panel"], QPalette.ColorRole.AlternateBase: t["card"],
        QPalette.ColorRole.Text: t["text"], QPalette.ColorRole.Button: t["input"],
        QPalette.ColorRole.ButtonText: t["text"], QPalette.ColorRole.Highlight: t["accent"],
        QPalette.ColorRole.HighlightedText: "#ffffff", QPalette.ColorRole.ToolTipBase: t["panel"],
        QPalette.ColorRole.ToolTipText: t["text"], QPalette.ColorRole.PlaceholderText: t["muted"],
        QPalette.ColorRole.Link: t["accent"],
    }
    for role, color in roles.items():
        pal.setColor(role, QColor(color))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(t["muted"]))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(t["muted"]))
    app.setPalette(pal)
    app.setStyleSheet(QSS % t)


def setup_icon_theme():
    """Qt apps on Cinnamon/MATE often miss the desktop icon theme; borrow it."""
    if QIcon.themeName() not in ("", "hicolor"):
        return
    for schema in ("org.cinnamon.desktop.interface", "org.mate.interface",
                   "org.gnome.desktop.interface"):
        try:
            out = subprocess.run(["gsettings", "get", schema, "icon-theme"],
                                 capture_output=True, text=True, timeout=1)
            name = out.stdout.strip().strip("'")
            if out.returncode == 0 and name:
                QIcon.setThemeName(name)
                return
        except (OSError, subprocess.SubprocessError):
            pass
    QIcon.setThemeName("Adwaita")


def menu_add(menu, text, slot):
    a = menu.addAction(text)
    a.triggered.connect(lambda _=False: slot())
    return a


def icon(names, fallback=None):
    for n in names.split():
        ic = QIcon.fromTheme(n)
        if not ic.isNull():
            return ic
    if fallback is not None:
        return QApplication.style().standardIcon(fallback)
    return QIcon()


SP = QStyle.StandardPixmap


def bin_icon():
    """A clear red rubbish-bin icon, drawn so it looks the same on every desktop theme."""
    ic = QIcon()
    for size in (16, 24, 32, 48, 64):
        pix = QPixmap(size, size)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s = size / 64.0
        red = QColor("#e5534b")
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(red)
        p.drawRoundedRect(QRectF(24 * s, 6 * s, 16 * s, 7 * s), 3 * s, 3 * s)    # handle
        p.drawRoundedRect(QRectF(8 * s, 12 * s, 48 * s, 7 * s), 3 * s, 3 * s)    # lid
        body = QPainterPath()
        body.moveTo(13 * s, 22 * s)
        body.lineTo(51 * s, 22 * s)
        body.lineTo(47 * s, 58 * s)
        body.quadTo(46.5 * s, 60 * s, 44 * s, 60 * s)
        body.lineTo(20 * s, 60 * s)
        body.quadTo(17.5 * s, 60 * s, 17 * s, 58 * s)
        body.closeSubpath()
        p.drawPath(body)
        pen = QPen(QColor(255, 255, 255, 210), max(1.0, 3.2 * s))
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        for x in (24, 32, 40):
            p.drawLine(QPointF(x * s, 29 * s), QPointF(x * s, 52 * s))
        p.end()
        ic.addPixmap(pix)
    return ic


# ======================================================================= settings
_SETTINGS = None


def settings():
    global _SETTINGS
    if _SETTINGS is None:
        _SETTINGS = QSettings(APP_ID, APP_ID)
        if not _SETTINGS.allKeys():  # carry over settings from the old "acdview" name
            old = QSettings("acdview", "acdview")
            for k in old.allKeys():
                _SETTINGS.setValue(k, old.value(k))
    return _SETTINGS


def setting(key, default, typ=None):
    typ = typ or type(default)
    try:
        return settings().value(key, default, type=typ)
    except TypeError:
        return default


# ======================================================================= helpers
def natural_key(name):
    """Sort 'img2' before 'img10', like a human would."""
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", name.lower())]


def human_size(n):
    for unit in ("bytes", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:,.0f} {unit}" if unit == "bytes" else f"{n:,.1f} {unit}"
        n /= 1024
    return str(n)


def copyable_box(kind, parent, title, text):
    """A message box whose text can be selected and copied (with a Copy button)."""
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Warning if kind == "warning" else QMessageBox.Icon.Information)
    box.setWindowTitle(title)
    box.setText(text)
    box.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse
                                | Qt.TextInteractionFlag.TextSelectableByKeyboard)
    copy = box.addButton("Copy", QMessageBox.ButtonRole.ActionRole)
    box.addButton(QMessageBox.StandardButton.Ok)
    copy.clicked.connect(lambda: QApplication.clipboard().setText(f"{title}\n{text}"))
    box.exec()
    return QMessageBox.StandardButton.Ok


def command_dialog(parent, title, intro, command, outro=""):
    """Shows a terminal command that can be copied with one click."""
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    lay = QVBoxLayout(dlg)
    lab = QLabel(intro)
    lab.setWordWrap(True)
    lay.addWidget(lab)
    line = QLineEdit(command)
    line.setReadOnly(True)
    line.setMinimumWidth(560)
    line.setCursorPosition(0)
    lay.addWidget(line)
    if outro:
        o = QLabel(outro)
        o.setWordWrap(True)
        lay.addWidget(o)
    row = QHBoxLayout()
    row.addStretch(1)
    copy = QPushButton("Copy command")
    done = QPushButton("Close")
    row.addWidget(copy)
    row.addWidget(done)
    lay.addLayout(row)

    def do_copy():
        QApplication.clipboard().setText(command)
        copy.setText("Copied ✓")

    copy.clicked.connect(do_copy)
    done.clicked.connect(dlg.accept)
    dlg.exec()


def image_dims(reader):
    """Width/height after EXIF rotation, from the header only."""
    size = reader.size()
    if not size.isValid():
        return 0, 0
    w, h = size.width(), size.height()
    try:
        if reader.transformation() & QImageIOHandler.Transformation.TransformationRotate90:
            w, h = h, w
    except (TypeError, AttributeError):
        pass
    return w, h


def _remote_bytes(path):
    """Reads a whole network/cloud file with Python's own file reading. Unlike Qt's file
    reading this lets the rest of HansViewer keep running while a slow download (e.g. a
    Google Drive photo through rclone) is still in progress, so the window never freezes."""
    t0 = time.monotonic()
    chunks = []
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1 << 20)
            if not chunk:
                break
            chunks.append(chunk)
    data = b"".join(chunks)
    alog("read done", path, bytes=len(data), took=f"{time.monotonic() - t0:.2f}s")
    return data


def _reader_for(path):
    """A QImageReader for the photo. Network and cloud photos are first fetched completely
    in the background (gvfs through GIO, rclone and other mounts with Python's file reading)."""
    if is_remote(path):
        try:
            data = gio_read(path) if is_gvfs(path) else _remote_bytes(path)
        except Exception as e:
            alog("read ERROR", path, error=str(e)[:120])
            return None, None
        buf = QBuffer()
        buf.setData(QByteArray(data))
        buf.open(QBuffer.OpenModeFlag.ReadOnly)
        reader = QImageReader(buf)
        reader.setDecideFormatFromContent(True)
        return reader, buf
    return QImageReader(path), None


def _read_local_file(path, max_edge=None):
    reader = QImageReader(path)
    reader.setAutoTransform(True)  # respect EXIF rotation
    dims = image_dims(reader)
    if max_edge:
        size = reader.size()
        if size.isValid() and max(size.width(), size.height()) > max_edge:
            size.scale(max_edge, max_edge, Qt.AspectRatioMode.KeepAspectRatio)
            reader.setScaledSize(size)  # JPEGs decode at reduced size: fast
    img = reader.read()
    return img, reader.errorString(), dims


def read_image(path, max_edge=None, with_dims=False):
    """Decodes a photo. with_dims=True returns (image, (full width, full height))."""
    if is_remote(path):
        img, dims = _read_remote(path, max_edge)
        return (img, dims) if with_dims else img
    img, _err, dims = _read_local_file(path, max_edge)
    return (img, dims) if with_dims else img


_READS = {}
_READS_LOCK = threading.Lock()


def _fetch_shared(path):
    """Downloads a network/cloud photo. When the same photo is already being downloaded
    (e.g. the viewer was closed and opened again), waits for that download instead of
    starting a second one, so stuck or slow downloads never pile up."""
    with _READS_LOCK:
        job = _READS.get(path)
        owner = job is None
        if owner:
            job = {"done": threading.Event(), "data": None, "error": None}
            _READS[path] = job
    if owner:
        try:
            job["data"] = gio_read(path) if is_gvfs(path) else _remote_bytes(path)
        except Exception as e:
            job["error"] = e
        finally:
            job["done"].set()
            with _READS_LOCK:
                _READS.pop(path, None)
    else:
        alog("read shared", path)
        job["done"].wait(READ_TIMEOUT + 30)
    if job["error"] is not None:
        raise job["error"]
    if job["data"] is None:
        raise ServerTimeout("The photo did not arrive in time")
    return job["data"]


def _read_remote(path, max_edge=None):
    dims = (0, 0)
    try:
        data = _fetch_shared(path)
    except Exception as e:
        alog("read ERROR", path, error=str(e)[:120])
        return QImage(), dims
    return _decode_bytes(path, data, max_edge)


def _decode_bytes(path, data, max_edge=None):
    """Decodes downloaded photo bytes from a short-lived copy on the local disk, exactly the way
    local photos are opened. Returns (image, (full width, full height))."""
    dims = (0, 0)
    tmp_dir = os.path.join(os.path.dirname(LIST_CACHE_DIR), "tmp")
    tmp = os.path.join(tmp_dir, f"{threading.get_native_id()}-{hashlib.md5(path.encode()).hexdigest()}"
                                f"{os.path.splitext(path)[1].lower()}")
    try:
        os.makedirs(tmp_dir, exist_ok=True)
        with open(tmp, "wb") as f:
            f.write(data)
        img, err, dims = _read_local_file(tmp, max_edge)
    except OSError as e:
        img, err = QImage(), str(e)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    if img.isNull():
        img = QImage.fromData(data)  # second try, without rotation
        if not img.isNull():
            dims = (img.width(), img.height())
    if img.isNull() and PILImage is not None:
        img, pdims = _decode_with_pil(data, max_edge)  # third try: Pillow
        if not img.isNull():
            dims = pdims
    if img.isNull():
        alog("decode ERROR", path, bytes=len(data), error=err or "-", jpeg=jpeg_header_info(data))
    return img, dims


def _decode_with_pil(data, max_edge=None):
    try:
        import io
        from PIL import ImageOps
        pil = PILImage.open(io.BytesIO(data))
        pil = ImageOps.exif_transpose(pil)
        dims = pil.size
        if max_edge and max(pil.size) > max_edge:
            pil.thumbnail((max_edge, max_edge))
        pil = pil.convert("RGBA")
        raw = pil.tobytes("raw", "RGBA")
        img = QImage(raw, pil.width, pil.height, pil.width * 4, QImage.Format.Format_RGBA8888).copy()
        return img, dims
    except Exception as e:
        alog("pillow ERROR", "-", error=str(e)[:120])
        return QImage(), (0, 0)


def jpeg_header_info(data):
    """Short description of a JPEG's frame header (kind, bits, size, colour channels) for the log."""
    try:
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            m = data[i + 1]
            if m in (0xD8, 0x01, 0xFF) or 0xD0 <= m <= 0xD7:
                i += 1 if m == 0xFF else 2
                continue
            length = (data[i + 2] << 8) | data[i + 3]
            if 0xC0 <= m <= 0xCF and m not in (0xC4, 0xC8, 0xCC):
                bits = data[i + 4]
                h = (data[i + 5] << 8) | data[i + 6]
                w = (data[i + 7] << 8) | data[i + 8]
                return f"SOF{m - 0xC0}/{bits}bit/{w}x{h}/{data[i + 9]}ch"
            i += 2 + length
    except Exception:
        pass
    return "-"


def unique_path(folder, name):
    base, ext = os.path.splitext(name)
    cand, n = os.path.join(folder, name), 1
    while os.path.exists(cand):
        cand = os.path.join(folder, f"{base} ({n}){ext}")
        n += 1
    return cand


def move_to_trash(path):
    try:
        res = QFile_moveToTrash(path)
        if res:
            return True
    except Exception:
        pass
    try:
        return subprocess.run(["gio", "trash", path], timeout=20).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def QFile_moveToTrash(path):
    from PyQt6.QtCore import QFile
    res = QFile.moveToTrash(path)
    return res[0] if isinstance(res, tuple) else bool(res)


def exif_summary(path):
    """A few readable camera facts, if Pillow is installed."""
    if PILImage is None:
        return []
    try:
        with PILImage.open(path) as im:
            ex = im.getexif()
            if not ex:
                return []
            sub = ex.get_ifd(0x8769)
    except Exception:
        return []
    out = []
    make, model = str(ex.get(0x010F, "")).strip(), str(ex.get(0x0110, "")).strip()
    if model:
        out.append(("Camera", model if model.startswith(make) else f"{make} {model}".strip()))
    if sub.get(0xA434):
        out.append(("Lens", str(sub[0xA434]).strip()))
    taken = sub.get(0x9003) or ex.get(0x0132)
    if taken:
        out.append(("Taken", str(taken).replace(":", "-", 2)))
    try:
        if sub.get(0x829A):
            e = float(sub[0x829A])
            out.append(("Exposure", f"1/{round(1 / e)} s" if 0 < e < 1 else f"{e:g} s"))
        if sub.get(0x829D):
            out.append(("Aperture", f"f/{float(sub[0x829D]):.1f}"))
        if sub.get(0x8827):
            iso = sub[0x8827]
            out.append(("ISO", str(iso[0] if isinstance(iso, tuple) else iso)))
        if sub.get(0x920A):
            out.append(("Focal length", f"{float(sub[0x920A]):.0f} mm"))
    except (TypeError, ValueError, ZeroDivisionError):
        pass
    return out


# ---------------------------------------------------------------- photo "date taken" (EXIF)
_EXIF_DT = re.compile(rb"(\d{4})[:\-](\d\d)[:\-](\d\d)[ T](\d\d):(\d\d):(\d\d)")


def _parse_exif_dt(raw):
    m = _EXIF_DT.match(raw or b"")
    if not m:
        return None
    y, mo, d, h, mi, sec = (int(x) for x in m.groups())
    if y < 1900 or not (1 <= mo <= 12 and 1 <= d <= 31):
        return None
    try:
        return time.mktime((y, mo, d, h, mi, sec, 0, 0, -1))
    except (OverflowError, ValueError):
        return None


def _tiff_date(buf, base):
    """Date taken from a TIFF/EXIF block starting at `base` (DateTimeOriginal first)."""
    order = buf[base:base + 2]
    e = "<" if order == b"II" else ">" if order == b"MM" else None
    if e is None or base + 8 > len(buf):
        return None

    def entries(off):
        o, out = base + off, {}
        if off <= 0 or o + 2 > len(buf):
            return out
        n = struct.unpack_from(e + "H", buf, o)[0]
        for i in range(min(n, 400)):
            p = o + 2 + i * 12
            if p + 12 > len(buf):
                break
            tag, typ, cnt = struct.unpack_from(e + "HHI", buf, p)
            out[tag] = (typ, cnt, p + 8)
        return out

    def text(ent):
        typ, cnt, p = ent
        if typ != 2:
            return None
        if cnt > 4:
            p = base + struct.unpack_from(e + "I", buf, p)[0]
        return buf[p:p + min(cnt, 64)]

    try:
        ifd0 = entries(struct.unpack_from(e + "I", buf, base + 4)[0])
        found = []
        if 0x8769 in ifd0:
            sub = entries(struct.unpack_from(e + "I", buf, ifd0[0x8769][2])[0])
            found += [text(sub[t]) for t in (0x9003, 0x9004) if t in sub]
        if 0x0132 in ifd0:
            found.append(text(ifd0[0x0132]))
    except struct.error:
        return None
    for raw in found:
        ts = _parse_exif_dt(raw)
        if ts:
            return ts
    return None


def exif_date(path):
    """When the photo was taken, from its metadata. None if the file has no such date."""
    try:
        if is_gvfs(path):
            head = gio_read(path, 131072)
        else:
            with open(path, "rb") as f:
                head = f.read(131072)  # EXIF sits at the start; keeps network reads small
                if head[:4] in (b"II*\x00", b"MM\x00*"):  # TIFF and TIFF-based RAW files
                    head += f.read(786432)
    except Exception:
        return None
    if head[:2] == b"\xff\xd8":  # JPEG: walk the markers to the EXIF block
        i = 2
        while i + 4 <= len(head):
            if head[i] != 0xFF:
                break
            marker = head[i + 1]
            if marker == 0xFF:
                i += 1
                continue
            if marker in (0xD9, 0xDA):
                break
            if marker == 0x01 or 0xD0 <= marker <= 0xD7:
                i += 2
                continue
            length = struct.unpack_from(">H", head, i + 2)[0]
            if marker == 0xE1 and head[i + 4:i + 10] == b"Exif\x00\x00":
                return _tiff_date(head, i + 10)
            i += 2 + length
        return None
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return _tiff_date(head, 0)
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        pos = 8
        while pos + 8 <= len(head):
            length, typ = struct.unpack_from(">I4s", head, pos)
            if typ == b"eXIf":
                return _tiff_date(head, pos + 8)
            if typ == b"IDAT":
                break
            pos += 12 + length
        return None
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        pos = 12
        while pos + 8 <= len(head):
            typ, length = struct.unpack_from("<4sI", head, pos)
            if typ == b"EXIF":
                start = pos + 8
                if head[start:start + 6] == b"Exif\x00\x00":
                    start += 6
                return _tiff_date(head, start)
            pos += 8 + length + (length & 1)
        return None
    if PILImage is not None:  # other formats (e.g. HEIC with a plugin): let Pillow try
        try:
            with PILImage.open(path) as im:
                ex = im.getexif()
                raw = ex.get_ifd(0x8769).get(0x9003) or ex.get(0x0132)
                return _parse_exif_dt(str(raw).encode()) if raw else None
        except Exception:
            return None
    return None


DATE_CACHE_FILE = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                               "hansviewer", "dates.json")
_DATE_CACHE = None


def date_cache():
    global _DATE_CACHE
    if _DATE_CACHE is None:
        try:
            with open(DATE_CACHE_FILE) as f:
                _DATE_CACHE = json.load(f)
            if not isinstance(_DATE_CACHE, dict):
                _DATE_CACHE = {}
        except (OSError, ValueError):
            _DATE_CACHE = {}
    return _DATE_CACHE


def date_key(e):
    return f"{e['path']}\t{int(e['mtime'])}\t{e['size']}"


def save_date_cache():
    cache = date_cache()
    if len(cache) > 300000:
        cache.clear()
    try:
        os.makedirs(os.path.dirname(DATE_CACHE_FILE), exist_ok=True)
        tmp = DATE_CACHE_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cache, f)
        os.replace(tmp, DATE_CACHE_FILE)
    except OSError:
        pass


# ---------------------------------------------------------------- freedesktop thumbnail cache
def thumb_cache_file(path, folder=None):
    uri = bytes(QUrl.fromLocalFile(path).toEncoded()).decode()
    return uri, os.path.join(folder or CACHE_DIR, hashlib.md5(uri.encode()).hexdigest() + ".png")


def mtime_matches(stored, mtime, tolerant=False):
    """Whether a thumbnail's stored file date fits. [tolerant] (same NAS reached another way, e.g.
    AFP instead of SMB): a 2-second rounding difference or a whole-hour time-zone shift is fine."""
    try:
        d = abs(int(stored) - int(mtime))
    except (TypeError, ValueError):
        return False
    if d == 0:
        return True
    return tolerant and (d <= 2 or (d <= 14 * 3600 and min(d % 3600, 3600 - d % 3600) <= 2))


def _read_cached(cache, mtime, lenient=False, tolerant=False):
    """A stored thumbnail for this file version. [lenient]: accept it even if the file date differs
    (used while a remembered network list is being checked, so tiles don't go blank meanwhile)."""
    if not os.path.exists(cache):
        return None
    img = QImage()
    if img.load(cache) and (lenient or mtime_matches(img.text("Thumb::MTime"), mtime, tolerant)):
        try:
            w = int(img.text("Thumb::Image::Width") or 0)
            h = int(img.text("Thumb::Image::Height") or 0)
        except ValueError:
            w = h = 0
        return img, w, h
    return None


def _write_cached(img, cache, uri, mtime, w, h):
    try:
        os.makedirs(os.path.dirname(cache), mode=0o700, exist_ok=True)
        img.setText("Thumb::URI", uri)
        img.setText("Thumb::MTime", str(int(mtime)))
        img.setText("Thumb::Image::Width", str(w))
        img.setText("Thumb::Image::Height", str(h))
        img.setText("Software", f"{APP} {VERSION}")
        tmp = f"{cache}.{os.getpid()}.tmp"
        if img.save(tmp, "PNG"):
            os.replace(tmp, cache)
    except OSError:
        pass


def video_length(path, timeout=30):
    """A video's length in seconds (ffprobe, from the ffmpeg package), or 0 if unknown."""
    if not shutil.which("ffprobe"):
        return 0
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "csv=p=0", path], capture_output=True, text=True, timeout=timeout)
        return int(float(r.stdout.strip().splitlines()[0])) if r.returncode == 0 and r.stdout.strip() else 0
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        return 0


def video_frame(path, timeout=60):
    """A still picture from a video (ffmpegthumbnailer, or ffmpeg), as a QImage."""
    tmp = os.path.join(os.path.dirname(LIST_CACHE_DIR), f"vthumb-{threading.get_native_id()}.png")
    os.makedirs(os.path.dirname(tmp), exist_ok=True)
    cmds = []
    if shutil.which("ffmpegthumbnailer"):
        cmds.append(["ffmpegthumbnailer", "-i", path, "-o", tmp, "-s", str(THUMB_MAX), "-t", "10%", "-q", "8"])
    if shutil.which("ffmpeg"):
        cmds.append(["ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", "1", "-i", path, "-frames:v", "1",
                     "-vf", f"scale={THUMB_MAX}:-2", tmp])
    img = QImage()
    for cmd in cmds:
        try:
            if subprocess.run(cmd, capture_output=True, timeout=timeout).returncode == 0 and img.load(tmp):
                break
        except (OSError, subprocess.SubprocessError):
            pass
    try:
        os.remove(tmp)
    except OSError:
        pass
    return img


def alt_cached(path, mtime, lenient=False):
    """A thumbnail stored for the same photo under another connection (SMB, AFP, WebDAV); the
    file date must match, so different photos with the same name are not mixed up."""
    for alt in thumb_alternatives(path):
        for folder in (CACHE_DIR, CACHE_DIR_NORMAL):
            hit = _read_cached(thumb_cache_file(alt, folder)[1], mtime, lenient, tolerant=True)
            if hit:
                return hit
    return None


def video_thumbnail(path, mtime, use_cache=True, cache_only=False, source=None, remote=False, lenient=False):
    """Thumbnail of a video, shared with the file manager's thumbnail folder. [source] can be a
    downloaded copy of a network video. The length is kept in the thumbnail (Thumb::Movie::Length)."""
    uri, cache = thumb_cache_file(path)
    _, cache_small = thumb_cache_file(path, CACHE_DIR_NORMAL)
    if use_cache:
        for c in (cache, cache_small):
            if os.path.exists(c):
                img = QImage()
                if img.load(c) and (lenient or img.text("Thumb::MTime") == str(int(mtime))):
                    if not img.text("Thumb::Movie::Length") and not remote and not cache_only:
                        length = video_length(source or path)
                        if length:
                            img.setText("Thumb::Movie::Length", str(length))
                            tmp = f"{c}.{os.getpid()}.tmp"
                            if img.save(tmp, "PNG"):
                                os.replace(tmp, c)
                    return img, 0, 0
        if remote:
            hit = alt_cached(path, mtime, lenient)
            if hit:
                return hit[0], 0, 0
    if cache_only:
        return QImage(), -1, -1
    src = source or path
    img = video_frame(src, timeout=120 if remote and not source else 60)
    if img.isNull():
        return img, 0, 0
    length = video_length(src, timeout=60 if remote and not source else 30)
    if length:
        img.setText("Thumb::Movie::Length", str(length))
    if use_cache:
        _write_cached(img, cache, uri, mtime, 0, 0)
    return img, 0, 0


def fmt_length(secs):
    try:
        secs = int(secs)
    except (TypeError, ValueError):
        return ""
    if secs <= 0:
        return ""
    h, rest = divmod(secs, 3600)
    m, s = divmod(rest, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def exif_preview(path, limit=65536):
    """The small preview JPEG that cameras and phones embed in a photo. Usually it is inside the
    first 64 KB; only if not, a bit more is read (up to 512 KB).
    Returns (jpeg_bytes or None, orientation, width, height)."""
    try:
        head = read_head(path, limit)
    except Exception:
        return None, 1, 0, 0
    data, orientation, w, h, need = exif_preview_from(head)
    if data is None and len(head) >= limit:
        more = need + 4096 if need else 196608
        if limit < more <= 524288:
            try:
                head = read_head(path, more)
            except Exception:
                return None, orientation, w, h
            data, orientation, w, h, _need = exif_preview_from(head)
    return data, orientation, w, h


def exif_preview_from(head):
    """Finds the embedded preview in the start of a photo:
    (jpeg_bytes or None, orientation, width, height, bytes needed if `head` was too short)."""
    if head[:2] != b"\xff\xd8":
        return None, 1, 0, 0, 0
    i, base = 2, None
    while i + 4 <= len(head):
        if head[i] != 0xFF:
            break
        marker = head[i + 1]
        if marker in (0xD9, 0xDA):
            break
        length = struct.unpack_from(">H", head, i + 2)[0]
        if marker == 0xE1 and head[i + 4:i + 10] == b"Exif\x00\x00":
            base = i + 10
            break
        i += 2 + length
    if base is None:
        return None, 1, 0, 0, (i + 4 if i + 4 > len(head) else 0)
    order = head[base:base + 2]
    e = "<" if order == b"II" else ">" if order == b"MM" else None
    if e is None:
        return None, 1, 0, 0, 0

    def ifd(off):
        out, o = {}, base + off
        if off <= 0 or o + 2 > len(head):
            return out, 0
        n = struct.unpack_from(e + "H", head, o)[0]
        for k in range(min(n, 300)):
            q = o + 2 + k * 12
            if q + 12 > len(head):
                return out, 0
            tag, typ = struct.unpack_from(e + "HH", head, q)
            val = struct.unpack_from(e + ("H" if typ == 3 else "I"), head, q + 8)[0]
            out[tag] = val
        nxt = o + 2 + n * 12
        return out, (struct.unpack_from(e + "I", head, nxt)[0] if nxt + 4 <= len(head) else 0)

    try:
        ifd0, ifd1_off = ifd(struct.unpack_from(e + "I", head, base + 4)[0])
        orientation = ifd0.get(0x0112, 1)
        w = h = 0
        if 0x8769 in ifd0:
            sub, _ = ifd(ifd0[0x8769])
            w, h = sub.get(0xA002, 0), sub.get(0xA003, 0)
        ifd1, _ = ifd(ifd1_off)
        off, length = ifd1.get(0x0201), ifd1.get(0x0202)
    except struct.error:
        return None, 1, 0, 0, 0
    if not off or not length:
        return None, orientation, w, h, 0
    if base + off + length > len(head):
        return None, orientation, w, h, base + off + length
    data = head[base + off:base + off + length]
    return (data if data[:2] == b"\xff\xd8" else None), orientation, w, h, 0


def orient_qimage(img, orientation):
    """Turns an image the way the EXIF orientation tag says."""
    t = QTransform()
    if orientation in (3, 4):
        t.rotate(180)
    elif orientation in (5, 6):
        t.rotate(90)
    elif orientation in (7, 8):
        t.rotate(270)
    if orientation in (3, 4, 5, 6, 7, 8):
        img = img.transformed(t)
    if orientation in (2, 4, 5, 7):
        img = flip_qimage(img, True)
    return img


def cache_valid(path, mtime):
    """True if a stored thumbnail for this exact file version exists (reads the PNG header only)."""
    for folder in (CACHE_DIR, CACHE_DIR_NORMAL):
        _, cache = thumb_cache_file(path, folder)
        if os.path.exists(cache):
            r = QImageReader(cache)
            if r.text("Thumb::MTime") == str(int(mtime)):
                return True
    for alt in thumb_alternatives(path):    # made for the same photo under another connection
        for folder in (CACHE_DIR, CACHE_DIR_NORMAL):
            _, cache = thumb_cache_file(alt, folder)
            if os.path.exists(cache) and mtime_matches(QImageReader(cache).text("Thumb::MTime"), mtime, True):
                return True
    return False


def thumb_from_image(path, mtime, image, use_cache=True):
    """Makes and stores a thumbnail from a photo that is already decoded (e.g. in the viewer)."""
    if image.isNull():
        return image, 0, 0
    w, h = image.width(), image.height()
    thumb = image if max(w, h) <= THUMB_MAX else image.scaled(
        THUMB_MAX, THUMB_MAX, Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation)
    if use_cache:
        uri, cache = thumb_cache_file(path)
        _write_cached(thumb, cache, uri, mtime, w, h)
    return thumb, w, h


def preview_thumbnail(path, mtime, use_cache=True):
    """The quick way for network photos: only the first ~190 KB are read and the preview the
    camera embedded is used. Returns (QImage, width, height), or None if there is no preview."""
    data, orientation, w, h = exif_preview(path)
    if not data:
        return None
    img = QImage.fromData(data, "JPEG")
    if img.isNull():
        return None
    img = orient_qimage(img, orientation)
    if orientation in (5, 6, 7, 8):
        w, h = h, w
    if max(img.width(), img.height()) > 128:
        img = img.scaled(128, 128, Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    if use_cache:
        uri, cache_small = thumb_cache_file(path, CACHE_DIR_NORMAL)
        _write_cached(img, cache_small, uri, mtime, w, h)
    return img, w, h


def make_thumbnail(path, mtime, use_cache=True, remote=False, cache_only=False, lenient=False):
    """Returns (QImage, width, height). Shares ~/.cache/thumbnails with the file manager.
    Network files first try the small preview embedded in the photo, which is much faster
    than reading the whole file."""
    if is_video(path):
        return video_thumbnail(path, mtime, use_cache, cache_only, remote=remote, lenient=lenient)
    uri, cache = thumb_cache_file(path)
    _, cache_small = thumb_cache_file(path, CACHE_DIR_NORMAL)
    if use_cache:
        hit = _read_cached(cache, mtime, lenient) or (_read_cached(cache_small, mtime, lenient) if remote else None)
        if not hit and remote:
            hit = alt_cached(path, mtime, lenient)
        if hit:
            return hit
    if cache_only:  # on-demand folder: never read the photo itself here
        return QImage(), -1, -1
    if remote:
        hit = preview_thumbnail(path, mtime, use_cache)
        if hit:
            return hit
    if remote or is_remote(path):
        img, (w, h) = read_image(path, THUMB_MAX, with_dims=True)
        if img.isNull():
            return img, 0, 0
        if use_cache:
            _write_cached(img, cache, uri, mtime, w, h)
        return img, w, h
    reader, buf = _reader_for(path)
    if reader is None:
        return QImage(), 0, 0
    reader.setAutoTransform(True)
    w, h = image_dims(reader)
    size = reader.size()
    if size.isValid() and max(size.width(), size.height()) > THUMB_MAX:
        size.scale(THUMB_MAX, THUMB_MAX, Qt.AspectRatioMode.KeepAspectRatio)
        reader.setScaledSize(size)
    img = reader.read()
    if buf is not None:
        buf.close()
    if img.isNull():
        return img, 0, 0
    if use_cache and not path.startswith(os.path.dirname(CACHE_DIR)):
        _write_cached(img, cache, uri, mtime, w, h)
    return img, w, h


# ---------------------------------------------------------------- saving & editing
PIL_FORMATS = {"jpeg": "JPEG", "png": "PNG", "webp": "WEBP", "tiff": "TIFF", "bmp": "BMP"}


def norm_format(path):
    ext = os.path.splitext(path)[1][1:].lower()
    return {"jpg": "jpeg", "jpe": "jpeg", "tif": "tiff"}.get(ext, ext)


def can_write(path):
    fmt = norm_format(path)
    writable = {bytes(f).decode().lower() for f in QImageWriter.supportedImageFormats()}
    return fmt in writable or (PILImage is not None and fmt in PIL_FORMATS)


def qimage_to_pil(img):
    has_alpha = img.hasAlphaChannel()
    img = img.convertToFormat(QImage.Format.Format_RGBA8888)
    ptr = img.constBits()
    ptr.setsize(img.sizeInBytes())
    pil = PILImage.frombuffer("RGBA", (img.width(), img.height()), bytes(ptr),
                              "raw", "RGBA", img.bytesPerLine(), 1)
    return pil if has_alpha else pil.convert("RGB")


def save_image(img, dest, src=None, quality=None, strip_gps=False):
    """Save atomically. With Pillow, camera EXIF from `src` is kept (orientation reset);
    `strip_gps` leaves out the location (GPS) where the photo was taken."""
    quality = quality or setting("jpeg_quality", 92, int)
    fmt = norm_format(dest)
    tmp = f"{dest}.{os.getpid()}.acdtmp"
    ok = False
    if PILImage is not None and fmt in PIL_FORMATS:
        try:
            pil = qimage_to_pil(img)
            kw = {}
            if fmt in ("jpeg", "webp"):
                kw["quality"] = quality
            if src and os.path.exists(src) and fmt in ("jpeg", "webp", "png", "tiff"):
                try:
                    with PILImage.open(src) as orig:
                        exif = orig.getexif()
                        if exif:
                            exif[0x0112] = 1  # pixels are already upright
                            if strip_gps and 0x8825 in exif:
                                del exif[0x8825]
                            kw["exif"] = exif.tobytes()
                except Exception:
                    pass
            if fmt == "jpeg" and pil.mode != "RGB":
                pil = pil.convert("RGB")
            pil.save(tmp, format=PIL_FORMATS[fmt], **kw)
            ok = True
        except Exception:
            ok = False
    if not ok:
        out = img
        if fmt == "jpeg" and img.hasAlphaChannel():
            out = img.convertToFormat(QImage.Format.Format_RGB32)
        ok = out.save(tmp, fmt, quality if fmt in ("jpeg", "webp") else -1)
    if ok:
        os.replace(tmp, dest)
    elif os.path.exists(tmp):
        os.remove(tmp)
    return ok


def blur_region(img, rect, mode="blur", strength=50):
    """Blurs or pixelates one rectangle of the photo (e.g. a number plate or a face).
    strength 1–100 is relative to the size of the area, so small and large areas look alike."""
    r = QRectF(rect).toAlignedRect().intersected(img.rect())
    if r.width() < 2 or r.height() < 2:
        return img
    out = img.convertToFormat(QImage.Format.Format_ARGB32) if img.hasAlphaChannel() \
        else img.convertToFormat(QImage.Format.Format_RGB32)
    part = out.copy(r)
    short = min(r.width(), r.height())
    block = max(2.0, short * (0.04 + 0.36 * max(1, min(100, strength)) / 100.0))
    sw, sh = max(1, round(r.width() / block)), max(1, round(r.height() / block))
    if mode == "pixelate":
        small = part.scaled(sw, sh, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
        part = small.scaled(r.width(), r.height(), Qt.AspectRatioMode.IgnoreAspectRatio,
                            Qt.TransformationMode.FastTransformation)
    else:
        for k in range(3):   # repeated down/up scaling gives a soft blur with no detail left
            f = 1.0 + 0.35 * k
            small = part.scaled(max(1, round(sw * f)), max(1, round(sh * f)),
                                Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
            part = small.scaled(r.width(), r.height(), Qt.AspectRatioMode.IgnoreAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
    p = QPainter(out)
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source)
    p.drawImage(r.topLeft(), part)
    p.end()
    return out


def rotate_qimage(img, degrees):
    return img.transformed(QTransform().rotate(degrees))


def flip_qimage(img, horizontal):
    flipped = getattr(img, "flipped", None)
    if flipped is not None:
        return flipped(Qt.Orientation.Horizontal if horizontal else Qt.Orientation.Vertical)
    return img.mirrored(horizontal, not horizontal)


def rotate_file(path, degrees):
    img = read_image(path)
    if img.isNull() or not can_write(path):
        return False
    return save_image(rotate_qimage(img, degrees), path, src=path, quality=95)


def to_array(img):
    img = img.convertToFormat(QImage.Format.Format_RGBA8888)
    w, h = img.width(), img.height()
    ptr = img.constBits()
    ptr.setsize(img.sizeInBytes())
    arr = np.frombuffer(ptr, np.uint8).reshape(h, img.bytesPerLine())[:, :w * 4]
    return arr.reshape(h, w, 4).copy()


def from_array(arr):
    arr = np.ascontiguousarray(arr, dtype=np.uint8)
    h, w = arr.shape[:2]
    return QImage(arr.tobytes(), w, h, w * 4, QImage.Format.Format_RGBA8888).copy()


def adjust_image(img, brightness=0, contrast=0, saturation=0, warmth=0):
    """All values -100..100. Needs numpy."""
    if np is None or not any((brightness, contrast, saturation, warmth)):
        return img
    arr = to_array(img)
    rgb = arr[..., :3].astype(np.float32)
    if saturation:
        gray = (rgb @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
        rgb = gray + (rgb - gray) * (1 + saturation / 100.0)
    if contrast:
        c = contrast * 2.55
        f = (259 * (c + 255)) / (255 * (259 - c))
        rgb = (rgb - 128) * f + 128
    if brightness:
        rgb += brightness * 1.5
    if warmth:
        rgb[..., 0] += warmth * 0.5
        rgb[..., 2] -= warmth * 0.5
    arr[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    return from_array(arr)


def filter_image(img, name):
    if name == "grayscale" and np is None:
        fmt = QImage.Format.Format_ARGB32 if img.hasAlphaChannel() else QImage.Format.Format_RGB32
        return img.convertToFormat(QImage.Format.Format_Grayscale8).convertToFormat(fmt)
    if np is None:
        return img
    arr = to_array(img)
    rgb = arr[..., :3].astype(np.float32)
    if name == "grayscale":
        g = rgb @ np.array([0.299, 0.587, 0.114], np.float32)
        rgb = np.repeat(g[..., None], 3, axis=2)
    elif name == "sepia":
        m = np.array([[0.393, 0.769, 0.189], [0.349, 0.686, 0.168], [0.272, 0.534, 0.131]],
                     np.float32)
        rgb = rgb @ m.T
    elif name == "autolevels":
        lo = np.percentile(rgb, 0.5, axis=(0, 1))
        hi = np.percentile(rgb, 99.5, axis=(0, 1))
        rgb = (rgb - lo) * (255.0 / np.maximum(hi - lo, 1))
    elif name == "sharpen":
        p = np.pad(rgb, ((1, 1), (1, 1), (0, 0)), mode="edge")
        blur = sum(p[dy:dy + rgb.shape[0], dx:dx + rgb.shape[1]]
                   for dy in range(3) for dx in range(3)) / 9.0
        rgb = rgb + 0.8 * (rgb - blur)
    elif name == "invert":
        rgb = 255 - rgb
    arr[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    return from_array(arr)


# ---------------------------------------------------------------- drives & places
CLOUD_SCHEMES = ("google-drive", "onedrive")


def gvfs_label(name):
    """'smb-share:server=nas,share=photos' -> 'photos on nas'."""
    if ":" not in name:
        return name
    scheme, _, rest = name.partition(":")
    kv = dict(p.split("=", 1) for p in rest.split(",") if "=" in p)
    host = kv.get("server") or kv.get("host") or scheme
    share = kv.get("share") or urllib.parse.unquote(kv.get("prefix", "")).strip("/")
    user = kv.get("user", "")
    if scheme == "google-drive":
        return f"Google Drive ({user}@{host})" if user else "Google Drive"
    if scheme == "onedrive":
        return f"OneDrive ({user})" if user else "OneDrive"
    if scheme == "smb-share":
        return f"{share} on {host}" if share else host
    if scheme in ("sftp", "ftp", "dav", "davs"):
        kind = {"sftp": "SFTP", "ftp": "FTP", "dav": "WebDAV", "davs": "WebDAV"}[scheme]
        return f"{share} on {host} ({kind})" if share else f"{host} ({kind})"
    return f"{share} on {host}" if share else host


_MOUNTS = {"time": 0.0, "rows": []}


def _unescape_mount(text):
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), text)


def mount_table(force=False):
    """(mount point, filesystem type) from /proc/self/mounts, longest path first.
    Reading this never touches the drives themselves, so a slow network drive can't block it."""
    now = time.monotonic()
    if force or now - _MOUNTS["time"] > 2:
        rows = []
        try:
            with open("/proc/self/mounts") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 3:
                        rows.append((_unescape_mount(parts[1]), parts[2]))
        except OSError:
            pass
        rows.sort(key=lambda r: len(r[0]), reverse=True)
        _MOUNTS["rows"], _MOUNTS["time"] = rows, now
    return _MOUNTS["rows"]


def mount_of(path):
    for mount, fs in mount_table():
        if path == mount or path.startswith(mount.rstrip("/") + "/"):
            return mount, fs
    return "/", ""


def is_mounted(path, force=False):
    path = path.rstrip("/") or "/"
    return any(m == path for m, _ in mount_table(force))


def is_remote(path):
    """True for network shares and cloud drives, where file access can be slow."""
    if path.startswith(f"/run/user/{os.getuid()}/gvfs/"):
        return True
    _, fs = mount_of(path)
    return fs in NET_FS or fs.startswith("fuse.rclone") or fs == "fuse.gvfsd-fuse"


LAZY_GVFS = ("dav", "davs", "ftp", "sftp", "google-drive", "onedrive")


def is_lazy(path):
    """WebDAV, FTP, SFTP and cloud drives: thumbnails are only made when a photo is viewed
    (or by "Make thumbnails"), because reading every photo over the internet is far too slow.
    SMB shares keep making thumbnails while browsing."""
    root = f"/run/user/{os.getuid()}/gvfs/"
    if path.startswith(root):
        return path[len(root):].split(":", 1)[0] in LAZY_GVFS
    _, fs = mount_of(path)
    return fs.startswith("fuse.rclone") or fs in ("fuse.sshfs", "sshfs", "davfs")


def list_devices():
    """(label, path, kind) for the home folder, disks, USB, network shares and cloud drives."""
    places = [("Home", os.path.expanduser("~"), "home"), ("Computer", "/", "hd")]
    vols, seen = [], set()
    for root, fs in mount_table():
        if root in seen or root == "/":
            continue
        if fs in NET_FS and "gvfs" not in root:
            seen.add(root)
            kind = "cloud" if fs.startswith("fuse.rclone") else "net"
            vols.append((os.path.basename(root) or root, root, kind))
        elif root.startswith(("/media/", "/run/media/", "/mnt/")) and not fs.startswith("fuse.gvfs"):
            seen.add(root)
            vols.append((os.path.basename(root) or root, root, "hd"))
    places += sorted(vols, key=lambda p: p[0].lower())
    gvfs = f"/run/user/{os.getuid()}/gvfs"
    t0 = time.monotonic()
    try:
        names = sorted(os.listdir(gvfs))  # the GVFS helper answers this itself, no network
    except OSError:
        names = []
    if time.monotonic() - t0 > 0.5:
        alog("SLOW drive list", gvfs, took=f"{time.monotonic() - t0:.2f}s")
    for name in names:
        kind = "cloud" if name.split(":", 1)[0] in CLOUD_SCHEMES else "net"
        places.append((gvfs_label(name), os.path.join(gvfs, name), kind))
    return places


_FREEZE = {}


def start_freeze_watch(app):
    """If the window ever stops responding for 8 seconds, writes what every part of HansViewer
    was doing at that moment to ~/.cache/hansviewer/freeze.log (also on a hard crash)."""
    try:
        import faulthandler
        path = os.path.join(os.path.dirname(ACTIVITY_LOG), "freeze.log")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > 1_000_000:
            os.replace(path, path + ".old")
        f = open(path, "a")
        f.write(f"\n=== HansViewer {VERSION} started {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.flush()
        faulthandler.enable(file=f)

        def arm():
            faulthandler.dump_traceback_later(8, repeat=False, file=f)

        timer = QTimer(app)
        timer.timeout.connect(arm)
        timer.start(2000)
        arm()
        _FREEZE.update(file=f, timer=timer)
    except Exception:
        pass


def drive_key(path):
    """Identifies the drive a path is on, so each drive can have its own worker threads."""
    root = f"/run/user/{os.getuid()}/gvfs/"
    if path.startswith(root):
        return root + path[len(root):].split("/", 1)[0]
    return mount_of(path)[0]


_DRIVE_POOLS = {}


def drive_pool(kind, path, threads=3):
    """A small thread pool per drive and job kind: a slow drive can't hold up another one."""
    key = (kind, drive_key(path))
    pool = _DRIVE_POOLS.get(key)
    if pool is None:
        pool = QThreadPool()
        pool.setMaxThreadCount(threads)
        _DRIVE_POOLS[key] = pool
    if is_remote(path):
        alog(f"queue {kind}", path, busy=f"{pool.activeThreadCount()}/{pool.maxThreadCount()}")
    return pool


def remote_reachable(path):
    """Whether the network/cloud drive holding `path` is connected, without touching it."""
    root = gvfs_root() + "/"
    if path.startswith(root):
        try:
            return path[len(root):].split("/", 1)[0] in os.listdir(gvfs_root())
        except OSError:
            return False
    mount, fs = mount_of(path)
    return mount != "/" and (fs in NET_FS or fs.startswith("fuse.rclone"))


# ------------------------------------------------- one NAS, several ways to connect (SMB / AFP)
def gvfs_info(path):
    """For a path under /run/user/…/gvfs: (mount name, scheme, {key: value}, rest), else None."""
    root = gvfs_root() + "/"
    if not path.startswith(root):
        return None
    name, _, rest = path[len(root):].partition("/")
    scheme, _, params = name.partition(":")
    kv = {}
    for part in params.split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            kv[k.lower()] = v
    return name, scheme, kv, rest


_HOST_IPS, _HOST_LOCK = {}, threading.Lock()


def host_ips(host):
    """The addresses of a NAS name (e.g. MNL-DS720.local), remembered; at most ~3 s the first time."""
    host = host.lower()
    with _HOST_LOCK:
        if host in _HOST_IPS:
            return _HOST_IPS[host]
    if re.fullmatch(r"[0-9.]+|[0-9a-f:]+", host):
        ips = {host}
    else:
        box = {}

        def look():
            try:
                box["ips"] = {a[4][0] for a in socket.getaddrinfo(host, None)}
            except OSError:
                box["ips"] = set()
        t = threading.Thread(target=look, daemon=True)
        t.start()
        t.join(3)
        ips = box.get("ips", set())
    with _HOST_LOCK:
        _HOST_IPS[host] = ips
    return ips


def same_host(a, b):
    a, b = a.lower(), b.lower()
    if a == b or a.removesuffix(".local") == b.removesuffix(".local"):
        return True
    return bool(host_ips(a) & host_ips(b))


NAS_SCHEMES = ("smb-share", "afp-volume")
THUMB_SCHEMES = ("smb-share", "afp-volume", "dav")
_THUMB_NAMES = {"names": frozenset(), "found": None, "running": False}


def _find_thumb_names():
    """Once every few days, in the background: which network connections the saved thumbnails
    belong to (from the address stored inside each thumbnail)."""
    found, root = set(), gvfs_root() + "/"
    for folder in (CACHE_DIR, CACHE_DIR_NORMAL):
        try:
            names = os.listdir(folder)
        except OSError:
            continue
        for n in names:
            if not n.endswith(".png"):
                continue
            try:
                uri = QImageReader(os.path.join(folder, n)).text("Thumb::URI")
            except Exception:
                continue
            p = urllib.parse.unquote(uri[7:]) if uri.startswith("file://") else ""
            if p.startswith(root):
                name = p[len(root):].split("/", 1)[0]
                if name.partition(":")[0] in THUMB_SCHEMES:
                    found.add(name)
    alog("thumb-names", "", found=len(found))
    _THUMB_NAMES["found"] = found
    _THUMB_NAMES["running"] = False


def share_key(path):
    """(share, path inside the share) of a file on SMB, AFP or WebDAV, e.g. ("photo", "Pictures/a.jpg")."""
    info = gvfs_info(path)
    if not info or info[1] not in THUMB_SCHEMES:
        return None
    name, scheme, kv, rest = info
    if scheme == "dav":
        prefix = urllib.parse.unquote(kv.get("prefix", "")).strip("/")
        full = f"{prefix}/{rest}" if prefix else rest
        share, _, inner = full.partition("/")
    else:
        share, inner = kv.get("share") or kv.get("volume") or "", rest
    return (share, inner) if share and inner else None


def _path_in(name, share, inner):
    """The same file under another connection `name`, or None if that connection has another share."""
    scheme, _, params = name.partition(":")
    kv = dict(p.split("=", 1) for p in params.split(",") if "=" in p)
    root = gvfs_root()
    if scheme in NAS_SCHEMES:
        if (kv.get("share") or kv.get("volume") or "").lower() != share.lower():
            return None
        return os.path.join(root, name, inner)
    if scheme == "dav":
        prefix = urllib.parse.unquote(kv.get("prefix", "")).strip("/")
        full = f"{share}/{inner}"
        if prefix:
            if not full.lower().startswith(prefix.lower() + "/"):
                return None
            full = full[len(prefix) + 1:]
        return os.path.join(root, name, full)
    return None


def thumb_alternatives(path):
    """The same photo (same share, folders and name) under the other connections that have
    thumbnails: e.g. your external NAS by WebDAV and the local NAS by SMB, when they hold copies."""
    key = share_key(path)
    if not key:
        return []
    own = gvfs_info(path)[0]
    out = []
    for name in sorted(_THUMB_NAMES["names"] | _mounted_names()):
        if name != own:
            alt = _path_in(name, *key)
            if alt:
                out.append(alt)
    return out


def _nas_key(name):
    """(host, share) of an SMB or AFP mount name, else None."""
    scheme, _, params = name.partition(":")
    if scheme not in NAS_SCHEMES:
        return None
    kv = dict(p.split("=", 1) for p in params.split(",") if "=" in p)
    host = kv.get("server") or kv.get("host") or ""
    share = kv.get("share") or kv.get("volume") or ""
    return (host.lower(), share.lower()) if host and share else None


_NAS_STATE = {"names": frozenset(), "servers": []}   # read by worker threads, set by the window


def refresh_nas_state():
    """Remembers the SMB/AFP connections seen and the saved servers (call from the window), so
    worker threads never need the settings file and connections can be recognised later."""
    try:
        mounted = [n for n in os.listdir(gvfs_root()) if n.partition(":")[0] in THUMB_SCHEMES]
    except OSError:
        mounted = []
    known = setting("known_mounts", [], list)
    new = [n for n in mounted if n not in known]
    if new:
        known = (known + new)[-40:]
        settings().setValue("known_mounts", known)
    names = set(known)
    for f in setting("favourites", [], list) + [setting("last_folder", "", str)]:
        info = gvfs_info(str(f))
        if info:
            names.add(info[0])
    servers = saved_servers()
    for srv in servers:
        if srv.get("scheme") == "smb" and srv.get("host") and srv.get("share"):
            names.add(f"smb-share:server={srv['host'].lower()},share={srv['share'].lower()}")
    if _THUMB_NAMES["found"] is not None:            # the background look-up has finished
        settings().setValue("thumb_names", sorted(_THUMB_NAMES["found"]))
        settings().setValue("thumb_names_time", int(time.time()))
        _THUMB_NAMES["found"] = None
    _THUMB_NAMES["names"] = frozenset(setting("thumb_names", [], list)) | names
    if not _THUMB_NAMES["running"] and time.time() - setting("thumb_names_time", 0, int) > 3 * 86400:
        _THUMB_NAMES["running"] = True
        threading.Thread(target=_find_thumb_names, name="thumb-names", daemon=True).start()
    _NAS_STATE["names"] = frozenset(names)
    _NAS_STATE["servers"] = servers
    _MOUNTED["t"] = 0.0          # look at the connections again


_ALT_CACHE, _ALT_LOCK = {}, threading.Lock()


_MOUNTED = {"t": 0.0, "names": frozenset()}


def _mounted_names():
    """The GVFS connections right now (looked up at most every 5 seconds)."""
    if time.monotonic() - _MOUNTED["t"] > 5:
        try:
            _MOUNTED["names"] = frozenset(os.listdir(gvfs_root()))
        except OSError:
            _MOUNTED["names"] = frozenset()
        _MOUNTED["t"] = time.monotonic()
    return _MOUNTED["names"]


def nas_alt_names(name):
    """Other mount names that reach the same share on the same NAS (SMB ↔ AFP, name ↔ address)."""
    me = _nas_key(name)
    if me is None:
        return []
    cands = set(_NAS_STATE["names"]) | _mounted_names()
    cands.discard(name)
    key = (name, frozenset(cands))
    with _ALT_LOCK:
        if key in _ALT_CACHE:
            return _ALT_CACHE[key]
    out = []
    for c in sorted(cands):
        k = _nas_key(c)
        if k and k[1] == me[1] and same_host(k[0], me[0]):
            out.append(c)
    with _ALT_LOCK:
        _ALT_CACHE[key] = out
    return out


def nas_alternatives(path):
    """The same file or folder under the NAS's other connections."""
    info = gvfs_info(path)
    if not info or info[1] not in NAS_SCHEMES:
        return []
    root = gvfs_root()
    return [os.path.join(root, n, info[3]) if info[3] else os.path.join(root, n)
            for n in nas_alt_names(info[0])]


def live_alternative(path):
    """If the NAS of `path` is connected another way (e.g. AFP instead of SMB): that path."""
    for alt in nas_alternatives(path):
        if remote_reachable(alt):
            return alt
    return None


# ------------------------------------------------- direct WebDAV reads (thumbnails)
_DAV_AUTH, _DAV_LOCK = {}, threading.Lock()
_DAV_LOCAL = threading.local()


def _gnome_keyring_login(protocol, host):
    """A login that the file manager saved ("Remember forever"): (user, password) or None."""
    if not keyring_available():
        return None
    try:
        r = subprocess.run(["secret-tool", "search", "--all", "--unlock", "protocol", protocol,
                            "server", host], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    user = secret = None
    for line in (r.stdout + "\n" + r.stderr).splitlines():
        line = line.strip()
        if line.startswith("attribute.user = "):
            user = line.split("= ", 1)[1]
        elif line.startswith("secret = "):
            secret = line.split("= ", 1)[1]
        if user and secret:
            return user, secret
    return None


def dav_login(name, kv):
    """(host, port, ssl, prefix, auth header) for a WebDAV mount, or None if no saved login."""
    with _DAV_LOCK:
        if name in _DAV_AUTH:
            return _DAV_AUTH[name]
    host = kv.get("host", "")
    use_ssl = kv.get("ssl") == "true"
    port = int(kv.get("port") or (443 if use_ssl else 80))
    prefix = urllib.parse.unquote(kv.get("prefix", "")).rstrip("/")
    login = None
    for srv in _NAS_STATE["servers"]:
        if srv.get("scheme") not in ("dav", "davs"):
            continue
        h, _, p = srv.get("host", "").lower().partition(":")
        if h != host.lower() or (p and int(p) != port):
            continue
        user = srv.get("user", "")
        pw = keyring_lookup(server_uri(srv["scheme"], srv["host"], srv.get("share", "")), user) \
            if srv.get("remember") else None
        if user and pw is not None:
            login = (user, pw)
            break
    if login is None:
        login = _gnome_keyring_login("davs" if use_ssl else "dav", host)
    result = None
    if login:
        token = base64.b64encode(f"{login[0]}:{login[1]}".encode()).decode()
        result = (host, port, use_ssl, prefix, "Basic " + token)
    with _DAV_LOCK:
        _DAV_AUTH[name] = result
    return result


def dav_direct_possible(path):
    info = gvfs_info(path)
    return bool(info and info[1] == "dav" and dav_login(info[0], info[2]))


def dav_head(path, limit):
    """Reads the first `limit` bytes of a file on a WebDAV mount straight from the server
    (one small request on a kept-open connection, much quicker than through GVFS).
    Returns the bytes, or None to fall back to the usual way."""
    info = gvfs_info(path)
    if not info or info[1] != "dav":
        return None
    login = dav_login(info[0], info[2])
    if not login:
        return None
    host, port, use_ssl, prefix, auth = login
    conns = getattr(_DAV_LOCAL, "conns", None)
    if conns is None:
        conns = _DAV_LOCAL.conns = {}
    url = urllib.parse.quote(f"{prefix}/{info[3]}")
    t0 = time.monotonic()
    for attempt in (1, 2):                    # once more on a fresh connection if it was closed
        conn = conns.get(info[0])
        if conn is None:
            if use_ssl:
                conn = http.client.HTTPSConnection(host, port, timeout=30,
                                                   context=ssl._create_unverified_context())
            else:
                conn = http.client.HTTPConnection(host, port, timeout=30)
            conns[info[0]] = conn
        try:
            conn.request("GET", url, headers={"Range": f"bytes=0-{limit - 1}", "Authorization": auth,
                                              "User-Agent": f"HansViewer/{VERSION}"})
            r = conn.getresponse()
            if r.status in (200, 206):
                data = r.read(limit)
                if r.status == 200 or not r.isclosed() and r.length:
                    conn.close()                  # whole file was being sent: don't read it all
                    conns.pop(info[0], None)
                alog("read done", path, bytes=len(data), took=f"{time.monotonic() - t0:.2f}s", via="direct")
                return data
            r.read()
            if r.status in (401, 403):
                with _DAV_LOCK:
                    _DAV_AUTH[info[0]] = None     # login not accepted: use GVFS from now on
                alog("direct dav LOGIN", path, status=r.status)
                return None
            alog("direct dav ERROR", path, status=r.status)
            return None
        except (OSError, http.client.HTTPException) as err:
            conn.close()
            conns.pop(info[0], None)
            if attempt == 2:
                alog("direct dav ERROR", path, error=str(err)[:120])
                return None
    return None


def read_head(path, limit):
    """The first `limit` bytes of a photo: direct WebDAV, GVFS, or a normal file read."""
    if is_gvfs(path):
        data = dav_head(path, limit)
        return data if data is not None else gio_read(path, limit)
    with open(path, "rb") as f:
        return f.read(limit)


# ---------------------------------------------------------------- network servers (GVFS)
SERVER_TYPES = [("smb", "Windows / NAS share (SMB)"), ("sftp", "SSH / SFTP"),
                ("davs", "WebDAV (https)"), ("dav", "WebDAV (http)"), ("ftp", "FTP")]
GVFS_PREFIX = {"smb": "smb-share", "sftp": "sftp", "dav": "dav", "davs": "davs", "ftp": "ftp"}


def gvfs_root():
    return f"/run/user/{os.getuid()}/gvfs"


def parse_server(text, scheme="smb"):
    """'nas', '\\\\nas\\photos', 'smb://nas/photos/2024' -> (scheme, host, share, rest)."""
    t = text.strip()
    if "://" in t:
        scheme, t = t.split("://", 1)
    t = t.replace("\\", "/").strip("/")
    parts = [p for p in t.split("/") if p]
    host = parts[0] if parts else ""
    if "@" in host:
        host = host.split("@", 1)[1]
    share = parts[1] if len(parts) > 1 else ""
    rest = "/".join(parts[2:])
    return scheme.lower(), host, share, rest


def server_uri(scheme, host, share="", rest=""):
    path = "/".join(p for p in (share, rest) if p)
    return f"{scheme}://{host}/{path}" if path else f"{scheme}://{host}/"


def gio_mount(uri, user="", domain="", password="", anonymous=False, timeout=45):
    """Mounts with GVFS, answering gio's questions. Returns (ok, message)."""
    if shutil.which("gio") is None:
        return False, "The 'gio' program is missing. Install it with: sudo apt install libglib2.0-bin"
    cmd = ["gio", "mount"] + (["-a"] if anonymous else []) + [uri]
    env = dict(os.environ, LANG="C", LC_ALL="C")
    try:
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, env=env)
    except OSError as err:
        return False, str(err)
    fd = proc.stdout.fileno()
    os.set_blocking(fd, False)
    out, asked = b"", {}
    deadline = time.monotonic() + timeout
    while True:
        if time.monotonic() > deadline:
            proc.kill()
            return False, "The server did not answer in time. Check the address and that it is switched on."
        ready, _, _ = select.select([fd], [], [], 0.2)
        if ready:
            try:
                chunk = os.read(fd, 4096)
            except BlockingIOError:
                chunk = b""
            if chunk:
                out += chunk
                tail = out.decode(errors="ignore").rsplit("\n", 1)[-1]
                if tail.rstrip().endswith(":"):
                    low = tail.lower()
                    if "password" in low:
                        key, answer = "password", password
                    elif "domain" in low:
                        key, answer = "domain", domain
                    elif "user" in low:
                        key, answer = "user", user
                    else:
                        key, answer = low, ""
                    asked[key] = asked.get(key, 0) + 1
                    if asked[key] > 2:  # asked again and again: the login is wrong
                        proc.kill()
                        return False, "The server did not accept the user name or password."
                    try:
                        proc.stdin.write((answer + "\n").encode())
                        proc.stdin.flush()
                    except OSError:
                        pass
                    out += b"\n"
                continue
        if proc.poll() is not None:
            try:
                out += os.read(fd, 65536)
            except (BlockingIOError, OSError):
                pass
            break
    text = out.decode(errors="ignore")
    ok = proc.returncode == 0 or "already mounted" in text.lower()
    lines = [l for l in text.splitlines() if l.strip() and not l.rstrip().endswith(":")
             and "authentication required" not in l.lower() and "enter " not in l.lower()]
    return ok, ("\n".join(lines[-3:]) or ("Connected" if ok else "Could not connect"))


def find_gvfs_path(scheme, host, share="", rest=""):
    """The local folder GVFS made for a mounted server, or None."""
    prefix = GVFS_PREFIX.get(scheme, scheme)
    host = host.lower()
    try:
        entries = sorted(os.scandir(gvfs_root()), key=lambda e: e.name)
    except OSError:
        return None
    for e in entries:
        name = e.name.lower()
        if not name.startswith(prefix + ":"):
            continue
        kv = dict(p.split("=", 1) for p in name.split(":", 1)[1].split(",") if "=" in p)
        if (kv.get("server") or kv.get("host")) != host:
            continue
        if scheme == "smb":
            if share and kv.get("share") != share.lower():
                continue
            path = os.path.join(e.path, rest) if rest else e.path
        else:
            path = os.path.join(e.path, share, rest) if share else e.path
        return path
    return None


def uri_from_gvfs_name(name):
    scheme, _, rest = name.partition(":")
    kv = dict(p.split("=", 1) for p in rest.split(",") if "=" in p)
    host = kv.get("server") or kv.get("host", "")
    port = f":{kv['port']}" if kv.get("port") else ""
    user = f"{kv['user']}@" if kv.get("user") and scheme in ("sftp", "ftp") else ""
    if scheme == "smb-share":
        return f"smb://{host}/{kv.get('share', '')}"
    if scheme == "dav":
        scheme = "davs" if kv.get("ssl") == "true" else "dav"
        prefix = urllib.parse.unquote(kv.get("prefix", "")).strip("/")
        return f"{scheme}://{host}{port}/{prefix}" if prefix else f"{scheme}://{host}{port}/"
    if scheme in ("sftp", "ftp", "davs"):
        return f"{scheme}://{user}{host}{port}/"
    if scheme == "afp-volume":
        return f"afp://{host}/{kv.get('volume', '')}"
    return None


ACTIVITY_LOG = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                            "hansviewer", "activity.log")
_LOG_LOCK = threading.Lock()


def alog(event, path="", **details):
    """One line per network/cloud request in ~/.cache/hansviewer/activity.log (folder names and
    timings only), to find out which request is slow or hangs."""
    extra = "  ".join(f"{k}={v}" for k, v in details.items())
    line = (f"{time.strftime('%H:%M:%S')}.{int(time.time() * 1000) % 1000:03d}  "
            f"{threading.current_thread().name[:14]:14}  {event:18}  {path}  {extra}\n")
    try:
        with _LOG_LOCK:
            os.makedirs(os.path.dirname(ACTIVITY_LOG), exist_ok=True)
            if os.path.exists(ACTIVITY_LOG) and os.path.getsize(ACTIVITY_LOG) > 2_000_000:
                os.replace(ACTIVITY_LOG, ACTIVITY_LOG + ".old")
            with open(ACTIVITY_LOG, "a") as f:
                f.write(line)
    except OSError:
        pass


class _Deadline:
    """Cancels a GIO request that takes longer than `seconds`, so no request can hang forever."""

    def __init__(self, seconds):
        self.cancellable = Gio.Cancellable()
        self.timer = threading.Timer(seconds, self.cancellable.cancel)
        self.timer.daemon = True

    def __enter__(self):
        self.timer.start()
        return self.cancellable

    def __exit__(self, *exc):
        self.timer.cancel()
        return False


LIST_TIMEOUT = 300     # seconds for reading one folder (very large folders can take minutes)
READ_TIMEOUT = 180     # seconds for downloading one photo


def is_gvfs(path):
    return Gio is not None and path.startswith(f"/run/user/{os.getuid()}/gvfs/")


def gio_file(path):
    """The GIO object for a path under /run/user/…/gvfs, talking to the connection directly
    (one request per folder) instead of through the slow per-file path gateway."""
    f = Gio.File.new_for_path(path)
    if f.get_uri_scheme() != "file":
        return f
    root = f"/run/user/{os.getuid()}/gvfs/"
    name, _, rel = path[len(root):].partition("/")
    base = uri_from_gvfs_name(name)
    if not base:
        return f
    g = Gio.File.new_for_uri(base)
    return g.resolve_relative_path(rel) if rel else g


GIO_ATTRS = "standard::name,standard::type,standard::size,time::modified"


class ServerTimeout(Exception):
    pass


def gio_list(folder, timeout=LIST_TIMEOUT):
    """[(name, is_folder, size, mtime)] for a gvfs folder in one go, using the same `gio list`
    route as the file manager (measured: 9431 entries in 4 s on a WebDAV NAS)."""
    t0 = time.monotonic()
    uri = gio_file(folder).get_uri()
    cmd = ["gio", "list", "-u", "-l", "-a", "standard::type,standard::size,time::modified", uri]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout,
                           env=dict(os.environ, LANG="C", LC_ALL="C"))
    except subprocess.TimeoutExpired:
        alog("list TIMEOUT", folder, after=f"{time.monotonic() - t0:.1f}s")
        raise ServerTimeout(f"The server did not answer within {timeout} seconds")
    if r.returncode != 0:
        msg = r.stderr.decode(errors="replace").strip().splitlines()
        msg = msg[-1] if msg else "could not read the folder"
        alog("list ERROR", folder, error=msg)
        raise OSError(msg)
    out = []
    for line in r.stdout.decode(errors="replace").splitlines():
        fields = line.split("\t")
        if not fields or not fields[0]:
            continue
        name = urllib.parse.unquote(fields[0].rstrip("/").rsplit("/", 1)[-1])
        size, kind, mtime = 0, "", 0.0
        for f in fields[1:]:
            if f.startswith("(") and f.endswith(")"):
                kind = f[1:-1]
            elif f.startswith("time::modified="):
                try:
                    mtime = float(f.split("=", 1)[1])
                except ValueError:
                    pass
            elif f.isdigit():
                size = int(f)
        out.append((name, kind == "directory", size, mtime))
    alog("list done", folder, entries=len(out), took=f"{time.monotonic() - t0:.2f}s")
    return out


LIST_CACHE_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                              "hansviewer", "lists")
_INFLIGHT = {}
_INFLIGHT_LOCK = threading.Lock()


def _list_cache_file(folder):
    return os.path.join(LIST_CACHE_DIR, hashlib.md5(folder.encode()).hexdigest() + ".json")


def list_cache_get(folder):
    """The remembered contents of a network folder from an earlier visit, or None."""
    try:
        with open(_list_cache_file(folder)) as f:
            data = json.load(f)
        if data.get("folder") == folder:
            return [tuple(e) for e in data["entries"]]
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None


def list_cache_put(folder, entries):
    try:
        os.makedirs(LIST_CACHE_DIR, exist_ok=True)
        tmp = _list_cache_file(folder) + f".{os.getpid()}.{threading.get_native_id()}.tmp"
        with open(tmp, "w") as f:
            json.dump({"folder": folder, "time": time.time(), "entries": entries}, f)
        os.replace(tmp, _list_cache_file(folder))
    except OSError:
        pass


def rename_folder_really(old, new):
    """Renames a folder where it is stored (disk, NAS, cloud). Runs in a background thread.
    Returns (ok, message)."""
    name = os.path.basename(new)
    try:
        if is_gvfs(old):
            target = gio_file(new)
            if target.query_exists(None):
                return False, f"“{name}” already exists in this folder."
            gio_file(old).set_display_name(name, None)  # a single rename request to the server
        else:
            if os.path.lexists(new):
                return False, f"“{name}” already exists in this folder."
            os.rename(old, new)
    except Exception as err:
        return False, getattr(err, "message", None) or getattr(err, "strerror", None) or str(err)
    alog("folder renamed", old, to=name)
    carry_over_caches(old, new)
    return True, new


def _moved(path, old, new):
    if path == old:
        return new
    if path.startswith(old.rstrip("/") + "/"):
        return new + path[len(old.rstrip("/")):]
    return None


def carry_over_caches(old, new):
    """After a folder rename: remembered folder lists and thumbnails move along, so a renamed
    network or cloud folder still opens at once and nothing has to be downloaded again."""
    moved_lists = []
    try:
        names = os.listdir(LIST_CACHE_DIR)
    except OSError:
        names = []
    parent = os.path.dirname(old.rstrip("/"))
    for n in names:
        if not n.endswith(".json"):
            continue
        f = os.path.join(LIST_CACHE_DIR, n)
        try:
            with open(f) as fh:
                data = json.load(fh)
            folder = data.get("folder", "")
        except (OSError, ValueError):
            continue
        target = _moved(folder, old, new)
        if target:
            entries = [tuple(e) for e in data.get("entries", [])]
            list_cache_put(target, entries)
            try:
                os.remove(f)
            except OSError:
                pass
            moved_lists.append((folder, target, entries))
        elif folder == parent:  # the parent's list still has the old name in it
            oldname, newname = os.path.basename(old.rstrip("/")), os.path.basename(new)
            entries = [[newname if e[0] == oldname else e[0]] + list(e[1:]) for e in data.get("entries", [])]
            list_cache_put(folder, entries)
    # thumbnails: network folders from the remembered lists, local folders by looking
    pairs = []
    for folder, target, entries in moved_lists:
        pairs += [(os.path.join(folder, e[0]), os.path.join(target, e[0])) for e in entries if not e[1]]
    if not is_remote(new):
        for root, _dirs, files in os.walk(new):
            for fn in files:
                p_new = os.path.join(root, fn)
                pairs.append((old + p_new[len(new):], p_new))
    n = 0
    for p_old, p_new in pairs:
        for d in (CACHE_DIR, CACHE_DIR_NORMAL):
            _, c_old = thumb_cache_file(p_old, d)
            if os.path.exists(c_old):
                _, c_new = thumb_cache_file(p_new, d)
                try:
                    os.replace(c_old, c_new)
                    n += 1
                except OSError:
                    pass
    alog("caches carried over", new, lists=len(moved_lists), thumbnails=n)


def gio_list_shared(folder, timeout=LIST_TIMEOUT):
    """Like gio_list, but when the same folder is already being read (e.g. for the grid and the
    sidebar at once), waits for that answer instead of asking the server a second time.
    Every answer is remembered on disk for instant display on the next visit."""
    with _INFLIGHT_LOCK:
        job = _INFLIGHT.get(folder)
        owner = job is None
        if owner:
            job = {"done": threading.Event(), "result": None, "error": None}
            _INFLIGHT[folder] = job
    if owner:
        try:
            job["result"] = gio_list(folder, timeout)
            list_cache_put(folder, job["result"])
        except Exception as err:
            job["error"] = err
        finally:
            job["done"].set()
            with _INFLIGHT_LOCK:
                _INFLIGHT.pop(folder, None)
    else:
        alog("list shared", folder)
        job["done"].wait(timeout + 10)
    if job["error"] is not None:
        raise job["error"]
    if job["result"] is None:
        raise ServerTimeout(f"The server did not answer within {timeout} seconds")
    return job["result"]


def entries_from_listing(folder, listing):
    """Photo (and video) entries for the grid from a folder listing."""
    out = []
    exts = media_exts()
    for name, is_dir, size, mtime in listing:
        ext = os.path.splitext(name)[1][1:].lower()
        if not is_dir and not name.startswith(".") and ext in exts:
            out.append({"path": os.path.join(folder, name), "name": name, "ext": ext,
                        "size": size, "mtime": mtime, "taken": None, "taken_known": False})
    return out


def subfolders_from_listing(folder, listing):
    subs = [(n, os.path.join(folder, n)) for n, is_dir, _s, _m in listing
            if is_dir and not n.startswith(".")]
    return sorted(subs, key=lambda x: natural_key(x[0]))[:3000]


def gio_read(path, limit=None, timeout=READ_TIMEOUT):
    """Reads a gvfs file directly (whole file, or only the first `limit` bytes)."""
    t0 = time.monotonic()
    f = gio_file(path)
    with _Deadline(timeout) as cancel:
        try:
            if limit is None:
                ok, data, _etag = f.load_contents(cancel)
                data = bytes(data)
            else:
                stream = f.read(cancel)
                try:
                    chunks, left = [], limit
                    while left > 0:
                        b = stream.read_bytes(min(left, 65536), cancel).get_data()
                        if not b:
                            break
                        chunks.append(bytes(b))
                        left -= len(b)
                    data = b"".join(chunks)
                finally:
                    try:
                        stream.close(None)
                    except Exception:
                        pass
        except Exception as err:
            if cancel.is_cancelled():
                alog("read TIMEOUT", path, after=f"{time.monotonic() - t0:.1f}s")
                raise ServerTimeout(f"The server did not answer within {timeout} seconds")
            alog("read ERROR", path, error=getattr(err, "message", err))
            raise
    alog("read done", path, bytes=len(data), took=f"{time.monotonic() - t0:.2f}s")
    return data


def gio_unmount(path):
    """Disconnects the GVFS mount that contains `path`."""
    target = path
    root = gvfs_root()
    if path.startswith(root + "/"):
        name = path[len(root) + 1:].split("/", 1)[0]
        target = uri_from_gvfs_name(name) or os.path.join(root, name)
    try:
        r = subprocess.run(["gio", "mount", "-u", target], capture_output=True, text=True, timeout=20)
        return r.returncode == 0, (r.stderr or r.stdout).strip()
    except (OSError, subprocess.SubprocessError) as err:
        return False, str(err)


def discover_servers(timeout=6):
    """Network shares announced on the local network (needs avahi-utils)."""
    if shutil.which("avahi-browse") is None:
        return None
    found = {}
    for service, scheme in (("_smb._tcp", "smb"), ("_sftp-ssh._tcp", "sftp"),
                            ("_webdavs._tcp", "davs"), ("_webdav._tcp", "dav")):
        try:
            r = subprocess.run(["avahi-browse", "-tpr", service], capture_output=True,
                               text=True, timeout=timeout)
        except (OSError, subprocess.SubprocessError):
            continue
        for line in r.stdout.splitlines():
            f = line.split(";")
            if len(f) >= 9 and f[0] == "=" and f[2] == "IPv4":
                name = f[3].replace("\\032", " ")
                host = f[6] or f[7]
                found[(scheme, host)] = (name, scheme, host)
    return sorted(found.values(), key=lambda x: (x[0].lower(), x[1]))


def keyring_available():
    return shutil.which("secret-tool") is not None


def keyring_store(uri, user, password):
    if not keyring_available():
        return False
    try:
        r = subprocess.run(["secret-tool", "store", "--label", f"HansViewer: {uri}",
                            "hansviewer-uri", uri, "user", user or "-"],
                           input=password, text=True, capture_output=True, timeout=10)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def keyring_lookup(uri, user):
    if not keyring_available():
        return None
    try:
        r = subprocess.run(["secret-tool", "lookup", "hansviewer-uri", uri, "user", user or "-"],
                           capture_output=True, text=True, timeout=10)
        return r.stdout if r.returncode == 0 and r.stdout else None
    except (OSError, subprocess.SubprocessError):
        return None


def keyring_clear(uri, user):
    if keyring_available():
        try:
            subprocess.run(["secret-tool", "clear", "hansviewer-uri", uri, "user", user or "-"],
                           capture_output=True, timeout=10)
        except (OSError, subprocess.SubprocessError):
            pass


def saved_servers():
    try:
        v = json.loads(setting("servers", "[]", str) or "[]")
        return v if isinstance(v, list) else []
    except ValueError:
        return []


def save_servers(servers):
    settings().setValue("servers", json.dumps(servers))


# ---------------------------------------------------------------- cloud storage (rclone)
# Services that sign in through the browser; rclone brings its own app registration.
CLOUD_SERVICES = [("drive", "Google Drive"), ("onedrive", "Microsoft OneDrive"),
                  ("dropbox", "Dropbox"), ("box", "Box"), ("pcloud", "pCloud")]
CLOUD_DIR = os.path.expanduser("~/Cloud")


def rclone_available():
    return shutil.which("rclone") is not None


def rclone_remotes():
    """Names of the accounts already set up in rclone."""
    if not rclone_available():
        return []
    try:
        r = subprocess.run(["rclone", "listremotes"], capture_output=True, text=True, timeout=15)
        return [l.strip().rstrip(":") for l in r.stdout.splitlines() if l.strip()]
    except (OSError, subprocess.SubprocessError):
        return []


def rclone_create(name, service, timeout=600):
    """Creates an rclone account; the browser opens for signing in. Returns (ok, message)."""
    try:
        r = subprocess.run(["rclone", "config", "create", name, service], capture_output=True,
                           text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, "Signing in took too long. Please try again."
    except OSError as err:
        return False, str(err)
    if r.returncode != 0:
        lines = (r.stderr or r.stdout).strip().splitlines()
        return False, lines[-1] if lines else "rclone could not set up the account"
    return True, "ok"


def cloud_path(name):
    return os.path.join(CLOUD_DIR, name)


def cloud_dir(cloud):
    """Where a saved cloud entry appears as a folder (an entry may set its own folder name)."""
    return os.path.join(CLOUD_DIR, cloud.get("mount") or cloud["name"])


def cloud_mounted(cloud):
    return is_mounted(cloud_dir(cloud) if isinstance(cloud, dict) else cloud_path(cloud))


def rclone_remote_types():
    """{account name: service type} from rclone's settings (local, quick)."""
    if not rclone_available():
        return {}
    try:
        r = subprocess.run(["rclone", "listremotes", "--long"], capture_output=True, text=True,
                           timeout=15)
    except (OSError, subprocess.SubprocessError):
        return {}
    out = {}
    for line in r.stdout.splitlines():
        if ":" in line:
            name, _, kind = line.partition(":")
            out[name.strip()] = kind.strip()
    return out


def shared_entry(cloud):
    """The extra 'Shared with me' entry for a Google Drive account."""
    base = cloud.get("label") or cloud["name"]
    return {"name": cloud["name"], "mount": cloud["name"] + "-shared",
            "label": f"{base} – Shared with me", "args": ["--drive-shared-with-me"]}


def rclone_webdav(name, url, user, password):
    """Creates (or replaces) an rclone WebDAV account. Returns (ok, message)."""
    if name in rclone_remotes():
        subprocess.run(["rclone", "config", "delete", name], capture_output=True, timeout=15)
    cmd = ["rclone", "config", "create", name, "webdav", f"url={url}", "vendor=other"]
    if user:
        cmd.append(f"user={user}")
    if password:
        cmd += [f"pass={password}", "--obscure"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as err:
        return False, str(err)
    if r.returncode != 0:
        lines = (r.stderr or r.stdout).strip().splitlines()
        return False, lines[-1] if lines else "rclone could not set up the server"
    return True, "ok"


RCLONE_TUNING = [
    "--vfs-cache-mode", "full",      # keeps what was read, so photos open fast the second time
    "--vfs-cache-max-size", "4G",    # ...up to 4 GB; the oldest copies are removed first
    "--vfs-cache-max-age", "168h",
    "--vfs-read-ahead", "0",         # but only download what is actually read...
    "--buffer-size", "1M",           # ...so a thumbnail doesn't pull in a whole photo
    "--vfs-read-chunk-size", "1M",
    # folder lists are kept 12 hours (a big shared folder can take Google 1-2 minutes to list);
    # changes are still picked up, because rclone asks the cloud every minute what changed
    "--dir-cache-time", "12h", "--poll-interval", "1m", "--attr-timeout", "10s",
    "--timeout", "60s", "--contimeout", "15s",
]
RCLONE_KEEP_FLAGS = ("--drive-shared-with-me", "--no-check-certificate")
RCLONE_LOG_MAX = 50_000_000


def rclone_log_file(path):
    """rclone's own log for one cloud folder: every refusal or retry from the cloud is in it."""
    folder = os.path.join(os.path.dirname(ACTIVITY_LOG), "rclone")
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, os.path.basename(path.rstrip("/")) + ".log")


def trim_rclone_logs():
    """Keeps the rclone logs small: when one passes 50 MB, its last 5 MB go to .old."""
    folder = os.path.join(os.path.dirname(ACTIVITY_LOG), "rclone")
    try:
        names = os.listdir(folder)
    except OSError:
        return
    for n in names:
        f = os.path.join(folder, n)
        try:
            if n.endswith(".log") and os.path.getsize(f) > RCLONE_LOG_MAX:
                with open(f, "rb") as src:
                    src.seek(-5_000_000, os.SEEK_END)
                    tail = src.read()
                with open(f + ".old", "wb") as dst:
                    dst.write(tail)
                os.truncate(f, 0)  # rclone keeps appending to the emptied file
        except OSError:
            pass


def rclone_process(path):
    """(pid, command line) of the rclone program serving a cloud folder, or (None, [])."""
    path = path.rstrip("/")
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return None, []
    for pid in pids:
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as f:
                args = [a.decode(errors="replace") for a in f.read().split(b"\0") if a]
        except OSError:
            continue
        if len(args) >= 4 and os.path.basename(args[0]) == "rclone" and "mount" in args[1:3] \
                and path in (a.rstrip("/") for a in args):
            return int(pid), args
    return None, []


def rclone_refresh(path):
    """Makes rclone forget its remembered folder lists, so the next look asks the cloud again."""
    pid, _ = rclone_process(mount_of(path)[0])
    if pid:
        try:
            os.kill(pid, signal.SIGHUP)  # rclone: "flush all directory caches"
            alog("rclone refresh", path)
            return True
        except OSError:
            pass
    return False


def rclone_update_mounts():
    """Cloud folders connected by an older HansViewer get reconnected once with the current
    settings (12-hour folder lists, own log). Returns how many were reconnected."""
    n = 0
    for mount, fs in list(mount_table(force=True)):
        if not fs.startswith("fuse.rclone") or not mount.startswith(CLOUD_DIR.rstrip("/") + "/"):
            continue
        pid, args = rclone_process(mount)
        if not pid or ("12h" in args and "--log-file" in args):
            continue
        remote = next((a for a in args[2:] if a.endswith(":") or ":" in a and not a.startswith("-")), None)
        if not remote:
            continue
        extra = [a for a in args if a in RCLONE_KEEP_FLAGS]
        ok, msg = rclone_unmount(mount)
        if not ok:
            alog("rclone update skipped", mount, error=msg[:100] or "-")
            continue
        for _ in range(20):
            if not is_mounted(mount, force=True):
                break
            time.sleep(0.25)
        ok, msg = rclone_mount(remote.rstrip(":").split(":")[0], extra=extra,
                               mount=os.path.relpath(mount, CLOUD_DIR))
        alog("rclone reconnected", mount, ok=ok)
        n += ok
    return n


def rclone_log_hint(path):
    """A plain explanation from the end of rclone's log for this cloud folder, or ""."""
    try:
        with open(rclone_log_file(path), "rb") as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - 60000))
            tail = f.read().decode(errors="replace")
    except OSError:
        return ""
    if "rateLimitExceeded" in tail or "Rate limited" in tail or "userRateLimitExceeded" in tail:
        return ("Google is limiting requests right now. rclone shares one Google app ID with all its "
                "users worldwide, so this happens often. Please try again in a few minutes. "
                "The lasting fix is your own Google app ID (see the HansViewer guide).")
    if "invalid_grant" in tail or "token expired" in tail.lower() or "oauth2" in tail.lower() and "error" in tail.lower():
        return "The sign-in has expired. Remove the cloud entry and add it again to sign in once more."
    lines = [l for l in tail.splitlines() if " ERROR " in l or "Fatal" in l or "CRITICAL" in l]
    return lines[-1][:300] if lines else ""


def rclone_mount(name, timeout=90, extra=(), mount=None):
    """Connects an rclone account as a folder under ~/Cloud. Returns (ok, message).
    Connecting can take a while when the cloud is slow, so it waits up to 90 seconds."""
    path = os.path.join(CLOUD_DIR, mount or name)
    if is_mounted(path, force=True):
        return True, path
    if shutil.which("fusermount3") is None and shutil.which("fusermount") is None:
        return False, "FUSE is missing. Install it with: sudo apt install fuse3"
    os.makedirs(path, exist_ok=True)
    t0 = time.monotonic()
    r = None
    try:
        log = ["--log-file", rclone_log_file(path), "--log-level", "DEBUG"]
        r = subprocess.run(["rclone", "mount", f"{name}:", path, *RCLONE_TUNING, *log,
                            "--daemon", *extra],
                           capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        pass  # rclone is still connecting in the background: keep checking below
    except OSError as err:
        return False, str(err)
    while time.monotonic() - t0 < timeout:
        if is_mounted(path, force=True):
            return True, path
        time.sleep(0.5)
    hint = rclone_log_hint(path)
    if hint:
        return False, hint
    msg = ((r.stderr or r.stdout) if r is not None else "").strip()
    return False, msg.splitlines()[-1] if msg else "The cloud folder did not connect within 90 seconds."


def rclone_unmount(path):
    for tool in ("fusermount3", "fusermount"):
        if shutil.which(tool):
            try:
                r = subprocess.run([tool, "-u", path], capture_output=True, text=True, timeout=20)
                return r.returncode == 0, (r.stderr or "").strip()
            except (OSError, subprocess.SubprocessError) as err:
                return False, str(err)
    return False, "fusermount is missing"


def saved_clouds():
    try:
        v = json.loads(setting("clouds", "[]", str) or "[]")
        return v if isinstance(v, list) else []
    except ValueError:
        return []


def save_clouds(clouds):
    settings().setValue("clouds", json.dumps(clouds))


def drive_names():
    """Your own names for drives that aren't saved servers or clouds (path -> name)."""
    try:
        v = json.loads(setting("drive_names", "{}", str) or "{}")
        return v if isinstance(v, dict) else {}
    except ValueError:
        return {}


SERVER_KIND = {"smb": "SMB", "sftp": "SFTP", "dav": "WebDAV", "davs": "WebDAV", "ftp": "FTP"}


def server_real_name(srv):
    """The real name of a saved server share, e.g. "photo on 192.168.1.5 (WebDAV)"."""
    kind = SERVER_KIND.get(srv.get("scheme"), (srv.get("scheme") or "").upper())
    host, share = srv.get("host", ""), srv.get("share", "")
    return f"{share} on {host} ({kind})" if share else f"{host} ({kind})"


def server_alias(srv):
    """Your alias for a saved server ("name" was used for this before version 4.0)."""
    if srv.get("alias") is not None:
        return srv["alias"]
    name = srv.get("name") or ""
    host, share = srv.get("host", ""), srv.get("share", "")
    return "" if name in ("", host, f"{share} on {host}", server_real_name(srv)) else name


def set_drive_name(path, name):
    names = drive_names()
    if name:
        names[path] = name
    else:
        names.pop(path, None)
    settings().setValue("drive_names", json.dumps(names))


def open_in_terminal(cmd):
    for term in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["xfce4-terminal", "-x"],
                 ["konsole", "-e"], ["xterm", "-e"]):
        if shutil.which(term[0]):
            try:
                subprocess.Popen(term + cmd)
                return True
            except OSError:
                pass
    return False


def set_wallpaper(path):
    uri = QUrl.fromLocalFile(path).toString()
    de = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
    if "cinnamon" in de:
        cmds = [["gsettings", "set", "org.cinnamon.desktop.background", "picture-uri", uri]]
    elif "mate" in de:
        cmds = [["gsettings", "set", "org.mate.background", "picture-filename", path]]
    elif any(d in de for d in ("gnome", "unity", "budgie", "pantheon")):
        cmds = [["gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri],
                ["gsettings", "set", "org.gnome.desktop.background", "picture-uri-dark", uri]]
    else:
        return False
    try:
        return all(subprocess.run(c, timeout=5).returncode == 0 for c in cmds)
    except (OSError, subprocess.SubprocessError):
        return False


ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
<stop offset="0" stop-color="#5b9bff"/><stop offset="1" stop-color="#2a5fd6"/></linearGradient></defs>
<rect x="8" y="8" width="112" height="112" rx="26" fill="url(#g)"/>
<circle cx="86" cy="42" r="12" fill="#ffd96a"/>
<path d="M20 98 L52 58 L72 80 L84 68 L108 98 Z" fill="#ffffff" opacity="0.95"/>
</svg>"""


def install_desktop_entry():
    share = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"))
    appdir = os.path.join(share, APP_ID)
    os.makedirs(appdir, exist_ok=True)
    target = os.path.join(appdir, "hansviewer.py")
    me = os.path.abspath(__file__)
    if me != target:
        shutil.copy2(me, target)
    icondir = os.path.join(share, "icons", "hicolor", "scalable", "apps")
    os.makedirs(icondir, exist_ok=True)
    with open(os.path.join(icondir, "hansviewer.svg"), "w") as f:
        f.write(ICON_SVG)
    mimes = ";".join(f"image/{m}" for m in ("jpeg", "png", "gif", "bmp", "webp", "tiff",
                                            "x-portable-pixmap", "svg+xml")) + ";"
    desktop_dir = os.path.join(share, "applications")
    os.makedirs(desktop_dir, exist_ok=True)
    # remove the menu entry of the earlier "acdview" version, if it was installed
    for old in (os.path.join(desktop_dir, "acdview.desktop"),
                os.path.join(icondir, "acdview.svg")):
        try:
            os.remove(old)
        except OSError:
            pass
    with open(os.path.join(desktop_dir, "hansviewer.desktop"), "w") as f:
        f.write(f"[Desktop Entry]\nType=Application\nName={APP} {VERSION}\n"
                "GenericName=Image Browser\nComment=Browse, view and edit photos\n"
                f'Exec=python3 "{target}" %f\nIcon=hansviewer\nTerminal=false\n'
                f"Categories=Graphics;Viewer;Photography;\nMimeType={mimes}\n")
    try:
        subprocess.run(["update-desktop-database", desktop_dir], timeout=10,
                       capture_output=True)
    except (OSError, subprocess.SubprocessError):
        pass
    return target


# ======================================================================= background jobs
class JobSignals(QObject):
    thumb = pyqtSignal(str, float, QImage, int, int)
    dates = pyqtSignal(object, int, int, int)  # results, done, total, generation
    image = pyqtSignal(str, QImage, object)


class ThumbJob(QRunnable):
    """One thumbnail. With [net_pool] (network folders): first only the stored thumbnail is looked
    up, on the local disk; only when there is none, the photo is read in [net_pool] (a few at a
    time, the most recently asked first). Network videos are not read here (Make thumbnails does)."""

    def __init__(self, path, mtime, signals, use_cache, remote=False, cache_only=False, lenient=False,
                 net_pool=None, priority=0, token=None):
        super().__init__()
        self.token, self.gen = token, (token or {}).get("gen")
        self.path, self.mtime, self.signals, self.use_cache = path, mtime, signals, use_cache
        self.remote, self.cache_only, self.lenient = remote, cache_only, lenient
        self.net_pool, self.priority = net_pool, priority

    def run(self):
        if self.net_pool is not None:
            img, w, h = make_thumbnail(self.path, self.mtime, self.use_cache, self.remote,
                                       True, self.lenient)
            if w == -1 and not is_video(self.path):
                if self.token is not None and self.token.get("gen") != self.gen:
                    return                  # the folder was left meanwhile
                try:
                    self.net_pool.start(ThumbJob(self.path, self.mtime, self.signals, self.use_cache,
                                                 self.remote, False, self.lenient), self.priority)
                except RuntimeError:        # the folder was left meanwhile
                    pass
                return
        else:
            img, w, h = make_thumbnail(self.path, self.mtime, self.use_cache, self.remote,
                                       self.cache_only, self.lenient)
        self.signals.thumb.emit(self.path, self.mtime, img, w, h)


def scan_folder(folder):
    """The images in a folder: (entries, error message)."""
    entries, error = [], ""
    if is_gvfs(folder):
        try:
            entries = entries_from_listing(folder, gio_list_shared(folder))
        except Exception as err:  # GLib errors carry a readable message
            error = getattr(err, "message", None) or str(err)
        return entries, error
    exts = media_exts()
    try:
        with os.scandir(folder) as it:
            for e in it:
                if e.name.startswith("."):
                    continue
                ext = os.path.splitext(e.name)[1][1:].lower()
                if ext not in exts:
                    continue
                try:
                    if not e.is_file():
                        continue
                    st = e.stat()
                except OSError:
                    continue
                entries.append({"path": e.path, "name": e.name, "ext": ext,
                                "size": st.st_size, "mtime": st.st_mtime,
                                "taken": None, "taken_known": False})
    except OSError as err:
        error = err.strerror or str(err)
    return entries, error


def timeline_listing(folder):
    """Timeline: (photos, subfolders) of one folder. Network folders read before are taken from
    the remembered list, so a Timeline over many folders appears quickly."""
    if is_gvfs(folder):
        listing = list_cache_get(folder)
        if listing is None:
            listing = gio_list_shared(folder)
        entries, subs = entries_from_listing(folder, listing), subfolders_from_listing(folder, listing)
    else:
        entries, subs = scan_folder(folder)[0], scan_subfolders(folder)
    subs = [(n, p) for n, p in subs if not n.startswith(("@", "#"))]   # NAS system folders
    return entries, subs


class TimelineSignals(QObject):
    found = pyqtSignal(int, object)      # generation, entries
    status = pyqtSignal(int, str)
    done = pyqtSignal(int, int, int)     # generation, folders, files


def scan_subfolders(folder):
    """Visible subfolders as (name, path), sorted naturally."""
    subs = []
    if is_gvfs(folder):
        try:
            return subfolders_from_listing(folder, gio_list_shared(folder))
        except Exception:
            return []
    try:
        with os.scandir(folder) as it:
            for e in it:
                try:
                    if not e.name.startswith(".") and e.is_dir():
                        subs.append((e.name, e.path))
                except OSError:
                    pass
    except OSError:
        pass
    return sorted(subs, key=lambda x: natural_key(x[0]))[:3000]


def _lower_thread_priority():
    """Background threads run at low priority so your own work always comes first."""
    try:
        os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 15)
    except (AttributeError, OSError):
        pass


def thumb_from_bytes(path, mtime, data, use_cache=True):
    """Decodes a downloaded photo at reduced size and stores its thumbnail."""
    buf = QBuffer()
    buf.setData(QByteArray(data))
    buf.open(QBuffer.OpenModeFlag.ReadOnly)
    reader = QImageReader(buf)
    reader.setDecideFormatFromContent(True)
    reader.setAutoTransform(True)
    w, h = image_dims(reader)
    size = reader.size()
    if size.isValid() and max(size.width(), size.height()) > THUMB_MAX:
        size.scale(THUMB_MAX, THUMB_MAX, Qt.AspectRatioMode.KeepAspectRatio)
        reader.setScaledSize(size)
    img = reader.read()
    buf.close()
    if img.isNull():
        img, (w, h) = _decode_bytes(path, data, THUMB_MAX)
    if img.isNull():
        return img, 0, 0
    if use_cache:
        uri, cache = thumb_cache_file(path)
        _write_cached(img, cache, uri, mtime, w, h)
    return img, w, h


class ThumbQueue(QObject):
    """"Make thumbnails" for network/cloud folders: keeps working after you leave the folder and
    after a restart. The folder asked for last goes first. Photos first (the quick way: only the
    preview embedded in the photo is read), videos last. 3 at a time, low priority."""
    progress = pyqtSignal(str, int, int, str)          # folder, done, total, state
    made = pyqtSignal(str, float, QImage, int, int)    # path, mtime, thumbnail, width, height
    changed = pyqtSignal()                             # the list of folders changed
    idle = pyqtSignal()

    def __init__(self, items, use_cache=True):
        super().__init__()
        self.items = [dict(i) for i in items if isinstance(i, dict) and i.get("folder")]
        self.use_cache = use_cache
        self.lock = threading.Lock()
        self.decode_lock = threading.Lock()
        self.wake = threading.Event()
        self.paused = False         # the Pause button
        self.viewer_busy = False    # the viewer is showing a network photo
        self.cancel = False
        self.current = None         # folder being worked on
        self.errors = 0             # files that could not be read in the current folder
        self.thread = None

    def snapshot(self):
        with self.lock:
            return [dict(i) for i in self.items]

    def waiting(self):
        """Folders in the list besides the one being worked on."""
        with self.lock:
            return max(0, len(self.items) - 1)

    def add(self, folder, subfolders):
        """Puts the folder at the front: the one asked for last is done first. A folder that was
        being worked on stays in the list and continues afterwards."""
        with self.lock:
            old = next((it for it in self.items if it["folder"] == folder), None)
            if old is not None:
                self.items.remove(old)
                subfolders = subfolders or old.get("subfolders", False)
            self.items.insert(0, {"folder": folder, "subfolders": subfolders})
            if self.current is not None and self.current != folder:
                self.cancel = True              # leave the current folder for now
        alog("thumbs-add", folder, subfolders=subfolders)
        self.changed.emit()
        self.start()

    def start(self):
        if self.thread is None or not self.thread.is_alive():
            self.thread = threading.Thread(target=self._run, name="thumb-queue", daemon=True)
            self.thread.start()
        self.wake.set()

    def stop_all(self):
        with self.lock:
            self.items.clear()
        self.cancel = True
        self.wake.set()
        self.changed.emit()

    def set_paused(self, on):
        self.paused = on
        self.wake.set()

    def _hold(self):
        """Waits while paused; returns False when the current folder should be abandoned."""
        while (self.paused or self.viewer_busy) and not self.cancel:
            self.wake.wait(0.5)
            self.wake.clear()
        return not self.cancel

    def _run(self):
        _lower_thread_priority()
        while True:
            try:
                self._next()
            except Exception as ex:             # never let one bad folder end the whole job
                alog("thumbs-error", self.current or "", error=repr(ex)[:200])
                with self.lock:
                    if self.items and self.items[0]["folder"] == self.current and not self.cancel:
                        self.items.append(self.items.pop(0))
                self.current = None
                time.sleep(2)

    def _next(self):
        self.cancel = False
        with self.lock:
            item = dict(self.items[0]) if self.items else None
        if item is None:
            self.current = None
            self.idle.emit()
            self.wake.wait()
            self.wake.clear()
            return
        folder = key = item["folder"]
        self.current = key
        name = os.path.basename(folder.rstrip("/")) or folder
        if is_remote(folder) and not remote_reachable(folder):
            folder = live_alternative(folder) or folder   # same NAS connected another way
        if is_remote(folder) and not remote_reachable(folder):
            with self.lock:
                others = len(self.items) > 1
                if others and self.items and self.items[0]["folder"] == key:
                    self.items.append(self.items.pop(0))  # do the others first
            self._skips = getattr(self, "_skips", 0) + 1
            if others and self._skips < len(self.items):
                self.changed.emit()
                time.sleep(1)
                return
            self._skips = 0
            self.progress.emit(name, 0, 0, "waiting")  # drive not connected: try again later
            self.wake.wait(60)
            self.wake.clear()
            return
        self._skips = 0
        self.errors = 0
        self.progress.emit(name, 0, 0, "listing")
        folders, files = [folder], []
        k = 0
        while k < len(folders) and not self.cancel:
            entries, _err = scan_folder(folders[k])
            files += entries
            if item.get("subfolders"):
                folders += [p for _n, p in scan_subfolders(folders[k])]
            k += 1
            if k % 5 == 0:
                self.progress.emit(name, 0, len(files), "listing")
        if self.cancel:
            return
        todo = [e for e in files if not cache_valid(e["path"], e["mtime"])]
        todo.sort(key=lambda e: is_video(e["path"]))    # photos first, videos last
        total, done = len(files), len(files) - len(todo)
        workers = 6 if todo and dav_direct_possible(todo[0]["path"]) else 3   # direct WebDAV: 6 at a time
        alog("thumbs-folder", folder, total=total, todo=len(todo), workers=workers)
        self.progress.emit(name, done, total, "working")
        with ThreadPoolExecutor(max_workers=workers, initializer=_lower_thread_priority) as pool:
            running = set()

            def collect(block):
                nonlocal done, running
                finished = {f for f in running if f.done()} if not block else set(running)
                for f in finished:
                    if f.cancelled():
                        continue
                    try:
                        f.result()
                    except Exception as ex:
                        self.errors += 1
                        alog("thumbs-file-error", "", error=repr(ex)[:200])
                    done += 1
                running -= finished
                if finished:
                    self.progress.emit(name, done, total, "working")
                return finished

            last = time.monotonic()
            for e in todo:
                if not self._hold():
                    break
                while len(running) >= workers:
                    if not collect(False):
                        time.sleep(0.05)
                    if time.monotonic() - last > 2:     # keep the status line alive
                        self.progress.emit(name, done, total, "working")
                        last = time.monotonic()
                running.add(pool.submit(self._one, e))
            if self.cancel:
                for f in running:
                    f.cancel()
            collect(True)
        self.progress.emit(name, done, total, "working")
        with self.lock:
            if not self.cancel and self.items and self.items[0]["folder"] == key:
                self.items.pop(0)
        if not self.cancel:
            alog("thumbs-done", folder, done=done, total=total, errors=self.errors)
        self.current = None
        self.changed.emit()

    def _one(self, e):
        path, mtime = e["path"], e["mtime"]
        if self.cancel:
            return
        try:
            if is_video(path):              # only a frame is read; ffmpeg has a time limit
                img, w, h = video_thumbnail(path, mtime, self.use_cache, remote=True)
            else:
                hit = preview_thumbnail(path, mtime, self.use_cache)   # quick: photo head only
                if hit:
                    img, w, h = hit
                else:                       # no preview inside: the whole photo is needed
                    if is_gvfs(path):
                        data = gio_read(path)
                    else:
                        with open(path, "rb") as f:
                            data = f.read()
                    if self.cancel:
                        return
                    with self.decode_lock:  # the computing (1 at a time)
                        img, w, h = thumb_from_bytes(path, mtime, data, self.use_cache)
        except Exception as ex:             # one unreadable file doesn't stop the others
            self.errors += 1
            alog("thumbs-file-error", path, error=repr(ex)[:200])
            return
        if img.isNull():
            self.errors += 1
            return
        self.made.emit(path, mtime, img, w, h)


class ListSignals(QObject):
    folder = pyqtSignal(int, object, str, bool)  # generation, entries, error, finished
    subfolders = pyqtSignal(str, object)     # folder, [(name, path)]


class ListJob(QRunnable):
    def __init__(self, folder, gen, signals):
        super().__init__()
        self.folder, self.gen, self.signals = folder, gen, signals
        self.created = time.monotonic()

    def run(self):
        """Sends the photos in batches, so a big network folder fills the grid while it loads."""
        t0 = time.monotonic()
        alog("folder start", self.folder, waited=f"{t0 - self.created:.2f}s")
        if is_gvfs(self.folder):  # one request through GIO, like the file manager
            entries, error = scan_folder(self.folder)
            alog("folder done", self.folder, photos=len(entries), error=error or "-",
                 took=f"{time.monotonic() - t0:.2f}s")
            self.signals.folder.emit(self.gen, entries, error, True)
            return
        batch, error, last = [], "", time.monotonic()
        remember = is_lazy(self.folder)  # cloud drives: keep the list for an instant next visit
        exts = media_exts()
        listing = []
        try:
            with os.scandir(self.folder) as it:
                for e in it:
                    if e.name.startswith("."):
                        continue
                    ext = os.path.splitext(e.name)[1][1:].lower()
                    if ext not in exts:
                        continue
                    try:
                        if not e.is_file():
                            continue
                        st = e.stat()
                    except OSError:
                        continue
                    batch.append({"path": e.path, "name": e.name, "ext": ext,
                                  "size": st.st_size, "mtime": st.st_mtime,
                                  "taken": None, "taken_known": False})
                    if remember:
                        listing.append((e.name, False, st.st_size, st.st_mtime))
                    if len(batch) >= 400 or (batch and time.monotonic() - last > 1.5):
                        self.signals.folder.emit(self.gen, batch, "", False)
                        batch, last = [], time.monotonic()
        except OSError as err:
            error = err.strerror or str(err)
        if remember and not error:
            list_cache_put(self.folder, listing)
        alog("folder done", self.folder, error=error or "-", took=f"{time.monotonic() - t0:.2f}s")
        self.signals.folder.emit(self.gen, batch, error, True)


class SubfolderJob(QRunnable):
    def __init__(self, folder, signals):
        super().__init__()
        self.folder, self.signals = folder, signals

    def run(self):
        t0 = time.monotonic()
        alog("subfolders start", self.folder)
        if is_gvfs(self.folder):
            try:
                subs = subfolders_from_listing(self.folder, gio_list_shared(self.folder))
            except Exception as err:
                self.signals.subfolders.emit(self.folder, str(err))
                return
        else:
            subs = scan_subfolders(self.folder)
        alog("subfolders done", self.folder, count=len(subs), took=f"{time.monotonic() - t0:.2f}s")
        self.signals.subfolders.emit(self.folder, subs)


class ImageThumbJob(QRunnable):
    """Turns a photo decoded by the viewer into a stored thumbnail, off the main thread."""

    def __init__(self, path, mtime, image, signals, use_cache=True):
        super().__init__()
        self.path, self.mtime, self.image, self.signals = path, mtime, image, signals
        self.use_cache = use_cache

    def run(self):
        img, w, h = thumb_from_image(self.path, self.mtime, self.image, self.use_cache)
        self.signals.thumb.emit(self.path, self.mtime, img, w, h)


class DateJob(QRunnable):
    """Reads the 'date taken' of many photos, reporting in chunks."""

    def __init__(self, entries, token, gen, signals):
        super().__init__()
        self.entries, self.token, self.gen, self.signals = entries, token, gen, signals

    def run(self):
        out, total = [], len(self.entries)
        for n, e in enumerate(self.entries, 1):
            if self.token["gen"] != self.gen:
                return  # the folder changed; stop
            try:
                ts = exif_date(e["path"])
            except Exception:
                ts = None
            out.append((date_key(e), e["path"], ts))
            if len(out) >= 100 or n == total:
                self.signals.dates.emit(out, n, total, self.gen)
                out = []


class ImageJob(QRunnable):
    """Decodes an image (optionally downscaled) plus info for the preview pane."""

    def __init__(self, path, signals, max_edge=None, with_info=False, wanted=None):
        super().__init__()
        self.path, self.signals, self.max_edge, self.with_info = path, signals, max_edge, with_info
        self.wanted = wanted  # returns False when the photo is no longer needed (skip it)

    def run(self):
        if self.wanted is not None and not self.wanted(self.path):
            self.signals.image.emit(self.path, QImage(), {"skipped": True})
            return
        remote = is_remote(self.path)
        if remote:
            alog("photo start", self.path, preview=bool(self.with_info))
        info = None
        if self.with_info:
            if remote:  # fetch once; Qt must not read the network file itself (window would freeze)
                img, dims = read_image(self.path, self.max_edge, with_dims=True)
                alog("photo done", self.path, ok=not img.isNull())
                self.signals.image.emit(self.path, img, {"dims": dims, "exif": exif_summary(self.path)})
                return
            info = {"dims": image_dims(QImageReader(self.path)), "exif": exif_summary(self.path)}
        img, dims = read_image(self.path, self.max_edge, with_dims=True)
        if remote:
            alog("photo done", self.path, ok=not img.isNull(), shown=f"{img.width()}x{img.height()}")
        if info is None:
            info = {}
        info["full"] = not self.max_edge or max(dims) <= max(img.width(), img.height())
        info.setdefault("dims", dims)
        self.signals.image.emit(self.path, img, info)


# ======================================================================= thumbnail model
class FolderModel(QAbstractListModel):
    date_progress = pyqtSignal(int, int)
    relisted = pyqtSignal()  # a remembered folder list was updated from the server
    checked = pyqtSignal(int, int, int, str)  # background check done: added, removed, total, error
    checking = pyqtSignal()  # a remembered list is shown; the server is being asked quietly
    dates_finished = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.all, self.items, self.row_of = [], [], {}
        self.thumbs, self.dims, self.pending = {}, {}, set()
        self.lengths = {}
        self.sort_key, self.sort_desc, self.filter = "name", False, ""
        self.kind = "all"
        self.extra = []        # Timeline: the photos in the subfolders (the folder's own are in self.all)
        self.month_at = {}     # Timeline: row -> "October 2026" for the first photo of each month
        self.use_cache = True
        self.pool = QThreadPool()
        self.pool.setMaxThreadCount(max(2, (os.cpu_count() or 4) - 1))
        self.disk_pool = QThreadPool()      # network folders: stored thumbnails, from the local disk
        self.disk_pool.setMaxThreadCount(max(2, (os.cpu_count() or 4) - 1))
        self._prio = 0
        self.signals = JobSignals()
        self.signals.thumb.connect(self._thumb_ready)
        self.signals.dates.connect(self._dates_ready)
        self.token, self.dates_gen = {"gen": 0}, -1
        self.error = ""
        self.remote, self.loading, self._on_done = False, False, None
        self.lazy, self.missing = False, set()
        self._refreshing = False
        self.folder, self._incoming, self._keep_old = None, [], False
        self.list_signals = ListSignals()
        self.list_signals.folder.connect(self._listed)
        self.list_pool = QThreadPool()  # folder reads never wait behind other work
        self.list_pool.setMaxThreadCount(4)

    # -- loading / ordering
    def load(self, folder, remote=False, on_done=None, lazy=False):
        """Local folders load at once; network and cloud folders in the background."""
        self.pool.clear()
        self.disk_pool.clear()
        self.pending.clear()
        self.missing.clear()  # look again: thumbnails may have been made meanwhile
        self.token["gen"] += 1
        self.remote, self.lazy = remote, lazy
        # few parallel downloads on a network drive, all cores on a local disk
        # few parallel downloads on a network drive, all cores on a local disk (and for
        # on-demand folders, which only read stored thumbnails from the local disk)
        self.pool.setMaxThreadCount(3 if remote and not lazy else max(2, (os.cpu_count() or 4) - 1))
        self._on_done = on_done
        same = folder == self.folder
        self.folder = folder
        cached = list_cache_get(folder) if remote and (is_gvfs(folder) or lazy) else None
        if cached is not None:
            # shown at once from the last visit; the server is asked quietly in the background
            self._apply(entries_from_listing(folder, cached), "")
            self.loading, self._refreshing, self._incoming = True, True, []
            self.checking.emit()
            drive_pool("list", folder).start(ListJob(folder, self.token["gen"], self.list_signals))
            return
        self._refreshing = False
        if remote:
            self.loading = True
            self._incoming = []
            # re-reading the same folder: keep showing it until the new list is complete
            self._keep_old = same and bool(self.all)
            if not self._keep_old:
                self.all, self.error = [], ""
                self._rebuild()
            drive_pool("list", folder).start(ListJob(folder, self.token["gen"], self.list_signals))
            return
        entries, error = scan_folder(folder)
        self._apply(entries, error)

    def _listed(self, gen, entries, error, finished):
        if gen != self.token["gen"]:
            return
        self._incoming.extend(entries)
        if finished and getattr(self, "_refreshing", False):
            self._refreshing = False
            self.loading = False
            entries, self._incoming = self._incoming, []
            if error:
                self.checked.emit(0, 0, len(self.all), error)
                return  # keep showing the remembered list
            old = {(e["path"], e["size"], e["mtime"]) for e in self.all}
            new = {(e["path"], e["size"], e["mtime"]) for e in entries}
            if self.missing:  # the check is done: look again for tiles that had no thumbnail
                self.missing.clear()
                if self.items:
                    self.dataChanged.emit(self.index(0), self.index(len(self.items) - 1))
            if old != new:
                old_paths = {p for p, _s, _m in old}
                new_paths = {p for p, _s, _m in new}
                self._apply(entries, error)
                self.relisted.emit()
                self.checked.emit(len(new_paths - old_paths), len(old_paths - new_paths), len(entries), "")
            else:
                self.checked.emit(0, 0, len(entries), "")
            return
        if finished:
            entries, self._incoming = self._incoming, []
            self._apply(entries, error)
        elif not self._keep_old:
            self.all = list(self._incoming)  # show what has arrived so far
            self._rebuild()

    def _apply(self, entries, error):
        self.loading = False
        self.error = error
        if len(self.thumbs) > 3000:  # keep memory in check across many folders
            self.thumbs.clear()
            self.dims.clear()
        cache = date_cache()
        for e in entries:
            k = date_key(e)
            if k in cache:
                e["taken"], e["taken_known"] = cache[k], True
        self.all = entries
        if self.sort_key == "taken" and not self.lazy:
            self.ensure_dates()
        self._rebuild()
        done, self._on_done = self._on_done, None
        if done:
            done()

    def ensure_dates(self):
        """Read missing 'date taken' values in the background."""
        missing = [e for e in self.all + self.extra if not e["taken_known"]]
        if missing and self.dates_gen != self.token["gen"]:
            self.dates_gen = self.token["gen"]
            QThreadPool.globalInstance().start(
                DateJob(missing, self.token, self.token["gen"], self.signals))

    def _dates_ready(self, results, done, total, gen):
        if gen != self.token["gen"]:
            return
        cache = date_cache()
        by_path = {e["path"]: e for e in self.all + self.extra}
        for key, path, ts in results:
            cache[key] = ts
            e = by_path.get(path)
            if e is not None:
                e["taken"], e["taken_known"] = ts, True
        self.date_progress.emit(done, total)
        if done >= total:
            save_date_cache()
            self.dates_finished.emit()

    def _rebuild(self):
        self.beginResetModel()
        items = self.all
        self.month_at = {}
        if self.kind == "timeline":   # this folder and all below it, newest first, folders ignored
            items = self.all + self.extra
            if self.filter:
                f = self.filter.lower()
                items = [e for e in items if f in e["name"].lower()]
            self.items = sorted(items, key=lambda e: (e["taken"] or e["mtime"], e["name"]), reverse=True)
            self.row_of = {e["path"]: i for i, e in enumerate(self.items)}
            last = None
            for i, e in enumerate(self.items):
                ts = e["taken"] or e["mtime"]
                label = time.strftime("%B %Y", time.localtime(ts)) if ts else "Unknown date"
                if label != last:
                    self.month_at[i] = label
                    last = label
            self.endResetModel()
            return
        if self.kind == "photos":
            items = [e for e in items if e["ext"] not in VIDEO_EXTS]
        elif self.kind == "videos":
            items = [e for e in items if e["ext"] in VIDEO_EXTS]
        if self.filter:
            f = self.filter.lower()
            items = [e for e in items if f in e["name"].lower()]
        key = {
            "name": lambda e: natural_key(e["name"]),
            "date": lambda e: (e["mtime"], natural_key(e["name"])),
            "taken": lambda e: (e["taken"] or e["mtime"], natural_key(e["name"])),
            "size": lambda e: (e["size"], natural_key(e["name"])),
            "type": lambda e: (e["ext"], natural_key(e["name"])),
        }[self.sort_key]
        self.items = sorted(items, key=key, reverse=self.sort_desc)
        self.row_of = {e["path"]: i for i, e in enumerate(self.items)}
        self.endResetModel()

    def set_sort(self, key, desc):
        self.sort_key, self.sort_desc = key, desc
        if key == "taken" and not self.lazy:
            self.ensure_dates()
        self._rebuild()

    def set_filter(self, text):
        self.filter = text.strip()
        self._rebuild()

    def add_extra(self, entries):
        """Timeline: photos found in the subfolders (arrive in portions while they are read)."""
        known = self.row_of.keys() | {e["path"] for e in self.extra}
        new = [e for e in entries if e["path"] not in known]
        if not new:
            return
        cache = date_cache()
        for e in new:   # dates read earlier are remembered
            if not e.get("taken_known"):
                ts = cache.get(date_key(e))
                if ts:
                    e["taken"], e["taken_known"] = ts, True
        self.extra += new
        if self.kind == "timeline":
            self._rebuild()

    def clear_extra(self):
        self.extra = []

    def set_kind(self, kind):
        """All / Photos / Videos."""
        self.kind = kind
        self._rebuild()

    def paths(self):
        return [e["path"] for e in self.items]

    def entry(self, path):
        row = self.row_of.get(path)
        return self.items[row] if row is not None else None

    def total_size(self, rows=None):
        rows = range(len(self.items)) if rows is None else rows
        return sum(self.items[r]["size"] for r in rows)

    # -- Qt model API
    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.items)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or index.row() >= len(self.items):
            return None
        e = self.items[index.row()]
        key = (e["path"], e["mtime"])
        if role == Qt.ItemDataRole.DisplayRole:
            return e["name"]
        if role == Qt.ItemDataRole.DecorationRole:
            if key in self.thumbs:
                return self.thumbs[key]
            if key not in self.pending and key not in self.missing:
                self.pending.add(key)
                lenient = bool(getattr(self, "_refreshing", False))
                if self.remote and not self.lazy:
                    self._prio = (self._prio + 1) % 1_000_000   # tiles asked for last go first
                    self.disk_pool.start(ThumbJob(e["path"], e["mtime"], self.signals, self.use_cache,
                                                  True, lenient=lenient, net_pool=self.pool,
                                                  priority=self._prio, token=self.token))
                else:
                    self.pool.start(ThumbJob(e["path"], e["mtime"], self.signals, self.use_cache,
                                             self.remote, cache_only=self.lazy, lenient=lenient))
            return None
        if role == ROLE_MISSING:
            return key in self.missing
        if role == ROLE_SIZE:
            return human_size(e["size"])
        if role == ROLE_DIMS:
            return self.dims.get(key)
        if role == ROLE_PATH:
            return e["path"]
        if role == ROLE_LENGTH:
            return self.lengths.get(key, "") if e["ext"] in VIDEO_EXTS else None
        if role == ROLE_MONTH:
            return self.month_at.get(index.row())
        if role == Qt.ItemDataRole.ToolTipRole:
            d = self.dims.get(key)
            dims = f"{d[0]} × {d[1]}  ·  " if d and d[0] else ""
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(e["mtime"]))
            tip = f"{e['name']}\n{dims}{human_size(e['size'])}  ·  modified {when}"
            if e["taken"]:
                tip += "\ntaken " + time.strftime("%Y-%m-%d %H:%M", time.localtime(e["taken"]))
            return tip
        return None

    def flags(self, index):
        base = super().flags(index)
        return base | Qt.ItemFlag.ItemIsDragEnabled if index.isValid() else base

    def mimeTypes(self):
        return ["text/uri-list"]

    def mimeData(self, indexes):
        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(self.items[i.row()]["path"]) for i in indexes])
        return md

    def supportedDragActions(self):
        return Qt.DropAction.CopyAction

    def _thumb_ready(self, path, mtime, image, w, h):
        key = (path, mtime)
        self.pending.discard(key)
        row = self.row_of.get(path)
        if w == -1:  # on-demand folder and no stored thumbnail yet
            self.missing.add(key)
            if row is not None:
                idx = self.index(row)
                self.dataChanged.emit(idx, idx)
            return
        self.missing.discard(key)
        if image.isNull():
            image = QImage()
        self.thumbs[key] = QPixmap.fromImage(image) if not image.isNull() else QPixmap()
        self.dims[key] = (w, h)
        if is_video(path):
            self.lengths[key] = fmt_length(image.text("Thumb::Movie::Length")) if not image.isNull() else ""
        if row is not None and self.items[row]["mtime"] == mtime:
            idx = self.index(row)
            self.dataChanged.emit(idx, idx)


class SidebarDelegate(QStyledItemDelegate):
    """Sidebar entries with an alias show it on the first line and the real name of the share
    or cloud folder in smaller grey text on a second line."""

    def _small(self, option):
        f = QFont(option.font)
        f.setPointSizeF(max(6.5, f.pointSizeF() * 0.82))
        return f

    def sizeHint(self, option, index):
        size = super().sizeHint(option, index)
        if index.data(ROLE_REAL):
            from PyQt6.QtGui import QFontMetrics
            size.setHeight(size.height() + QFontMetrics(self._small(option)).height())
        return size

    def paint(self, painter, option, index):
        real = index.data(ROLE_REAL)
        if not real:
            return super().paint(painter, option, index)
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        alias = opt.text
        opt.text = ""
        style = opt.widget.style() if opt.widget else QApplication.style()
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)
        text_rect = style.subElementRect(QStyle.SubElement.SE_ItemViewItemText, opt, opt.widget)
        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        painter.save()
        fm = painter.fontMetrics()
        top = text_rect.adjusted(2, 2, -2, 0)
        top.setHeight(fm.height())
        painter.setFont(opt.font)
        painter.setPen(opt.palette.color(QPalette.ColorRole.HighlightedText if selected
                                         else QPalette.ColorRole.Text))
        painter.drawText(top, int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                         painter.fontMetrics().elidedText(alias, Qt.TextElideMode.ElideRight, top.width()))
        small = self._small(opt)
        painter.setFont(small)
        bottom = text_rect.adjusted(14, 2 + fm.height(), -2, 0)
        painter.setPen(QColor(THEME["muted"]) if not selected
                       else opt.palette.color(QPalette.ColorRole.HighlightedText))
        painter.drawText(bottom, int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop),
                         painter.fontMetrics().elidedText(real, Qt.TextElideMode.ElideMiddle, bottom.width()))
        painter.restore()


class ThumbDelegate(QStyledItemDelegate):
    """Draws each image as a rounded card with a caption."""

    def __init__(self, size):
        super().__init__()
        self.size = size

    def cell(self):
        return QSize(self.size + 26, self.size + 54)

    def sizeHint(self, option, index):
        return self.cell()

    def paint(self, p, option, index):
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        r = QRectF(option.rect).adjusted(5, 5, -5, -5)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        accent = QColor(THEME["accent"])
        if selected:
            fill = QColor(accent)
            fill.setAlpha(60)
            p.setPen(QPen(accent, 2))
            p.setBrush(fill)
        else:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(THEME["card_hover"] if hover else THEME["card"]))
        p.drawRoundedRect(r, 10, 10)

        box = QRectF(r.x() + 8, r.y() + 8, r.width() - 16, self.size)
        pix = index.data(Qt.ItemDataRole.DecorationRole)
        if isinstance(pix, QPixmap) and not pix.isNull():
            s = min(box.width() / pix.width(), box.height() / pix.height(), 1.6)
            w, h = pix.width() * s, pix.height() * s
            target = QRectF(box.center().x() - w / 2, box.center().y() - h / 2, w, h)
            path = QPainterPath()
            path.addRoundedRect(target, 4, 4)
            p.setClipPath(path)
            p.drawPixmap(target, pix, QRectF(pix.rect()))
            p.setClipping(False)
        elif pix is None and index.data(ROLE_MISSING):
            if index.data(ROLE_LENGTH) is not None:
                self._film_symbol(p, box)   # a video without thumbnail yet
            else:
                self._photo_symbol(p, box)
        else:
            p.setPen(QColor(THEME["muted"]))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, "…" if pix is None else "?")
        length = index.data(ROLE_LENGTH)
        if length is not None:  # a video: play symbol in the corner
            d = max(22.0, min(34.0, self.size / 6))
            c = QPointF(box.left() + d * 0.5 + 6, box.bottom() - d * 0.5 - 6)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 170))
            p.drawEllipse(c, d / 2, d / 2)
            tri = QPainterPath()
            tri.moveTo(c.x() - d * 0.14, c.y() - d * 0.2)
            tri.lineTo(c.x() + d * 0.22, c.y())
            tri.lineTo(c.x() - d * 0.14, c.y() + d * 0.2)
            tri.closeSubpath()
            p.setBrush(QColor("#ffffff"))
            p.drawPath(tri)

        month = index.data(ROLE_MONTH)
        if month:   # Timeline: the first photo of a month carries the month's name
            bf = QFont(option.font)
            bf.setBold(True)
            p.setFont(bf)
            mw = QFontMetrics(bf).horizontalAdvance(month) + 16
            band = QRectF(box.left(), box.top(), min(mw, box.width()), QFontMetrics(bf).height() + 6)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(THEME["accent"]))
            p.drawRoundedRect(band, 5, 5)
            p.setPen(QColor("#ffffff"))
            p.drawText(band, Qt.AlignmentFlag.AlignCenter, month)
            p.setFont(option.font)

        p.setPen(QColor(THEME["text"]))
        fm = option.fontMetrics
        name = fm.elidedText(index.data(Qt.ItemDataRole.DisplayRole) or "",
                             Qt.TextElideMode.ElideMiddle, int(r.width() - 12))
        text_y = box.bottom() + 6
        p.drawText(QRectF(r.x() + 6, text_y, r.width() - 12, fm.height()),
                   Qt.AlignmentFlag.AlignHCenter, name)
        dims = index.data(ROLE_DIMS)
        sub = f"{dims[0]} × {dims[1]}" if dims and dims[0] > 0 else (
            index.data(ROLE_SIZE) if index.data(ROLE_MISSING) else "")
        if length is not None:
            sub = ("▶ " + length) if length else "▶ video"
        if sub:
            small = QFont(option.font)
            small.setPointSizeF(max(6.0, option.font.pointSizeF() * 0.85))
            p.setFont(small)
            p.setPen(QColor(THEME["muted"]))
            p.drawText(QRectF(r.x() + 6, text_y + fm.height(), r.width() - 12, fm.height()),
                       Qt.AlignmentFlag.AlignHCenter, sub)
        p.restore()

    @staticmethod
    def _film_symbol(p, box):
        """A film strip with a play triangle, for videos that have no thumbnail yet."""
        side = min(box.width(), box.height()) * 0.46
        r = QRectF(box.center().x() - side / 2, box.center().y() - side * 0.36, side, side * 0.72)
        col = QColor(THEME["muted"])
        col.setAlpha(170)
        p.setPen(QPen(col, max(1.5, side / 30)))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(r, side / 12, side / 12)
        hole = side / 11
        p.setBrush(col)
        for k in range(5):  # sprocket holes along the top and bottom
            x = r.left() + side * 0.1 + k * (side * 0.8 - hole) / 4
            p.drawRect(QRectF(x, r.top() + hole * 0.5, hole, hole * 0.8))
            p.drawRect(QRectF(x, r.bottom() - hole * 1.3, hole, hole * 0.8))
        tri = QPainterPath()
        c = r.center()
        tri.moveTo(c.x() - side * 0.1, c.y() - side * 0.14)
        tri.lineTo(c.x() + side * 0.16, c.y())
        tri.lineTo(c.x() - side * 0.1, c.y() + side * 0.14)
        tri.closeSubpath()
        p.drawPath(tri)

    @staticmethod
    def _photo_symbol(p, box):
        """A simple outlined picture symbol for photos that have no thumbnail yet."""
        side = min(box.width(), box.height()) * 0.42
        r = QRectF(box.center().x() - side / 2, box.center().y() - side * 0.4, side, side * 0.8)
        col = QColor(THEME["muted"])
        col.setAlpha(150)
        pen = QPen(col, max(1.5, side / 30))
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(r, side / 10, side / 10)
        sun = side / 9
        p.drawEllipse(QPointF(r.right() - side * 0.25, r.top() + side * 0.25), sun, sun)
        path = QPainterPath()
        path.moveTo(r.left() + side * 0.08, r.bottom() - side * 0.1)
        path.lineTo(r.left() + side * 0.38, r.top() + side * 0.38)
        path.lineTo(r.left() + side * 0.58, r.bottom() - side * 0.3)
        path.lineTo(r.left() + side * 0.7, r.bottom() - side * 0.42)
        path.lineTo(r.right() - side * 0.08, r.bottom() - side * 0.1)
        p.drawPath(path)


class ThumbGrid(QListView):
    def __init__(self):
        super().__init__()
        self.setObjectName("grid")
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setMovement(QListView.Movement.Static)
        self.setUniformItemSizes(True)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.setDragEnabled(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        self.setMouseTracking(True)
        self.viewport().setAttribute(Qt.WidgetAttribute.WA_Hover)
        self.empty_text = ""

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.model() is not None and self.model().rowCount() == 0 and self.empty_text:
            p = QPainter(self.viewport())
            p.setPen(QColor(THEME["muted"]))
            p.drawText(self.viewport().rect(), Qt.AlignmentFlag.AlignCenter, self.empty_text)


# ======================================================================= preview pane
class PreviewPane(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("previewPane")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.pix = None
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setMinimumHeight(200)
        self.image_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.title = QLabel()
        self.title.setObjectName("title")
        self.title.setWordWrap(True)
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        self.form.setHorizontalSpacing(14)
        self.form.setVerticalSpacing(6)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)
        lay.addWidget(self.image_label)
        lay.addWidget(self.title)
        lay.addLayout(self.form)
        lay.addStretch(1)
        self.clear()

    def clear(self, text="No image selected"):
        self.pix = None
        self.image_label.clear()
        self.image_label.setText(text)
        self.title.clear()
        self._set_rows([])

    def _set_rows(self, rows):
        while self.form.rowCount():
            self.form.removeRow(0)
        for k, v in rows:
            key = QLabel(k)
            key.setObjectName("muted")
            val = QLabel(v)
            val.setWordWrap(True)
            val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.form.addRow(key, val)

    def show_entry(self, entry, image=None, info=None):
        self.title.setText(entry["name"])
        rows = []
        if info and info["dims"][0]:
            w, h = info["dims"]
            mp = w * h / 1e6
            rows.append(("Dimensions", f"{w} × {h}  ({mp:.1f} MP)"))
        rows += [("File size", human_size(entry["size"])),
                 ("Type", entry["ext"].upper()),
                 ("Modified", time.strftime("%Y-%m-%d %H:%M", time.localtime(entry["mtime"]))),
                 ("Folder", os.path.dirname(entry["path"]))]
        if info:
            rows += info["exif"]
        self._set_rows(rows)
        if image is not None and not image.isNull():
            self.pix = QPixmap.fromImage(image)
            self._scale()
        elif image is not None:
            self.pix = None
            self.image_label.setText("Cannot preview")

    def _scale(self):
        if self.pix:
            w = max(50, self.image_label.width())
            h = max(150, min(self.image_label.width(), 420))
            self.image_label.setPixmap(self.pix.scaled(
                w, h, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._scale()


# ======================================================================= full-screen viewer

# ======================================================================= videos
VIDEO_CACHE_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                               "hansviewer", "videos")
VIDEO_CACHE_MAX = 4_000_000_000   # network videos kept for replaying: up to 4 GB


def trim_video_cache(keep=None):
    try:
        files = [os.path.join(VIDEO_CACHE_DIR, n) for n in os.listdir(VIDEO_CACHE_DIR)]
    except OSError:
        return
    files = [f for f in files if os.path.isfile(f) and f != keep]
    total = sum(os.path.getsize(f) for f in files)
    for f in sorted(files, key=os.path.getatime):
        if total <= VIDEO_CACHE_MAX:
            break
        try:
            total -= os.path.getsize(f)
            os.remove(f)
        except OSError:
            pass


class VideoDownload:
    """Copies a network video into the video cache in the background (fast sequential reading),
    measuring the speed. Parts that are not here yet (e.g. the index some cameras put at the end)
    are read directly from the drive when the player asks for them."""

    def __init__(self, path, size, mtime):
        self.path, self.size = path, size
        key = hashlib.md5(f"{path}|{size}|{int(mtime)}".encode()).hexdigest()
        self.final = os.path.join(VIDEO_CACHE_DIR, key + os.path.splitext(path)[1].lower())
        self.part = self.final + ".part"
        self.have, self.done, self.error, self.cancelled = 0, False, "", False
        self.started = time.monotonic()
        self.cond = threading.Condition()
        if os.path.exists(self.final) and os.path.getsize(self.final) == size:
            self.have, self.done = size, True
            try:
                os.utime(self.final)  # recently used: kept longer
            except OSError:
                pass
        else:
            threading.Thread(target=self._run, name="video-download", daemon=True).start()

    @property
    def file(self):
        return self.final if self.done else self.part

    def speed(self):
        t = time.monotonic() - self.started
        return self.have / t if t > 0.5 else 0.0

    def _run(self):
        _lower_thread_priority()
        try:
            os.makedirs(VIDEO_CACHE_DIR, exist_ok=True)
            trim_video_cache()
            alog("video download", self.path, size=self.size)
            fails = 0
            with open(self.part, "wb") as out:
                src = None
                while not self.cancelled:
                    try:
                        if src is None:
                            src = open(self.path, "rb")
                            if self.have:
                                src.seek(self.have)     # continue where the connection broke
                        chunk = src.read(1 << 20)
                    except OSError as err:
                        # WebDAV through GVFS sometimes drops a long read ("Input/output error"),
                        # e.g. when the player reads the end of the video at the same time:
                        # open the file again and continue, instead of giving up.
                        fails += 1
                        alog("video RETRY", self.path, at=self.have, fails=fails, error=str(err)[:80])
                        try:
                            if src is not None:
                                src.close()
                        except OSError:
                            pass
                        src = None
                        if fails > 12:
                            raise
                        time.sleep(min(5, fails))
                        continue
                    if not chunk:
                        break
                    fails = 0
                    out.write(chunk)
                    out.flush()
                    with self.cond:
                        self.have += len(chunk)
                        self.cond.notify_all()
                if src is not None:
                    src.close()
            if self.have < self.size and not self.cancelled:
                raise OSError(f"only {self.have} of {self.size} bytes arrived")
            if self.cancelled:
                os.remove(self.part)
                return
            os.replace(self.part, self.final)
            with self.cond:
                self.done, self.have = True, max(self.have, self.size)
                self.cond.notify_all()
            alog("video downloaded", self.path, took=f"{time.monotonic() - self.started:.1f}s")
        except Exception as err:
            with self.cond:
                self.error = str(err)[:200]
                self.cond.notify_all()
            alog("video ERROR", self.path, error=self.error)

    def cancel(self):
        if not self.done:
            self.cancelled = True
            with self.cond:
                self.cond.notify_all()

    def read(self, pos, length):
        """Bytes for the player: from the cache when here (waiting a little if they are about to
        arrive), otherwise directly from the drive."""
        with self.cond:
            while not self.done and not self.error and not self.cancelled \
                    and self.have < pos + 1 and pos < self.have + (16 << 20):
                self.cond.wait(1.0)
            here = self.have > pos
        if here:
            with open(self.file, "rb") as f:
                f.seek(pos)
                return f.read(min(length, self.have - pos))
        for attempt in range(4):  # far ahead (e.g. the index at the end): straight from the drive
            try:
                with open(self.path, "rb") as f:
                    f.seek(pos)
                    return f.read(length)
            except OSError as err:
                alog("video read RETRY", self.path, at=pos, error=str(err)[:80])
                if attempt == 3:
                    raise
                time.sleep(1 + attempt)


class _VideoServer:
    """A tiny web server on this computer only (127.0.0.1) that hands network videos to the player
    while they download, so playback can start before the whole file is here."""
    downloads = {}
    port = None
    _lock = threading.Lock()

    @classmethod
    def url_for(cls, dl):
        import http.server
        with cls._lock:
            if cls.port is None:
                class Handler(http.server.BaseHTTPRequestHandler):
                    protocol_version = "HTTP/1.1"

                    def log_message(self, *args):
                        pass

                    def do_GET(self):
                        token = self.path.strip("/").split("/")[-1].split(".")[0]
                        d = cls.downloads.get(token)
                        if d is None:
                            self.send_error(404)
                            return
                        start, end = 0, d.size - 1
                        rng = self.headers.get("Range", "")
                        m = re.match(r"bytes=(\d*)-(\d*)", rng)
                        if m:
                            if m.group(1):
                                start = int(m.group(1))
                                if m.group(2):
                                    end = min(int(m.group(2)), d.size - 1)
                            elif m.group(2):
                                start = max(0, d.size - int(m.group(2)))
                        if start > end:
                            self.send_error(416)
                            return
                        self.send_response(206 if m else 200)
                        ctype = {"mp4": "video/mp4", "m4v": "video/mp4", "mov": "video/quicktime",
                                 "mkv": "video/x-matroska", "webm": "video/webm", "avi": "video/x-msvideo"}
                        self.send_header("Content-Type", ctype.get(os.path.splitext(d.path)[1][1:].lower(),
                                                                   "application/octet-stream"))
                        self.send_header("Accept-Ranges", "bytes")
                        self.send_header("Content-Length", str(end - start + 1))
                        if m:
                            self.send_header("Content-Range", f"bytes {start}-{end}/{d.size}")
                        self.end_headers()
                        pos = start
                        try:
                            while pos <= end and not d.cancelled:
                                data = d.read(pos, min(1 << 20, end - pos + 1))
                                if not data:
                                    break
                                self.wfile.write(data)
                                pos += len(data)
                        except (BrokenPipeError, ConnectionResetError, OSError):
                            pass

                server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
                server.daemon_threads = True
                cls.port = server.server_address[1]
                threading.Thread(target=server.serve_forever, name="video-server", daemon=True).start()
            token = hashlib.md5(dl.final.encode()).hexdigest()[:16]
            cls.downloads[token] = dl
        return f"http://127.0.0.1:{cls.port}/v/{token}{os.path.splitext(dl.path)[1].lower()}"


class BufferSlider(QSlider):
    """The position slider; the part already downloaded is shown in a lighter colour."""

    def __init__(self):
        super().__init__(Qt.Orientation.Horizontal)
        self.buffered = 1.0

    def paintEvent(self, e):
        if self.buffered < 1.0:
            p = QPainter(self)
            groove = self.rect().adjusted(8, self.height() // 2 - 2, -8, -(self.height() // 2 - 2))
            p.fillRect(groove, QColor(255, 255, 255, 40))
            done = QRect(groove)
            done.setWidth(int(groove.width() * max(0.0, min(1.0, self.buffered))))
            p.fillRect(done, QColor(255, 255, 255, 90))
            p.end()
        super().paintEvent(e)


class VideoPane(QWidget):
    """Plays a video inside the viewer: play/pause, position, sound, full screen. Network videos
    start as soon as enough has arrived to play through without stopping ("smart start")."""
    finished_download = pyqtSignal(str, str)   # original path, downloaded copy

    def __init__(self, viewer):
        super().__init__(viewer)
        from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer
        from PyQt6.QtMultimediaWidgets import QVideoWidget
        self.viewer = viewer
        self.QMediaPlayer = QMediaPlayer
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self.video = QVideoWidget(self)
        self.player.setVideoOutput(self.video)
        self.setStyleSheet("QWidget#vbar { background: #111; } QLabel { color: #ddd; } "
                           "QPushButton { color: #eee; background: #2a2a2a; border: none; padding: 6px 12px; "
                           "border-radius: 6px; } QPushButton:hover { background: #3a3a3a; }")
        self.play_btn = QPushButton("Play")
        self.back_btn = QPushButton("« 10 s")
        self.back_btn.setToolTip("10 seconds back")
        self.fwd_btn = QPushButton("10 s »")
        self.fwd_btn.setToolTip("10 seconds forward")
        self.slider = BufferSlider()
        self.slider.setRange(0, 0)
        self.time = QLabel("0:00 / 0:00")
        self.mute_btn = QPushButton("Sound on")
        self.full_btn = QPushButton("Full screen")
        self.ext_btn = QPushButton("Other player")
        self.ext_btn.setToolTip("Play this video in your usual video player (e.g. VLC or Celluloid)")
        self.resolution = ""
        self.status = QLabel("")
        bar = QWidget()
        bar.setObjectName("vbar")
        row = QHBoxLayout(bar)
        row.setContentsMargins(10, 6, 10, 6)
        for w in (self.back_btn, self.play_btn, self.fwd_btn, self.slider, self.time, self.status, self.mute_btn,
                  self.full_btn, self.ext_btn):
            w.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            row.addWidget(w, 1 if w is self.slider else 0)
        # while a network video buffers, a message in the middle (on its thumbnail) instead of black
        self.msg_page = QWidget()
        self.msg_page.setStyleSheet("background: #000;")
        self.poster = QLabel(self.msg_page)
        self.poster.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.poster.setStyleSheet("background: transparent;")
        self.big = QLabel(self.msg_page)
        self.big.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.big.setWordWrap(True)
        self.big.setStyleSheet("color: #fff; background: rgba(0,0,0,170); border-radius: 14px; "
                               "padding: 18px 28px; font-size: 20px;")
        self.msg_page.installEventFilter(self)
        self.stack = QStackedWidget()
        self.stack.addWidget(self.video)
        self.stack.addWidget(self.msg_page)
        self.poster_img = QImage()
        self.known_length = 0           # seconds, from the thumbnail or ffprobe
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.stack, 1)
        lay.addWidget(bar)
        self.bar = bar
        self.video.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.video.installEventFilter(self)
        self.play_btn.clicked.connect(self.toggle)
        self.back_btn.clicked.connect(lambda: self.skip(-10_000))
        self.fwd_btn.clicked.connect(lambda: self.skip(10_000))
        self.mute_btn.clicked.connect(self.toggle_mute)
        self.full_btn.clicked.connect(viewer.toggle_full_screen)
        self.ext_btn.clicked.connect(self.open_external)
        self.player.metaDataChanged.connect(self._metadata)
        self.slider.sliderMoved.connect(self.player.setPosition)
        self.player.positionChanged.connect(self._position)
        self.player.durationChanged.connect(self._duration)
        self.player.playbackStateChanged.connect(self._state)
        self.player.errorOccurred.connect(self._error)
        self.download, self.path, self.waiting = None, None, False
        self.pending = None             # a video waiting for its play click: (path, size, mtime)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        # full screen: the control bar hides after 3 s and comes back with the mouse at the bottom
        self._bar_seen = 0.0
        self.bar_timer = QTimer(self)
        self.bar_timer.setInterval(300)
        self.bar_timer.timeout.connect(self._auto_bar)

    def eventFilter(self, obj, e):
        if obj is self.msg_page and e.type() == QEvent.Type.Resize:
            self._layout_msg()
            return False
        if e.type() == QEvent.Type.MouseButtonDblClick:
            self.viewer.toggle_full_screen()
            return True
        if e.type() == QEvent.Type.MouseButtonPress and e.button() == Qt.MouseButton.LeftButton:
            self.toggle()
            return True
        return False

    def open(self, path, size, mtime):
        """Shows the video's picture with a play symbol; it starts when you click."""
        self.stop()
        self.path = path
        self.pending = (path, size, mtime)
        self.slider.buffered = 1.0
        self._bar_seen = time.monotonic()
        self.bar.show()
        self.bar_timer.start()
        self._load_poster(path, mtime)
        self._message("▶\nClick to play")
        self.status.setText("")

    def _begin(self, path, size, mtime):
        self.pending = None
        self.status.setText("")
        if is_remote(path):
            self.download = VideoDownload(path, size, mtime)
            self.player.setSource(QUrl(_VideoServer.url_for(self.download)))
            self.waiting = True
            self._message("Buffering…")
            self.timer.start(500)
        else:
            self._message(None)
            self.player.setSource(QUrl.fromLocalFile(path))
            self.player.play()

    def _auto_bar(self):
        if not self.viewer.isFullScreen():
            if self.bar.isHidden():
                self.bar.show()
            return
        pos = self.mapFromGlobal(QCursor.pos())
        if self.rect().contains(pos) and pos.y() >= self.height() * 0.85:
            self._bar_seen = time.monotonic()
            if self.bar.isHidden():
                self.bar.show()
        elif not self.bar.isHidden() and time.monotonic() - self._bar_seen > 3 and not self.bar.underMouse():
            self.bar.hide()

    # -- the message in the middle while buffering
    def _load_poster(self, path, mtime):
        """The video's thumbnail as background, and its length if the thumbnail knows it
        (otherwise ffprobe finds it in the background)."""
        self.poster_img, self.known_length = QImage(), 0
        for folder in (CACHE_DIR, CACHE_DIR_NORMAL):
            _, cache = thumb_cache_file(path, folder)
            img = QImage()
            if os.path.exists(cache) and img.load(cache):
                self.poster_img = img
                try:
                    self.known_length = int(img.text("Thumb::Movie::Length") or 0)
                except ValueError:
                    self.known_length = 0
                break
        if not self.known_length and shutil.which("ffprobe"):
            want = path

            def probe():
                n = video_length(path, timeout=40)
                if n and self.path == want:
                    self.known_length = n
            threading.Thread(target=probe, name="video-length", daemon=True).start()
        self._layout_msg()

    def _layout_msg(self):
        r = self.msg_page.rect()
        self.poster.setGeometry(r)
        if not self.poster_img.isNull() and r.width() > 0:
            pm = QPixmap.fromImage(self.poster_img).scaled(
                r.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            dim = QPixmap(pm.size())             # darkened, so the text stays readable
            dim.fill(Qt.GlobalColor.black)
            p = QPainter(dim)
            p.setOpacity(0.45)
            p.drawPixmap(0, 0, pm)
            p.end()
            self.poster.setPixmap(dim)
        else:
            self.poster.clear()
        w = min(r.width() - 40, 620)
        self.big.setFixedWidth(max(200, w))
        self.big.adjustSize()
        self.big.move((r.width() - self.big.width()) // 2, (r.height() - self.big.height()) // 2)
        self.big.raise_()

    def _message(self, text):
        """Shows `text` in the middle of the video and in the bar; None goes back to the video."""
        if text is None:
            self.status.setText("")
            self.stack.setCurrentWidget(self.video)
            return
        self.status.setText(text.split("\n")[0])
        self.big.setText(text)
        self.stack.setCurrentWidget(self.msg_page)
        self._layout_msg()

    def _start_playing(self):
        self.waiting = False
        self._message(None)
        self.player.play()

    def _tick(self):
        d = self.download
        if d is None:
            self.timer.stop()
            return
        self.slider.buffered = 1.0 if d.done else (d.have / d.size if d.size else 0.0)
        self.slider.update()
        if d.error and not d.done:
            self._message("Download failed:\n" + d.error[:80])
            self.timer.stop()
            return
        if d.done:
            if self.waiting:
                self._start_playing()
            self.timer.stop()
            self.finished_download.emit(d.path, d.final)
            return
        if not self.waiting:
            return
        pct = int(100 * d.have / max(1, d.size))
        speed = d.speed()
        rate = f" · {speed / 1048576:.1f} MB/s" if speed > 0 else ""
        hint = "\nClick to play now"
        if setting("video_download_first", False, bool):
            left = (d.size - d.have) / speed if speed > 0 else 0
            eta = f"\nready in about {fmt_wait(left)}" if left > 0 and time.monotonic() - d.started >= 1.0 else ""
            self._message(f"Downloading… {pct} %{rate}{eta}{hint}")
            return
        dur = self.player.duration() / 1000.0 or float(self.known_length)
        if dur <= 0 or speed <= 0 or time.monotonic() - d.started < 1.0:
            self._message(f"Buffering… {pct} %{rate}{hint}")
            return
        need = (d.size - d.have) / speed      # seconds until the whole file is here
        wait = need - dur * 0.9               # start so the download stays ahead to the end
        if wait <= 0 and d.have >= min(d.size, 2 << 20):
            self._start_playing()
        else:
            self._message(f"Buffering… {pct} %{rate}\nstarts in about {fmt_wait(max(wait, 1))}{hint}")

    def skip(self, ms):
        """10 seconds back or forward."""
        if self.pending is not None:
            return
        dur = self.player.duration()
        pos = self.player.position() + ms
        self.player.setPosition(max(0, min(pos, dur - 500) if dur > 0 else max(0, pos)))

    def toggle(self):
        if self.pending is not None:      # the first click starts the video
            self._begin(*self.pending)
            return
        if self.waiting:
            self._start_playing()     # play now, even before the smart start would
            return
        if self.player.playbackState() == self.QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def _metadata(self):
        try:
            from PyQt6.QtMultimedia import QMediaMetaData
            size = self.player.metaData().value(QMediaMetaData.Key.Resolution)
            self.resolution = f"{size.width()} × {size.height()}" if size and size.width() > 0 else ""
        except Exception:
            self.resolution = ""

    def open_external(self):
        """Plays the video in the usual video player (the downloaded copy, if it is complete)."""
        if not self.path:
            return
        self.player.pause()
        target = self.download.final if self.download is not None and self.download.done else self.path
        QDesktopServices.openUrl(QUrl.fromLocalFile(target))

    def toggle_mute(self):
        self.audio.setMuted(not self.audio.isMuted())
        self.mute_btn.setText("Sound off" if self.audio.isMuted() else "Sound on")

    def _position(self, ms):
        if not self.slider.isSliderDown():
            self.slider.setValue(ms)
        res = f"   ·   {self.resolution}" if self.resolution else ""
        self.time.setText(f"{fmt_length(ms // 1000) or '0:00'} / "
                          f"{fmt_length(self.player.duration() // 1000) or '0:00'}{res}")

    def _duration(self, ms):
        self.slider.setRange(0, ms)

    def _state(self, state):
        self.play_btn.setText("Pause" if state == self.QMediaPlayer.PlaybackState.PlayingState else "Play")

    def _error(self, *_args):
        msg = self.player.errorString() or "unknown error"
        self.stack.setCurrentWidget(self.video)
        self.status.setText("Can't play this video (" + msg[:60] + "). Missing codecs? "
                            "sudo apt install gstreamer1.0-libav gstreamer1.0-plugins-bad")
        alog("video play ERROR", self.path or "-", error=msg[:150])

    def stop(self):
        self.timer.stop()
        self.bar_timer.stop()
        self.pending = None
        self.player.stop()
        self.player.setSource(QUrl())
        if self.download is not None:
            self.download.cancel()
            self.download = None
        self.waiting = False
        self.stack.setCurrentWidget(self.video)


def fmt_wait(secs):
    secs = int(secs + 0.999)
    if secs < 60:
        return f"{secs} s"
    m, s = divmod(secs, 60)
    return f"{m} min {s:02d} s" if m < 60 else f"{m // 60} h {m % 60:02d} min"


def video_support_missing():
    """None when videos can be played, otherwise the command that installs what is missing."""
    try:
        import PyQt6.QtMultimedia  # noqa: F401
        import PyQt6.QtMultimediaWidgets  # noqa: F401
        return None
    except ImportError:
        return "sudo apt install python3-pyqt6.qtmultimedia gstreamer1.0-libav gstreamer1.0-plugins-good"


def share_by_email(paths, parent=None):
    """Opens the mail program (e.g. Thunderbird) with the photos attached."""
    paths = [p for p in paths if p]
    if not paths:
        return
    if shutil.which("xdg-email") is None:
        copyable_box("warning", parent, "Send by email", "The program 'xdg-email' is missing. "
                     "Install it with: sudo apt install xdg-utils")
        return
    cmd = ["xdg-email", "--subject", os.path.basename(paths[0]) if len(paths) == 1 else f"{len(paths)} photos"]
    for p in paths:
        cmd += ["--attach", p]
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError as err:
        copyable_box("warning", parent, "Send by email", f"Could not open the mail program:\n{err}")


def copy_files_to_clipboard(paths):
    """Puts the files on the clipboard, to paste them in the file manager or a chat app."""
    paths = [p for p in paths if p]
    if not paths:
        return
    md = QMimeData()
    md.setUrls([QUrl.fromLocalFile(p) for p in paths])
    uris = "\n".join(QUrl.fromLocalFile(p).toString() for p in paths)
    md.setData("x-special/gnome-copied-files", QByteArray(("copy\n" + uris).encode()))
    md.setData("text/uri-list", QByteArray((uris + "\r\n").encode()))
    QApplication.clipboard().setMimeData(md)


def add_share_menu(m, paths, parent):
    sub = m.addMenu("Share…")
    menu_add(sub, "Send by email…", lambda: share_by_email(paths, parent))
    menu_add(sub, "Copy files (to paste elsewhere)", lambda: copy_files_to_clipboard(paths))
    return sub


class Viewer(QWidget):
    closed = pyqtSignal(str)   # path of the last image shown
    changed = pyqtSignal()     # files were edited/rotated/deleted
    decoded = pyqtSignal(str, QImage)  # a photo was loaded (used to make thumbnails)
    thumb_made = pyqtSignal(str, float, QImage)  # a network video's thumbnail after playing it

    def __init__(self, files, index, slideshow=False, full=False, meta=None):
        super().__init__(None, Qt.WindowType.Window)
        self.meta = meta or {}  # path -> (size, mtime), for network videos
        self.vpane, self.video_msg = None, None
        self.start_full = full  # View → View full size: open the first photo at 100 %
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle(APP)
        self.files, self.i = list(files), index
        self.cache = {}
        self.signals = JobSignals()
        self.signals.image.connect(self._preloaded)
        self.pool = QThreadPool.globalInstance()
        self.pix, self.fit, self.zoom = None, True, 1.0
        self.pan, self.drag_from = QPointF(0, 0), None
        self.show_info, self.overlay_until, self.flash = False, 0.0, ""
        self.loading, self.requested = False, set()
        self.reduced = set()   # network photos shown at screen size (full size only on request)
        self.full_wanted = set()
        self.full_dims = {}    # path -> (width, height) of the original photo
        self.alive = True
        scr = QApplication.primaryScreen()
        g = scr.geometry() if scr else QRect(0, 0, 1920, 1080)
        ratio = scr.devicePixelRatio() if scr else 1.0
        self.screen_edge = int(max(g.width(), g.height()) * ratio)
        self.setMouseTracking(True)
        self.setMinimumSize(320, 240)
        self.slide = QTimer(self)
        self.slide.timeout.connect(self.slide_next)
        self.cursor_timer = QTimer(self)
        self.cursor_timer.setSingleShot(True)
        self.cursor_timer.timeout.connect(self._hide_cursor)
        self.overlay_timer = QTimer(self)
        self.overlay_timer.setSingleShot(True)
        self.overlay_timer.timeout.connect(self.update)
        self.bar_until, self.bar_buttons, self.bar_hover = 0.0, [], -1
        self.bar_timer = QTimer(self)
        self.bar_timer.setSingleShot(True)
        self.bar_timer.timeout.connect(self.update)
        self.hint_until = 0.0
        if not setting("viewer_hint_shown", False, bool):  # once: how to use the viewer
            self.hint_until = time.monotonic() + 8
            settings().setValue("viewer_hint_shown", True)
            QTimer.singleShot(8100, self.update)
        self.show_image()
        if full:
            self.show_full_size()
        if slideshow:
            self.toggle_slideshow()

    # -- loading
    def path(self):
        return self.files[self.i]

    def _start_job(self, path, full=False, first=False):
        """Network photos: their own small download pool per drive, shown at screen size
        (a 36-megapixel photo needs ~150 MB in memory at full size). The photo on screen
        (`first`) jumps ahead of photos that are only fetched in advance. Local photos: as before."""
        if is_remote(path):
            edge = None if full else self.screen_edge
            drive_pool("photo", path, threads=4).start(
                ImageJob(path, self.signals, max_edge=edge, wanted=self._still_wanted),
                10 if (first or full) else 0)
        else:
            self.pool.start(ImageJob(path, self.signals))

    def _still_wanted(self, path):
        """Called from the download thread: skip photos you have already moved away from."""
        if not self.alive:
            return False
        try:
            near = self.files[max(0, self.i - 1): self.i + 2]
        except Exception:
            return False
        return path in near or path in self.full_wanted

    def show_image(self, flash=""):
        self.want_100 = False
        path = self.path()
        image = self.cache.get(path)
        self.fit, self.zoom, self.pan = True, 1.0, QPointF(0, 0)
        self.setWindowTitle(f"{os.path.basename(path)} — {APP}")
        if is_video(path):
            self._show_video(path)
            self.poke_overlay(flash)
            self._forget_far()
            return
        self._hide_video()
        if image is None and is_remote(path):
            # network photo: load it in the background and show "Loading…" meanwhile.
            # The photos before/after are only fetched once this one is on screen.
            self.pix, self.loading = None, True
            if path not in self.requested:
                self.requested.add(path)
                self._start_job(path, first=True)
            self.poke_overlay(flash)
            self._forget_far()
            return
        else:
            if image is None:
                image = read_image(path)
                self.cache[path] = image
                self._report(path, image)
            self.loading = False
            self.pix = None if image.isNull() else QPixmap.fromImage(image)
        self.poke_overlay(flash)
        self.preload_neighbours()

    # -- videos
    def _show_video(self, path):
        self.pix, self.loading = None, False
        self.video_msg = video_support_missing()
        if self.video_msg:
            if self.vpane is not None:
                self.vpane.hide()
            self.update()
            if not getattr(Viewer, "_told_video", False):
                Viewer._told_video = True
                QTimer.singleShot(200, lambda: command_dialog(
                    self, "Video playback",
                    "To play videos, HansViewer needs Qt's video part and a few codecs. "
                    "Open a terminal, paste this command and press Enter:",
                    self.video_msg, "Then start HansViewer again."))
            return
        if self.vpane is None:
            self.vpane = VideoPane(self)
            self.vpane.finished_download.connect(self._video_downloaded)
        self.vpane.setGeometry(self.rect())
        self.vpane.show()
        self.vpane.raise_()
        size, mtime = self.meta.get(path, (0, 0))
        if not size:
            try:
                st = os.stat(path)
                size, mtime = st.st_size, st.st_mtime
            except OSError:
                pass
        self.vpane.open(path, size, mtime)

    def _hide_video(self):
        self.video_msg = None
        if self.vpane is not None:
            self.vpane.stop()
            self.vpane.hide()

    def _video_downloaded(self, path, copy):
        """A network video was played: its thumbnail is made from the downloaded copy."""
        mtime = self.meta.get(path, (0, 0))[1]
        if not mtime or cache_valid(path, mtime):
            return

        def work():
            img, _w, _h = video_thumbnail(path, mtime, True, source=copy)
            if not img.isNull() and self.alive:
                self.thumb_made.emit(path, float(mtime), img)

        threading.Thread(target=work, daemon=True).start()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self.vpane is not None:
            self.vpane.setGeometry(self.rect())

    def _report(self, path, image):
        if not image.isNull() and is_lazy(path):
            self.decoded.emit(path, image)

    def _near(self):
        return {self.files[j] for j in (self.i - 1, self.i, self.i + 1) if 0 <= j < len(self.files)}

    def _forget_far(self):
        wanted = self._near()
        self.cache = {p: img for p, img in self.cache.items() if p in wanted}
        self.requested &= wanted

    def preload_neighbours(self):
        wanted = self._near()
        self._forget_far()
        for p in wanted - self.cache.keys() - self.requested:
            if is_video(p):
                continue  # videos are only opened when shown
            self.requested.add(p)
            self._start_job(p)

    def _preloaded(self, path, image, info):
        info = info or {}
        if info.get("skipped"):
            self.requested.discard(path)
            self.full_wanted.discard(path)
            return
        if path in self.full_wanted and info.get("full", True):  # the full size asked for
            self.full_wanted.discard(path)
            if image.isNull() or not self.files or path != self.path():
                return
            old_w = self.pix.width() if self.pix else image.width()
            scale = self.current_scale()
            self.reduced.discard(path)
            self.cache[path] = image
            self.pix = QPixmap.fromImage(image)
            if getattr(self, "want_100", False):
                self.fit, self.zoom = False, 1.0
            elif not self.fit:  # keep the same view: same size on screen, now sharper
                self.zoom = scale * old_w / max(1, image.width())
            self.want_100 = False
            self.poke_overlay("Full size")
            return
        self.requested.discard(path)
        self._report(path, image)  # viewed-ahead photos get thumbnails too
        if not image.isNull() and not info.get("full", True):
            self.reduced.add(path)
            if info.get("dims"):
                self.full_dims[path] = tuple(info["dims"])
        near = self.files[max(0, self.i - 1): self.i + 2]
        if path in near and path not in self.cache:
            self.cache[path] = image
        if self.files and path == self.path() and self.loading:
            self.loading = False
            self.pix = None if image.isNull() else QPixmap.fromImage(image)
            self.poke_overlay()
            self.preload_neighbours()  # now fetch the photos before and after

    def show_full_size(self):
        """View → Show full size (right-click, key 1): the photo at 100 %. A network photo shown
        at screen size is fetched in full first; until then it shows "Loading full size…"."""
        if not self.files:
            return
        path = self.path()
        self.fit, self.zoom, self.pan = False, 1.0, QPointF(0, 0)
        if self.loading and path not in self.full_wanted:
            # still loading at screen size: fetch the full-size version as well (it goes first)
            self.reduced.add(path)
        if path in self.reduced:
            self.want_100 = True
            if path not in self.full_wanted:
                self.full_wanted.add(path)
                self._start_job(path, full=True)
            self.poke_overlay("Loading full size…")
        else:
            self.poke_overlay("Full size")

    def go(self, j, wrap=False):
        if not self.files:
            return
        if wrap:
            j %= len(self.files)
        j = max(0, min(len(self.files) - 1, j))
        if j != self.i:
            self.i = j
            self.show_image()

    # -- slideshow
    def toggle_slideshow(self):
        if self.slide.isActive():
            self.slide.stop()
            self.poke_overlay("Slideshow stopped")
        else:
            self.slide.start(int(setting("slideshow_secs", 4, int) * 1000))
            if not self.isFullScreen():
                self.showFullScreen()
            self.poke_overlay("Slideshow ▶")

    def slide_next(self):
        """Next photo in the slideshow; videos are skipped."""
        n = len(self.files)
        for step in range(1, n + 1):
            j = (self.i + step) % n
            if not is_video(self.files[j]):
                self.go(j, wrap=True)
                return
        self.toggle_slideshow()  # only videos here: stop

    # -- file actions
    def rotate(self, degrees):
        path = self.path()
        if is_video(path):
            self.poke_overlay("Videos can't be rotated here")
            return
        if rotate_file(path, degrees):
            self.cache.pop(path, None)
            self.show_image("Rotated and saved")
            self.changed.emit()
        else:
            self.poke_overlay("Can't save this file type")

    def delete(self):
        path = self.path()
        if setting("confirm_delete", True, bool):
            ans = QMessageBox.question(self, "Move to Trash",
                                       f"Move “{os.path.basename(path)}” to the Trash?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        if not move_to_trash(path):
            self.poke_overlay("Could not move to Trash")
            return
        self.changed.emit()
        del self.files[self.i]
        self.cache.pop(path, None)
        if not self.files:
            self.close()
            return
        self.i = min(self.i, len(self.files) - 1)
        self.show_image("Moved to Trash")

    def edit(self):
        if is_video(self.path()):
            self.poke_overlay("Videos can't be edited here")
            return
        self.slide.stop()
        dlg = EditorDialog(self.path(), self)
        dlg.saved.connect(lambda _p: self.changed.emit())
        dlg.exec()
        self.cache.pop(self.path(), None)
        self.show_image()

    # -- zoom
    def current_scale(self):
        if not self.pix:
            return 1.0
        if self.fit:
            return min(self.width() / self.pix.width(), self.height() / self.pix.height(), 1.0)
        return self.zoom

    def set_zoom(self, factor):
        self.zoom = max(0.05, min(32.0, self.current_scale() * factor))
        self.fit = False
        self.poke_overlay()

    def poke_overlay(self, flash=""):
        self.flash = flash
        self.overlay_until = time.monotonic() + 2.5
        self.overlay_timer.start(2600)
        self.update()

    def toggle_full_screen(self):
        """Full screen: only the photo, no taskbar or window title (double-click, F or the button)."""
        if self.isFullScreen():
            self.showMaximized() if getattr(self, "_was_maximized", True) else self.showNormal()
        else:
            self._was_maximized = self.isMaximized()
            self.showFullScreen()

    def fit_to_screen(self):
        self.fit, self.zoom, self.pan = True, 1.0, QPointF(0, 0)
        self.poke_overlay("Fit to screen")

    def show_bar(self, seconds=3.0):
        self.bar_until = time.monotonic() + seconds
        self.bar_timer.start(int(seconds * 1000) + 50)
        self.update()

    def _bar_items(self):
        full = self.isFullScreen()
        return [("Exit full screen" if full else "Full screen", self.toggle_full_screen),
                ("Full size", self.show_full_size), ("Fit", self.fit_to_screen),
                ("↺", lambda: self.rotate(-90)), ("↻", lambda: self.rotate(90)),
                ("Edit", self.edit), ("Close", self.close)]

    def _bar_hit(self, pos):
        if time.monotonic() >= self.bar_until:
            return -1
        for i, (rect, _fn) in enumerate(self.bar_buttons):
            if rect.contains(pos):
                return i
        return -1

    def _draw_bar(self, p):
        """The button bar at the bottom: appears when the mouse moves, hides after 3 seconds."""
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        fm = p.fontMetrics()
        items = self._bar_items()
        pad, gap, h = 16, 6, 34
        widths = [fm.horizontalAdvance(t) + 2 * pad for t, _ in items]
        total = sum(widths) + gap * (len(items) - 1) + 16
        x = (self.width() - total) / 2 + 8
        y = self.height() - 58 - 12 - h - 8
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 185))
        p.drawRoundedRect(QRectF(x - 8, y - 6, total, h + 12), 12, 12)
        self.bar_buttons = []
        for i, ((text, fn), w) in enumerate(zip(items, widths)):
            r = QRectF(x, y, w, h)
            p.setBrush(QColor(255, 255, 255, 60 if i == self.bar_hover else 22))
            p.drawRoundedRect(r, 8, 8)
            p.setPen(QColor("#f2f2f2"))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, text)
            p.setPen(Qt.PenStyle.NoPen)
            self.bar_buttons.append((r, fn))
            x += w + gap

    def _draw_hint(self, p):
        text = "Double-click or F: full screen   ·   1: full size   ·   Esc: back"
        fm = p.fontMetrics()
        w = fm.horizontalAdvance(text) + 48
        rect = QRectF((self.width() - w) / 2, 28, w, 40)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 190))
        p.drawRoundedRect(rect, 20, 20)
        p.setPen(QColor("#ffffff"))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)

    def _hide_cursor(self):
        if self.isFullScreen():
            self.setCursor(Qt.CursorShape.BlankCursor)

    # -- painting
    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(THEME["viewer"]))
        if self.pix:
            s = self.current_scale()
            w, h = self.pix.width() * s, self.pix.height() * s
            x = (self.width() - w) / 2 + (0 if self.fit else self.pan.x())
            y = (self.height() - h) / 2 + (0 if self.fit else self.pan.y())
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, s < 4)
            p.drawPixmap(QRectF(x, y, w, h), self.pix, QRectF(self.pix.rect()))
        elif self.loading:
            p.setPen(QColor("#aaaaaa"))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Loading…")
        elif self.files and is_video(self.path()):
            p.setPen(QColor("#bbbbbb"))
            p.drawText(self.rect().adjusted(40, 0, -40, 0), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap,
                       "To play videos, HansViewer needs Qt's video part (see the window with the command).\n\n"
                       "Meanwhile: in the thumbnail view, right-click → “Open with default app”.")
        else:
            p.setPen(QColor("#888888"))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Cannot open this image")
        now = time.monotonic()
        # the info line (name, number, size) only comes with the bar; messages such as
        # "Loading full size…" or "Rotated and saved" still show briefly on their own
        if self.show_info or now < self.bar_until or (now < self.overlay_until and self.flash):
            self._draw_overlay(p)
        if now < self.bar_until:
            self._draw_bar(p)
        else:
            self.bar_buttons = []
        if now < self.hint_until:
            self._draw_hint(p)

    def _draw_overlay(self, p):
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        parts = [os.path.basename(self.path()), f"{self.i + 1} / {len(self.files)}"]
        if self.pix and self.path() in self.reduced:
            w, h = self.full_dims.get(self.path(), (self.pix.width(), self.pix.height()))
            parts += [f"{w} × {h}", "screen size (1 = full size)"]
        elif self.pix:
            parts += [f"{self.pix.width()} × {self.pix.height()}",
                      f"{self.current_scale() * 100:.0f}%"]
        if self.slide.isActive():
            parts.append("▶ slideshow")
        if self.flash:
            parts.append(self.flash)
        text = "   ·   ".join(parts)
        fm = p.fontMetrics()
        w = min(self.width() - 40, fm.horizontalAdvance(text) + 36)
        rect = QRectF((self.width() - w) / 2, self.height() - 58, w, 36)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 175))
        p.drawRoundedRect(rect, 18, 18)
        p.setPen(QColor("#f2f2f2"))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter,
                   fm.elidedText(text, Qt.TextElideMode.ElideMiddle, int(w - 24)))

    # -- input
    def keyPressEvent(self, e):
        k, K = e.key(), Qt.Key
        if k in (K.Key_Right, K.Key_Left, K.Key_Space, K.Key_Backspace, K.Key_PageUp,
                 K.Key_PageDown, K.Key_Up, K.Key_Down, K.Key_Home, K.Key_End):
            self.hide_bar()
        ctrl = bool(e.modifiers() & Qt.KeyboardModifier.ControlModifier)
        if self.files and is_video(self.path()) and self.vpane is not None and self.vpane.isVisible() \
                and k in (K.Key_Space, K.Key_K, K.Key_M):
            self.vpane.toggle_mute() if k == K.Key_M else self.vpane.toggle()  # Space: play / pause
            return
        if k in (K.Key_Right, K.Key_Space, K.Key_PageDown, K.Key_Down):
            self.go(self.i + 1)
        elif k in (K.Key_Left, K.Key_Backspace, K.Key_PageUp, K.Key_Up):
            self.go(self.i - 1)
        elif k == K.Key_Home:
            self.go(0)
        elif k == K.Key_End:
            self.go(len(self.files) - 1)
        elif k in (K.Key_Plus, K.Key_Equal):
            self.set_zoom(1.25)
        elif k == K.Key_Minus:
            self.set_zoom(0.8)
        elif k in (K.Key_0, K.Key_Asterisk):
            self.fit, self.zoom, self.pan = not self.fit, 1.0, QPointF(0, 0)
            self.poke_overlay()
        elif k == K.Key_1:
            self.show_full_size()
        elif k in (K.Key_F, K.Key_F11):
            self.toggle_full_screen()
        elif k == K.Key_S:
            self.toggle_slideshow()
        elif k == K.Key_I:
            self.show_info = not self.show_info
            self.update()
        elif k == K.Key_BracketRight:
            self.rotate(90)
        elif k == K.Key_BracketLeft:
            self.rotate(-90)
        elif k == K.Key_E:
            self.edit()
        elif k == K.Key_Delete:
            self.delete()
        elif ctrl and k == K.Key_C and self.pix:
            QApplication.clipboard().setPixmap(self.pix)
            self.poke_overlay("Copied")
        elif k in (K.Key_Escape, K.Key_Return, K.Key_Enter):
            if k == K.Key_Escape and self.slide.isActive():
                self.toggle_slideshow()
            else:
                self.close()
        else:
            super().keyPressEvent(e)

    def hide_bar(self):
        if self.bar_until:
            self.bar_until, self.bar_hover = 0.0, -1
            self.update()

    def wheelEvent(self, e):
        self.hide_bar()  # scrolling through photos: no bar
        up = e.angleDelta().y() > 0
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.set_zoom(1.25 if up else 0.8)
        else:
            self.go(self.i - 1 if up else self.i + 1)

    def mousePressEvent(self, e):
        hit = self._bar_hit(e.position()) if e.button() == Qt.MouseButton.LeftButton else -1
        if hit >= 0:
            self._bar_pressed = True
            self.bar_buttons[hit][1]()
            return
        self._bar_pressed = False
        self.drag_from = e.position()

    def mouseMoveEvent(self, e):
        self.unsetCursor()
        self.cursor_timer.start(2000)
        hover = self._bar_hit(e.position()) if self.bar_buttons else -1
        in_zone = e.position().y() >= self.height() * 0.85  # the bar lives in the bottom strip
        if hover >= 0 or in_zone:
            self.show_bar(6.0 if hover >= 0 else 3.0)
        elif time.monotonic() < self.bar_until:
            self.show_bar(min(2.0, self.bar_until - time.monotonic()))  # left the strip: hides soon
        if hover != self.bar_hover:
            self.bar_hover = hover
            self.setCursor(Qt.CursorShape.PointingHandCursor if hover >= 0 else Qt.CursorShape.ArrowCursor)
        if self.drag_from is not None and not self.fit:
            self.pan += e.position() - self.drag_from
            self.drag_from = e.position()
            self.update()

    def mouseReleaseEvent(self, _):
        self.drag_from = None

    def mouseDoubleClickEvent(self, e):
        if self._bar_hit(e.position()) >= 0 or getattr(self, "_bar_pressed", False):
            return  # quick clicks on a button are not a double-click on the photo
        self.toggle_full_screen()

    def contextMenuEvent(self, e):
        m = QMenu(self)
        menu_add(m, "Next\tSpace", lambda: self.go(self.i + 1))
        menu_add(m, "Previous\tBackspace", lambda: self.go(self.i - 1))
        m.addSeparator()
        menu_add(m, "Slideshow\tS", self.toggle_slideshow)
        menu_add(m, "Show full size\t1", self.show_full_size)
        menu_add(m, "Fit to screen\t0", self.fit_to_screen)
        menu_add(m, "Exit full screen\tF" if self.isFullScreen() else "Full screen\tF  (double-click)",
                 self.toggle_full_screen)
        m.addSeparator()
        menu_add(m, "Rotate left\t[", lambda: self.rotate(-90))
        menu_add(m, "Rotate right\t]", lambda: self.rotate(90))
        menu_add(m, "Edit…\tE", self.edit)
        menu_add(m, "Copy image\tCtrl+C", lambda: QApplication.clipboard().setPixmap(self.pix)
                 if self.pix else None)
        menu_add(m, "Set as wallpaper", self._wallpaper)
        add_share_menu(m, [self.path()], self)
        m.addSeparator()
        menu_add(m, "Move to Trash\tDel", self.delete)
        menu_add(m, "Back to browser\tEsc", self.close)
        m.exec(e.globalPos())

    def _wallpaper(self):
        self.poke_overlay("Wallpaper set" if set_wallpaper(self.path())
                          else "Couldn't set wallpaper on this desktop")

    def _check_brightness(self):
        """Brighter screen while a photo is open in the viewer (maximized, normal window or full
        screen); back to normal when it is minimized or closed. Checked on every window change
        and twice a second."""
        on = bool(self.isVisible() and not self.isMinimized()
                  and not self.windowState() & Qt.WindowState.WindowMinimized)
        if on != getattr(self, "_bright_on", False):
            self._bright_on = on
            alog("viewer open" if on else "viewer hidden", "-")
            Brightness.up() if on else Brightness.down()

    def changeEvent(self, e):
        super().changeEvent(e)
        if e.type() == QEvent.Type.WindowStateChange:
            QTimer.singleShot(0, self._check_brightness)

    def showEvent(self, e):
        super().showEvent(e)
        if not hasattr(self, "_bright_timer"):
            self._bright_timer = QTimer(self)
            self._bright_timer.timeout.connect(self._check_brightness)
            self._bright_timer.start(500)
        QTimer.singleShot(300, self._check_brightness)

    def closeEvent(self, e):
        self._hide_video()
        if hasattr(self, "_bright_timer"):
            self._bright_timer.stop()
        self._bright_on = False
        Brightness.down()  # does nothing if the brightness wasn't raised
        self.alive = False  # queued downloads for this viewer are skipped
        self.slide.stop()
        self.closed.emit(self.path() if self.files else "")
        super().closeEvent(e)


# ======================================================================= editor
class EditCanvas(QWidget):
    selection_changed = pyqtSignal()
    area_drawn = pyqtSignal(QRectF)    # blur mode: a rectangle was drawn (image coordinates)

    def __init__(self):
        super().__init__()
        self.pix, self.full = None, QSize()
        self.crop_mode, self.sel, self.aspect, self.start = False, None, None, None
        self.blur_mode = False
        self.setMinimumSize(480, 360)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_image(self, display, full_size):
        self.pix = QPixmap.fromImage(display)
        self.full = QSize(full_size)
        self.update()

    def target(self):
        if not self.pix:
            return QRectF()
        m = 20
        s = min((self.width() - 2 * m) / self.pix.width(),
                (self.height() - 2 * m) / self.pix.height(), 1.0 * self.full.width() / self.pix.width())
        w, h = self.pix.width() * s, self.pix.height() * s
        return QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)

    def to_image(self, pos):
        t = self.target()
        x = (pos.x() - t.x()) / t.width() * self.full.width()
        y = (pos.y() - t.y()) / t.height() * self.full.height()
        return QPointF(max(0.0, min(self.full.width(), x)), max(0.0, min(self.full.height(), y)))

    def to_widget(self, r):
        t = self.target()
        sx, sy = t.width() / self.full.width(), t.height() / self.full.height()
        return QRectF(t.x() + r.x() * sx, t.y() + r.y() * sy, r.width() * sx, r.height() * sy)

    def mousePressEvent(self, e):
        if (self.crop_mode or self.blur_mode) and self.pix:
            self.start = self.to_image(e.position())
            self.sel = None
            self.update()

    def mouseMoveEvent(self, e):
        if self.start is None:
            return
        cur = self.to_image(e.position())
        sx, sy = self.start.x(), self.start.y()
        dx, dy = cur.x() - sx, cur.y() - sy
        maxw = self.full.width() - sx if dx >= 0 else sx
        maxh = self.full.height() - sy if dy >= 0 else sy
        w, h = abs(dx), abs(dy)
        if self.aspect and not self.blur_mode:
            w = min(max(w, h * self.aspect), maxw, maxh * self.aspect)
            h = w / self.aspect
        else:
            w, h = min(w, maxw), min(h, maxh)
        x = sx if dx >= 0 else sx - w
        y = sy if dy >= 0 else sy - h
        self.sel = QRectF(x, y, w, h)
        self.update()
        self.selection_changed.emit()

    def mouseReleaseEvent(self, _):
        self.start = None
        if self.sel is not None and (self.sel.width() < 2 or self.sel.height() < 2):
            self.sel = None
            self.update()
        if self.blur_mode and self.sel is not None:
            area, self.sel = QRectF(self.sel), None
            self.update()
            self.area_drawn.emit(area)
            return
        self.selection_changed.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(THEME["viewer"]))
        if not self.pix:
            return
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        t = self.target()
        p.drawPixmap(t, self.pix, QRectF(self.pix.rect()))
        if self.sel is not None and self.blur_mode:
            r = self.to_widget(self.sel)
            p.setPen(QPen(QColor(255, 255, 255), 2, Qt.PenStyle.DashLine))
            p.setBrush(QColor(255, 255, 255, 40))
            p.drawRect(r)
        elif self.sel is not None:
            r = self.to_widget(self.sel)
            shade = QPainterPath()
            shade.addRect(t)
            hole = QPainterPath()
            hole.addRect(r)
            p.fillPath(shade.subtracted(hole), QColor(0, 0, 0, 150))
            p.setPen(QPen(QColor(255, 255, 255, 90), 1))
            for i in (1, 2):
                p.drawLine(QPointF(r.x() + r.width() * i / 3, r.y()),
                           QPointF(r.x() + r.width() * i / 3, r.bottom()))
                p.drawLine(QPointF(r.x(), r.y() + r.height() * i / 3),
                           QPointF(r.right(), r.y() + r.height() * i / 3))
            p.setPen(QPen(QColor(THEME["accent"]), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(r)


class EditorDialog(QDialog):
    saved = pyqtSignal(str)
    ASPECTS = [("Free", None), ("Original", "orig"), ("1:1", 1.0), ("4:3", 4 / 3),
               ("3:2", 3 / 2), ("16:9", 16 / 9), ("3:4", 3 / 4), ("2:3", 2 / 3), ("9:16", 9 / 16)]

    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.path = path
        self.setWindowTitle(f"Edit — {os.path.basename(path)}")
        self.resize(1280, 820)
        self.image = read_image(path)
        self.undo, self.redo, self.dirty = [], [], False
        self.proxy = None
        self.last_blur = None      # (area, image before it): the strength can still be changed
        self.preview_timer = QTimer(self)
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self._live_preview)
        self._build()
        if self.image.isNull():
            copyable_box("warning", self, "Edit", "This image can't be opened for editing.")
            QTimer.singleShot(0, super().reject)
            return
        self._refresh()

    # -- UI
    def _build(self):
        self.canvas = EditCanvas()
        self.canvas.selection_changed.connect(self._sel_changed)
        self.canvas.area_drawn.connect(self._blur_area)

        tools = QWidget()
        tools.setObjectName("toolsPanel")
        col = QVBoxLayout(tools)
        col.setContentsMargins(12, 6, 12, 12)
        col.setSpacing(8)

        def button(text, slot, icon_names=None):
            b = QPushButton(text)
            if icon_names:
                b.setIcon(icon(icon_names))
            b.clicked.connect(slot)
            return b

        g = QGroupBox("Rotate & flip")
        gl = QGridLayout(g)
        gl.addWidget(button("Left", lambda: self._op(lambda im: rotate_qimage(im, -90)),
                            "object-rotate-left"), 0, 0)
        gl.addWidget(button("Right", lambda: self._op(lambda im: rotate_qimage(im, 90)),
                            "object-rotate-right"), 0, 1)
        gl.addWidget(button("Flip ↔", lambda: self._op(lambda im: flip_qimage(im, True)),
                            "object-flip-horizontal"), 1, 0)
        gl.addWidget(button("Flip ↕", lambda: self._op(lambda im: flip_qimage(im, False)),
                            "object-flip-vertical"), 1, 1)
        col.addWidget(g)

        g = QGroupBox("Crop")
        gl = QGridLayout(g)
        self.aspect_box = QComboBox()
        for label, _ in self.ASPECTS:
            self.aspect_box.addItem(label)
        self.aspect_box.currentIndexChanged.connect(self._aspect_changed)
        self.crop_btn = QPushButton("Select area")
        self.crop_btn.setCheckable(True)
        self.crop_btn.toggled.connect(self._crop_mode)
        self.apply_crop_btn = button("Apply crop", self._apply_crop, "transform-crop")
        self.apply_crop_btn.setObjectName("primary")
        self.sel_label = QLabel("Drag on the image")
        self.sel_label.setObjectName("muted")
        gl.addWidget(QLabel("Ratio"), 0, 0)
        gl.addWidget(self.aspect_box, 0, 1)
        gl.addWidget(self.crop_btn, 1, 0)
        gl.addWidget(self.apply_crop_btn, 1, 1)
        gl.addWidget(self.sel_label, 2, 0, 1, 2)
        col.addWidget(g)

        g = QGroupBox("Blur (number plates, faces)")
        gl = QGridLayout(g)
        self.blur_btn = QPushButton("Draw areas")
        self.blur_btn.setCheckable(True)
        self.blur_btn.setToolTip("Drag a rectangle over each number plate or face. "
                                 "Every area can be undone on its own (Ctrl+Z).")
        self.blur_btn.toggled.connect(self._blur_mode)
        self.blur_kind = QComboBox()
        self.blur_kind.addItems(["Blur", "Pixelate"])
        self.blur_strength = QSlider(Qt.Orientation.Horizontal)
        self.blur_strength.setRange(1, 100)
        self.blur_strength.setValue(setting("blur_strength", 60, int))
        self.blur_kind.setCurrentIndex(1 if setting("blur_kind", "blur", str) == "pixelate" else 0)
        self.blur_kind.currentIndexChanged.connect(self._blur_settings_changed)
        self.blur_strength.sliderReleased.connect(self._blur_settings_changed)
        self.blur_strength.valueChanged.connect(
            lambda _v: None if self.blur_strength.isSliderDown() else self._blur_settings_changed())
        self.no_gps = QCheckBox("Remove location (GPS) from the copy")
        self.no_gps.setChecked(setting("blur_no_gps", True, bool))
        self.no_gps.toggled.connect(lambda on: settings().setValue("blur_no_gps", on))
        copy_b = button("Save as copy…", self._save_copy, "document-save-as")
        copy_b.setObjectName("primary")
        copy_b.setToolTip("Saves the edited photo next to the original as …_blurred, "
                          "the original stays as it is")
        self.blur_label = QLabel("Click “Draw areas”, then drag over each plate or face")
        self.blur_label.setObjectName("muted")
        self.blur_label.setWordWrap(True)
        gl.addWidget(self.blur_btn, 0, 0)
        gl.addWidget(self.blur_kind, 0, 1)
        gl.addWidget(QLabel("Strength"), 1, 0)
        gl.addWidget(self.blur_strength, 1, 1)
        gl.addWidget(self.blur_label, 2, 0, 1, 2)
        gl.addWidget(self.no_gps, 3, 0, 1, 2)
        gl.addWidget(copy_b, 4, 0, 1, 2)
        col.addWidget(g)

        g = QGroupBox("Resize")
        gl = QGridLayout(g)
        self.w_spin, self.h_spin = QSpinBox(), QSpinBox()
        for s in (self.w_spin, self.h_spin):
            s.setRange(1, 40000)
            s.setSuffix(" px")
        self.keep_aspect = QCheckBox("Keep proportions")
        self.keep_aspect.setChecked(True)
        self.w_spin.valueChanged.connect(lambda v: self._size_changed("w", v))
        self.h_spin.valueChanged.connect(lambda v: self._size_changed("h", v))
        self.pct_box = QComboBox()
        self.pct_box.addItems(["Preset…", "75%", "50%", "33%", "25%", "Long edge 3840",
                               "Long edge 1920", "Long edge 1280"])
        self.pct_box.activated.connect(self._preset_size)
        gl.addWidget(QLabel("Width"), 0, 0)
        gl.addWidget(self.w_spin, 0, 1)
        gl.addWidget(QLabel("Height"), 1, 0)
        gl.addWidget(self.h_spin, 1, 1)
        gl.addWidget(self.keep_aspect, 2, 0, 1, 2)
        gl.addWidget(self.pct_box, 3, 0)
        b = button("Apply size", self._apply_resize)
        b.setObjectName("primary")
        gl.addWidget(b, 3, 1)
        col.addWidget(g)

        g = QGroupBox("Adjust")
        gl = QGridLayout(g)
        self.sliders = {}
        for row, (key, label) in enumerate((("brightness", "Brightness"), ("contrast", "Contrast"),
                                            ("saturation", "Saturation"), ("warmth", "Warmth"))):
            sl = QSlider(Qt.Orientation.Horizontal)
            sl.setRange(-100, 100)
            val = QLabel("0")
            val.setObjectName("muted")
            val.setMinimumWidth(30)
            sl.valueChanged.connect(lambda v, lab=val: (lab.setText(str(v)),
                                                        self.preview_timer.start(40)))
            sl.sliderReleased.connect(lambda: self.preview_timer.start(0))
            self.sliders[key] = sl
            gl.addWidget(QLabel(label), row, 0)
            gl.addWidget(sl, row, 1)
            gl.addWidget(val, row, 2)
        reset = button("Reset", self._reset_sliders)
        apply_b = button("Apply", self._commit_adjust)
        apply_b.setObjectName("primary")
        gl.addWidget(reset, 4, 0)
        gl.addWidget(apply_b, 4, 1, 1, 2)
        if np is None:
            g.setEnabled(False)
            note = QLabel("Install python3-numpy to enable")
            note.setObjectName("muted")
            gl.addWidget(note, 5, 0, 1, 3)
        col.addWidget(g)

        g = QGroupBox("Effects")
        gl = QGridLayout(g)
        effects = [("Auto levels", "autolevels"), ("Sharpen", "sharpen"),
                   ("Black & white", "grayscale"), ("Sepia", "sepia"), ("Invert", "invert")]
        for n, (label, key) in enumerate(effects):
            b = button(label, lambda _=False, k=key: self._op(lambda im: filter_image(im, k)))
            b.setEnabled(np is not None or key == "grayscale")
            gl.addWidget(b, n // 2, n % 2)
        col.addWidget(g)

        g = QGroupBox("History")
        gl = QGridLayout(g)
        self.undo_btn = button("Undo", self._undo, "edit-undo")
        self.redo_btn = button("Redo", self._redo, "edit-redo")
        gl.addWidget(self.undo_btn, 0, 0)
        gl.addWidget(self.redo_btn, 0, 1)
        gl.addWidget(button("Revert to original", self._revert, "document-revert"), 1, 0, 1, 2)
        col.addWidget(g)
        col.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidget(tools)
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(320)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.info = QLabel()
        self.info.setObjectName("muted")
        self.quality = QSpinBox()
        self.quality.setRange(30, 100)
        self.quality.setValue(setting("jpeg_quality", 92, int))
        self.quality.setPrefix("Quality ")
        self.quality.setToolTip("JPEG / WebP quality when saving")
        save = button("Save", self._save, "document-save")
        save.setObjectName("primary")
        save_as = button("Save as…", self._save_as, "document-save-as")
        close = button("Close", self.reject)
        bottom = QHBoxLayout()
        bottom.setContentsMargins(14, 8, 14, 10)
        bottom.addWidget(self.info, 1)
        bottom.addWidget(self.quality)
        bottom.addWidget(close)
        bottom.addWidget(save_as)
        bottom.addWidget(save)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(0)
        top.addWidget(self.canvas, 1)
        top.addWidget(scroll)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addLayout(top, 1)
        bar = QFrame()
        bar.setLayout(bottom)
        bar.setObjectName("toolsPanel")
        lay.addWidget(bar)

        for seq, slot in (("Ctrl+Z", self._undo), ("Ctrl+Y", self._redo),
                          ("Ctrl+Shift+Z", self._redo), ("Ctrl+S", self._save)):
            a = QAction(self)
            a.setShortcut(QKeySequence(seq))
            a.triggered.connect(slot)
            self.addAction(a)

    # -- state
    def _adjust_values(self):
        return {k: s.value() for k, s in self.sliders.items()}

    def _refresh(self):
        img = self.image
        big = max(img.width(), img.height())
        self.proxy = img if big <= 1600 else img.scaled(
            1600, 1600, Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self._live_preview()
        for spin, v in ((self.w_spin, img.width()), (self.h_spin, img.height())):
            spin.blockSignals(True)
            spin.setValue(v)
            spin.blockSignals(False)
        self.undo_btn.setEnabled(bool(self.undo))
        self.redo_btn.setEnabled(bool(self.redo))
        self.info.setText(f"{img.width()} × {img.height()}" + ("   ·   edited" if self.dirty else ""))
        self.setWindowTitle(f"Edit — {os.path.basename(self.path)}" + (" *" if self.dirty else ""))
        self._sel_changed()

    def _live_preview(self):
        if self.proxy is None:
            return
        shown = adjust_image(self.proxy, **self._adjust_values())
        self.canvas.set_image(shown, self.image.size())

    def _push(self, new_image):
        if new_image is None or new_image.isNull():
            return
        self.undo.append(self.image)
        del self.undo[:-15]
        self.redo.clear()
        self.last_blur = None
        self.image = new_image
        self.dirty = True
        self._refresh()

    def _op(self, fn):
        self._commit_adjust()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self._push(fn(self.image))
        finally:
            QApplication.restoreOverrideCursor()

    def _commit_adjust(self):
        vals = self._adjust_values()
        if any(vals.values()):
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            try:
                new = adjust_image(self.image, **vals)
            finally:
                QApplication.restoreOverrideCursor()
            self._reset_sliders(refresh=False)
            self._push(new)

    def _reset_sliders(self, refresh=True):
        for s in self.sliders.values():
            s.setValue(0)
        if refresh:
            self._live_preview()

    def _undo(self):
        self.last_blur = None
        if self.undo:
            self.redo.append(self.image)
            self.image = self.undo.pop()
            self.dirty = True
            self._refresh()

    def _redo(self):
        self.last_blur = None
        if self.redo:
            self.undo.append(self.image)
            self.image = self.redo.pop()
            self.dirty = True
            self._refresh()

    def _revert(self):
        orig = read_image(self.path)
        if not orig.isNull():
            self._reset_sliders(refresh=False)
            self._push(orig)
            self.dirty = False
            self._refresh()

    # -- crop
    def _aspect_changed(self, i):
        a = self.ASPECTS[i][1]
        if a == "orig":
            a = self.image.width() / max(1, self.image.height())
        self.canvas.aspect = a
        self.canvas.sel = None
        self.canvas.update()
        self._sel_changed()

    # -- blur
    def _blur_mode(self, on):
        if on and self.crop_btn.isChecked():
            self.crop_btn.setChecked(False)
        self.canvas.blur_mode = on
        self.canvas.sel = None
        self.canvas.setCursor(Qt.CursorShape.CrossCursor if on else Qt.CursorShape.ArrowCursor)
        self.canvas.update()
        self.blur_label.setText("Drag over each number plate or face. Ctrl+Z undoes the last area."
                                if on else "Click “Draw areas”, then drag over each plate or face")

    def _blur_params(self):
        return ("pixelate" if self.blur_kind.currentIndex() == 1 else "blur"), self.blur_strength.value()

    def _blur_area(self, area):
        mode, strength = self._blur_params()
        self._commit_adjust()
        before = self.image
        self._op(lambda im: blur_region(im, area, mode, strength))
        if self.image is not before:
            self.last_blur = (area, before)
            n = getattr(self, "_blur_count", 0) + 1
            self._blur_count = n
            self.blur_label.setText(f"{n} area{'s' if n != 1 else ''} done. Changing Blur/Pixelate or "
                                    "the strength changes the last area. Ctrl+Z undoes it.")

    def _blur_settings_changed(self, *_):
        mode, strength = self._blur_params()
        settings().setValue("blur_kind", mode)
        settings().setValue("blur_strength", strength)
        if self.last_blur is None:
            return
        area, before = self.last_blur       # redo the last area with the new setting
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self.image = blur_region(before, area, mode, strength)
        finally:
            QApplication.restoreOverrideCursor()
        self._refresh()

    def _save_copy(self):
        stem, ext = os.path.splitext(self.path)
        if not can_write(self.path):
            ext = ".jpg"
        stem = re.sub(r"_blurred(_\d+)?$", "", stem)
        name, n = f"{stem}_blurred{ext}", 2
        while os.path.exists(name):
            name, n = f"{stem}_blurred_{n}{ext}", n + 1
        dest, _ = QFileDialog.getSaveFileName(
            self, "Save as copy", name,
            "Images (*.jpg *.jpeg *.png *.webp *.tif *.tiff *.bmp);;All files (*)")
        if not dest:
            return
        if not os.path.splitext(dest)[1]:
            dest += ".jpg"
        if os.path.abspath(dest) == os.path.abspath(self.path):
            copyable_box("warning", self, "Save as copy", "Please choose a different name, "
                                                         "so the original stays as it is.")
            return
        if self._write(dest, src=self.path, strip_gps=self.no_gps.isChecked()):
            gps = " without location" if self.no_gps.isChecked() else ""
            self.path = dest
            self._refresh()
            self.info.setText(self.info.text() + f"   ·   saved copy{gps}: {os.path.basename(dest)}")

    def _crop_mode(self, on):
        if on and self.blur_btn.isChecked():
            self.blur_btn.setChecked(False)
        self.canvas.crop_mode = on
        self.canvas.setCursor(Qt.CursorShape.CrossCursor if on else Qt.CursorShape.ArrowCursor)
        if not on:
            self.canvas.sel = None
            self.canvas.update()
        self._sel_changed()

    def _sel_changed(self):
        sel = self.canvas.sel
        self.apply_crop_btn.setEnabled(sel is not None)
        if sel is not None:
            self.sel_label.setText(f"Selection {int(sel.width())} × {int(sel.height())}")
        else:
            self.sel_label.setText("Click “Select area”, then drag" if not self.canvas.crop_mode
                                   else "Drag on the image")

    def _apply_crop(self):
        sel = self.canvas.sel
        if sel is None:
            return
        rect = sel.toRect().intersected(self.image.rect())
        self.canvas.sel = None
        self.crop_btn.setChecked(False)
        self._op(lambda im: im.copy(rect))

    # -- resize
    def _size_changed(self, which, v):
        if not self.keep_aspect.isChecked() or self.image.isNull():
            return
        w0, h0 = self.image.width(), self.image.height()
        other = self.h_spin if which == "w" else self.w_spin
        val = round(v * h0 / w0) if which == "w" else round(v * w0 / h0)
        other.blockSignals(True)
        other.setValue(max(1, val))
        other.blockSignals(False)

    def _preset_size(self, i):
        text = self.pct_box.itemText(i)
        w0, h0 = self.image.width(), self.image.height()
        if text.endswith("%"):
            f = int(text[:-1]) / 100
        elif text.startswith("Long edge"):
            f = int(text.split()[-1]) / max(w0, h0)
        else:
            return
        self.w_spin.blockSignals(True)
        self.h_spin.blockSignals(True)
        self.w_spin.setValue(max(1, round(w0 * f)))
        self.h_spin.setValue(max(1, round(h0 * f)))
        self.w_spin.blockSignals(False)
        self.h_spin.blockSignals(False)
        self.pct_box.setCurrentIndex(0)

    def _apply_resize(self):
        w, h = self.w_spin.value(), self.h_spin.value()
        if (w, h) == (self.image.width(), self.image.height()):
            return
        self._op(lambda im: im.scaled(w, h, Qt.AspectRatioMode.IgnoreAspectRatio,
                                      Qt.TransformationMode.SmoothTransformation))

    # -- saving
    def _write(self, dest, src=None, strip_gps=False):
        self._commit_adjust()
        if not can_write(dest):
            copyable_box("warning", self, "Save", f"Saving as {norm_format(dest).upper()} isn't "
                                              "supported. Use Save as… and pick JPEG or PNG.")
            return False
        settings().setValue("jpeg_quality", self.quality.value())
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            ok = save_image(self.image, dest, src=src or self.path, quality=self.quality.value(),
                            strip_gps=strip_gps)
        finally:
            QApplication.restoreOverrideCursor()
        if not ok:
            copyable_box("warning", self, "Save", f"Could not save {dest}")
            return False
        self.dirty = False
        self._refresh()
        self.saved.emit(dest)
        return True

    def _save(self):
        if not self.dirty and not any(self._adjust_values().values()):
            return
        ans = QMessageBox.question(self, "Save", f"Overwrite “{os.path.basename(self.path)}” "
                                                 "with your changes?")
        if ans == QMessageBox.StandardButton.Yes:
            self._write(self.path)

    def _save_as(self):
        stem, ext = os.path.splitext(self.path)
        if not can_write(self.path):
            ext = ".jpg"
        dest, _ = QFileDialog.getSaveFileName(
            self, "Save as", f"{stem}_edited{ext}",
            "Images (*.jpg *.jpeg *.png *.webp *.tif *.tiff *.bmp);;All files (*)")
        if not dest:
            return
        if not os.path.splitext(dest)[1]:
            dest += ".jpg"
        if self._write(dest):
            self.path = dest

    def reject(self):
        if self.dirty or any(self._adjust_values().values()):
            box = QMessageBox(QMessageBox.Icon.Question, "Unsaved changes",
                              "Save your changes before closing?",
                              QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
                              | QMessageBox.StandardButton.Cancel, self)
            box.exec()
            ans = box.standardButton(box.clickedButton())
            if ans in (QMessageBox.StandardButton.Cancel, QMessageBox.StandardButton.NoButton):
                return
            if ans == QMessageBox.StandardButton.Save:
                if not self._write(self.path):
                    return
        super().reject()


# ======================================================================= dialogs
class BatchRenameDialog(QDialog):
    def __init__(self, entries, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Rename {len(entries)} files")
        self.resize(560, 460)
        self.entries = entries
        self.dates = [e.get("taken") or exif_date(e["path"]) or e["mtime"] for e in entries]
        self.pattern = QLineEdit("Photo ###")
        self.start = QSpinBox()
        self.start.setRange(0, 999999)
        self.start.setValue(1)
        help_ = QLabel("# = number (### → 001), {name} = old name, "
                       "{date} = date taken (or file date)")
        help_.setObjectName("muted")
        help_.setWordWrap(True)
        self.preview = QListWidget()
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                        | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        form = QFormLayout()
        form.addRow("New name", self.pattern)
        form.addRow("Start at", self.start)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(help_)
        lay.addWidget(self.preview, 1)
        lay.addWidget(self.buttons)
        self.pattern.textChanged.connect(self._update)
        self.start.valueChanged.connect(self._update)
        self._update()

    def new_names(self):
        pat, out = self.pattern.text(), []
        multi = len(self.entries) > 1 and "#" not in pat and "{name}" not in pat
        for i, e in enumerate(self.entries):
            n = self.start.value() + i
            stem, ext = os.path.splitext(e["name"])
            s = re.sub(r"#+", lambda m, n=n: str(n).zfill(len(m.group())), pat)
            s = s.replace("{name}", stem).replace(
                "{date}", time.strftime("%Y-%m-%d", time.localtime(self.dates[i])))
            if multi:
                s = f"{s} {n}"
            out.append(s.strip() + ext.lower())
        return out

    def _update(self):
        names = self.new_names()
        self.preview.clear()
        for e, n in list(zip(self.entries, names))[:300]:
            self.preview.addItem(f"{e['name']}   →   {n}")
        ok = (len(set(names)) == len(names) and all(n and "/" not in n for n in names)
              and self.pattern.text().strip())
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(bool(ok))


# ======================================================================= screen brightness
class Brightness:
    """Brighter screen while a photo is shown full screen, back to your own level afterwards.
    1) Built-in screens (laptops, all-in-ones): through the login manager (systemd-logind),
       which lets the signed-in user change the backlight with no password and no extra tool.
    2) Separate monitors: through `ddcutil` (DDC/CI), if it is installed and allowed.
    3) Neither: nothing happens. Changes run in the background, so the window never waits."""
    _lock = threading.Lock()

    @staticmethod
    def _s():
        return QSettings(APP_ID, APP_ID)  # own settings object: these run in background threads

    @staticmethod
    def _backlight():
        base = "/sys/class/backlight"
        try:
            devs = os.listdir(base)
        except OSError:
            return None
        def kind(d):
            try:
                with open(os.path.join(base, d, "type")) as f:
                    return {"firmware": 0, "platform": 1, "raw": 2}.get(f.read().strip(), 3)
            except OSError:
                return 3
        for d in sorted(devs, key=kind):
            try:
                with open(os.path.join(base, d, "max_brightness")) as f:
                    if int(f.read()) > 0:
                        return d
            except (OSError, ValueError):
                pass
        return None

    @staticmethod
    def _read_backlight(dev):
        base = os.path.join("/sys/class/backlight", dev)
        with open(os.path.join(base, "brightness")) as f:
            cur = int(f.read())
        with open(os.path.join(base, "max_brightness")) as f:
            mx = int(f.read())
        return cur, mx

    @staticmethod
    def _set_backlight(dev, value):
        """Asks the login manager to set the backlight (busctl first: the same command you tested,
        then directly through D-Bus)."""
        err = ""
        if shutil.which("busctl"):
            try:
                r = subprocess.run(["busctl", "call", "org.freedesktop.login1",
                                    "/org/freedesktop/login1/session/auto",
                                    "org.freedesktop.login1.Session", "SetBrightness", "ssu",
                                    "backlight", dev, str(int(value))],
                                   capture_output=True, text=True, timeout=5)
                if r.returncode == 0:
                    return True
                err = (r.stderr or r.stdout).strip()[:120]
            except (OSError, subprocess.SubprocessError) as e:
                err = str(e)[:120]
        try:
            from gi.repository import Gio, GLib
            bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
            bus.call_sync("org.freedesktop.login1", "/org/freedesktop/login1/session/auto",
                          "org.freedesktop.login1.Session", "SetBrightness",
                          GLib.Variant("(ssu)", ("backlight", dev, int(value))),
                          None, Gio.DBusCallFlags.NONE, 3000, None)
            return True
        except Exception as e:
            alog("brightness set failed", dev, busctl=err or "-", dbus=str(e)[:120])
            return False

    @staticmethod
    def _ddc_read():
        if not shutil.which("ddcutil"):
            return None
        try:
            r = subprocess.run(["ddcutil", "getvcp", "10", "--brief"], capture_output=True,
                               text=True, timeout=8)
            parts = r.stdout.split()
            if r.returncode == 0 and len(parts) >= 5:
                return int(parts[3]), int(parts[4])  # "VCP 10 C <current> <max>"
        except (OSError, subprocess.SubprocessError, ValueError):
            pass
        return None

    @staticmethod
    def _ddc_set(value):
        try:
            return subprocess.run(["ddcutil", "setvcp", "10", str(int(value))],
                                  capture_output=True, timeout=8).returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False

    @classmethod
    def _current(cls, state):
        if state["method"] == "backlight":
            return cls._read_backlight(state["dev"])[0]
        got = cls._ddc_read()
        return got[0] if got else None

    @classmethod
    def _apply(cls, state, value):
        if state["method"] == "backlight":
            return cls._set_backlight(state["dev"], value)
        return cls._ddc_set(value)

    @classmethod
    def raise_now(cls, percent):
        with cls._lock:
            if Brightness._s().value("brightness_restore", "", type=str):
                return  # already raised
            state = None
            dev = cls._backlight()
            if dev:
                cur, mx = cls._read_backlight(dev)
                state = {"method": "backlight", "dev": dev, "old": cur, "set": max(1, mx * percent // 100)}
            else:
                got = cls._ddc_read()
                if got:
                    state = {"method": "ddc", "dev": "", "old": got[0], "set": max(1, got[1] * percent // 100)}
            if not state:
                alog("brightness unavailable", "-", why="no built-in backlight and no ddcutil monitor")
                return
            if state["set"] <= state["old"]:
                alog("brightness unchanged", state["method"], already=state["old"], wanted=state["set"])
                return
            st = cls._s()
            st.setValue("brightness_restore", json.dumps(state))
            st.sync()  # so it can be undone after a crash
            ok = cls._apply(state, state["set"])
            now = cls._current(state) if ok else None
            alog("brightness up", state["method"], device=state["dev"] or "monitor",
                 old=state["old"], wanted=state["set"], now=now, ok=ok)
            if not ok:
                st.remove("brightness_restore")
                st.sync()

    @classmethod
    def restore_now(cls):
        """Back to your own level, unless you changed the brightness yourself meanwhile."""
        with cls._lock:
            st = cls._s()
            raw = st.value("brightness_restore", "", type=str)
            if not raw:
                return
            st.remove("brightness_restore")
            st.sync()
            try:
                state = json.loads(raw)
                cur = cls._current(state)
                if cur is not None and abs(cur - state["set"]) > max(2, state["set"] // 50):
                    alog("brightness kept", state["method"], yours=cur)
                    return
                cls._apply(state, state["old"])
                alog("brightness back", state["method"], value=state["old"])
            except Exception as e:
                alog("brightness ERROR", "-", error=str(e)[:100])

    _queue = None

    @classmethod
    def _worker(cls):
        while True:
            job = cls._queue.get()
            try:
                if job[0] == "up":
                    cls.raise_now(job[1])
                else:
                    cls.restore_now()
            except Exception as e:  # never silent: the reason goes to the activity log
                alog("brightness ERROR", job[0], error=f"{type(e).__name__}: {e}"[:160])

    @classmethod
    def _send(cls, job):
        """All changes run one after the other in one background thread, in the order asked."""
        if cls._queue is None:
            import queue
            cls._queue = queue.Queue()
            threading.Thread(target=cls._worker, name="brightness", daemon=True).start()
        cls._queue.put(job)

    @classmethod
    def up(cls):
        if not setting("bright_full", True, bool):
            alog("brightness off", "-", why="switched off in Settings")
            return
        pct = max(10, min(100, setting("bright_level", 99, int)))
        cls._send(("up", pct))

    @classmethod
    def down(cls):
        cls._send(("down",))


# ======================================================================= export / import
EXPORT_SKIP = {"geometry", "split_main", "last_folder", "last_local_folder", "last_transfer",
               "thumb_queue", "brightness_restore"}   # belongs to this computer only
EXPORT_EXT = ".hansviewer"


def _portable(value, to_file):
    """Paths in your home folder and network drives work on another computer too, even with a
    different user name: they are written as {HOME} and {RUNUSER} in the file."""
    pairs = [(os.path.expanduser("~"), "{HOME}"), (f"/run/user/{os.getuid()}", "{RUNUSER}")]
    if isinstance(value, list):
        return [_portable(v, to_file) for v in value]
    if not isinstance(value, str):
        return value
    for real, token in pairs:
        value = value.replace(real, token) if to_file else value.replace(token, real)
    return value


def _openssl(data, passphrase, decrypt=False):
    """AES-256 with a key made from your password (openssl, PBKDF2 with 200 000 rounds)."""
    cmd = ["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "200000", "-a", "-A",
           "-pass", "env:HV_EXPORT_PASS"]
    if decrypt:
        cmd.insert(2, "-d")
    else:
        cmd.insert(2, "-salt")
    r = subprocess.run(cmd, input=data, capture_output=True, timeout=60,
                       env=dict(os.environ, HV_EXPORT_PASS=passphrase))
    if r.returncode != 0:
        raise ValueError("wrong password" if decrypt else (r.stderr.decode(errors="replace")[:200]
                                                           or "openssl failed"))
    return r.stdout


def _rclone_conf_path():
    try:
        r = subprocess.run(["rclone", "config", "file"], capture_output=True, text=True, timeout=10)
        lines = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        return lines[-1] if lines else None
    except (OSError, subprocess.SubprocessError):
        return None


def _rclone_sections(names):
    """The rclone account settings (incl. sign-in tokens) of your cloud entries."""
    import configparser
    path = _rclone_conf_path()
    if not path or not os.path.exists(path):
        return {}
    with open(path) as f:
        text = f.read()
    if text.lstrip().startswith("# Encrypted rclone configuration"):
        return {}
    cp = configparser.RawConfigParser()
    cp.read_string(text)
    return {n: dict(cp.items(n)) for n in names if cp.has_section(n)}


def _rclone_add_sections(sections):
    """Adds cloud accounts from an imported file to rclone (existing ones stay untouched)."""
    import configparser
    path = _rclone_conf_path() or os.path.expanduser("~/.config/rclone/rclone.conf")
    cp = configparser.RawConfigParser()
    if os.path.exists(path):
        with open(path) as f:
            text = f.read()
        if text.lstrip().startswith("# Encrypted rclone configuration"):
            return 0
        cp.read_string(text)
    added = 0
    for name, items in sections.items():
        if not cp.has_section(name):
            cp.add_section(name)
            for k, v in items.items():
                cp.set(name, k, v)
            added += 1
    if added:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".hansviewer-tmp"
        with open(tmp, "w") as f:
            cp.write(f)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    return added


def export_settings(path, passphrase=None):
    """Writes your favourites, aliases, saved servers, cloud entries and settings to one file.
    With a password, the saved server passwords and cloud sign-ins are added, encrypted."""
    st = settings()
    st.sync()
    values = {}
    for key in st.allKeys():
        if key in EXPORT_SKIP:
            continue
        v = st.value(key)
        if v is None:
            continue
        try:
            json.dumps(v)
        except (TypeError, ValueError):
            continue
        values[key] = _portable(v, True)
    data = {"app": APP, "format": 1, "version": VERSION,
            "exported": time.strftime("%Y-%m-%d %H:%M"), "computer": os.uname().nodename,
            "settings": values}
    if passphrase:
        secrets = {"passwords": [], "rclone": {}}
        for srv in saved_servers():
            if srv.get("remember") and not srv.get("guest"):
                uri = server_uri(srv["scheme"], srv["host"], srv["share"])
                pw = keyring_lookup(uri, srv.get("user", ""))
                if pw:
                    secrets["passwords"].append({"uri": uri, "user": srv.get("user", ""), "password": pw})
        clouds = {c["name"] for c in saved_clouds()}
        secrets["rclone"] = _rclone_sections(sorted(clouds))
        data["secrets"] = _openssl(json.dumps(secrets).encode(), passphrase).decode()
        data["secrets_info"] = {"passwords": len(secrets["passwords"]), "clouds": len(secrets["rclone"])}
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=1)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    return data


def read_export(path):
    with open(path) as f:
        data = json.load(f)
    if not isinstance(data, dict) or data.get("app") != APP or not isinstance(data.get("settings"), dict):
        raise ValueError("This is not a HansViewer settings file.")
    return data


def import_settings(data, passphrase=None):
    """Applies an exported file. Returns a short summary for the message box."""
    secrets = None
    if data.get("secrets"):
        if passphrase is None:
            raise ValueError("password needed")
        secrets = json.loads(_openssl(data["secrets"].encode(), passphrase, decrypt=True))
    st = settings()
    for key, v in data["settings"].items():
        if key not in EXPORT_SKIP:
            st.setValue(key, _portable(v, False))
    st.setValue("favourites_seeded", True)
    st.sync()
    done = {"passwords": 0, "clouds": 0}
    if secrets:
        for e in secrets.get("passwords", []):
            done["passwords"] += bool(keyring_store(e["uri"], e.get("user", ""), e["password"]))
        if secrets.get("rclone") and rclone_available():
            done["clouds"] = _rclone_add_sections(secrets["rclone"])
    return done


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.theme = QComboBox()
        self.theme.addItems(["Dark", "Light"])
        self.theme.setCurrentIndex(0 if setting("theme", "dark") == "dark" else 1)
        self.slides = QSpinBox()
        self.slides.setRange(1, 120)
        self.slides.setSuffix(" s")
        self.slides.setValue(setting("slideshow_secs", 4, int))
        self.quality = QSpinBox()
        self.quality.setRange(30, 100)
        self.quality.setValue(setting("jpeg_quality", 92, int))
        self.confirm = QCheckBox("Ask before moving files to the Trash")
        self.confirm.setChecked(setting("confirm_delete", True, bool))
        self.cache = QCheckBox("Save thumbnails to disk (shared with the file manager)")
        self.cache.setChecked(setting("disk_cache", True, bool))
        self.start_mode = QComboBox()
        self.start_mode.addItem("The last folder on this computer", "last_local")
        self.start_mode.addItem("The last folder (also network and cloud)", "last")
        self.start_mode.addItem("Always this folder:", "fixed")
        self.start_mode.setCurrentIndex(max(0, self.start_mode.findData(
            setting("start_mode", "last_local", str))))
        self.start_folder = QLineEdit(setting("start_folder", os.path.expanduser("~/Pictures"), str))
        browse = QPushButton("Choose…")
        browse.clicked.connect(lambda: (lambda d: d and self.start_folder.setText(d))(
            QFileDialog.getExistingDirectory(self, "Start folder", self.start_folder.text())))
        self.start_row = QWidget()
        sr = QHBoxLayout(self.start_row)
        sr.setContentsMargins(0, 0, 0, 0)
        sr.addWidget(self.start_folder, 1)
        sr.addWidget(browse)
        self.start_mode.currentIndexChanged.connect(
            lambda: self.start_row.setEnabled(self.start_mode.currentData() == "fixed"))
        self.start_row.setEnabled(self.start_mode.currentData() == "fixed")
        self.auto_cloud = QCheckBox("Connect cloud storage when HansViewer starts")
        self.auto_cloud.setChecked(setting("auto_cloud", True, bool))
        self.fullscreen = QCheckBox("Open the viewer in full screen")
        self.fullscreen.setChecked(setting("viewer_fullscreen", False, bool))
        self.bright = QCheckBox("Brighter screen while viewing a photo")
        self.bright.setChecked(setting("bright_full", True, bool))
        self.bright_level = QSpinBox()
        self.bright_level.setRange(10, 100)
        self.bright_level.setSuffix(" %")
        self.bright_level.setValue(setting("bright_level", 99, int))
        self.bright.toggled.connect(self.bright_level.setEnabled)
        self.bright_level.setEnabled(self.bright.isChecked())
        self.videos = QCheckBox("Show videos (slideshows skip them)")
        self.videos.setChecked(setting("show_videos", True, bool))
        self.video_net = QComboBox()
        self.video_net.addItem("Automatic (starts as soon as it can play without stopping)", False)
        self.video_net.addItem("Download completely first (for slow connections)", True)
        self.video_net.setCurrentIndex(1 if setting("video_download_first", False, bool) else 0)
        form = QFormLayout()
        form.addRow("Theme", self.theme)
        form.addRow("When starting, open", self.start_mode)
        form.addRow("", self.start_row)
        form.addRow("Slideshow delay", self.slides)
        form.addRow("JPEG quality", self.quality)
        form.addRow(self.confirm)
        form.addRow(self.cache)
        form.addRow(self.fullscreen)
        form.addRow(self.bright)
        form.addRow("Brightness while viewing", self.bright_level)
        form.addRow(self.videos)
        form.addRow("Network videos", self.video_net)
        form.addRow(self.auto_cloud)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                   | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(buttons)

    def save(self):
        s = settings()
        s.setValue("theme", "dark" if self.theme.currentIndex() == 0 else "light")
        s.setValue("slideshow_secs", self.slides.value())
        s.setValue("jpeg_quality", self.quality.value())
        s.setValue("confirm_delete", self.confirm.isChecked())
        s.setValue("disk_cache", self.cache.isChecked())
        s.setValue("viewer_fullscreen", self.fullscreen.isChecked())
        s.setValue("bright_full", self.bright.isChecked())
        s.setValue("bright_level", self.bright_level.value())
        s.setValue("show_videos", self.videos.isChecked())
        s.setValue("video_download_first", bool(self.video_net.currentData()))
        SHOW_VIDEOS[0] = self.videos.isChecked()
        s.setValue("auto_cloud", self.auto_cloud.isChecked())
        s.setValue("start_mode", self.start_mode.currentData())
        s.setValue("start_folder", self.start_folder.text().strip())


class ConnectSignals(QObject):
    done = pyqtSignal(bool, str)
    found = pyqtSignal(object)


class ConnectJob(QRunnable):
    def __init__(self, fn, signal):
        super().__init__()
        self.fn, self.signal = fn, signal

    def run(self):
        result = self.fn()
        if isinstance(result, tuple):
            self.signal.emit(*result)
        else:
            self.signal.emit(result)


class ConnectDialog(QDialog):
    """Connect to a NAS, a Windows or Linux share, an SSH server or WebDAV."""

    def __init__(self, parent=None, server=None):
        super().__init__(parent)
        self.setWindowTitle("Connect to server")
        self.setMinimumWidth(520)
        self.result_path = None
        self.server = None
        self.cloud = None
        self.signals = ConnectSignals()
        self.signals.done.connect(self._connected)
        self.signals.found.connect(self._found)

        self.type_box = QComboBox()
        for key, label in SERVER_TYPES:
            self.type_box.addItem(label, key)
        self.host = QLineEdit()
        self.host.setPlaceholderText("nas.local, 192.168.1.20 or smb://nas/photos")
        self.find_btn = QPushButton("Find…")
        self.find_btn.setToolTip("Look for servers on your network")
        self.find_btn.clicked.connect(self._find)
        host_row = QHBoxLayout()
        host_row.addWidget(self.host, 1)
        host_row.addWidget(self.find_btn)
        self.share = QLineEdit()
        self.share.setPlaceholderText("photos  (optional)")
        self.user = QLineEdit()
        self.domain = QLineEdit()
        self.domain.setPlaceholderText("WORKGROUP  (usually leave empty)")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.guest = QCheckBox("Connect as guest (no password)")
        self.guest.toggled.connect(self._guest_toggled)
        self.save = QCheckBox("Show this server in the sidebar")
        self.save.setChecked(True)
        self.trust = QCheckBox("Trust this server's certificate (self-signed, e.g. a Synology NAS)")
        self.trust.setToolTip("Only tick this for your own server. The connection stays encrypted.")
        self.remember = QCheckBox("Remember the password")
        if not keyring_available():
            self.remember.setEnabled(False)
            self.remember.setToolTip("Install libsecret-tools to remember passwords safely")
        self.status = QLabel()
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)

        form = QFormLayout()
        form.addRow("Type", self.type_box)
        form.addRow("Server", host_row)
        form.addRow("Share / folder", self.share)
        form.addRow("User name", self.user)
        self.domain_label = QLabel("Domain")
        form.addRow(self.domain_label, self.domain)
        form.addRow("Password", self.password)
        form.addRow(self.guest)
        form.addRow(self.trust)
        form.addRow(self.save)
        form.addRow(self.remember)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.connect_btn = self.buttons.addButton("Connect", QDialogButtonBox.ButtonRole.AcceptRole)
        self.connect_btn.setObjectName("primary")
        self.connect_btn.setDefault(True)
        self.buttons.accepted.connect(self._connect)
        self.buttons.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(self.status)
        lay.addWidget(self.buttons)
        self.type_box.currentIndexChanged.connect(self._type_changed)

        if server:
            i = self.type_box.findData(server.get("scheme", "smb"))
            self.type_box.setCurrentIndex(max(0, i))
            self.host.setText(server.get("host", ""))
            self.share.setText("/".join(p for p in (server.get("share", ""), server.get("rest", "")) if p))
            self.user.setText(server.get("user", ""))
            self.domain.setText(server.get("domain", ""))
            self.guest.setChecked(server.get("guest", False))
            self.remember.setChecked(server.get("remember", False) and keyring_available())
        else:
            self.user.setText(os.environ.get("USER", ""))
        self._type_changed()

    def _type_changed(self):
        self.trust.setVisible(self.type_box.currentData() == "davs")
        smb = self.type_box.currentData() == "smb"
        self.domain.setVisible(smb)
        self.domain_label.setVisible(smb)
        self.share.setPlaceholderText("photos  (optional)" if smb else "folder on the server  (optional)")

    def _guest_toggled(self, on):
        for w in (self.user, self.domain, self.password):
            w.setEnabled(not on)
        self.remember.setEnabled(not on and keyring_available())

    def _busy(self, text):
        self.status.setText(text)
        busy = bool(text) and text.endswith("…")
        for w in (self.connect_btn, self.find_btn, self.host, self.share, self.type_box):
            w.setEnabled(not busy)

    def _find(self):
        self._busy("Looking for servers on your network…")
        QThreadPool.globalInstance().start(ConnectJob(discover_servers, self.signals.found))

    def _found(self, servers):
        self._busy("")
        if servers is None:
            self.status.setText("Searching needs the avahi-utils package (sudo apt install avahi-utils). "
                                "You can still type the server's name or address.")
            return
        if not servers:
            self.status.setText("No servers announced themselves. Type the server's name or IP address.")
            return
        m = QMenu(self)
        labels = dict(SERVER_TYPES)
        for name, scheme, host in servers:
            a = m.addAction(f"{name}   —   {host}   ({labels.get(scheme, scheme)})")
            a.triggered.connect(lambda _=False, sc=scheme, h=host: self._pick(sc, h))
        m.exec(self.find_btn.mapToGlobal(self.find_btn.rect().bottomLeft()))

    def _pick(self, scheme, host):
        self.type_box.setCurrentIndex(max(0, self.type_box.findData(scheme)))
        self.host.setText(host)
        self.share.setFocus()

    def _connect(self):
        scheme, host, share, rest = parse_server(self.host.text(), self.type_box.currentData())
        if not host:
            self.status.setText("Please enter the server's name or IP address.")
            return
        extra = [p for p in self.share.text().strip().replace("\\", "/").split("/") if p]
        if extra and not share:
            share, rest = extra[0], "/".join(extra[1:] + ([rest] if rest else []))
        if scheme == "smb" and not share:
            self.status.setText("Please enter the share name (for example photos). "
                                "Open the NAS in the file manager once to see its shares.")
            return
        i = self.type_box.findData(scheme)
        if i >= 0:
            self.type_box.setCurrentIndex(i)
        guest = self.guest.isChecked()
        user, domain, pw = self.user.text().strip(), self.domain.text().strip(), self.password.text()
        uri = server_uri(scheme, host, share)
        if not guest and not pw and self.remember.isChecked():
            pw = keyring_lookup(uri, user) or ""
        self.server = {"name": f"{share} on {host}" if share else host, "scheme": scheme, "host": host,
                       "share": share, "rest": rest, "user": "" if guest else user,
                       "domain": "" if guest else domain, "guest": guest,
                       "remember": self.remember.isChecked() and not guest}
        self._password = pw
        if scheme == "davs" and self.trust.isChecked():
            if not rclone_available():
                self.status.setText("Trusting a certificate needs rclone: sudo apt install rclone fuse3")
                return
            name = "webdav-" + re.sub(r"[^A-Za-z0-9]+", "-", host).strip("-").lower()
            url = "https://" + host + "/" + "/".join(p for p in (share, rest) if p)
            label = f"{share or host} (WebDAV)"
            self.cloud = {"name": name, "label": label, "args": ["--no-check-certificate"]}
            self._busy(f"Connecting to {host}…")

            def job():
                ok, msg = rclone_webdav(name, url, "" if guest else user, "" if guest else pw)
                return rclone_mount(name, extra=["--no-check-certificate"]) if ok else (ok, msg)
            QThreadPool.globalInstance().start(ConnectJob(job, self.signals.done))
            return
        self._busy(f"Connecting to {host}…")
        QThreadPool.globalInstance().start(ConnectJob(
            lambda: gio_mount(uri, user, domain, pw, anonymous=guest), self.signals.done))

    def _connected(self, ok, message):
        self._busy("")
        if not ok:
            if self.cloud is None and ("certificate" in message.lower() or "tls" in message.lower()):
                self.trust.setVisible(True)
                self.status.setText("The server's certificate isn't trusted (normal for a NAS with its "
                                    "own certificate). If this is your own server, tick “Trust this "
                                    "server's certificate” and click Connect again.")
            else:
                self.status.setText("Could not connect: " + message)
            self.cloud = None
            return
        if self.cloud is not None:
            self.result_path = cloud_path(self.cloud["name"])
            self.accept()
            return
        s = self.server
        if s["remember"] and self._password:
            keyring_store(server_uri(s["scheme"], s["host"], s["share"]), s["user"], self._password)
        self.result_path = find_gvfs_path(s["scheme"], s["host"], s["share"], s["rest"])
        self.accept()


class CloudDialog(QDialog):
    """Add a cloud account (via rclone) to the CLOUD section of the sidebar."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add cloud storage")
        self.setMinimumWidth(560)
        self.added = None
        self.signals = ConnectSignals()
        self.signals.done.connect(self._created)
        lay = QVBoxLayout(self)
        if not rclone_available():
            note = QLabel("<h3>One-time setup</h3><p>Cloud storage uses the free program "
                          "<b>rclone</b>. Install it once in a terminal:</p>"
                          "<p><code>sudo apt install rclone fuse3</code></p>"
                          "<p>Then open this window again.</p>")
            note.setTextFormat(Qt.TextFormat.RichText)
            note.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            lay.addWidget(note)
            b = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
            b.rejected.connect(self.reject)
            lay.addWidget(b)
            return

        intro = QLabel("Choose a service and a name. Your browser opens so you can sign in; "
                       "HansViewer never sees your password.")
        intro.setWordWrap(True)
        self.service = QComboBox()
        for key, label in CLOUD_SERVICES:
            self.service.addItem(label, key)
        self.name = QLineEdit()
        self.name.setPlaceholderText("for example: google")
        self.service.currentIndexChanged.connect(self._suggest)
        self._suggest()
        form = QFormLayout()
        form.addRow("Service", self.service)
        form.addRow("Name", self.name)
        self.add_btn = QPushButton("Sign in and add")
        self.add_btn.setObjectName("primary")
        self.add_btn.clicked.connect(self._create)

        existing = [r for r in rclone_remotes() if r not in {c["name"] for c in saved_clouds()}]
        self.existing = QComboBox()
        self.existing.addItems(existing)
        use_btn = QPushButton("Add")
        use_btn.clicked.connect(self._use_existing)
        ex_row = QHBoxLayout()
        ex_row.addWidget(self.existing, 1)
        ex_row.addWidget(use_btn)

        other = QLabel("<b>Other services</b> such as Apple iCloud Drive, MEGA, Nextcloud or "
                       "Amazon S3: set them up once in rclone's own setup, then add them above "
                       "under <i>Already set up</i>.")
        other.setWordWrap(True)
        other.setTextFormat(Qt.TextFormat.RichText)
        term_btn = QPushButton("Open rclone setup in a terminal")
        term_btn.clicked.connect(lambda: open_in_terminal(["rclone", "config"]) or
                                 copyable_box("info", self, "rclone", "Open a terminal and run: rclone config"))
        not_possible = QLabel("Google Photos, Amazon Photos and Apple iCloud Photos offer no access "
                              "for other programs.")
        not_possible.setObjectName("muted")
        not_possible.setWordWrap(True)
        self.status = QLabel()
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)

        lay.addWidget(intro)
        lay.addLayout(form)
        lay.addWidget(self.add_btn, 0, Qt.AlignmentFlag.AlignRight)
        if existing:
            g = QGroupBox("Already set up in rclone")
            QVBoxLayout(g).addLayout(ex_row)
            lay.addWidget(g)
        lay.addWidget(other)
        lay.addWidget(term_btn, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(not_possible)
        lay.addWidget(self.status)
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        b.rejected.connect(self.reject)
        lay.addWidget(b)

    def _suggest(self):
        base = {"drive": "google", "onedrive": "onedrive", "dropbox": "dropbox", "box": "box",
                "pcloud": "pcloud"}[self.service.currentData()]
        taken = set(rclone_remotes())
        name, n = base, 2
        while name in taken:
            name, n = f"{base}{n}", n + 1
        self.name.setText(name)

    def _create(self):
        name = re.sub(r"[^A-Za-z0-9_-]", "", self.name.text().strip())
        if not name:
            self.status.setText("Please enter a name (letters and numbers).")
            return
        if name in rclone_remotes():
            self.status.setText(f"“{name}” already exists in rclone. Pick another name, or add it "
                                "under “Already set up”.")
            return
        self._name = name
        self.add_btn.setEnabled(False)
        self.status.setText("Your browser is opening — sign in there and allow access, then come "
                            "back here…")
        service = self.service.currentData()
        QThreadPool.globalInstance().start(ConnectJob(lambda: rclone_create(name, service),
                                                      self.signals.done))

    def _created(self, ok, message):
        self.add_btn.setEnabled(True)
        if not ok:
            self.status.setText("Could not add the account: " + message)
            return
        self.added = {"name": self._name, "label": self.service.currentText()}
        self.accept()

    def _use_existing(self):
        name = self.existing.currentText()
        if name:
            self.added = {"name": name, "label": name}
            self.accept()


SHORTCUTS_HTML = """
<h3>Browser</h3><table cellspacing=4>
<tr><td><b>Enter</b> / double-click</td><td>View image</td></tr>
<tr><td><b>Backspace</b>, <b>Alt+Up</b></td><td>Parent folder</td></tr>
<tr><td><b>Alt+Left / Alt+Right</b></td><td>Back / forward</td></tr>
<tr><td><b>Ctrl+D</b></td><td>Add / remove favourite</td></tr>
<tr><td><b>F2</b> in the sidebar</td><td>Rename a folder (really) · alias for a share or cloud · favourite name</td></tr>
<tr><td><b>Ctrl+F</b></td><td>Filter by name</td></tr>
<tr><td><b>F2</b></td><td>Rename (several selected: batch rename)</td></tr>
<tr><td><b>Ctrl+E</b></td><td>Edit image</td></tr>
<tr><td><b>Ctrl+[ / Ctrl+]</b></td><td>Rotate left / right</td></tr>
<tr><td><b>Del</b></td><td>Move to Trash</td></tr>
<tr><td><b>F5</b></td><td>Slideshow &nbsp;&nbsp; <b>Ctrl+R</b> Refresh (cloud: ask the cloud again)</td></tr>
<tr><td><b>Ctrl+Plus / Minus</b></td><td>Bigger / smaller thumbnails</td></tr>
<tr><td><b>F9</b></td><td>Preview pane</td></tr>
<tr><td><b>Ctrl+K</b></td><td>Connect to server</td></tr></table>
<h3>Viewer</h3><table cellspacing=4>
<tr><td><b>Space / Backspace</b>, wheel</td><td>Next / previous</td></tr>
<tr><td><b>+ / −</b>, Ctrl+wheel</td><td>Zoom &nbsp; <b>0</b> fit &nbsp; <b>1</b> show full size (network photos open at screen size)</td></tr>
<tr><td><b>F</b> / double-click</td><td>Full screen on / off (or the buttons that appear when you move the mouse)</td></tr>
<tr><td><b>S</b></td><td>Slideshow</td></tr>
<tr><td><b>I</b></td><td>Info bar</td></tr>
<tr><td><b>[ / ]</b></td><td>Rotate and save</td></tr>
<tr><td><b>E</b></td><td>Edit</td></tr>
<tr><td><b>Del</b></td><td>Move to Trash</td></tr>
<tr><td><b>Ctrl+C</b></td><td>Copy image</td></tr>
<tr><td><b>Esc</b></td><td>Back to browser</td></tr></table>
"""


# ======================================================================= browser window
WINDOWS = []           # the open HansViewer windows (File → New window)
_SHARED_QUEUE = None   # one "Make thumbnails" list for all of them


class Browser(QMainWindow):
    def __init__(self, start):
        super().__init__()
        WINDOWS.append(self)
        self.setWindowTitle(APP)
        self.setWindowIcon(icon("hansviewer image-viewer", SP.SP_DesktopIcon))
        self.resize(1400, 880)
        self.viewer = None
        self.folder = None
        self.history, self.hpos = [], -1
        self._syncing = False

        self.model = FolderModel()
        self.model.use_cache = setting("disk_cache", True, bool)
        self.model.sort_key = setting("sort_key", "name")
        self.model.date_progress.connect(self._date_progress)
        self.model.relisted.connect(self._relisted)
        self.model.checking.connect(lambda: self.set_check("⟳ Checking for changes…"))
        self.model.checked.connect(self._checked)
        self.model.dates_finished.connect(self._dates_finished)
        if self.model.sort_key not in ("name", "taken", "date", "size", "type"):
            self.model.sort_key = "name"
        self.model.sort_desc = setting("sort_desc", False, bool)

        self.thumb_pool = QThreadPool(self)
        self.thumb_pool.setMaxThreadCount(1)
        self.preview_signals = JobSignals()
        self.preview_signals.image.connect(self._preview_ready)
        self.preview_timer = QTimer(self)
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self._load_preview)

        self.watcher = QFileSystemWatcher(self)
        self.watcher.directoryChanged.connect(lambda _p: self.reload_timer.start(600))
        self.reload_timer = QTimer(self)
        self.reload_timer.setSingleShot(True)
        self.reload_timer.timeout.connect(self.reload)

        self._build_widgets()
        self._build_actions()
        self._build_menus_and_toolbar()
        self._restore_layout()

        self.places_timer = QTimer(self)
        self.places_timer.timeout.connect(self.refresh_devices)
        self.places_timer.start(3000)

        # the window appears first; the start folder is opened right after
        QTimer.singleShot(0, lambda: self._open_start_folder(start))

    def show_banner(self, text, button=None, action=None):
        self.banner_text.setText(text)
        self.banner_btn.setVisible(bool(button))
        self.banner_btn.setText(button or "")
        self._banner_action = action
        self.banner.show()

    def _banner_clicked(self):
        self.banner.hide()
        if self._banner_action:
            self._banner_action()

    def _unconnected_cloud(self, path):
        """True for a path inside one of your cloud drives while that drive isn't connected."""
        for c in saved_clouds():
            d = cloud_dir(c)
            if (path == d or path.startswith(d + "/")) and not remote_reachable(d):
                return True
        return False

    def _continue_in(self, path):
        """Opens a network/cloud folder from the start bar, connecting the drive if needed."""
        if remote_reachable(path) or is_gvfs(path):
            self.navigate(path)          # network shares are connected by navigate() if needed
            return
        for c in saved_clouds():
            d = cloud_dir(c)
            if path == d or path.startswith(d + "/"):
                self.statusBar().showMessage(f"Connecting {c.get('label') or c['name']}…", 8000)
                signals = ConnectSignals()
                self._cloud_signals = getattr(self, "_cloud_signals", []) + [signals]

                def done(ok, msg, p=path):
                    self._devices_sig = None
                    self.refresh_devices()
                    if ok:
                        self._cloud_retry = p      # don't try to connect again in a loop
                        try:
                            self.navigate(p)
                        finally:
                            self._cloud_retry = None
                    else:
                        copyable_box("warning", self, APP, f"Could not connect:\n{msg}")

                signals.done.connect(done)
                QThreadPool.globalInstance().start(ConnectJob(
                    lambda c=c: rclone_mount(c["name"], extra=c.get("args", []), mount=c.get("mount")),
                    signals.done))
                return
        self.statusBar().showMessage("That drive isn't connected yet. Connect it in the sidebar "
                                     "(NETWORK or CLOUD), then try again.", 8000)

    def _open_start_folder(self, explicit):
        home = os.path.expanduser("~")
        pictures = os.path.join(home, "Pictures")
        fallback = pictures if os.path.isdir(pictures) else home
        if explicit:  # a folder or photo given when starting (e.g. "Open with")
            path = os.path.abspath(os.path.expanduser(explicit))
            target = None
            if not is_remote(path) and os.path.isfile(path):
                path, target = os.path.dirname(path), path
            elif is_remote(path) and os.path.splitext(path)[1][1:].lower() in media_exts():
                path, target = os.path.dirname(path), path
            self.navigate(path, then=(lambda: (self.select_path(target), self.view_current()))
                          if target else None)
            return
        mode = setting("start_mode", "last_local", str)
        last = setting("last_folder", "", str)
        local = setting("last_local_folder", "", str)
        if not local or not os.path.isdir(local):
            local = fallback

        def ok(p):
            if not p:
                return False
            return remote_reachable(p) if is_remote(p) else os.path.isdir(p)

        if mode == "fixed":
            target = setting("start_folder", fallback, str)
            if not ok(target):
                target = local
        elif mode == "last":
            target = last if ok(last) else local
            if last and is_gvfs(last) and not ok(last):
                QTimer.singleShot(300, lambda: self._continue_in(last))   # connect it by itself
            elif last and is_remote(last) and not ok(last):
                self.show_banner(f"Your last folder “{os.path.basename(last) or last}” is on a "
                                 "network or cloud drive that isn't connected yet.",
                                 "Try again", lambda: self._continue_in(last))
        else:  # last folder on this computer
            target = last if last and not is_remote(last) and ok(last) else local
            if last and is_remote(last):
                self.show_banner(f"Last time you were in “{os.path.basename(last.rstrip('/')) or last}” "
                                 "on a network or cloud drive.", "Continue there",
                                 lambda: self._continue_in(last))
        self.navigate(target)

    # ------------------------------------------------------------------ layout
    def _build_widgets(self):
        # Sidebar: favourites + devices
        self.sidebar = QTreeWidget()
        self.sidebar.setHeaderHidden(True)
        self.sidebar.setRootIsDecorated(True)
        self.sidebar.setIndentation(14)
        self.sidebar.setAnimated(True)
        self.sidebar.itemExpanded.connect(self._populate)
        self._populating = {}
        self._refreshing_tree = {}
        self.sub_pool = QThreadPool(self)
        self.sub_pool.setMaxThreadCount(4)
        self.list_signals = ListSignals()
        self.list_signals.subfolders.connect(self._subfolders_ready)
        self.sidebar_delegate = SidebarDelegate(self.sidebar)
        self.sidebar.setItemDelegate(self.sidebar_delegate)
        self.sidebar.itemChanged.connect(self._sidebar_item_changed)
        self.sidebar.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.sidebar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.sidebar.customContextMenuRequested.connect(self._sidebar_menu)
        self.sidebar.itemClicked.connect(self._sidebar_clicked)
        self.sidebar.itemCollapsed.connect(self._sidebar_collapsed)
        del_fav = QAction(self.sidebar)
        del_fav.setShortcut(QKeySequence(Qt.Key.Key_Delete))
        del_fav.setShortcutContext(Qt.ShortcutContext.WidgetShortcut)
        del_fav.triggered.connect(self._delete_sidebar_favourite)
        self.sidebar.addAction(del_fav)
        ren = QAction(self.sidebar)
        ren.setShortcut(QKeySequence(Qt.Key.Key_F2))
        ren.setShortcutContext(Qt.ShortcutContext.WidgetShortcut)
        ren.triggered.connect(self._rename_sidebar_item)
        self.sidebar.addAction(ren)
        self.sec_fav = self._section("FAVOURITES")
        self.sec_dev = self._section("DEVICES")
        self.sec_net = self._section("NETWORK")
        self.sec_cloud = self._section("CLOUD")
        self._devices_sig = None
        self.refresh_favourites()
        self.refresh_network()
        self.refresh_clouds()
        self.refresh_devices()
        if setting("auto_cloud", True, bool):
            QTimer.singleShot(1500, self.auto_connect_clouds)

        self.left = self.sidebar

        # Grid
        self.delegate = ThumbDelegate(setting("thumb_size", 160, int))
        self.grid = ThumbGrid()
        self.grid.setModel(self.model)
        self.grid.setItemDelegate(self.delegate)
        self.grid.setGridSize(self.delegate.cell())
        self.grid.activated.connect(lambda _i: self.view_current())
        self.grid.selectionModel().selectionChanged.connect(lambda *_: self._selection_changed())
        self.grid.selectionModel().currentChanged.connect(lambda *_: self._selection_changed())
        self.grid.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.grid.customContextMenuRequested.connect(self._grid_menu)

        self.preview = PreviewPane()
        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidget(self.preview)
        self.preview_scroll.setWidgetResizable(True)
        self.preview_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.banner = QFrame()
        self.banner.setObjectName("banner")
        self.banner_text = QLabel()
        self.banner_text.setWordWrap(True)
        self.banner_btn = QPushButton()
        self.banner_btn.setObjectName("primary")
        self.banner_btn.clicked.connect(self._banner_clicked)
        banner_close = QPushButton("✕")
        banner_close.setFixedWidth(32)
        banner_close.setToolTip("Close")
        banner_close.clicked.connect(self.banner.hide)
        bl = QHBoxLayout(self.banner)
        bl.setContentsMargins(12, 6, 8, 6)
        bl.addWidget(self.banner_text, 1)
        bl.addWidget(self.banner_btn)
        bl.addWidget(banner_close)
        self.banner.hide()
        self._banner_action = None
        self.grid_box = QWidget()
        gl = QVBoxLayout(self.grid_box)
        gl.setContentsMargins(0, 0, 0, 0)
        gl.setSpacing(0)
        gl.addWidget(self.banner)
        gl.addWidget(self.grid, 1)

        self.main_split = QSplitter()
        self.main_split.addWidget(self.left)
        self.main_split.addWidget(self.grid_box)
        self.main_split.addWidget(self.preview_scroll)
        self.main_split.setStretchFactor(1, 1)
        self.main_split.setSizes([270, 830, 300])
        self.setCentralWidget(self.main_split)

        self.status_left = QLabel()
        self.status_right = QLabel()
        self.statusBar().addWidget(self.status_left, 1)
        self.statusBar().addPermanentWidget(self.status_right)
        # refresh / check result: its own place, so other messages can't hide it
        self.status_check = QLabel("")
        self.status_check.setStyleSheet(f"color: {THEME['accent']}; padding: 0 8px;")
        self.statusBar().addPermanentWidget(self.status_check)
        self._check_timer = QTimer(self)
        self._check_timer.setSingleShot(True)
        self._check_timer.timeout.connect(lambda: self.status_check.setText(""))

        # background "Make thumbnails" queue (continues after restarts)
        refresh_nas_state()
        try:
            items = json.loads(setting("thumb_queue", "[]", str) or "[]")
        except ValueError:
            items = []
        global _SHARED_QUEUE
        first = _SHARED_QUEUE is None
        if first:   # one thumbnail list for all windows
            _SHARED_QUEUE = ThumbQueue(items if isinstance(items, list) else [],
                                       setting("disk_cache", True, bool))
        self.queue = _SHARED_QUEUE
        self.queue.progress.connect(self._queue_progress)
        self.queue.made.connect(self._queue_made)
        self.queue.changed.connect(self._queue_changed)
        self.queue.idle.connect(lambda: self.queue_box.hide())
        self.queue_box = QWidget()
        ql = QHBoxLayout(self.queue_box)
        ql.setContentsMargins(0, 0, 6, 0)
        self.queue_label = QLabel("Thumbnails")
        self.queue_label.setMinimumWidth(260)
        self.queue_pause = QPushButton("Pause")
        self.queue_pause.setCheckable(True)
        self.queue_pause.toggled.connect(self._queue_pause_toggled)
        queue_stop = QPushButton("Stop")
        queue_stop.setToolTip("Stop making thumbnails and clear the list")
        queue_stop.clicked.connect(self._queue_stop)
        for w in (self.queue_label, self.queue_pause, queue_stop):
            ql.addWidget(w)
        self.queue_box.hide()
        self.statusBar().addPermanentWidget(self.queue_box)
        if first and self.queue.items:
            QTimer.singleShot(5000, self._resume_queue)

    def _section(self, title):
        it = QTreeWidgetItem([title])
        f = it.font(0)
        f.setBold(True)
        f.setPointSizeF(max(6.0, f.pointSizeF() * 0.8))
        it.setFont(0, f)
        it.setForeground(0, QColor(THEME["muted"]))
        it.setFlags(Qt.ItemFlag.ItemIsEnabled)
        self.sidebar.addTopLevelItem(it)
        it.setExpanded(True)
        return it

    def act(self, text, slot, shortcut=None, icon_names=None, fallback=None,
            scoped=False, checkable=False, tip=None):
        a = QAction(text, self)
        if icon_names or fallback is not None:
            a.setIcon(icon(icon_names or "", fallback))
        if shortcut:
            seqs = shortcut if isinstance(shortcut, (list, tuple)) else [shortcut]
            a.setShortcuts([QKeySequence(s) for s in seqs])
        if tip:
            a.setToolTip(tip)
        a.setCheckable(checkable)
        if checkable:
            a.toggled.connect(slot)
        else:
            a.triggered.connect(lambda _=False: slot())
        if scoped:  # only while the thumbnail grid has focus (keeps typing in boxes working)
            a.setShortcutContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            self.grid.addAction(a)
        else:
            self.addAction(a)
        return a

    def _build_actions(self):
        A = self.act
        self.a_back = A("Back", self.go_back, "Alt+Left", "go-previous", SP.SP_ArrowBack)
        self.a_fwd = A("Forward", self.go_forward, "Alt+Right", "go-next", SP.SP_ArrowForward)
        self.a_up = A("Up", self.go_up, "Alt+Up", "go-up", SP.SP_ArrowUp,
                      tip="Parent folder (Backspace)")
        self.a_parent_bs = A("Parent folder", self.go_up, "Backspace", scoped=True)
        self.a_refresh = A("Refresh", lambda: self.reload(fresh=True), "Ctrl+R", "view-refresh",
                           SP.SP_BrowserReload)
        self.a_home = A("Home", lambda: self.navigate(os.path.expanduser("~")), "Alt+Home",
                        "go-home", SP.SP_DirHomeIcon)
        self.a_open = A("Open folder…", self.open_folder_dialog, "Ctrl+O", "folder-open",
                        SP.SP_DirOpenIcon)
        self.a_fav = A("Add to favourites", self.toggle_favourite, "Ctrl+D",
                       "starred bookmark-new", tip="Add / remove favourite (Ctrl+D)")
        self.a_view = A("View", self.view_current, None, "zoom-fit-best image-x-generic",
                        SP.SP_FileDialogContentsView)
        self.a_view_full = A("View full size", self.view_full_size, None, "zoom-original")
        self.a_slideshow = A("Slideshow", self.slideshow, "F5",
                             "media-playback-start view-presentation", SP.SP_MediaPlay)
        self.a_edit = A("Edit…", self.edit_current, "Ctrl+E", "document-edit image-edit",
                        scoped=True)
        self.a_rot_l = A("Rotate left", lambda: self.rotate_selected(-90), "Ctrl+[",
                         "object-rotate-left", scoped=True)
        self.a_rot_r = A("Rotate right", lambda: self.rotate_selected(90), "Ctrl+]",
                         "object-rotate-right", scoped=True)
        self.a_rename = A("Rename…", self.rename_selected, "F2", "edit-rename", scoped=True)
        self.a_batch = A("Batch rename…", self.batch_rename, None, "edit-rename")
        self.a_copy_to = A("Copy to folder…", lambda: self.transfer(False), "Ctrl+Shift+C",
                           "edit-copy", scoped=True)
        self.a_move_to = A("Move to folder…", lambda: self.transfer(True), "Ctrl+Shift+M",
                           "go-jump", scoped=True)
        self.a_delete = A("Move to Trash", self.delete_selected, "Delete", scoped=True)
        self.a_delete.setIcon(bin_icon())
        self.a_copy_img = A("Copy image", self.copy_image, "Ctrl+C", "edit-copy", scoped=True)
        self.a_copy_path = A("Copy path", self.copy_path, "Ctrl+Shift+P", None)
        self.a_select_all = A("Select all", self.grid.selectAll, "Ctrl+A", "edit-select-all",
                              scoped=True)
        self.a_wallpaper = A("Set as wallpaper", self.wallpaper, None, "preferences-desktop-wallpaper")
        self.a_open_with = A("Open with default app", self.open_external, None,
                             "document-open", SP.SP_DialogOpenButton)
        self.a_show_folder = A("Open folder in file manager", self.show_in_files, None,
                               "system-file-manager folder")
        self.a_export = A("Export settings…", self.export_settings_dialog, None, "document-save-as")
        self.a_import = A("Import settings…", self.import_settings_dialog, None, "document-open")
        self.a_settings = A("Settings…", self.open_settings, "Ctrl+,", "preferences-system",
                            SP.SP_FileDialogDetailedView)
        self.a_bigger = A("Bigger thumbnails", lambda: self.step_thumbs(+32),
                          ["Ctrl++", "Ctrl+="], "zoom-in")
        self.a_smaller = A("Smaller thumbnails", lambda: self.step_thumbs(-32), "Ctrl+-",
                           "zoom-out")
        self.a_filter = A("Filter by name", lambda: (self.filter_box.setFocus(),
                                                     self.filter_box.selectAll()), "Ctrl+F")
        self.a_preview = A("Preview pane", lambda on: (self.preview_scroll.setVisible(on),
                                                       self.preview_timer.start(50)),
                           "F9", checkable=True)
        self.a_sidebar = A("Sidebar", self.left.setVisible, "Ctrl+B", checkable=True)
        self.a_install = A(f"Add {APP} to the app menu", self.install, None, "list-add")
        self.a_activity = A("Show activity log (network)", self.show_activity_log, None, "text-x-generic")
        self.a_connect = A("Connect to server…", self.connect_server, "Ctrl+K",
                           "network-server folder-remote", SP.SP_DriveNetIcon)
        self.a_cloud = A("Add cloud storage…", self.add_cloud, None, "folder-cloud weather-overcast")
        self.a_thumbs = A("Make thumbnails for this folder", lambda: self.make_thumbnails(), None,
                          "view-preview image-x-generic")
        self.a_thumbs_sub = A("Make thumbnails for this folder and subfolders",
                              lambda: self.make_thumbnails(subfolders=True), None, "view-preview")
        self.a_shortcuts = A("Keyboard shortcuts", self.show_shortcuts, "F1", "help-contents")
        self.a_about = A(f"About {APP}", self.about, None, "help-about")
        self.a_quit = A("Quit", self.close, "Ctrl+Q", "application-exit")
        self.a_new_window = A("New window", self.new_window, "Ctrl+N", "window-new")

    def _build_menus_and_toolbar(self):
        mb = self.menuBar()
        m = mb.addMenu("&File")
        m.addAction(self.a_new_window)
        m.addSeparator()
        for a in (self.a_open, self.a_home, self.a_refresh, None, self.a_connect, self.a_cloud,
                  None, self.a_open_with,
                  self.a_show_folder, None, self.a_settings, self.a_export, self.a_import, None,
                  self.a_quit):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Edit")
        for a in (self.a_select_all, self.a_copy_img, self.a_copy_path, None, self.a_rename,
                  self.a_batch, self.a_copy_to, self.a_move_to, None, self.a_delete):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&View")
        for a in (self.a_view, self.a_view_full, self.a_slideshow, None, self.a_thumbs,
                  self.a_thumbs_sub, None,
                  self.a_bigger, self.a_smaller, self.a_filter, None, self.a_preview, self.a_sidebar):
            m.addSeparator() if a is None else m.addAction(a)
        sort_menu = m.addMenu("Sort by")
        self.sort_actions = {}
        for key, label in (("name", "Name"), ("taken", "Date taken (photo info)"),
                           ("date", "Date modified (file)"), ("size", "Size"), ("type", "Type")):
            a = sort_menu.addAction(label)
            a.setCheckable(True)
            a.triggered.connect(lambda _=False, k=key: self.set_sort(k, self.model.sort_desc))
            self.sort_actions[key] = a
        sort_menu.addSeparator()
        self.a_desc = sort_menu.addAction("Descending")
        self.a_desc.setCheckable(True)
        self.a_desc.triggered.connect(lambda on: self.set_sort(self.model.sort_key, on))
        m = mb.addMenu("&Image")
        for a in (self.a_edit, self.a_rot_l, self.a_rot_r, None, self.a_wallpaper):
            m.addSeparator() if a is None else m.addAction(a)
        self.fav_menu = mb.addMenu("F&avourites")
        self.fav_menu.aboutToShow.connect(self._fill_fav_menu)
        m = mb.addMenu("&Help")
        for a in (self.a_shortcuts, self.a_install, self.a_activity, None, self.a_about):
            m.addSeparator() if a is None else m.addAction(a)

        tb = self.addToolBar("Main")
        tb.setObjectName("main_toolbar")
        tb.setMovable(False)
        tb.setIconSize(QSize(20, 20))
        for a in (self.a_back, self.a_fwd, self.a_up, self.a_home):
            tb.addAction(a)
        self.address = QLineEdit()
        self.address.setPlaceholderText("Folder path")
        self.address.returnPressed.connect(lambda: self.navigate(self.address.text()))
        self.address.setMinimumWidth(260)
        self.address.textChanged.connect(self.address.setToolTip)  # full path when hovering
        tb.addWidget(self.address)
        tb.addAction(self.a_fav)
        tb.addSeparator()
        self.filter_box = QLineEdit()
        self.filter_box.setPlaceholderText("Filter…")
        self.filter_box.setClearButtonEnabled(True)
        self.filter_box.setFixedWidth(170)
        self.filter_box.textChanged.connect(self._filter_changed)
        tb.addWidget(self.filter_box)
        self.kind_box = QComboBox()
        self.kind_box.addItem("All", "all")
        self.kind_box.addItem("Photos", "photos")
        self.kind_box.addItem("Videos", "videos")
        self.kind_box.addItem("Timeline", "timeline")
        self.kind_box.setItemData(3, "Everything in this folder and all its subfolders, newest first, "
                                     "with the months marked", Qt.ItemDataRole.ToolTipRole)
        self.kind_box.setToolTip("Show all, only photos, only videos, or the Timeline")
        self.kind_box.currentIndexChanged.connect(lambda _i: self._kind_changed())
        tb.addWidget(self.kind_box)
        self.sort_box = QComboBox()
        self.sort_keys = ["name", "taken", "date", "size", "type"]
        self.sort_box.addItems(["Name", "Date taken", "Date modified", "Size", "Type"])
        self.sort_box.setItemData(1, "From the photo's own information (EXIF); files "
                                     "without it use their file date",
                                  Qt.ItemDataRole.ToolTipRole)
        self.sort_box.setToolTip("Sort by")
        self.sort_box.activated.connect(
            lambda i: self.set_sort(self.sort_keys[i], self.model.sort_desc))
        tb.addWidget(self.sort_box)
        self.order_btn = QPushButton()
        self.order_btn.setToolTip("Ascending / descending")
        self.order_btn.setFixedWidth(36)
        self.order_btn.clicked.connect(
            lambda: self.set_sort(self.model.sort_key, not self.model.sort_desc))
        tb.addWidget(self.order_btn)
        tb.addSeparator()
        self.size_slider = QSlider(Qt.Orientation.Horizontal)
        self.size_slider.setRange(96, 256)
        self.size_slider.setSingleStep(16)
        self.size_slider.setPageStep(32)
        self.size_slider.setValue(self.delegate.size)
        self.size_slider.setFixedWidth(120)
        self.size_slider.setToolTip("Thumbnail size")
        self.size_slider.valueChanged.connect(self.set_thumb_size)
        tb.addWidget(self.size_slider)
        tb.addSeparator()
        for a in (self.a_slideshow, self.a_edit, self.a_rot_l, self.a_rot_r):
            tb.addAction(a)
        tb.addSeparator()
        tb.addAction(self.a_delete)
        tb.addAction(self.a_refresh)  # refresh the folder (also asks the cloud again)
        bin_btn = tb.widgetForAction(self.a_delete)
        if bin_btn is not None:
            bin_btn.setIconSize(QSize(30, 30))
            bin_btn.setToolTip("Move to Trash (Delete)")
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)
        tb.addAction(self.a_settings)
        self._sync_sort_ui()

    def _restore_layout(self):
        s = settings()
        geo = s.value("geometry")
        if geo is not None:
            self.restoreGeometry(geo)
        state = s.value("split_main")
        if state is not None:
            self.main_split.restoreState(state)
        self.a_preview.setChecked(setting("show_preview", True, bool))
        self.a_sidebar.setChecked(setting("show_sidebar", True, bool))
        self.preview_scroll.setVisible(self.a_preview.isChecked())
        self.left.setVisible(self.a_sidebar.isChecked())

    def new_window(self):
        """Another window in the same HansViewer: shares settings, favourites and the thumbnail list."""
        w = Browser(self.folder)
        w.move(self.pos() + QPoint(40, 40))
        w.show()

    def closeEvent(self, e):
        if self in WINDOWS:
            WINDOWS.remove(self)
        s = settings()
        s.setValue("geometry", self.saveGeometry())
        s.setValue("split_main", self.main_split.saveState())
        s.setValue("show_preview", self.a_preview.isChecked())
        s.setValue("show_sidebar", self.a_sidebar.isChecked())
        s.setValue("thumb_size", self.delegate.size)
        if self.folder:
            s.setValue("last_folder", self.folder)
        if self.viewer is not None:
            self.viewer.close()
        super().closeEvent(e)

    # ------------------------------------------------------------------ navigation
    def navigate(self, path, record=True, keep=None, keep_selected=(), keep_row=None, then=None):
        """Opens a folder. Local folders load at once; network and cloud folders load in the
        background so the window never freezes. `then` runs once the photos are listed."""
        path = os.path.abspath(os.path.expanduser(path.strip()))
        if path != getattr(self, "_via_fav", None):
            self._via_fav = None  # opened some other way: the tree follows again
        remote = is_remote(path)
        if remote and not remote_reachable(path):
            # connect the share the way it was saved (SMB stays SMB); only if that fails, use the
            # same NAS if it is connected another way
            def fallback(p=path):
                alt = live_alternative(p)
                if alt:
                    if self._via_fav == p:
                        self._via_fav, self._fav_from = alt, p   # the favourite stays highlighted
                    self.navigate(alt, record, keep, keep_selected, keep_row, then)
                    return True
                return False
            if is_gvfs(path) and self._auto_connect(path, lambda: self.navigate(
                    path, record, keep, keep_selected, keep_row, then), fallback):
                return
            if fallback():
                return
            copyable_box("warning", self, APP, f"This network or cloud drive isn't connected:\n{path}")
            self.address.setText(self.folder or "")
            return
        if not remote and self._unconnected_cloud(path) and getattr(self, "_cloud_retry", None) != path:
            # a folder on a cloud drive that isn't connected (e.g. after a restart): connect it first
            self._continue_in(path)
            return
        if not remote and not os.path.isdir(path):
            copyable_box("warning", self, APP, f"Folder not found:\n{path}")
            self.address.setText(self.folder or "")
            return
        if record and path != self.folder:
            del self.history[self.hpos + 1:]
            self.history.append(path)
            self.hpos = len(self.history) - 1
        if self.watcher.directories():
            self.watcher.removePaths(self.watcher.directories())
        if not remote:  # change notifications only work (and only make sense) on local disks
            self.watcher.addPath(path)
            settings().setValue("last_local_folder", path)
        if path != self.folder:  # another folder: the last refresh result no longer applies
            self.set_check("")
            self._fresh_pending = False
        self.folder = path
        self.address.setText(path)
        self.setWindowTitle(f"{os.path.basename(path) or path} — {APP} {VERSION}")
        self.a_back.setEnabled(self.hpos > 0)
        self.a_fwd.setEnabled(self.hpos < len(self.history) - 1)
        self._update_fav_button()
        self.grid.empty_text = "Loading…"
        if remote:
            self.status_left.setText(f"Loading…  ·  {path}")
            self.status_left.setToolTip(path)
        self.sync_sidebar()
        lazy = remote and is_lazy(path)
        if remote:
            alog("open folder", path, on_demand=lazy)
        if path != getattr(self, "_tl_folder", None):
            self.model.clear_extra()
        self.model.load(path, remote, lambda: self._loaded(path, keep, keep_selected, keep_row, then),
                        lazy=lazy)
        if self.model.kind == "timeline" and path != getattr(self, "_tl_folder", None):
            self._start_timeline(path)
        if lazy and self.model.sort_key == "taken":
            self.statusBar().showMessage("On this drive photos are sorted by file date — reading "
                                         "“date taken” would mean downloading every photo.", 8000)
        if remote:
            gen = self.model.token["gen"]
            started = time.monotonic()
            QTimer.singleShot(10000, lambda: self._still_loading(path, gen, started))

    def _still_loading(self, path, gen, started):
        """Keeps a live note while the server prepares a big folder list."""
        if not (self.model.loading and self.model.token["gen"] == gen and self.folder == path):
            return
        secs = int(time.monotonic() - started)
        if not self.model.items:
            self.grid.empty_text = (f"The server is still preparing the list of this large folder… "
                                    f"({secs} s)\nYou can keep using HansViewer meanwhile.")
            self.grid.viewport().update()
        self.statusBar().showMessage(f"Reading this folder from the server… {secs} s", 6000)
        QTimer.singleShot(5000, lambda: self._still_loading(path, gen, started))

    def _relisted(self):
        """The server's answer differed from the remembered list: update, keeping the selection."""
        keep, selected = self.current_path(), set(self.selected_paths())
        self._loaded(self.folder, keep, selected, None, None)

    # -- Timeline: this folder and all its subfolders
    def _kind_changed(self):
        kind = self.kind_box.currentData()
        if kind == "timeline":
            self.model.set_kind(kind)
            self._start_timeline(self.folder)
        else:
            self._stop_timeline()
            self.model.set_kind(kind)
        self._selection_changed()

    def _stop_timeline(self):
        self._tl_gen = getattr(self, "_tl_gen", 0) + 1
        self._tl_folder = None
        self.model.clear_extra()

    def _start_timeline(self, folder):
        self._tl_gen = getattr(self, "_tl_gen", 0) + 1
        self._tl_folder = folder
        self.model.clear_extra()
        if not folder:
            return
        if not hasattr(self, "_tl_signals"):
            self._tl_signals = TimelineSignals()
            self._tl_signals.found.connect(lambda g, e: self.model.add_extra(e) if g == self._tl_gen else None)
            self._tl_signals.status.connect(lambda g, t: self.set_check(t) if g == self._tl_gen else None)
            self._tl_signals.done.connect(self._timeline_done)
        self.set_check("Timeline: reading the subfolders…")
        threading.Thread(target=self._timeline_run, args=(folder, self._tl_gen),
                         name="timeline", daemon=True).start()

    def _timeline_run(self, folder, gen):
        _lower_thread_priority()
        sig = self._tl_signals
        try:
            queue = [p for _n, p in timeline_listing(folder)[1]]
        except Exception:
            queue = []
        folders = files = 0
        batch = []
        while queue and self._tl_gen == gen:
            f = queue.pop(0)
            try:
                entries, subs = timeline_listing(f)
            except Exception as ex:
                alog("timeline ERROR", f, error=str(ex)[:100])
                continue
            folders += 1
            files += len(entries)
            batch += entries
            queue += [p for _n, p in subs]
            if len(batch) >= 300 or folders % 10 == 0:
                sig.found.emit(gen, batch)
                batch = []
                sig.status.emit(gen, f"Timeline: reading subfolders… {folders:,} · {files:,} more files")
        if self._tl_gen != gen:
            return
        if batch:
            sig.found.emit(gen, batch)
        sig.done.emit(gen, folders, files)

    def _timeline_done(self, gen, folders, files):
        if gen != self._tl_gen:
            return
        self.set_check(f"✓ Timeline – {len(self.model.items):,} items, {folders:,} subfolders", 15000)
        if self.folder and not is_remote(self.folder):
            self.model.ensure_dates()    # "date taken" from the photos (on this computer only)

    def set_check(self, text, clear_after=0):
        """The refresh / check state in the status bar (stays until replaced, or [clear_after] ms)."""
        self.status_check.setText(text)
        self._check_timer.stop()
        if clear_after:
            self._check_timer.start(clear_after)

    def _checked(self, added, removed, total, error):
        self._fresh_pending = False
        if error:
            self.set_check(f"⚠ Could not check for changes: {error[:80]}", 20000)
        elif added or removed:
            parts = []
            if added:
                parts.append(f"{added:,} new")
            if removed:
                parts.append(f"{removed:,} gone")
            self.set_check(f"✓ Updated: {', '.join(parts)} – {total:,} items", 20000)
        else:
            self.set_check(f"✓ Up to date – {total:,} items", 15000)

    def _loaded(self, path, keep, keep_selected, keep_row, then):
        if path != self.folder:
            return
        if is_remote(path):
            alog("folder shown", path, photos=len(self.model.items), error=self.model.error or "-")
        self.grid.empty_text = (f"Can't open this folder: {self.model.error}" if self.model.error
                                else "No images in this folder")
        if keep and keep in self.model.row_of:
            self.select_path(keep)
        elif keep_row is not None and self.model.items:
            self.grid.setCurrentIndex(self.model.index(min(keep_row, len(self.model.items) - 1)))
        elif self.model.items:
            self.grid.setCurrentIndex(self.model.index(0))
        if keep_selected:
            sm = self.grid.selectionModel()
            for p in keep_selected:
                row = self.model.row_of.get(p)
                if row is not None:
                    sm.select(self.model.index(row), sm.SelectionFlag.Select)
        self.grid.scrollTo(self.grid.currentIndex())
        self.grid.viewport().update()
        self._selection_changed()
        if getattr(self, "_fresh_pending", False) and not getattr(self.model, "_refreshing", False):
            # a refreshed network folder that had no remembered list: it was read in full just now
            self._fresh_pending = False
            self.set_check(f"✓ Refreshed – {len(self.model.all):,} items", 15000)
        if then:
            then()

    def reload(self, then=None, fresh=False):
        """Refresh (Ctrl+R). On a cloud drive this also makes rclone ask the cloud again, so
        changes made elsewhere (e.g. photos added to a shared folder) show up."""
        if not self.folder:
            return
        if fresh:
            self.set_check("⟳ Refreshing…")
            self._fresh_pending = True
        if fresh and is_remote(self.folder) and mount_of(self.folder)[1].startswith("fuse.rclone"):
            if rclone_refresh(self.folder):
                self.statusBar().showMessage("Asking the cloud for the latest folder contents…", 6000)
        item = self.sidebar.currentItem()
        data = item.data(0, Qt.ItemDataRole.UserRole) if item else None
        if data and data[0] in ("dev", "dir") and data[1] == self.folder and item.isExpanded() \
                and is_remote(self.folder):
            self.sidebar.collapseItem(item)   # re-read its subfolders
            self.sidebar.expandItem(item)
        if is_remote(self.folder) or os.path.isdir(self.folder):
            self.navigate(self.folder, record=False, keep=self.current_path(),
                          keep_selected=set(self.selected_paths()), then=then)
            if fresh and not is_remote(self.folder):
                self._fresh_pending = False
                self.set_check(f"✓ Refreshed – {len(self.model.all):,} items", 15000)
        else:
            self.go_up()


    def go_back(self):
        if self.hpos > 0:
            self.hpos -= 1
            self.navigate(self.history[self.hpos], record=False)

    def go_forward(self):
        if self.hpos < len(self.history) - 1:
            self.hpos += 1
            self.navigate(self.history[self.hpos], record=False)

    def go_up(self):
        if self.folder:
            parent = os.path.dirname(self.folder.rstrip("/")) or "/"
            while not is_remote(parent) and not os.path.isdir(parent) and parent != "/":
                parent = os.path.dirname(parent)
            self.navigate(parent, keep=None)

    def open_folder_dialog(self):
        d = QFileDialog.getExistingDirectory(self, "Open folder", self.folder or "")
        if d:
            self.navigate(d)

    # ------------------------------------------------------------------ sidebar
    def refresh_favourites(self):
        self.sec_fav.takeChildren()
        favs = setting("favourites", [], list)
        if not favs and not setting("favourites_seeded", False, bool):
            favs = [os.path.expanduser("~")]
            pics = os.path.expanduser("~/Pictures")
            if os.path.isdir(pics):
                favs.append(pics)
            settings().setValue("favourites", favs)
        settings().setValue("favourites_seeded", True)
        self.sidebar.blockSignals(True)
        for p in favs:
            if p == os.path.expanduser("~"):
                ic = icon("user-home", SP.SP_DirHomeIcon)
            else:
                ic = icon("folder-pictures folder" if "Pictures" in p else "folder", SP.SP_DirIcon)
            it = QTreeWidgetItem([self.fav_label(p)])
            it.setIcon(0, ic)
            it.setToolTip(0, p)
            it.setData(0, Qt.ItemDataRole.UserRole, ("fav", p))
            it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
                        | Qt.ItemFlag.ItemIsEditable)
            self.sec_fav.addChild(it)
        self.sidebar.blockSignals(False)
        if self.folder:
            self.sync_sidebar()
        if hasattr(self, "a_fav"):
            self._update_fav_button()

    def refresh_devices(self):
        """Rebuilds DEVICES (this computer), NETWORK and CLOUD when drives come and go."""
        refresh_nas_state()
        if len(WINDOWS) > 1:   # favourites changed in another window: show them here too
            sig = (tuple(setting("favourites", [], list)), setting("fav_names", "", str))
            if sig != getattr(self, "_fav_sig", sig):
                self.refresh_favourites()
            self._fav_sig = sig
        devs = list_devices()
        if devs == self._devices_sig:
            return
        self._devices_sig = devs
        self.refresh_network(devs)
        self.refresh_clouds(devs)
        local = [d for d in devs if d[2] in ("hd", "home")]
        if local != getattr(self, "_local_sig", None):
            self._local_sig = local
            self.sec_dev.takeChildren()
            for label, path, kind in local:
                if kind == "home":
                    ic = icon("user-home", SP.SP_DirHomeIcon)
                elif path.startswith(("/media/", "/run/media/")):
                    ic = icon("drive-removable-media media-removable", SP.SP_DriveHDIcon)
                else:
                    ic = icon("drive-harddisk", SP.SP_DriveHDIcon)
                self.sec_dev.addChild(self._drive_item(label, path, ic))
        if self.folder:
            self.sync_sidebar()

    def _drive_item(self, label, path, ic, tip=None):
        it = QTreeWidgetItem([label])
        it.setIcon(0, ic)
        it.setToolTip(0, tip or path)
        it.setData(0, Qt.ItemDataRole.UserRole, ("dev", path))
        self._add_placeholder(it)
        return it

    def _add_placeholder(self, item):
        ph = QTreeWidgetItem([""])
        ph.setData(0, Qt.ItemDataRole.UserRole, ("placeholder", ""))
        ph.setFlags(Qt.ItemFlag.NoItemFlags)
        item.addChild(ph)

    def _populate(self, item):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data or data[0] not in ("dev", "dir") or item.childCount() != 1:
            return
        first = item.child(0).data(0, Qt.ItemDataRole.UserRole)
        if not first or first[0] not in ("placeholder", "failed"):
            return
        if is_remote(data[1]):
            cached = list_cache_get(data[1]) if is_gvfs(data[1]) else None
            if cached is not None:  # from the last visit; checked quietly afterwards
                item.takeChildren()
                self._fill_subfolders(item, subfolders_from_listing(data[1], cached))
                self._refreshing_tree[data[1]] = item
                drive_pool("subfolders", data[1]).start(SubfolderJob(data[1], self.list_signals))
                return
            ph = item.child(0)
            ph.setText(0, "Loading…")
            ph.setForeground(0, QColor(THEME["muted"]))
            ph.setData(0, Qt.ItemDataRole.UserRole, ("loading", data[1]))
            self._populating[data[1]] = item
            drive_pool("subfolders", data[1]).start(SubfolderJob(data[1], self.list_signals))
            return
        item.takeChildren()
        self._fill_subfolders(item, scan_subfolders(data[1]))

    def _fill_subfolders(self, item, subs):
        folder_icon = icon("folder", SP.SP_DirIcon)
        for name, path in subs:
            child = QTreeWidgetItem([name])
            child.setIcon(0, folder_icon)
            child.setToolTip(0, path)
            child.setData(0, Qt.ItemDataRole.UserRole, ("dir", path))
            self._add_placeholder(child)
            item.addChild(child)

    def _subfolders_ready(self, folder, subs):
        quiet = self._refreshing_tree.pop(folder, None)
        if quiet is not None:
            if sip.isdeleted(quiet) or isinstance(subs, str):
                return
            now = [quiet.child(i).text(0) for i in range(quiet.childCount())]
            if now != [n for n, _p in subs]:
                quiet.takeChildren()
                self._fill_subfolders(quiet, subs)
            return
        item = self._populating.pop(folder, None)
        if item is None or sip.isdeleted(item):
            return
        if item.childCount() != 1:
            return
        ph = item.child(0).data(0, Qt.ItemDataRole.UserRole)
        if not ph or ph[0] != "loading":
            return
        if isinstance(subs, str):  # the server didn't answer: say so, and allow a retry
            placeholder = item.child(0)
            placeholder.setText(0, "Server not answering — close and open again to retry")
            placeholder.setToolTip(0, subs)
            placeholder.setData(0, Qt.ItemDataRole.UserRole, ("failed", folder))
            return
        item.takeChildren()
        self._fill_subfolders(item, subs)
        if self.folder and (self.folder == folder or self.folder.startswith(folder.rstrip("/") + "/")):
            self.sync_sidebar()  # continue opening the tree down to the current folder

    def sync_sidebar(self):
        """Expand the device tree down to the current folder and highlight it. A folder opened
        through a favourite keeps that favourite highlighted and leaves the tree as it is."""
        path = self.folder
        if path and getattr(self, "_via_fav", None) == path:
            origin = getattr(self, "_fav_from", None)    # favourite reached by another connection
            for i in range(self.sec_fav.childCount()):
                it = self.sec_fav.child(i)
                d = it.data(0, Qt.ItemDataRole.UserRole)
                if d and d[0] == "fav" and os.path.abspath(os.path.expanduser(d[1])) in (path, origin):
                    self.sidebar.setCurrentItem(it)
                    self.sidebar.scrollToItem(it)
                    return
        best, best_root = None, ""
        tops = []
        for sec in (self.sec_dev, self.sec_net, self.sec_cloud):
            tops += [sec.child(i) for i in range(sec.childCount())]
        for it in tops:
            data = it.data(0, Qt.ItemDataRole.UserRole)
            if not data or data[0] != "dev":
                continue
            root = data[1]
            inside = path == root or path.startswith(root.rstrip("/") + "/")
            if inside and len(root) > len(best_root):
                best, best_root = it, root
        if best is None:
            self.sidebar.clearSelection()
            return
        item = best
        rel = os.path.relpath(path, best_root)
        for part in ([] if rel == "." else rel.split(os.sep)):
            self.sidebar.expandItem(item)  # fills in its subfolders
            nxt = None
            for i in range(item.childCount()):
                c = item.child(i)
                d = c.data(0, Qt.ItemDataRole.UserRole)
                if d and d[0] == "dir" and os.path.basename(d[1]) == part:
                    nxt = c
                    break
            if nxt is None:  # hidden or unreadable folder: stop at the closest parent
                break
            item = nxt
        self.sidebar.setCurrentItem(item)
        self.sidebar.scrollToItem(item)

    def _sidebar_clicked(self, item, _col):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data or data[0] in ("placeholder", "loading", "failed"):
            return
        if data[0] == "action":
            self.add_cloud() if data[1] == "cloud" else self.connect_server()
        elif data[0] == "cloud":
            self.open_cloud(data[1])
        elif data[0] == "server":
            self.open_server(data[1])
        else:
            self._via_fav = os.path.abspath(os.path.expanduser(data[1])) if data[0] == "fav" else None
            self._fav_from = None
            self.navigate(data[1])

    def _sidebar_menu(self, pos):
        item = self.sidebar.itemAt(pos)
        data = item.data(0, Qt.ItemDataRole.UserRole) if item else None
        if not data or data[0] in ("placeholder", "action", "loading", "failed"):
            return
        kind, path = data
        m = QMenu(self)
        cloud_index = None
        if item.parent() is self.sec_cloud:
            names = [cloud_dir(c) for c in saved_clouds()]
            cloud_index = path if kind == "cloud" else (names.index(path) if path in names else None)
        if cloud_index is not None:
            mounted = kind != "cloud"
            menu_add(m, "Open" if mounted else "Connect", lambda: self.open_cloud(cloud_index))
            self._alias_menu(m, item)
            if mounted:
                menu_add(m, "Add to favourites", lambda: self.add_favourite(path))
                menu_add(m, "Disconnect", lambda: self.disconnect_cloud(cloud_index))
                m.addSeparator()
                menu_add(m, "Make thumbnails for this folder", lambda: self.make_thumbnails(path))
                menu_add(m, "Make thumbnails incl. subfolders",
                         lambda: self.make_thumbnails(path, subfolders=True))
            m.addSeparator()
            menu_add(m, "Remove from sidebar", lambda: self.remove_cloud(cloud_index))
            m.exec(self.sidebar.viewport().mapToGlobal(pos))
            return
        srv_index = item.data(0, ROLE_SERVER)
        if kind == "server" or isinstance(srv_index, int):
            if kind == "server":
                srv_index = path
            path = srv_index
            servers = saved_servers()
            srv = servers[path] if 0 <= path < len(servers) else None
            if srv is None:
                return
            mounted = find_gvfs_path(srv["scheme"], srv["host"], srv["share"], srv.get("rest", ""))
            menu_add(m, "Open" if mounted else "Connect", lambda: self.open_server(path))
            self._alias_menu(m, item)
            menu_add(m, "Edit connection…", lambda: self.connect_server(edit=path))
            if mounted:
                menu_add(m, "Disconnect", lambda: self.disconnect(mounted))
                menu_add(m, "Make thumbnails for this folder",
                         lambda: self.make_thumbnails(mounted))
                menu_add(m, "Make thumbnails incl. subfolders",
                         lambda: self.make_thumbnails(mounted, subfolders=True))
            m.addSeparator()
            menu_add(m, "Remove from sidebar", lambda: self.remove_server(path))
            m.exec(self.sidebar.viewport().mapToGlobal(pos))
            return
        menu_add(m, "Open", lambda: self.navigate(path))
        menu_add(m, "Open in file manager",
                 lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(path)))
        if kind == "fav":
            favs = setting("favourites", [], list)
            i = favs.index(path) if path in favs else -1
            m.addSeparator()
            up = menu_add(m, "Move up", lambda: self._move_fav(i, -1))
            up.setEnabled(i > 0)
            down = menu_add(m, "Move down", lambda: self._move_fav(i, 1))
            down.setEnabled(0 <= i < len(favs) - 1)
            menu_add(m, "Rename…\tF2", lambda: self.rename_favourite(path))
            if path in self.fav_names():
                menu_add(m, "Restore original name", lambda: (self.set_fav_name(path, ""),
                                                              self.refresh_favourites()))
            menu_add(m, "Remove from favourites", lambda: self.remove_favourite(path))
        elif kind in ("dev", "dir"):
            menu_add(m, "Add to favourites", lambda: self.add_favourite(path))
            if kind == "dev" and item.parent() in (self.sec_net, self.sec_cloud):
                self._alias_menu(m, item)
            if kind == "dir":
                menu_add(m, "Rename…\tF2", lambda: self.rename_folder(item))
            if is_remote(path):
                m.addSeparator()
                menu_add(m, "Make thumbnails for this folder", lambda: self.make_thumbnails(path))
                menu_add(m, "Make thumbnails incl. subfolders",
                         lambda: self.make_thumbnails(path, subfolders=True))
            if kind == "dev" and path.startswith(gvfs_root() + "/"):
                m.addSeparator()
                menu_add(m, "Disconnect", lambda: self.disconnect(path))
        m.exec(self.sidebar.viewport().mapToGlobal(pos))

    # -- network servers
    def refresh_network(self, devs=None):
        devs = list_devices() if devs is None else devs
        nets = [d for d in devs if d[2] == "net"]
        servers = saved_servers()
        mounted = [find_gvfs_path(s["scheme"], s["host"], s["share"], s.get("rest", "")) for s in servers]
        sig = (json.dumps(servers), tuple(nets), tuple(mounted))
        if sig == getattr(self, "_network_sig", None):
            return
        self._network_sig = sig
        self.sec_net.takeChildren()
        on = icon("network-server folder-remote", SP.SP_DriveNetIcon)
        off = icon("network-offline network-server", SP.SP_DriveNetIcon)
        shown = set()
        for i, (srv, path) in enumerate(zip(servers, mounted)):
            alias, real = server_alias(srv), server_real_name(srv)
            label = alias or real
            uri = server_uri(srv["scheme"], srv["host"], srv["share"], srv.get("rest", ""))
            if path:  # connected: opens into its subfolders like a drive
                it = self._drive_item(label, path, on, uri + "   (connected)")
                root = gvfs_root() + "/"
                shown.add(root + path[len(root):].split("/", 1)[0] if path.startswith(root) else path)
            else:
                it = QTreeWidgetItem([label])
                it.setIcon(0, off)
                it.setToolTip(0, uri + "   (click to connect)")
                it.setData(0, Qt.ItemDataRole.UserRole, ("server", i))
            it.setData(0, ROLE_SERVER, i)
            if alias:
                it.setData(0, ROLE_REAL, real)
            self.sec_net.addChild(it)
        custom = drive_names()
        for label, path, _kind in nets:  # shares connected elsewhere (file manager, fstab)
            if path not in shown:
                it = self._drive_item(custom.get(path) or label, path, on)
                if custom.get(path):
                    it.setData(0, ROLE_REAL, label)
                self.sec_net.addChild(it)
        add = QTreeWidgetItem(["Connect to server…"])
        add.setIcon(0, icon("list-add", SP.SP_FileDialogNewFolder))
        add.setForeground(0, QColor(THEME["accent"]))
        add.setData(0, Qt.ItemDataRole.UserRole, ("action", "connect"))
        self.sec_net.addChild(add)

    def connect_server(self, edit=None):
        servers = saved_servers()
        prefill = servers[edit] if edit is not None and 0 <= edit < len(servers) else None
        dlg = ConnectDialog(self, prefill)
        if not dlg.exec():
            return
        if dlg.cloud is not None:
            clouds = [c for c in saved_clouds() if c["name"] != dlg.cloud["name"]]
            clouds.append(dlg.cloud)
            save_clouds(clouds)
            self._cloud_sig = None
            self._devices_sig = None
            self.refresh_devices()
            self.navigate(dlg.result_path)
            return
        srv = dlg.server
        if prefill is not None and "alias" not in srv:
            srv["alias"] = server_alias(prefill)  # editing the connection keeps your alias
        if dlg.save.isChecked() or edit is not None:
            servers = [s for j, s in enumerate(servers) if j != edit and not (
                s["scheme"] == srv["scheme"] and s["host"] == srv["host"] and s["share"] == srv["share"])]
            servers.append(srv)
            save_servers(servers)
        self._network_sig = None
        self.refresh_devices()
        self.refresh_network()
        self.navigate(dlg.result_path or gvfs_root())

    def open_server(self, index):
        servers = saved_servers()
        if not 0 <= index < len(servers):
            return
        srv = servers[index]
        path = find_gvfs_path(srv["scheme"], srv["host"], srv["share"], srv.get("rest", ""))
        if path:
            self.navigate(path)
            return
        uri = server_uri(srv["scheme"], srv["host"], srv["share"])
        pw = keyring_lookup(uri, srv.get("user", "")) if srv.get("remember") else None
        if not srv.get("guest") and pw is None:
            self.connect_server(edit=index)  # ask for the password
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self.statusBar().showMessage(f"Connecting to {srv['host']}…")
        signals = ConnectSignals()
        self._connect_signals = signals  # keep alive until done

        def done(ok, msg):
            QApplication.restoreOverrideCursor()
            self.statusBar().clearMessage()
            if ok:
                self._network_sig = None
                self.refresh_devices()
                self.refresh_network()
                self.navigate(find_gvfs_path(srv["scheme"], srv["host"], srv["share"],
                                             srv.get("rest", "")) or gvfs_root())
            else:
                copyable_box("warning", self, "Connect", f"Could not connect to {srv['host']}:\n{msg}")
                self.connect_server(edit=index)

        signals.done.connect(done)
        QThreadPool.globalInstance().start(ConnectJob(
            lambda: gio_mount(uri, srv.get("user", ""), srv.get("domain", ""), pw or "",
                              anonymous=srv.get("guest", False)), signals.done))

    def _auto_connect(self, path, then, fallback=None):
        """Connects the network share of `path` by itself (after a restart GVFS shares are not
        connected), with the saved login, then runs `then`. Returns False if it can't try."""
        info = gvfs_info(path)
        if not info or getattr(self, "_connecting", None):
            return bool(info and getattr(self, "_connecting", None))
        name, scheme, kv, rest = info
        uri = uri_from_gvfs_name(name)
        if not uri:
            return False
        host = (kv.get("server") or kv.get("host") or "").lower()
        share = (kv.get("share") or kv.get("volume") or "").lower()
        user, domain, pw, guest = kv.get("user", ""), kv.get("domain", ""), "", False
        for srv in saved_servers():
            sch = srv.get("scheme", "")
            if GVFS_PREFIX.get(sch, sch) != scheme and not (sch in ("dav", "davs") and scheme == "dav"):
                continue
            if srv.get("host", "").lower().split(":")[0] != host:
                continue
            if scheme == "smb-share" and srv.get("share", "").lower() != share:
                continue
            user, domain, guest = srv.get("user", ""), srv.get("domain", ""), srv.get("guest", False)
            if srv.get("remember"):
                pw = keyring_lookup(server_uri(sch, srv["host"], srv.get("share", "")), user) or ""
            break
        self._connecting = path
        label = host + (f" ({share})" if share else "")
        self.statusBar().showMessage(f"Connecting to {label}…")
        alog("auto-connect", uri)
        signals = ConnectSignals()
        self._auto_signals = signals

        def done(ok, msg):
            self._connecting = None
            self.statusBar().clearMessage()
            self._devices_sig = self._network_sig = None
            self.refresh_devices()
            self.refresh_network()
            alog("auto-connect done", uri, ok=ok, msg=str(msg)[:100])
            if ok and remote_reachable(path):
                then()
                return
            if ok and scheme == "smb-share":
                p2 = find_gvfs_path("smb", host, share, rest)
                if p2:
                    self.navigate(p2)
                    return
            if fallback is not None and fallback():
                return
            copyable_box("warning", self, "Connect",
                         f"Could not connect to {label} by itself:\n{msg}\n\n"
                         "Connect it once in the sidebar under NETWORK (with “Remember password”), "
                         "then HansViewer can do it by itself next time.")
            self.address.setText(self.folder or "")

        signals.done.connect(done)
        QThreadPool.globalInstance().start(ConnectJob(
            lambda: gio_mount(uri, user, domain, pw, anonymous=guest), signals.done))
        return True

    def remove_server(self, index):
        servers = saved_servers()
        if 0 <= index < len(servers):
            srv = servers.pop(index)
            keyring_clear(server_uri(srv["scheme"], srv["host"], srv["share"]), srv.get("user", ""))
            save_servers(servers)
            self._network_sig = None
            self.refresh_network()

    def disconnect(self, path):
        root = gvfs_root() + "/"
        mount = root + path[len(root):].split("/", 1)[0] if path.startswith(root) else path
        if self.folder and (self.folder == mount or self.folder.startswith(mount + "/")):
            self.navigate(os.path.expanduser("~"))
        ok, msg = gio_unmount(path)
        self._network_sig = None
        self.refresh_devices()
        self.refresh_network()
        self.statusBar().showMessage("Disconnected" if ok else f"Could not disconnect: {msg}", 4000)

    # -- cloud storage
    def refresh_clouds(self, devs=None):
        devs = list_devices() if devs is None else devs
        clouds = saved_clouds()
        others = [d for d in devs if d[2] == "cloud" and d[1] not in {cloud_dir(c) for c in clouds}]
        sig = (json.dumps(clouds), tuple(cloud_mounted(c) for c in clouds), tuple(others))
        if sig == getattr(self, "_cloud_sig", None):
            return
        self._cloud_sig = sig
        self.sec_cloud.takeChildren()
        ic = icon("folder-cloud weather-overcast folder-remote", SP.SP_DriveNetIcon)
        off = icon("network-offline folder-cloud", SP.SP_DriveNetIcon)
        for i, c in enumerate(clouds):
            real = c.get("label") or c["name"]
            label = c.get("alias") or real
            if cloud_mounted(c):
                it = self._drive_item(label, cloud_dir(c), ic, f"{c['name']}:  →  {cloud_dir(c)}")
            else:
                it = QTreeWidgetItem([label])
                it.setIcon(0, off)
                it.setToolTip(0, f"{c['name']}:  (click to connect)")
                it.setData(0, Qt.ItemDataRole.UserRole, ("cloud", i))
            if c.get("alias"):
                it.setData(0, ROLE_REAL, real)
            self.sec_cloud.addChild(it)
        custom = drive_names()
        for label, path, _kind in others:  # e.g. Google Drive from Online Accounts
            it = self._drive_item(custom.get(path) or label, path, ic)
            if custom.get(path):
                it.setData(0, ROLE_REAL, label)
            self.sec_cloud.addChild(it)
        add = QTreeWidgetItem(["Add cloud storage…"])
        add.setIcon(0, icon("list-add", SP.SP_FileDialogNewFolder))
        add.setForeground(0, QColor(THEME["accent"]))
        add.setData(0, Qt.ItemDataRole.UserRole, ("action", "cloud"))
        self.sec_cloud.addChild(add)

    def add_cloud(self):
        dlg = CloudDialog(self)
        if not dlg.exec() or not dlg.added:
            return
        clouds = [c for c in saved_clouds() if c["name"] != dlg.added["name"]]
        label = dlg.added["label"]
        if sum(1 for c in clouds if c.get("label") == label) or label == dlg.added["name"]:
            label = f"{label} ({dlg.added['name']})" if label != dlg.added["name"] else label
        entry = {"name": dlg.added["name"], "label": label, "shared_checked": True}
        clouds.append(entry)
        if rclone_remote_types().get(entry["name"]) == "drive":
            clouds.append(shared_entry(entry))
        save_clouds(clouds)
        self._cloud_sig = None
        main_index = clouds.index(entry)
        if len(clouds) > main_index + 1:
            self.open_cloud(main_index + 1, quiet=True)  # Shared with me, in the background
        self.open_cloud(main_index)

    def open_cloud(self, index, quiet=False):
        clouds = saved_clouds()
        if not 0 <= index < len(clouds):
            return
        c = clouds[index]
        if cloud_mounted(c):
            if not quiet:
                self.navigate(cloud_dir(c))
            return
        if not quiet:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self.statusBar().showMessage(f"Connecting {c.get('label') or c['name']}…")
        signals = ConnectSignals()
        self._cloud_signals = getattr(self, "_cloud_signals", []) + [signals]

        def done(ok, msg):
            if not quiet:
                QApplication.restoreOverrideCursor()
                self.statusBar().clearMessage()
            self._cloud_sig = None
            self._devices_sig = None
            self.refresh_devices()
            if ok and not quiet:
                self.navigate(cloud_dir(c))
            elif not ok and not quiet:
                copyable_box("warning", self, "Cloud storage",
                                    f"Could not connect {c.get('label') or c['name']}:\n{msg}")

        signals.done.connect(done)
        QThreadPool.globalInstance().start(ConnectJob(
            lambda: rclone_mount(c["name"], extra=c.get("args", []), mount=c.get("mount")), signals.done))

    def auto_connect_clouds(self):
        if not rclone_available():
            return
        trim_rclone_logs()
        if getattr(self, "_log_timer", None) is not None:
            self._log_timer.stop()
        self._log_timer = QTimer(self)
        self._log_timer.timeout.connect(
            lambda: threading.Thread(target=trim_rclone_logs, daemon=True).start())
        self._log_timer.start(10 * 60 * 1000)
        # first bring cloud folders connected by an older version up to date, then connect the rest
        sig = ConnectSignals()
        self._update_sig = sig
        sig.done.connect(self._clouds_updated)
        QThreadPool.globalInstance().start(
            ConnectJob(lambda: (True, str(rclone_update_mounts())), sig.done))

    def _clouds_updated(self, _ok, count):
        if count not in ("", "0"):
            self.statusBar().showMessage("Cloud folders reconnected with the new settings "
                                         "(folder lists are now kept for 12 hours).", 8000)
            self._devices_sig = None
            self.refresh_devices()
        self._add_shared_entries()
        for i, c in enumerate(saved_clouds()):
            if not cloud_mounted(c):
                self.open_cloud(i, quiet=True)

    def _add_shared_entries(self):
        """Google Drive accounts added before 2.8 get their 'Shared with me' entry once."""
        clouds = saved_clouds()
        todo = [c for c in clouds if not c.get("mount") and not c.get("shared_checked")]
        if not todo:
            return
        types = rclone_remote_types()
        for c in todo:
            c["shared_checked"] = True
            if types.get(c["name"]) == "drive" and not any(
                    x.get("mount") == c["name"] + "-shared" for x in clouds):
                clouds.insert(clouds.index(c) + 1, shared_entry(c))
        save_clouds(clouds)
        self._cloud_sig = None
        self.refresh_clouds()

    def disconnect_cloud(self, index):
        clouds = saved_clouds()
        if not 0 <= index < len(clouds):
            return
        path = cloud_dir(clouds[index])
        if self.folder and (self.folder == path or self.folder.startswith(path + "/")):
            self.navigate(os.path.expanduser("~"))
        ok, msg = rclone_unmount(path)
        self._cloud_sig = None
        self.refresh_clouds()
        self.statusBar().showMessage("Disconnected" if ok else f"Could not disconnect: {msg}", 4000)

    def remove_cloud(self, index):
        clouds = saved_clouds()
        if not 0 <= index < len(clouds):
            return
        if cloud_mounted(clouds[index]):
            self.disconnect_cloud(index)
        clouds.pop(index)
        save_clouds(clouds)
        self._cloud_sig = None
        self._devices_sig = None
        self.refresh_devices()

    def rename_drive(self, item, remove=False):
        """Sets your alias for a network share or cloud folder. The alias is shown first and the
        real name stays visible below it; nothing is changed on the server itself."""
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data:
            return
        real = item.data(0, ROLE_REAL) or item.text(0)
        current = item.text(0) if item.data(0, ROLE_REAL) else ""
        if remove:
            name = ""
        else:
            name, ok = QInputDialog.getText(
                self, "Set alias", f"Your name for “{real}”\n(the real name stays visible below "
                "it; leave empty to show only the real name):", text=current)
            if not ok:
                return
        name = name.strip()
        if name == real:
            name = ""
        srv_index = item.data(0, ROLE_SERVER)
        if isinstance(srv_index, int) or data[0] == "server":
            servers = saved_servers()
            i = srv_index if isinstance(srv_index, int) else data[1]
            if 0 <= i < len(servers):
                srv = servers[i]
                srv["alias"] = name
                srv.pop("name", None)  # the old way of renaming (before 4.0)
                save_servers(servers)
        elif item.parent() is self.sec_cloud:
            clouds = saved_clouds()
            idx = data[1] if data[0] == "cloud" else next(
                (j for j, c in enumerate(clouds) if cloud_dir(c) == data[1]), None)
            if idx is not None and 0 <= idx < len(clouds):
                clouds[idx]["alias"] = name
                save_clouds(clouds)
            else:
                set_drive_name(data[1], name)
        else:
            set_drive_name(data[1], name)
        self._network_sig = self._cloud_sig = self._devices_sig = None
        self.refresh_devices()

    def rename_folder(self, item):
        """Right-click → Rename (F2) on a folder in the sidebar: renamed for real, like in the
        file manager, on your disk, a NAS or a cloud drive."""
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data or data[0] != "dir":
            return
        old = data[1].rstrip("/")
        parent, base = os.path.split(old)
        name, ok = QInputDialog.getText(self, "Rename folder", f"New name for the folder “{base}”:",
                                        text=base)
        name = name.strip() if ok else ""
        if not name or name == base:
            return
        if "/" in name or name in (".", ".."):
            copyable_box("warning", self, "Rename folder", "Folder names can't contain “/”.")
            return
        new = os.path.join(parent, name)
        self.statusBar().showMessage(f"Renaming “{base}” to “{name}”…")
        sig = ConnectSignals()
        self._rename_sig = sig  # keep alive until done

        def done(ok, msg):
            self.statusBar().clearMessage()
            if not ok:
                copyable_box("warning", self, "Rename folder", f"Could not rename “{base}”:\n{msg}")
                return
            self._folder_renamed(old, new, item)
            self.statusBar().showMessage(f"Renamed to “{name}”.", 4000)

        sig.done.connect(done)
        QThreadPool.globalInstance().start(ConnectJob(lambda: rename_folder_really(old, new), sig.done))

    def _folder_renamed(self, old, new, item):
        """Everything in HansViewer that pointed into the renamed folder now points to the new name."""
        favs = setting("favourites", [], list)
        changed = [_moved(f, old, new) or f for f in favs]
        if changed != favs:
            settings().setValue("favourites", changed)
        names = self.fav_names()
        renamed = {(_moved(k, old, new) or k): v for k, v in names.items()}
        if renamed != names:
            settings().setValue("fav_names", json.dumps(renamed))
        self.history = [_moved(h, old, new) or h for h in self.history]
        with self.queue.lock:
            touched = False
            for q in self.queue.items:
                target = _moved(q["folder"], old, new)
                if target:
                    q["folder"], touched = target, True
        if touched:
            self._queue_changed()
        if not sip.isdeleted(item):
            item.setText(0, os.path.basename(new))
            item.setToolTip(0, new)
            item.setData(0, Qt.ItemDataRole.UserRole, ("dir", new))
            self.sidebar.collapseItem(item)
            item.takeChildren()
            self._add_placeholder(item)
        self.refresh_favourites()
        if self.folder:
            target = _moved(self.folder, old, new)
            if target:
                self.navigate(target, record=False)

    def _alias_menu(self, m, item):
        menu_add(m, "Set alias…\tF2", lambda: self.rename_drive(item))
        if item.data(0, ROLE_REAL):
            menu_add(m, "Remove alias", lambda: self.rename_drive(item, remove=True))

    def _rename_sidebar_item(self):
        item = self.sidebar.currentItem()
        data = item.data(0, Qt.ItemDataRole.UserRole) if item else None
        if not data:
            return
        if data[0] == "fav":
            self.sidebar.editItem(item, 0)
        elif item.parent() in (self.sec_net, self.sec_cloud) and data[0] in ("dev", "server", "cloud"):
            self.rename_drive(item)
        elif data[0] == "dir":
            self.rename_folder(item)

    def _delete_sidebar_favourite(self):
        item = self.sidebar.currentItem()
        data = item.data(0, Qt.ItemDataRole.UserRole) if item else None
        if data and data[0] == "fav":
            self.remove_favourite(data[1])

    def _sidebar_collapsed(self, item):
        """Network and cloud folders are read again the next time they are opened."""
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if data and data[0] in ("dev", "dir") and is_remote(data[1]):
            self._populating.pop(data[1], None)
            self._refreshing_tree.pop(data[1], None)
            item.takeChildren()
            self._add_placeholder(item)

    def _move_fav(self, i, d):
        favs = setting("favourites", [], list)
        if 0 <= i < len(favs) and 0 <= i + d < len(favs):
            favs[i], favs[i + d] = favs[i + d], favs[i]
            settings().setValue("favourites", favs)
            self.refresh_favourites()

    def add_favourite(self, path):
        favs = setting("favourites", [], list)
        if path not in favs:
            favs.append(path)
            settings().setValue("favourites", favs)
            self.refresh_favourites()
            self.statusBar().showMessage(f"Added “{os.path.basename(path) or path}” to favourites",
                                         3000)

    # -- favourite names (stored separately; the folder itself is never renamed)
    def fav_names(self):
        try:
            names = json.loads(setting("fav_names", "{}", str) or "{}")
            return names if isinstance(names, dict) else {}
        except ValueError:
            return {}

    @staticmethod
    def default_fav_label(path):
        if path == os.path.expanduser("~"):
            return "Home"
        return os.path.basename(path.rstrip("/")) or path

    def fav_label(self, path):
        return self.fav_names().get(path) or self.default_fav_label(path)

    def set_fav_name(self, path, name):
        names = self.fav_names()
        name = (name or "").strip()
        if not name or name == self.default_fav_label(path):
            names.pop(path, None)
        else:
            names[path] = name
        settings().setValue("fav_names", json.dumps(names))

    def rename_favourite(self, path):
        for i in range(self.sec_fav.childCount()):
            it = self.sec_fav.child(i)
            if it.data(0, Qt.ItemDataRole.UserRole) == ("fav", path):
                self.sidebar.setCurrentItem(it)
                self.sidebar.editItem(it, 0)  # type the new name, Enter to save
                return

    def _sidebar_item_changed(self, item, _col):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data or data[0] != "fav":
            return
        path = data[1]
        if item.text(0).strip() != self.fav_label(path):
            self.set_fav_name(path, item.text(0))
            QTimer.singleShot(0, self.refresh_favourites)  # shows the default if left empty

    def remove_favourite(self, path):
        favs = [f for f in setting("favourites", [], list) if f != path]
        settings().setValue("favourites", favs)
        self.set_fav_name(path, "")
        self.refresh_favourites()

    def toggle_favourite(self):
        if not self.folder:
            return
        if self.folder in setting("favourites", [], list):
            self.remove_favourite(self.folder)
        else:
            self.add_favourite(self.folder)

    def _update_fav_button(self):
        is_fav = self.folder in setting("favourites", [], list)
        self.a_fav.setIcon(icon("starred" if is_fav else "non-starred bookmark-new"))
        self.a_fav.setText("Remove from favourites" if is_fav else "Add to favourites")
        if self.a_fav.icon().isNull():
            self.a_fav.setText("★" if is_fav else "☆")

    def _fill_fav_menu(self):
        self.fav_menu.clear()
        self.fav_menu.addAction(self.a_fav)
        self.fav_menu.addSeparator()
        for p in setting("favourites", [], list):
            a = self.fav_menu.addAction(icon("folder", SP.SP_DirIcon), self.fav_label(p))
            a.setToolTip(p)
            a.triggered.connect(lambda _=False, p=p: self.navigate(p))

    # ------------------------------------------------------------------ grid helpers
    def current_entry(self):
        idx = self.grid.currentIndex()
        if idx.isValid() and idx.row() < len(self.model.items):
            return self.model.items[idx.row()]
        return None

    def current_path(self):
        e = self.current_entry()
        return e["path"] if e else None

    def selected_rows(self):
        rows = sorted(i.row() for i in self.grid.selectionModel().selectedIndexes())
        if not rows and self.grid.currentIndex().isValid():
            rows = [self.grid.currentIndex().row()]
        return [r for r in rows if r < len(self.model.items)]

    def selected_paths(self):
        return [self.model.items[r]["path"] for r in self.selected_rows()]

    def select_path(self, path):
        row = self.model.row_of.get(path)
        if row is not None:
            idx = self.model.index(row)
            self.grid.setCurrentIndex(idx)
            self.grid.scrollTo(idx)

    def _selection_changed(self):
        rows = self.selected_rows()
        n = len(self.model.items)
        total = len(self.model.all)
        shown = f"{n} of {total} images" if self.model.filter else f"{n} images"
        self.status_left.setText(f"{shown}  ·  {human_size(self.model.total_size())}"
                                 f"  ·  {self.folder or ''}")
        self.status_left.setToolTip(self.folder or "")
        if len(rows) > 1:
            self.status_right.setText(f"{len(rows)} selected  ·  "
                                      f"{human_size(self.model.total_size(rows))}")
        elif rows:
            e = self.model.items[rows[0]]
            self.status_right.setText(f"{e['name']}  ·  {human_size(e['size'])}  ·  "
                                      f"{rows[0] + 1} / {n}")
        else:
            self.status_right.clear()
        has = bool(rows)
        for a in (self.a_edit, self.a_rot_l, self.a_rot_r, self.a_rename, self.a_delete,
                  self.a_copy_to, self.a_move_to, self.a_copy_img, self.a_copy_path,
                  self.a_wallpaper, self.a_open_with, self.a_view, self.a_view_full):
            a.setEnabled(has)
        self.a_batch.setEnabled(len(rows) > 1)
        remote_folder = bool(self.folder) and is_remote(self.folder)
        self.a_thumbs.setEnabled(remote_folder)
        self.a_thumbs_sub.setEnabled(remote_folder)
        self.a_slideshow.setEnabled(n > 0)
        self.preview_timer.start(120)

    def _load_preview(self):
        if not self.preview_scroll.isVisible():
            return
        e = self.current_entry()
        if not e:
            self.preview.clear("No image selected" if self.model.items else "")
            return
        if self.model.lazy or is_video(e["path"]):
            # on-demand drive or a video: nothing is read just for the preview; the thumbnail is shown
            pix = self.model.thumbs.get((e["path"], e["mtime"]))
            if isinstance(pix, QPixmap) and not pix.isNull():
                self.preview.show_entry(e, pix.toImage(), None)
            else:
                self.preview.show_entry(e)
                self.preview.pix = None
                self.preview.image_label.clear()
                self.preview.image_label.setText("Open the photo to see it here")
            return
        self.preview.show_entry(e)
        QThreadPool.globalInstance().start(
            ImageJob(e["path"], self.preview_signals, max_edge=900, with_info=True), 10)

    def _preview_ready(self, path, image, info):
        e = self.current_entry()
        if e and e["path"] == path:
            self.preview.show_entry(e, image, info)

    def _filter_changed(self, text):
        keep = self.current_path()
        self.model.set_filter(text)
        if keep in self.model.row_of:
            self.select_path(keep)
        elif self.model.items:
            self.grid.setCurrentIndex(self.model.index(0))
        self._selection_changed()

    def set_sort(self, key, desc):
        keep = self.current_path()
        self.model.set_sort(key, desc)
        settings().setValue("sort_key", key)
        settings().setValue("sort_desc", desc)
        self._sync_sort_ui()
        if keep:
            self.select_path(keep)
        self._selection_changed()

    def _date_progress(self, done, total):
        if done < total and self.model.sort_key == "taken":
            self.statusBar().showMessage(f"Reading photo dates… {done} / {total}")

    def _dates_finished(self):
        self.statusBar().clearMessage()
        if self.model.sort_key != "taken":
            return
        keep = self.current_path()
        selected = set(self.selected_paths())
        self.model.set_sort("taken", self.model.sort_desc)
        if keep:
            self.select_path(keep)
        sm = self.grid.selectionModel()
        for p in selected:
            row = self.model.row_of.get(p)
            if row is not None:
                sm.select(self.model.index(row), sm.SelectionFlag.Select)
        self._selection_changed()

    def _sync_sort_ui(self):
        key, desc = self.model.sort_key, self.model.sort_desc
        self.sort_box.setCurrentIndex(self.sort_keys.index(key))
        for k, a in self.sort_actions.items():
            a.setChecked(k == key)
        self.a_desc.setChecked(desc)
        ic = icon("view-sort-descending" if desc else "view-sort-ascending")
        self.order_btn.setIcon(ic)
        self.order_btn.setText("" if not ic.isNull() else ("↓" if desc else "↑"))

    def set_thumb_size(self, v):
        v = max(96, min(256, int(round(v / 16.0) * 16)))
        self.delegate.size = v
        self.grid.setGridSize(self.delegate.cell())
        self.grid.doItemsLayout()
        self.grid.viewport().update()

    def step_thumbs(self, d):
        self.size_slider.setValue(self.delegate.size + d)

    # ------------------------------------------------------------------ viewer
    def view_full_size(self):
        self.view_current(full=True)

    def view_current(self, slideshow=False, full=False):
        files = self.model.paths()
        if not files:
            return
        row = max(0, self.grid.currentIndex().row())
        if self.viewer is not None:
            self.viewer.close()
        meta = {e["path"]: (e["size"], e["mtime"]) for e in self.model.items}
        self.viewer = Viewer(files, row, slideshow=slideshow, full=full, meta=meta)
        self.viewer.thumb_made.connect(lambda p, m, img: self.model._thumb_ready(p, m, img, 0, 0))
        self.viewer.closed.connect(self._viewer_closed)
        self.viewer.decoded.connect(self._viewer_decoded)
        self.queue.viewer_busy = bool(files) and is_remote(files[0])  # share the line with you
        self.viewer.changed.connect(lambda: self.reload_timer.start(300))
        if slideshow or setting("viewer_fullscreen", False, bool):
            self.viewer.showFullScreen()
        else:
            self.viewer.showMaximized()

    def slideshow(self):
        self.view_current(slideshow=True)

    # -- background thumbnails
    def make_thumbnails(self, folder=None, subfolders=False):
        folder = folder or self.folder
        if not folder:
            return
        self.queue.add(folder, subfolders)
        name = os.path.basename(folder.rstrip("/")) or folder
        self._show_queue(f"Thumbnails: starting “{name}”…")
        what = "and its subfolders " if subfolders else ""
        self.statusBar().showMessage(f"Making thumbnails for “{name}” {what}in the background "
                                     "(this folder goes first).", 5000)

    def _show_queue(self, text=None):
        if text is not None:
            w = self.queue.waiting()
            self.queue_label.setText(text + (f"  · {w} folder{'s' if w != 1 else ''} waiting" if w else ""))
        self.queue_box.show()
        self.queue_box.raise_()

    def _resume_queue(self):
        n = len(self.queue.items)
        self._show_queue("Thumbnails: continuing…")
        self.statusBar().showMessage(f"Continuing to make thumbnails ({n} folder"
                                     f"{'s' if n != 1 else ''} in the list).", 6000)
        self.queue.start()

    def _queue_progress(self, name, done, total, state):
        if state == "waiting":
            text = f"Thumbnails: waiting for “{name}” to be connected"
        elif state == "listing":
            text = f"Thumbnails: reading “{name}”…" + (f" {total} found" if total else "")
        else:
            pct = f" ({done * 100 // total} %)" if total else ""
            text = f"Thumbnails: {name} — {done} / {total}{pct}"
            if self.queue.errors:
                text += f"  · {self.queue.errors} unreadable"
        if self.queue.paused:
            text += "  · paused"
        elif self.queue.viewer_busy:
            text += "  · waits while you view"
        self._show_queue(text)

    def _queue_made(self, path, mtime, img, w, h):
        e = self.model.entry(path)
        if e is not None and e["mtime"] == mtime:
            self.model._thumb_ready(path, mtime, img, w, h)

    def _queue_changed(self):
        settings().setValue("thumb_queue", json.dumps(self.queue.snapshot()))

    def _queue_pause_toggled(self, on):
        self.queue.set_paused(on)
        self.queue_pause.setText("Resume" if on else "Pause")
        self.queue_label.setText(self.queue_label.text().split("  ·")[0] + ("  · paused" if on else ""))

    def _queue_stop(self):
        self.queue.stop_all()
        self.queue_pause.setChecked(False)
        self.queue_box.hide()
        self.statusBar().showMessage("Stopped making thumbnails.", 4000)

    def _viewer_decoded(self, path, image):
        """A photo on an on-demand drive was loaded by the viewer: keep a thumbnail of it."""
        e = self.model.entry(path)
        if e is None:
            try:
                mtime = os.stat(path).st_mtime
            except OSError:
                return
        else:
            mtime = e["mtime"]
        self.thumb_pool.start(ImageThumbJob(path, mtime, image, self.model.signals,
                                            self.model.use_cache))

    def _viewer_closed(self, path):
        self.viewer = None
        self.queue.viewer_busy = False
        self.queue.wake.set()
        if path:  # the folder is only read again when a photo was rotated, edited or deleted
            self.select_path(path)
        self.activateWindow()
        self.grid.setFocus()

    # ------------------------------------------------------------------ file operations
    def edit_current(self):
        path = self.current_path()
        if not path:
            return
        dlg = EditorDialog(path, self)
        dlg.saved.connect(lambda p: self.reload(then=lambda: self.select_path(p)))
        dlg.exec()

    def rotate_selected(self, degrees):
        paths = self.selected_paths()
        failed = [p for p in paths if not rotate_file(p, degrees)]
        self.reload()
        if failed:
            copyable_box("warning", self, "Rotate", f"Could not rotate {len(failed)} file(s) "
                                                "(read-only or unsupported format).")

    def rename_selected(self):
        rows = self.selected_rows()
        if len(rows) > 1:
            self.batch_rename()
            return
        if not rows:
            return
        e = self.model.items[rows[0]]
        name, ok = QInputDialog.getText(self, "Rename", "New name:", text=e["name"])
        name = name.strip()
        if not ok or not name or name == e["name"]:
            return
        if "/" in name:
            copyable_box("warning", self, "Rename", "Names can't contain “/”.")
            return
        dest = os.path.join(os.path.dirname(e["path"]), name)
        if os.path.exists(dest):
            copyable_box("warning", self, "Rename", f"“{name}” already exists.")
            return
        try:
            os.rename(e["path"], dest)
        except OSError as err:
            copyable_box("warning", self, "Rename", str(err))
            return
        self.reload(then=lambda: self.select_path(dest))

    def batch_rename(self):
        rows = self.selected_rows()
        if len(rows) < 2:
            return
        entries = [self.model.items[r] for r in rows]
        dlg = BatchRenameDialog(entries, self)
        if not dlg.exec():
            return
        names = dlg.new_names()
        folder = self.folder
        olds = {e["path"] for e in entries}
        clashes = [n for n in names if os.path.exists(os.path.join(folder, n))
                   and os.path.join(folder, n) not in olds]
        if clashes:
            copyable_box("warning", self, "Batch rename",
                                f"{len(clashes)} new name(s) already exist, e.g. “{clashes[0]}”.")
            return
        temps = []
        try:
            for i, e in enumerate(entries):  # two steps so names can swap safely
                tmp = os.path.join(folder, f".hansviewer-rename-{os.getpid()}-{i}")
                os.rename(e["path"], tmp)
                temps.append((tmp, os.path.join(folder, names[i]), e["path"]))
            for tmp, dest, _orig in temps:
                os.rename(tmp, dest)
        except OSError as err:
            for tmp, _dest, orig in temps:
                if os.path.exists(tmp):
                    os.rename(tmp, orig)
            copyable_box("warning", self, "Batch rename", str(err))
        self.reload()

    def transfer(self, move):
        paths = self.selected_paths()
        if not paths:
            return
        dest = QFileDialog.getExistingDirectory(self, "Move to folder" if move else "Copy to folder",
                                                setting("last_transfer", self.folder or "", str))
        if not dest:
            return
        settings().setValue("last_transfer", dest)
        prog = QProgressDialog("Moving files…" if move else "Copying files…", "Cancel",
                               0, len(paths), self)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(400)
        errors = []
        for i, p in enumerate(paths):
            prog.setValue(i)
            if prog.wasCanceled():
                break
            target = unique_path(dest, os.path.basename(p))
            try:
                shutil.move(p, target) if move else shutil.copy2(p, target)
            except OSError as err:
                errors.append(f"{os.path.basename(p)}: {err.strerror or err}")
        prog.setValue(len(paths))
        self.reload()
        verb = "Moved" if move else "Copied"
        done = len(paths) - len(errors)
        self.statusBar().showMessage(f"{verb} {done} file(s) to {dest}", 5000)
        if errors:
            copyable_box("warning", self, verb, "Some files failed:\n" + "\n".join(errors[:10]))

    def delete_selected(self):
        paths = self.selected_paths()
        if not paths:
            return
        if setting("confirm_delete", True, bool):
            what = f"“{os.path.basename(paths[0])}”" if len(paths) == 1 else f"{len(paths)} files"
            ans = QMessageBox.question(self, "Move to Trash", f"Move {what} to the Trash?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        rows = self.selected_rows()
        next_row = rows[0] if rows else 0
        failed = [p for p in paths if not move_to_trash(p)]
        self.navigate(self.folder, record=False, keep_row=next_row)
        if failed:
            copyable_box("warning", self, "Move to Trash", f"Could not move {len(failed)} file(s).")

    def copy_image(self):
        path = self.current_path()
        if path:
            img = read_image(path)
            if not img.isNull():
                QApplication.clipboard().setImage(img)
                self.statusBar().showMessage("Image copied", 2000)

    def copy_path(self):
        paths = self.selected_paths()
        if paths:
            QApplication.clipboard().setText("\n".join(paths))
            self.statusBar().showMessage("Path copied", 2000)

    def wallpaper(self):
        path = self.current_path()
        if path:
            ok = set_wallpaper(path)
            self.statusBar().showMessage("Wallpaper set" if ok else
                                         "Couldn't set the wallpaper on this desktop", 4000)

    def open_external(self):
        path = self.current_path()
        if path:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def show_in_files(self):
        if self.folder:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.folder))

    def _grid_menu(self, pos):
        idx = self.grid.indexAt(pos)
        if idx.isValid() and not self.grid.selectionModel().isSelected(idx):
            self.grid.setCurrentIndex(idx)
        m = QMenu(self)
        if idx.isValid():
            vpath = self.current_path()
            if vpath and is_video(vpath):
                menu_add(m, "Play in other player", lambda p=vpath: QDesktopServices.openUrl(QUrl.fromLocalFile(p)))
                m.addSeparator()
            for a in (self.a_view, self.a_view_full, self.a_edit, None, self.a_rot_l, self.a_rot_r, None,
                      self.a_rename, self.a_batch, self.a_copy_to, self.a_move_to, None,
                      self.a_copy_img, self.a_copy_path, self.a_open_with, self.a_wallpaper,
                      None, self.a_delete):
                m.addSeparator() if a is None else m.addAction(a)
            # "Share…": email with the photos attached, or copy the files
            add_share_menu(m, self.selected_paths() or [self.current_path()], self)
        else:
            for a in (self.a_select_all, self.a_refresh, self.a_slideshow, self.a_fav,
                      self.a_show_folder):
                m.addAction(a)
            if self.folder and is_remote(self.folder):
                m.addSeparator()
                m.addAction(self.a_thumbs)
                m.addAction(self.a_thumbs_sub)
        m.exec(self.grid.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------------ misc
    def export_settings_dialog(self):
        """File → Export settings: one file to take your HansViewer setup to another computer."""
        dlg = QDialog(self)
        dlg.setWindowTitle("Export settings")
        info = QLabel("Saves your favourites, aliases, saved servers, cloud entries and settings to "
                      "one file. Import it on another computer with File → Import settings.\n"
                      "Thumbnails are not included.")
        info.setWordWrap(True)
        incl = QCheckBox("Include saved passwords and cloud sign-ins (encrypted)")
        pw1, pw2 = QLineEdit(), QLineEdit()
        for w, ph in ((pw1, "Password for the file"), (pw2, "Repeat the password")):
            w.setEchoMode(QLineEdit.EchoMode.Password)
            w.setPlaceholderText(ph)
            w.setEnabled(False)
        incl.toggled.connect(pw1.setEnabled)
        incl.toggled.connect(pw2.setEnabled)
        note = QLabel("Without the password nobody can read the passwords in the file. "
                      "If you forget it, import the file without them and sign in again.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {THEME['muted']}")
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save
                                   | QDialogButtonBox.StandardButton.Cancel)
        buttons.rejected.connect(dlg.reject)

        def accept():
            if incl.isChecked():
                if len(pw1.text()) < 4:
                    copyable_box("warning", dlg, "Export settings", "Please choose a password of at least 4 characters.")
                    return
                if pw1.text() != pw2.text():
                    copyable_box("warning", dlg, "Export settings", "The two passwords are not the same.")
                    return
                if not shutil.which("openssl"):
                    copyable_box("warning", dlg, "Export settings", "Encryption needs openssl: sudo apt install openssl")
                    return
            dlg.accept()

        buttons.accepted.connect(accept)
        lay = QVBoxLayout(dlg)
        for w in (info, incl, pw1, pw2, note, buttons):
            lay.addWidget(w)
        if not dlg.exec():
            return
        default = os.path.join(os.path.expanduser("~"),
                               f"hansviewer-settings-{time.strftime('%Y-%m-%d')}{EXPORT_EXT}")
        path, _ = QFileDialog.getSaveFileName(self, "Export settings", default,
                                              f"HansViewer settings (*{EXPORT_EXT})")
        if not path:
            return
        if not path.endswith(EXPORT_EXT):
            path += EXPORT_EXT
        try:
            data = export_settings(path, pw1.text() if incl.isChecked() else None)
        except Exception as err:
            copyable_box("warning", self, "Export settings", f"Could not export:\n{err}")
            return
        extra = ""
        if data.get("secrets_info"):
            si = data["secrets_info"]
            extra = f"\n\nIncluded, encrypted: {si['passwords']} server password(s), {si['clouds']} cloud sign-in(s)."
        copyable_box("info", self, "Export settings", f"Saved to:\n{path}{extra}")

    def import_settings_dialog(self):
        """File → Import settings: takes over the setup exported on another computer."""
        path, _ = QFileDialog.getOpenFileName(self, "Import settings", os.path.expanduser("~"),
                                              f"HansViewer settings (*{EXPORT_EXT});;All files (*)")
        if not path:
            return
        try:
            data = read_export(path)
        except Exception as err:
            copyable_box("warning", self, "Import settings", f"Could not read the file:\n{err}")
            return
        what = (f"Exported on {data.get('exported', '?')} from “{data.get('computer', '?')}” "
                f"(HansViewer {data.get('version', '?')}).\n\nYour favourites, aliases, saved servers, "
                "cloud entries and settings will be replaced by those in the file.")
        if QMessageBox.question(self, "Import settings", what + "\n\nContinue?") \
                != QMessageBox.StandardButton.Yes:
            return
        passphrase = None
        if data.get("secrets"):
            for attempt in range(3):
                pw, ok = QInputDialog.getText(
                    self, "Import settings", "The file contains encrypted passwords and cloud sign-ins."
                    "\nPassword for the file (Cancel: import without them):",
                    QLineEdit.EchoMode.Password)
                if not ok:
                    data = dict(data, secrets=None)
                    break
                try:
                    _openssl(data["secrets"].encode(), pw, decrypt=True)
                    passphrase = pw
                    break
                except Exception:
                    copyable_box("warning", self, "Import settings", "Wrong password, please try again.")
            else:
                data = dict(data, secrets=None)
        try:
            done = import_settings(data, passphrase)
        except Exception as err:
            copyable_box("warning", self, "Import settings", f"Could not import:\n{err}")
            return
        self._network_sig = self._cloud_sig = self._devices_sig = None
        self.refresh_favourites()
        self.refresh_devices()
        self.refresh_network()
        self.refresh_clouds()
        msg = "Settings imported."
        if passphrase:
            msg += f"\n{done['passwords']} server password(s) and {done['clouds']} cloud sign-in(s) added."
        msg += "\n\nSome settings (theme, thumbnail size) take effect when HansViewer starts again."
        copyable_box("info", self, "Import settings", msg)
        if setting("auto_cloud", True, bool):
            QTimer.singleShot(500, self.auto_connect_clouds)

    def open_settings(self):
        dlg = SettingsDialog(self)
        videos_before = SHOW_VIDEOS[0]
        if dlg.exec():
            dlg.save()
            if SHOW_VIDEOS[0] != videos_before:
                self.reload()  # videos shown / hidden
            apply_theme(QApplication.instance(), setting("theme", "dark"))
            self.sec_fav.setForeground(0, QColor(THEME["muted"]))
            self.sec_dev.setForeground(0, QColor(THEME["muted"]))
            self.model.use_cache = setting("disk_cache", True, bool)
            self.grid.viewport().update()

    def install(self):
        if SYSTEM_INSTALL:
            copyable_box("info", self, APP, f"{APP} was installed from its package and is "
                                               "already in your app menu for all users.")
            return
        try:
            target = install_desktop_entry()
        except OSError as err:
            copyable_box("warning", self, APP, f"Could not install: {err}")
            return
        copyable_box("info", self, APP, f"{APP} is now in your app menu (Graphics).\n\n"
                                           f"The program was copied to:\n{target}\n\n"
                                           "You can also pick it under “Open With” for images.")

    def show_activity_log(self):
        if not os.path.exists(ACTIVITY_LOG):
            copyable_box("info", self, APP, "No network activity has been recorded yet.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(ACTIVITY_LOG))

    def show_shortcuts(self):
        box = QMessageBox(self)
        box.setWindowTitle("Keyboard shortcuts")
        box.setTextFormat(Qt.TextFormat.RichText)
        box.setText(SHORTCUTS_HTML)
        box.exec()

    def about(self):
        extras = []
        extras.append("numpy ✓" if np is not None else "numpy ✗ (adjustments off)")
        extras.append("Pillow ✓" if PILImage is not None else "Pillow ✗ (no EXIF)")
        QMessageBox.about(self, f"About {APP}",
                          f"<h3>{APP} {VERSION}</h3><p>A fast image browser, viewer and editor "
                          "for Linux.</p>"
                          f"<p>{' · '.join(extras)}</p>")


# ======================================================================= main
def main():
    if "--install" in sys.argv:
        if SYSTEM_INSTALL:
            print(f"{APP} is installed from its package; nothing to do.")
            return
        target = install_desktop_entry()
        print(f"Installed. {APP} is in your app menu; program copied to {target}")
        return
    QApplication.setApplicationName(APP)
    app = QApplication(sys.argv)
    app.setDesktopFileName(APP_ID)
    try:  # Qt refuses photos above 128-256 MB of pixels by default; large camera photos exceed it
        QImageReader.setAllocationLimit(2048)
    except AttributeError:
        pass
    start_freeze_watch(app)
    SHOW_VIDEOS[0] = setting("show_videos", True, bool)
    if Brightness._s().value("brightness_restore", "", type=str):  # HansViewer was closed while the screen was raised
        threading.Thread(target=Brightness.restore_now, daemon=True).start()
    setup_icon_theme()
    apply_theme(app, setting("theme", "dark"))
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if hand_over_to_running(args[0] if args else ""):
        return            # HansViewer is already open: its window comes to the front instead
    alog("=== start", f"{APP} {VERSION}", gio=Gio is not None)
    win = Browser(args[0] if args else None)
    win.show()
    listen_for_second_start()
    sys.exit(app.exec())


INSTANCE_NAME = f"hansviewer-{os.getuid()}"
_INSTANCE_SERVER = None


def hand_over_to_running(path):
    """If HansViewer is already running, sends it the folder/photo to open and returns True."""
    try:
        from PyQt6.QtNetwork import QLocalSocket
    except ImportError:
        return False
    sock = QLocalSocket()
    sock.connectToServer(INSTANCE_NAME)
    if not sock.waitForConnected(500):
        return False
    target = os.path.abspath(os.path.expanduser(path)) if path else ""
    sock.write(("open\t" + target + "\n").encode())
    sock.flush()
    sock.waitForBytesWritten(1000)
    sock.disconnectFromServer()
    return True


def listen_for_second_start():
    """Another start of HansViewer (e.g. from the menu or "Open with") brings this window forward."""
    global _INSTANCE_SERVER
    try:
        from PyQt6.QtNetwork import QLocalServer
    except ImportError:
        return
    server = QLocalServer()
    if not server.listen(INSTANCE_NAME):
        QLocalServer.removeServer(INSTANCE_NAME)   # left over from a crash
        if not server.listen(INSTANCE_NAME):
            return

    def incoming():
        conn = server.nextPendingConnection()
        if conn is None:
            return

        def read():
            line = bytes(conn.readAll()).decode(errors="ignore").strip()
            _cmd, _, target = line.partition("\t")
            win = next((w for w in reversed(WINDOWS) if w.isActiveWindow()), WINDOWS[-1] if WINDOWS else None)
            if win is None:
                return
            if win.isMinimized():
                win.showNormal()
            win.raise_()
            win.activateWindow()
            if target:
                win._open_start_folder(target)
        conn.readyRead.connect(read)
        if conn.bytesAvailable():
            read()
    server.newConnection.connect(incoming)
    _INSTANCE_SERVER = server


if __name__ == "__main__":
    main()
