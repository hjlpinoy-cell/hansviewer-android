#!/usr/bin/env python3
"""
HansViewer - a fast image browser, viewer and editor for Linux,
written with Python and Qt 6.

Usage:
    python3 hansviewer.py [folder-or-image]
    python3 hansviewer.py --install      # add HansViewer to your app menu

Needs:    sudo apt install python3-pyqt6
Optional: sudo apt install python3-numpy python3-pil
          (numpy: brightness/contrast/colour tools; Pillow: EXIF info and
           keeping camera data when saving)

Press F1 in the app for all keyboard shortcuts.
"""
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import time

from PyQt6.QtCore import (QAbstractListModel, QDir, QFileSystemWatcher,
                          QMimeData, QModelIndex, QObject, QPointF, QRect,
                          QRectF, QRunnable, QSettings, QSize, QStorageInfo,
                          Qt, QThreadPool, QTimer, QUrl, pyqtSignal)
from PyQt6.QtGui import (QAction, QColor, QDesktopServices, QFont, QIcon,
                         QImage, QImageIOHandler, QImageReader, QImageWriter,
                         QKeySequence, QPainter, QPainterPath, QPalette, QPen,
                         QPixmap, QTransform)
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox,
                             QComboBox, QDialog, QDialogButtonBox,
                             QFileDialog, QFormLayout, QFrame, QGridLayout,
                             QGroupBox, QHBoxLayout, QInputDialog, QLabel,
                             QLineEdit, QListView, QListWidget, QMainWindow,
                             QMenu, QMessageBox, QProgressDialog, QPushButton,
                             QScrollArea, QSizePolicy, QSlider, QSpinBox,
                             QSplitter, QStyle, QStyledItemDelegate,
                             QTreeView, QTreeWidget, QTreeWidgetItem,
                             QVBoxLayout, QWidget)

try:  # Qt 6.5+ moved QFileSystemModel to QtGui
    from PyQt6.QtGui import QFileSystemModel
except ImportError:
    from PyQt6.QtWidgets import QFileSystemModel

try:
    import numpy as np
except ImportError:
    np = None

try:
    from PIL import Image as PILImage
except ImportError:
    PILImage = None

APP = "HansViewer"
APP_ID = "hansviewer"
# True when installed from the .deb package (lives under /usr)
SYSTEM_INSTALL = os.path.abspath(__file__).startswith("/usr/")
VERSION = "2.5"
THUMB_MAX = 256  # thumbnails are generated at this size and scaled for display
READ_EXTS = {bytes(f).decode().lower() for f in QImageReader.supportedImageFormats()}
ROLE_DIMS = int(Qt.ItemDataRole.UserRole) + 1
ROLE_PATH = int(Qt.ItemDataRole.UserRole) + 2
NET_FS = {"cifs", "smb3", "smbfs", "nfs", "nfs4", "sshfs", "fuse.sshfs",
          "fuse.rclone", "davfs", "fuse.gvfsd-fuse"}
CACHE_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                         "thumbnails", "large")

# ======================================================================= theme
THEMES = {
    "dark": dict(bg="#17181b", panel="#1f2125", input="#2a2d32", hover="#2c3036",
                 border="#2f3237", text="#e8eaed", muted="#9aa0a8", accent="#4c8dff",
                 accent_soft="rgba(76,141,255,0.22)", card="#24272c", card_hover="#2d3138",
                 scroll="#3a3e45", viewer="#0e0f11"),
    "light": dict(bg="#eef0f3", panel="#fafbfc", input="#ffffff", hover="#e4e8ee",
                  border="#d9dde3", text="#1d2127", muted="#697180", accent="#2f6fed",
                  accent_soft="rgba(47,111,237,0.16)", card="#ffffff", card_hover="#f1f5fb",
                  scroll="#c3c8d0", viewer="#121314"),
}
THEME = dict(THEMES["dark"])

QSS = """
QMainWindow, QDialog { background: %(bg)s; }
QWidget { color: %(text)s; }
QToolBar { background: %(panel)s; border: none; border-bottom: 1px solid %(border)s;
           padding: 5px 8px; spacing: 3px; }
QToolBar::separator { background: %(border)s; width: 1px; margin: 4px 6px; }
QToolButton { background: transparent; border: none; border-radius: 6px; padding: 5px; }
QToolButton:hover { background: %(hover)s; }
QToolButton:checked { background: %(accent_soft)s; }
QLineEdit, QSpinBox, QComboBox { background: %(input)s; border: 1px solid %(border)s;
    border-radius: 6px; padding: 4px 8px; selection-background-color: %(accent)s; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border: 1px solid %(accent)s; }
QComboBox::drop-down { border: none; width: 18px; }
QComboBox QAbstractItemView { background: %(panel)s; border: 1px solid %(border)s;
    selection-background-color: %(accent)s; padding: 4px; }
QTreeView, QTreeWidget, QListWidget { background: %(panel)s; border: none; outline: 0; }
QTreeView::item, QTreeWidget::item { padding: 4px 2px; border-radius: 5px; }
QTreeView::item:hover, QTreeWidget::item:hover { background: %(hover)s; }
QTreeView::item:selected, QTreeWidget::item:selected { background: %(accent_soft)s; color: %(text)s; }
QListView#grid { background: %(bg)s; border: none; outline: 0; }
QSplitter::handle { background: %(border)s; }
QSplitter::handle:horizontal { width: 1px; }
QSplitter::handle:vertical { height: 1px; }
QStatusBar { background: %(panel)s; border-top: 1px solid %(border)s; color: %(muted)s; }
QStatusBar QLabel { color: %(muted)s; padding: 0 6px; }
QMenuBar { background: %(panel)s; padding: 2px; }
QMenuBar::item { padding: 4px 10px; background: transparent; border-radius: 4px; }
QMenuBar::item:selected { background: %(hover)s; }
QMenu { background: %(panel)s; border: 1px solid %(border)s; border-radius: 8px; padding: 6px; }
QMenu::item { padding: 6px 28px 6px 14px; border-radius: 5px; }
QMenu::item:selected { background: %(accent)s; color: white; }
QMenu::item:disabled { color: %(muted)s; }
QMenu::separator { height: 1px; background: %(border)s; margin: 4px 8px; }
QPushButton { background: %(input)s; border: 1px solid %(border)s; border-radius: 6px;
    padding: 6px 12px; }
QPushButton:hover { border-color: %(accent)s; }
QPushButton:pressed { background: %(hover)s; }
QPushButton:checked { background: %(accent_soft)s; border-color: %(accent)s; }
QPushButton:disabled { color: %(muted)s; border-color: %(border)s; }
QPushButton#primary { background: %(accent)s; border-color: %(accent)s; color: white; }
QGroupBox { border: 1px solid %(border)s; border-radius: 8px; margin-top: 16px;
    padding: 12px 8px 8px 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: %(muted)s; }
QSlider::groove:horizontal { height: 4px; background: %(border)s; border-radius: 2px; }
QSlider::sub-page:horizontal { background: %(accent)s; border-radius: 2px; }
QSlider::handle:horizontal { background: #ffffff; border: 1px solid %(border)s; width: 14px;
    height: 14px; margin: -6px 0; border-radius: 8px; }
QScrollBar:vertical { background: transparent; width: 11px; margin: 2px; }
QScrollBar:horizontal { background: transparent; height: 11px; margin: 2px; }
QScrollBar::handle:vertical { background: %(scroll)s; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:horizontal { background: %(scroll)s; border-radius: 4px; min-width: 30px; }
QScrollBar::handle:hover { background: %(muted)s; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: none; }
QScrollArea { border: none; background: transparent; }
QToolTip { background: %(panel)s; color: %(text)s; border: 1px solid %(border)s;
    padding: 4px; border-radius: 4px; }
QLabel#title { font-size: 15px; font-weight: bold; }
QLabel#muted { color: %(muted)s; }
QWidget#previewPane { background: %(panel)s; }
QWidget#toolsPanel { background: %(panel)s; }
"""


def apply_theme(app, name):
    THEME.clear()
    THEME.update(THEMES.get(name, THEMES["dark"]))
    t = THEME
    app.setStyle("Fusion")
    pal = QPalette()
    roles = {
        QPalette.ColorRole.Window: t["bg"], QPalette.ColorRole.WindowText: t["text"],
        QPalette.ColorRole.Base: t["panel"], QPalette.ColorRole.AlternateBase: t["card"],
        QPalette.ColorRole.Text: t["text"], QPalette.ColorRole.Button: t["input"],
        QPalette.ColorRole.ButtonText: t["text"], QPalette.ColorRole.Highlight: t["accent"],
        QPalette.ColorRole.HighlightedText: "#ffffff", QPalette.ColorRole.ToolTipBase: t["panel"],
        QPalette.ColorRole.ToolTipText: t["text"], QPalette.ColorRole.PlaceholderText: t["muted"],
        QPalette.ColorRole.Link: t["accent"],
    }
    for role, color in roles.items():
        pal.setColor(role, QColor(color))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(t["muted"]))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(t["muted"]))
    app.setPalette(pal)
    app.setStyleSheet(QSS % t)


def setup_icon_theme():
    """Qt apps on Cinnamon/MATE often miss the desktop icon theme; borrow it."""
    if QIcon.themeName() not in ("", "hicolor"):
        return
    for schema in ("org.cinnamon.desktop.interface", "org.mate.interface",
                   "org.gnome.desktop.interface"):
        try:
            out = subprocess.run(["gsettings", "get", schema, "icon-theme"],
                                 capture_output=True, text=True, timeout=1)
            name = out.stdout.strip().strip("'")
            if out.returncode == 0 and name:
                QIcon.setThemeName(name)
                return
        except (OSError, subprocess.SubprocessError):
            pass
    QIcon.setThemeName("Adwaita")


def menu_add(menu, text, slot):
    a = menu.addAction(text)
    a.triggered.connect(lambda _=False: slot())
    return a


def icon(names, fallback=None):
    for n in names.split():
        ic = QIcon.fromTheme(n)
        if not ic.isNull():
            return ic
    if fallback is not None:
        return QApplication.style().standardIcon(fallback)
    return QIcon()


SP = QStyle.StandardPixmap


# ======================================================================= settings
_SETTINGS = None


def settings():
    global _SETTINGS
    if _SETTINGS is None:
        _SETTINGS = QSettings(APP_ID, APP_ID)
        if not _SETTINGS.allKeys():  # carry over settings from the old "acdview" name
            old = QSettings("acdview", "acdview")
            for k in old.allKeys():
                _SETTINGS.setValue(k, old.value(k))
    return _SETTINGS


def setting(key, default, typ=None):
    typ = typ or type(default)
    try:
        return settings().value(key, default, type=typ)
    except TypeError:
        return default


# ======================================================================= helpers
def natural_key(name):
    """Sort 'img2' before 'img10', like a human would."""
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", name.lower())]


def human_size(n):
    for unit in ("bytes", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:,.0f} {unit}" if unit == "bytes" else f"{n:,.1f} {unit}"
        n /= 1024
    return str(n)


def image_dims(reader):
    """Width/height after EXIF rotation, from the header only."""
    size = reader.size()
    if not size.isValid():
        return 0, 0
    w, h = size.width(), size.height()
    try:
        if reader.transformation() & QImageIOHandler.Transformation.TransformationRotate90:
            w, h = h, w
    except (TypeError, AttributeError):
        pass
    return w, h


def read_image(path, max_edge=None):
    reader = QImageReader(path)
    reader.setAutoTransform(True)  # respect EXIF rotation
    if max_edge:
        size = reader.size()
        if size.isValid() and max(size.width(), size.height()) > max_edge:
            size.scale(max_edge, max_edge, Qt.AspectRatioMode.KeepAspectRatio)
            reader.setScaledSize(size)  # JPEGs decode at reduced size: fast
    return reader.read()


def unique_path(folder, name):
    base, ext = os.path.splitext(name)
    cand, n = os.path.join(folder, name), 1
    while os.path.exists(cand):
        cand = os.path.join(folder, f"{base} ({n}){ext}")
        n += 1
    return cand


def move_to_trash(path):
    try:
        res = QFile_moveToTrash(path)
        if res:
            return True
    except Exception:
        pass
    try:
        return subprocess.run(["gio", "trash", path], timeout=20).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def QFile_moveToTrash(path):
    from PyQt6.QtCore import QFile
    res = QFile.moveToTrash(path)
    return res[0] if isinstance(res, tuple) else bool(res)


def exif_summary(path):
    """A few readable camera facts, if Pillow is installed."""
    if PILImage is None:
        return []
    try:
        with PILImage.open(path) as im:
            ex = im.getexif()
            if not ex:
                return []
            sub = ex.get_ifd(0x8769)
    except Exception:
        return []
    out = []
    make, model = str(ex.get(0x010F, "")).strip(), str(ex.get(0x0110, "")).strip()
    if model:
        out.append(("Camera", model if model.startswith(make) else f"{make} {model}".strip()))
    if sub.get(0xA434):
        out.append(("Lens", str(sub[0xA434]).strip()))
    taken = sub.get(0x9003) or ex.get(0x0132)
    if taken:
        out.append(("Taken", str(taken).replace(":", "-", 2)))
    try:
        if sub.get(0x829A):
            e = float(sub[0x829A])
            out.append(("Exposure", f"1/{round(1 / e)} s" if 0 < e < 1 else f"{e:g} s"))
        if sub.get(0x829D):
            out.append(("Aperture", f"f/{float(sub[0x829D]):.1f}"))
        if sub.get(0x8827):
            iso = sub[0x8827]
            out.append(("ISO", str(iso[0] if isinstance(iso, tuple) else iso)))
        if sub.get(0x920A):
            out.append(("Focal length", f"{float(sub[0x920A]):.0f} mm"))
    except (TypeError, ValueError, ZeroDivisionError):
        pass
    return out


# ---------------------------------------------------------------- photo "date taken" (EXIF)
_EXIF_DT = re.compile(rb"(\d{4})[:\-](\d\d)[:\-](\d\d)[ T](\d\d):(\d\d):(\d\d)")


def _parse_exif_dt(raw):
    m = _EXIF_DT.match(raw or b"")
    if not m:
        return None
    y, mo, d, h, mi, sec = (int(x) for x in m.groups())
    if y < 1900 or not (1 <= mo <= 12 and 1 <= d <= 31):
        return None
    try:
        return time.mktime((y, mo, d, h, mi, sec, 0, 0, -1))
    except (OverflowError, ValueError):
        return None


def _tiff_date(buf, base):
    """Date taken from a TIFF/EXIF block starting at `base` (DateTimeOriginal first)."""
    order = buf[base:base + 2]
    e = "<" if order == b"II" else ">" if order == b"MM" else None
    if e is None or base + 8 > len(buf):
        return None

    def entries(off):
        o, out = base + off, {}
        if off <= 0 or o + 2 > len(buf):
            return out
        n = struct.unpack_from(e + "H", buf, o)[0]
        for i in range(min(n, 400)):
            p = o + 2 + i * 12
            if p + 12 > len(buf):
                break
            tag, typ, cnt = struct.unpack_from(e + "HHI", buf, p)
            out[tag] = (typ, cnt, p + 8)
        return out

    def text(ent):
        typ, cnt, p = ent
        if typ != 2:
            return None
        if cnt > 4:
            p = base + struct.unpack_from(e + "I", buf, p)[0]
        return buf[p:p + min(cnt, 64)]

    try:
        ifd0 = entries(struct.unpack_from(e + "I", buf, base + 4)[0])
        found = []
        if 0x8769 in ifd0:
            sub = entries(struct.unpack_from(e + "I", buf, ifd0[0x8769][2])[0])
            found += [text(sub[t]) for t in (0x9003, 0x9004) if t in sub]
        if 0x0132 in ifd0:
            found.append(text(ifd0[0x0132]))
    except struct.error:
        return None
    for raw in found:
        ts = _parse_exif_dt(raw)
        if ts:
            return ts
    return None


def exif_date(path):
    """When the photo was taken, from its metadata. None if the file has no such date."""
    try:
        with open(path, "rb") as f:
            head = f.read(262144)
            if head[:4] in (b"II*\x00", b"MM\x00*"):  # TIFF and TIFF-based RAW files
                head += f.read(786432)
    except OSError:
        return None
    if head[:2] == b"\xff\xd8":  # JPEG: walk the markers to the EXIF block
        i = 2
        while i + 4 <= len(head):
            if head[i] != 0xFF:
                break
            marker = head[i + 1]
            if marker == 0xFF:
                i += 1
                continue
            if marker in (0xD9, 0xDA):
                break
            if marker == 0x01 or 0xD0 <= marker <= 0xD7:
                i += 2
                continue
            length = struct.unpack_from(">H", head, i + 2)[0]
            if marker == 0xE1 and head[i + 4:i + 10] == b"Exif\x00\x00":
                return _tiff_date(head, i + 10)
            i += 2 + length
        return None
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return _tiff_date(head, 0)
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        pos = 8
        while pos + 8 <= len(head):
            length, typ = struct.unpack_from(">I4s", head, pos)
            if typ == b"eXIf":
                return _tiff_date(head, pos + 8)
            if typ == b"IDAT":
                break
            pos += 12 + length
        return None
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        pos = 12
        while pos + 8 <= len(head):
            typ, length = struct.unpack_from("<4sI", head, pos)
            if typ == b"EXIF":
                start = pos + 8
                if head[start:start + 6] == b"Exif\x00\x00":
                    start += 6
                return _tiff_date(head, start)
            pos += 8 + length + (length & 1)
        return None
    if PILImage is not None:  # other formats (e.g. HEIC with a plugin): let Pillow try
        try:
            with PILImage.open(path) as im:
                ex = im.getexif()
                raw = ex.get_ifd(0x8769).get(0x9003) or ex.get(0x0132)
                return _parse_exif_dt(str(raw).encode()) if raw else None
        except Exception:
            return None
    return None


DATE_CACHE_FILE = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                               "hansviewer", "dates.json")
_DATE_CACHE = None


def date_cache():
    global _DATE_CACHE
    if _DATE_CACHE is None:
        try:
            with open(DATE_CACHE_FILE) as f:
                _DATE_CACHE = json.load(f)
            if not isinstance(_DATE_CACHE, dict):
                _DATE_CACHE = {}
        except (OSError, ValueError):
            _DATE_CACHE = {}
    return _DATE_CACHE


def date_key(e):
    return f"{e['path']}\t{int(e['mtime'])}\t{e['size']}"


def save_date_cache():
    cache = date_cache()
    if len(cache) > 300000:
        cache.clear()
    try:
        os.makedirs(os.path.dirname(DATE_CACHE_FILE), exist_ok=True)
        tmp = DATE_CACHE_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cache, f)
        os.replace(tmp, DATE_CACHE_FILE)
    except OSError:
        pass


# ---------------------------------------------------------------- freedesktop thumbnail cache
def thumb_cache_file(path):
    uri = bytes(QUrl.fromLocalFile(path).toEncoded()).decode()
    return uri, os.path.join(CACHE_DIR, hashlib.md5(uri.encode()).hexdigest() + ".png")


def make_thumbnail(path, mtime, use_cache=True):
    """Returns (QImage, width, height). Shares ~/.cache/thumbnails with the file manager."""
    uri, cache = thumb_cache_file(path)
    if use_cache and os.path.exists(cache):
        img = QImage()
        if img.load(cache) and img.text("Thumb::MTime") == str(int(mtime)):
            try:
                w = int(img.text("Thumb::Image::Width") or 0)
                h = int(img.text("Thumb::Image::Height") or 0)
            except ValueError:
                w = h = 0
            return img, w, h
    reader = QImageReader(path)
    reader.setAutoTransform(True)
    w, h = image_dims(reader)
    size = reader.size()
    if size.isValid() and max(size.width(), size.height()) > THUMB_MAX:
        size.scale(THUMB_MAX, THUMB_MAX, Qt.AspectRatioMode.KeepAspectRatio)
        reader.setScaledSize(size)
    img = reader.read()
    if img.isNull():
        return img, 0, 0
    if use_cache and not path.startswith(CACHE_DIR):
        try:
            os.makedirs(CACHE_DIR, mode=0o700, exist_ok=True)
            img.setText("Thumb::URI", uri)
            img.setText("Thumb::MTime", str(int(mtime)))
            img.setText("Thumb::Image::Width", str(w))
            img.setText("Thumb::Image::Height", str(h))
            img.setText("Software", f"{APP} {VERSION}")
            tmp = f"{cache}.{os.getpid()}.tmp"
            if img.save(tmp, "PNG"):
                os.replace(tmp, cache)
        except OSError:
            pass
    return img, w, h


# ---------------------------------------------------------------- saving & editing
PIL_FORMATS = {"jpeg": "JPEG", "png": "PNG", "webp": "WEBP", "tiff": "TIFF", "bmp": "BMP"}


def norm_format(path):
    ext = os.path.splitext(path)[1][1:].lower()
    return {"jpg": "jpeg", "jpe": "jpeg", "tif": "tiff"}.get(ext, ext)


def can_write(path):
    fmt = norm_format(path)
    writable = {bytes(f).decode().lower() for f in QImageWriter.supportedImageFormats()}
    return fmt in writable or (PILImage is not None and fmt in PIL_FORMATS)


def qimage_to_pil(img):
    has_alpha = img.hasAlphaChannel()
    img = img.convertToFormat(QImage.Format.Format_RGBA8888)
    ptr = img.constBits()
    ptr.setsize(img.sizeInBytes())
    pil = PILImage.frombuffer("RGBA", (img.width(), img.height()), bytes(ptr),
                              "raw", "RGBA", img.bytesPerLine(), 1)
    return pil if has_alpha else pil.convert("RGB")


def save_image(img, dest, src=None, quality=None):
    """Save atomically. With Pillow, camera EXIF from `src` is kept (orientation reset)."""
    quality = quality or setting("jpeg_quality", 92, int)
    fmt = norm_format(dest)
    tmp = f"{dest}.{os.getpid()}.acdtmp"
    ok = False
    if PILImage is not None and fmt in PIL_FORMATS:
        try:
            pil = qimage_to_pil(img)
            kw = {}
            if fmt in ("jpeg", "webp"):
                kw["quality"] = quality
            if src and os.path.exists(src) and fmt in ("jpeg", "webp", "png", "tiff"):
                try:
                    with PILImage.open(src) as orig:
                        exif = orig.getexif()
                        if exif:
                            exif[0x0112] = 1  # pixels are already upright
                            kw["exif"] = exif.tobytes()
                except Exception:
                    pass
            if fmt == "jpeg" and pil.mode != "RGB":
                pil = pil.convert("RGB")
            pil.save(tmp, format=PIL_FORMATS[fmt], **kw)
            ok = True
        except Exception:
            ok = False
    if not ok:
        out = img
        if fmt == "jpeg" and img.hasAlphaChannel():
            out = img.convertToFormat(QImage.Format.Format_RGB32)
        ok = out.save(tmp, fmt, quality if fmt in ("jpeg", "webp") else -1)
    if ok:
        os.replace(tmp, dest)
    elif os.path.exists(tmp):
        os.remove(tmp)
    return ok


def rotate_qimage(img, degrees):
    return img.transformed(QTransform().rotate(degrees))


def flip_qimage(img, horizontal):
    flipped = getattr(img, "flipped", None)
    if flipped is not None:
        return flipped(Qt.Orientation.Horizontal if horizontal else Qt.Orientation.Vertical)
    return img.mirrored(horizontal, not horizontal)


def rotate_file(path, degrees):
    img = read_image(path)
    if img.isNull() or not can_write(path):
        return False
    return save_image(rotate_qimage(img, degrees), path, src=path, quality=95)


def to_array(img):
    img = img.convertToFormat(QImage.Format.Format_RGBA8888)
    w, h = img.width(), img.height()
    ptr = img.constBits()
    ptr.setsize(img.sizeInBytes())
    arr = np.frombuffer(ptr, np.uint8).reshape(h, img.bytesPerLine())[:, :w * 4]
    return arr.reshape(h, w, 4).copy()


def from_array(arr):
    arr = np.ascontiguousarray(arr, dtype=np.uint8)
    h, w = arr.shape[:2]
    return QImage(arr.tobytes(), w, h, w * 4, QImage.Format.Format_RGBA8888).copy()


def adjust_image(img, brightness=0, contrast=0, saturation=0, warmth=0):
    """All values -100..100. Needs numpy."""
    if np is None or not any((brightness, contrast, saturation, warmth)):
        return img
    arr = to_array(img)
    rgb = arr[..., :3].astype(np.float32)
    if saturation:
        gray = (rgb @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
        rgb = gray + (rgb - gray) * (1 + saturation / 100.0)
    if contrast:
        c = contrast * 2.55
        f = (259 * (c + 255)) / (255 * (259 - c))
        rgb = (rgb - 128) * f + 128
    if brightness:
        rgb += brightness * 1.5
    if warmth:
        rgb[..., 0] += warmth * 0.5
        rgb[..., 2] -= warmth * 0.5
    arr[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    return from_array(arr)


def filter_image(img, name):
    if name == "grayscale" and np is None:
        fmt = QImage.Format.Format_ARGB32 if img.hasAlphaChannel() else QImage.Format.Format_RGB32
        return img.convertToFormat(QImage.Format.Format_Grayscale8).convertToFormat(fmt)
    if np is None:
        return img
    arr = to_array(img)
    rgb = arr[..., :3].astype(np.float32)
    if name == "grayscale":
        g = rgb @ np.array([0.299, 0.587, 0.114], np.float32)
        rgb = np.repeat(g[..., None], 3, axis=2)
    elif name == "sepia":
        m = np.array([[0.393, 0.769, 0.189], [0.349, 0.686, 0.168], [0.272, 0.534, 0.131]],
                     np.float32)
        rgb = rgb @ m.T
    elif name == "autolevels":
        lo = np.percentile(rgb, 0.5, axis=(0, 1))
        hi = np.percentile(rgb, 99.5, axis=(0, 1))
        rgb = (rgb - lo) * (255.0 / np.maximum(hi - lo, 1))
    elif name == "sharpen":
        p = np.pad(rgb, ((1, 1), (1, 1), (0, 0)), mode="edge")
        blur = sum(p[dy:dy + rgb.shape[0], dx:dx + rgb.shape[1]]
                   for dy in range(3) for dx in range(3)) / 9.0
        rgb = rgb + 0.8 * (rgb - blur)
    elif name == "invert":
        rgb = 255 - rgb
    arr[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    return from_array(arr)


# ---------------------------------------------------------------- drives & places
def gvfs_label(name):
    """'smb-share:server=nas,share=photos' -> 'photos on nas'."""
    if ":" not in name:
        return name
    scheme, _, rest = name.partition(":")
    kv = dict(p.split("=", 1) for p in rest.split(",") if "=" in p)
    host = kv.get("server") or kv.get("host") or scheme
    share = kv.get("share") or kv.get("prefix", "").strip("/")
    return f"{share} on {host}" if share else host


def list_devices():
    """(label, path, kind) for the root disk, mounted disks, USB and network drives."""
    places = [("Home", os.path.expanduser("~"), "home"), ("Computer", "/", "hd")]
    vols = []
    for v in QStorageInfo.mountedVolumes():
        root = v.rootPath()
        if not (v.isValid() and v.isReady()) or root == "/":
            continue
        fs = bytes(v.fileSystemType()).decode(errors="ignore")
        if fs in NET_FS and "gvfs" not in root:
            vols.append((v.displayName() or os.path.basename(root), root, "net"))
        elif root.startswith(("/media/", "/run/media/", "/mnt/")):
            vols.append((v.displayName() or os.path.basename(root), root, "hd"))
    places += sorted(vols, key=lambda p: p[0].lower())
    gvfs = f"/run/user/{os.getuid()}/gvfs"
    try:
        for e in sorted(os.scandir(gvfs), key=lambda e: e.name):
            if e.is_dir():
                places.append((gvfs_label(e.name), e.path, "net"))
    except OSError:
        pass
    return places


def set_wallpaper(path):
    uri = QUrl.fromLocalFile(path).toString()
    de = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
    if "cinnamon" in de:
        cmds = [["gsettings", "set", "org.cinnamon.desktop.background", "picture-uri", uri]]
    elif "mate" in de:
        cmds = [["gsettings", "set", "org.mate.background", "picture-filename", path]]
    elif any(d in de for d in ("gnome", "unity", "budgie", "pantheon")):
        cmds = [["gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri],
                ["gsettings", "set", "org.gnome.desktop.background", "picture-uri-dark", uri]]
    else:
        return False
    try:
        return all(subprocess.run(c, timeout=5).returncode == 0 for c in cmds)
    except (OSError, subprocess.SubprocessError):
        return False


ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
<stop offset="0" stop-color="#5b9bff"/><stop offset="1" stop-color="#2a5fd6"/></linearGradient></defs>
<rect x="8" y="8" width="112" height="112" rx="26" fill="url(#g)"/>
<circle cx="86" cy="42" r="12" fill="#ffd96a"/>
<path d="M20 98 L52 58 L72 80 L84 68 L108 98 Z" fill="#ffffff" opacity="0.95"/>
</svg>"""


def install_desktop_entry():
    share = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"))
    appdir = os.path.join(share, APP_ID)
    os.makedirs(appdir, exist_ok=True)
    target = os.path.join(appdir, "hansviewer.py")
    me = os.path.abspath(__file__)
    if me != target:
        shutil.copy2(me, target)
    icondir = os.path.join(share, "icons", "hicolor", "scalable", "apps")
    os.makedirs(icondir, exist_ok=True)
    with open(os.path.join(icondir, "hansviewer.svg"), "w") as f:
        f.write(ICON_SVG)
    mimes = ";".join(f"image/{m}" for m in ("jpeg", "png", "gif", "bmp", "webp", "tiff",
                                            "x-portable-pixmap", "svg+xml")) + ";"
    desktop_dir = os.path.join(share, "applications")
    os.makedirs(desktop_dir, exist_ok=True)
    # remove the menu entry of the earlier "acdview" version, if it was installed
    for old in (os.path.join(desktop_dir, "acdview.desktop"),
                os.path.join(icondir, "acdview.svg")):
        try:
            os.remove(old)
        except OSError:
            pass
    with open(os.path.join(desktop_dir, "hansviewer.desktop"), "w") as f:
        f.write(f"[Desktop Entry]\nType=Application\nName={APP} {VERSION}\n"
                "GenericName=Image Browser\nComment=Browse, view and edit photos\n"
                f'Exec=python3 "{target}" %f\nIcon=hansviewer\nTerminal=false\n'
                f"Categories=Graphics;Viewer;Photography;\nMimeType={mimes}\n")
    try:
        subprocess.run(["update-desktop-database", desktop_dir], timeout=10,
                       capture_output=True)
    except (OSError, subprocess.SubprocessError):
        pass
    return target


# ======================================================================= background jobs
class JobSignals(QObject):
    thumb = pyqtSignal(str, float, QImage, int, int)
    dates = pyqtSignal(object, int, int, int)  # results, done, total, generation
    image = pyqtSignal(str, QImage, object)


class ThumbJob(QRunnable):
    def __init__(self, path, mtime, signals, use_cache):
        super().__init__()
        self.path, self.mtime, self.signals, self.use_cache = path, mtime, signals, use_cache

    def run(self):
        img, w, h = make_thumbnail(self.path, self.mtime, self.use_cache)
        self.signals.thumb.emit(self.path, self.mtime, img, w, h)


class DateJob(QRunnable):
    """Reads the 'date taken' of many photos, reporting in chunks."""

    def __init__(self, entries, token, gen, signals):
        super().__init__()
        self.entries, self.token, self.gen, self.signals = entries, token, gen, signals

    def run(self):
        out, total = [], len(self.entries)
        for n, e in enumerate(self.entries, 1):
            if self.token["gen"] != self.gen:
                return  # the folder changed; stop
            try:
                ts = exif_date(e["path"])
            except Exception:
                ts = None
            out.append((date_key(e), e["path"], ts))
            if len(out) >= 100 or n == total:
                self.signals.dates.emit(out, n, total, self.gen)
                out = []


class ImageJob(QRunnable):
    """Decodes an image (optionally downscaled) plus info for the preview pane."""

    def __init__(self, path, signals, max_edge=None, with_info=False):
        super().__init__()
        self.path, self.signals, self.max_edge, self.with_info = path, signals, max_edge, with_info

    def run(self):
        info = None
        if self.with_info:
            info = {"dims": image_dims(QImageReader(self.path)), "exif": exif_summary(self.path)}
        self.signals.image.emit(self.path, read_image(self.path, self.max_edge), info)


# ======================================================================= thumbnail model
class FolderModel(QAbstractListModel):
    date_progress = pyqtSignal(int, int)
    dates_finished = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.all, self.items, self.row_of = [], [], {}
        self.thumbs, self.dims, self.pending = {}, {}, set()
        self.sort_key, self.sort_desc, self.filter = "name", False, ""
        self.use_cache = True
        self.pool = QThreadPool()
        self.pool.setMaxThreadCount(max(2, (os.cpu_count() or 4) - 1))
        self.signals = JobSignals()
        self.signals.thumb.connect(self._thumb_ready)
        self.signals.dates.connect(self._dates_ready)
        self.token, self.dates_gen = {"gen": 0}, -1
        self.error = ""

    # -- loading / ordering
    def load(self, folder):
        self.pool.clear()
        self.pending.clear()
        self.token["gen"] += 1
        entries, self.error = [], ""
        try:
            with os.scandir(folder) as it:
                for e in it:
                    if e.name.startswith("."):
                        continue
                    ext = os.path.splitext(e.name)[1][1:].lower()
                    if ext not in READ_EXTS:
                        continue
                    try:
                        if not e.is_file():
                            continue
                        st = e.stat()
                    except OSError:
                        continue
                    entries.append({"path": e.path, "name": e.name, "ext": ext,
                                    "size": st.st_size, "mtime": st.st_mtime,
                                    "taken": None, "taken_known": False})
        except OSError as err:
            self.error = err.strerror or str(err)
        if len(self.thumbs) > 3000:  # keep memory in check across many folders
            self.thumbs.clear()
            self.dims.clear()
        cache = date_cache()
        for e in entries:
            k = date_key(e)
            if k in cache:
                e["taken"], e["taken_known"] = cache[k], True
        self.all = entries
        if self.sort_key == "taken":
            self.ensure_dates()
        self._rebuild()

    def ensure_dates(self):
        """Read missing 'date taken' values in the background."""
        missing = [e for e in self.all if not e["taken_known"]]
        if missing and self.dates_gen != self.token["gen"]:
            self.dates_gen = self.token["gen"]
            QThreadPool.globalInstance().start(
                DateJob(missing, self.token, self.token["gen"], self.signals))

    def _dates_ready(self, results, done, total, gen):
        if gen != self.token["gen"]:
            return
        cache = date_cache()
        by_path = {e["path"]: e for e in self.all}
        for key, path, ts in results:
            cache[key] = ts
            e = by_path.get(path)
            if e is not None:
                e["taken"], e["taken_known"] = ts, True
        self.date_progress.emit(done, total)
        if done >= total:
            save_date_cache()
            self.dates_finished.emit()

    def _rebuild(self):
        self.beginResetModel()
        items = self.all
        if self.filter:
            f = self.filter.lower()
            items = [e for e in items if f in e["name"].lower()]
        key = {
            "name": lambda e: natural_key(e["name"]),
            "date": lambda e: (e["mtime"], natural_key(e["name"])),
            "taken": lambda e: (e["taken"] or e["mtime"], natural_key(e["name"])),
            "size": lambda e: (e["size"], natural_key(e["name"])),
            "type": lambda e: (e["ext"], natural_key(e["name"])),
        }[self.sort_key]
        self.items = sorted(items, key=key, reverse=self.sort_desc)
        self.row_of = {e["path"]: i for i, e in enumerate(self.items)}
        self.endResetModel()

    def set_sort(self, key, desc):
        self.sort_key, self.sort_desc = key, desc
        if key == "taken":
            self.ensure_dates()
        self._rebuild()

    def set_filter(self, text):
        self.filter = text.strip()
        self._rebuild()

    def paths(self):
        return [e["path"] for e in self.items]

    def total_size(self, rows=None):
        rows = range(len(self.items)) if rows is None else rows
        return sum(self.items[r]["size"] for r in rows)

    # -- Qt model API
    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.items)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or index.row() >= len(self.items):
            return None
        e = self.items[index.row()]
        key = (e["path"], e["mtime"])
        if role == Qt.ItemDataRole.DisplayRole:
            return e["name"]
        if role == Qt.ItemDataRole.DecorationRole:
            if key in self.thumbs:
                return self.thumbs[key]
            if key not in self.pending:
                self.pending.add(key)
                self.pool.start(ThumbJob(e["path"], e["mtime"], self.signals, self.use_cache))
            return None
        if role == ROLE_DIMS:
            return self.dims.get(key)
        if role == ROLE_PATH:
            return e["path"]
        if role == Qt.ItemDataRole.ToolTipRole:
            d = self.dims.get(key)
            dims = f"{d[0]} × {d[1]}  ·  " if d and d[0] else ""
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(e["mtime"]))
            tip = f"{e['name']}\n{dims}{human_size(e['size'])}  ·  modified {when}"
            if e["taken"]:
                tip += "\ntaken " + time.strftime("%Y-%m-%d %H:%M", time.localtime(e["taken"]))
            return tip
        return None

    def flags(self, index):
        base = super().flags(index)
        return base | Qt.ItemFlag.ItemIsDragEnabled if index.isValid() else base

    def mimeTypes(self):
        return ["text/uri-list"]

    def mimeData(self, indexes):
        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(self.items[i.row()]["path"]) for i in indexes])
        return md

    def supportedDragActions(self):
        return Qt.DropAction.CopyAction

    def _thumb_ready(self, path, mtime, image, w, h):
        key = (path, mtime)
        self.pending.discard(key)
        row = self.row_of.get(path)
        if image.isNull():
            image = QImage()
        self.thumbs[key] = QPixmap.fromImage(image) if not image.isNull() else QPixmap()
        self.dims[key] = (w, h)
        if row is not None and self.items[row]["mtime"] == mtime:
            idx = self.index(row)
            self.dataChanged.emit(idx, idx)


class ThumbDelegate(QStyledItemDelegate):
    """Draws each image as a rounded card with a caption."""

    def __init__(self, size):
        super().__init__()
        self.size = size

    def cell(self):
        return QSize(self.size + 26, self.size + 54)

    def sizeHint(self, option, index):
        return self.cell()

    def paint(self, p, option, index):
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        r = QRectF(option.rect).adjusted(5, 5, -5, -5)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        accent = QColor(THEME["accent"])
        if selected:
            fill = QColor(accent)
            fill.setAlpha(60)
            p.setPen(QPen(accent, 2))
            p.setBrush(fill)
        else:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(THEME["card_hover"] if hover else THEME["card"]))
        p.drawRoundedRect(r, 10, 10)

        box = QRectF(r.x() + 8, r.y() + 8, r.width() - 16, self.size)
        pix = index.data(Qt.ItemDataRole.DecorationRole)
        if isinstance(pix, QPixmap) and not pix.isNull():
            s = min(box.width() / pix.width(), box.height() / pix.height(), 1.6)
            w, h = pix.width() * s, pix.height() * s
            target = QRectF(box.center().x() - w / 2, box.center().y() - h / 2, w, h)
            path = QPainterPath()
            path.addRoundedRect(target, 4, 4)
            p.setClipPath(path)
            p.drawPixmap(target, pix, QRectF(pix.rect()))
            p.setClipping(False)
        else:
            p.setPen(QColor(THEME["muted"]))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, "…" if pix is None else "?")

        p.setPen(QColor(THEME["text"]))
        fm = option.fontMetrics
        name = fm.elidedText(index.data(Qt.ItemDataRole.DisplayRole) or "",
                             Qt.TextElideMode.ElideMiddle, int(r.width() - 12))
        text_y = box.bottom() + 6
        p.drawText(QRectF(r.x() + 6, text_y, r.width() - 12, fm.height()),
                   Qt.AlignmentFlag.AlignHCenter, name)
        dims = index.data(ROLE_DIMS)
        if dims and dims[0]:
            small = QFont(option.font)
            small.setPointSizeF(max(6.0, option.font.pointSizeF() * 0.85))
            p.setFont(small)
            p.setPen(QColor(THEME["muted"]))
            p.drawText(QRectF(r.x() + 6, text_y + fm.height(), r.width() - 12, fm.height()),
                       Qt.AlignmentFlag.AlignHCenter, f"{dims[0]} × {dims[1]}")
        p.restore()


class ThumbGrid(QListView):
    def __init__(self):
        super().__init__()
        self.setObjectName("grid")
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setMovement(QListView.Movement.Static)
        self.setUniformItemSizes(True)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.setDragEnabled(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        self.setMouseTracking(True)
        self.viewport().setAttribute(Qt.WidgetAttribute.WA_Hover)
        self.empty_text = ""

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.model() is not None and self.model().rowCount() == 0 and self.empty_text:
            p = QPainter(self.viewport())
            p.setPen(QColor(THEME["muted"]))
            p.drawText(self.viewport().rect(), Qt.AlignmentFlag.AlignCenter, self.empty_text)


# ======================================================================= preview pane
class PreviewPane(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("previewPane")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.pix = None
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setMinimumHeight(200)
        self.image_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.title = QLabel()
        self.title.setObjectName("title")
        self.title.setWordWrap(True)
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        self.form.setHorizontalSpacing(14)
        self.form.setVerticalSpacing(6)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)
        lay.addWidget(self.image_label)
        lay.addWidget(self.title)
        lay.addLayout(self.form)
        lay.addStretch(1)
        self.clear()

    def clear(self, text="No image selected"):
        self.pix = None
        self.image_label.clear()
        self.image_label.setText(text)
        self.title.clear()
        self._set_rows([])

    def _set_rows(self, rows):
        while self.form.rowCount():
            self.form.removeRow(0)
        for k, v in rows:
            key = QLabel(k)
            key.setObjectName("muted")
            val = QLabel(v)
            val.setWordWrap(True)
            val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.form.addRow(key, val)

    def show_entry(self, entry, image=None, info=None):
        self.title.setText(entry["name"])
        rows = []
        if info and info["dims"][0]:
            w, h = info["dims"]
            mp = w * h / 1e6
            rows.append(("Dimensions", f"{w} × {h}  ({mp:.1f} MP)"))
        rows += [("File size", human_size(entry["size"])),
                 ("Type", entry["ext"].upper()),
                 ("Modified", time.strftime("%Y-%m-%d %H:%M", time.localtime(entry["mtime"]))),
                 ("Folder", os.path.dirname(entry["path"]))]
        if info:
            rows += info["exif"]
        self._set_rows(rows)
        if image is not None and not image.isNull():
            self.pix = QPixmap.fromImage(image)
            self._scale()
        elif image is not None:
            self.pix = None
            self.image_label.setText("Cannot preview")

    def _scale(self):
        if self.pix:
            w = max(50, self.image_label.width())
            h = max(150, min(self.image_label.width(), 420))
            self.image_label.setPixmap(self.pix.scaled(
                w, h, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._scale()


# ======================================================================= full-screen viewer
class Viewer(QWidget):
    closed = pyqtSignal(str)   # path of the last image shown
    changed = pyqtSignal()     # files were edited/rotated/deleted

    def __init__(self, files, index, slideshow=False):
        super().__init__(None, Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle(APP)
        self.files, self.i = list(files), index
        self.cache = {}
        self.signals = JobSignals()
        self.signals.image.connect(self._preloaded)
        self.pool = QThreadPool.globalInstance()
        self.pix, self.fit, self.zoom = None, True, 1.0
        self.pan, self.drag_from = QPointF(0, 0), None
        self.show_info, self.overlay_until, self.flash = False, 0.0, ""
        self.setMouseTracking(True)
        self.setMinimumSize(320, 240)
        self.slide = QTimer(self)
        self.slide.timeout.connect(self.slide_next)
        self.cursor_timer = QTimer(self)
        self.cursor_timer.setSingleShot(True)
        self.cursor_timer.timeout.connect(self._hide_cursor)
        self.overlay_timer = QTimer(self)
        self.overlay_timer.setSingleShot(True)
        self.overlay_timer.timeout.connect(self.update)
        self.show_image()
        if slideshow:
            self.toggle_slideshow()

    # -- loading
    def path(self):
        return self.files[self.i]

    def show_image(self, flash=""):
        path = self.path()
        image = self.cache.get(path)
        if image is None:
            image = read_image(path)
        self.cache[path] = image
        self.pix = None if image.isNull() else QPixmap.fromImage(image)
        self.fit, self.zoom, self.pan = True, 1.0, QPointF(0, 0)
        self.setWindowTitle(f"{os.path.basename(path)} — {APP}")
        self.poke_overlay(flash)
        self.preload_neighbours()

    def preload_neighbours(self):
        wanted = {self.files[j] for j in (self.i - 1, self.i, self.i + 1)
                  if 0 <= j < len(self.files)}
        self.cache = {p: img for p, img in self.cache.items() if p in wanted}
        for p in wanted - self.cache.keys():
            self.pool.start(ImageJob(p, self.signals))

    def _preloaded(self, path, image, _info):
        near = self.files[max(0, self.i - 1): self.i + 2]
        if path in near and path not in self.cache:
            self.cache[path] = image

    def go(self, j, wrap=False):
        if not self.files:
            return
        if wrap:
            j %= len(self.files)
        j = max(0, min(len(self.files) - 1, j))
        if j != self.i:
            self.i = j
            self.show_image()

    # -- slideshow
    def toggle_slideshow(self):
        if self.slide.isActive():
            self.slide.stop()
            self.poke_overlay("Slideshow stopped")
        else:
            self.slide.start(int(setting("slideshow_secs", 4, int) * 1000))
            if not self.isFullScreen():
                self.showFullScreen()
            self.poke_overlay("Slideshow ▶")

    def slide_next(self):
        self.go(self.i + 1, wrap=True)

    # -- file actions
    def rotate(self, degrees):
        path = self.path()
        if rotate_file(path, degrees):
            self.cache.pop(path, None)
            self.show_image("Rotated and saved")
            self.changed.emit()
        else:
            self.poke_overlay("Can't save this file type")

    def delete(self):
        path = self.path()
        if setting("confirm_delete", True, bool):
            ans = QMessageBox.question(self, "Move to Trash",
                                       f"Move “{os.path.basename(path)}” to the Trash?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        if not move_to_trash(path):
            self.poke_overlay("Could not move to Trash")
            return
        self.changed.emit()
        del self.files[self.i]
        self.cache.pop(path, None)
        if not self.files:
            self.close()
            return
        self.i = min(self.i, len(self.files) - 1)
        self.show_image("Moved to Trash")

    def edit(self):
        self.slide.stop()
        dlg = EditorDialog(self.path(), self)
        dlg.saved.connect(lambda _p: self.changed.emit())
        dlg.exec()
        self.cache.pop(self.path(), None)
        self.show_image()

    # -- zoom
    def current_scale(self):
        if not self.pix:
            return 1.0
        if self.fit:
            return min(self.width() / self.pix.width(), self.height() / self.pix.height(), 1.0)
        return self.zoom

    def set_zoom(self, factor):
        self.zoom = max(0.05, min(32.0, self.current_scale() * factor))
        self.fit = False
        self.poke_overlay()

    def poke_overlay(self, flash=""):
        self.flash = flash
        self.overlay_until = time.monotonic() + 2.5
        self.overlay_timer.start(2600)
        self.update()

    def _hide_cursor(self):
        if self.isFullScreen():
            self.setCursor(Qt.CursorShape.BlankCursor)

    # -- painting
    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(THEME["viewer"]))
        if self.pix:
            s = self.current_scale()
            w, h = self.pix.width() * s, self.pix.height() * s
            x = (self.width() - w) / 2 + (0 if self.fit else self.pan.x())
            y = (self.height() - h) / 2 + (0 if self.fit else self.pan.y())
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, s < 4)
            p.drawPixmap(QRectF(x, y, w, h), self.pix, QRectF(self.pix.rect()))
        else:
            p.setPen(QColor("#888888"))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Cannot open this image")
        if self.show_info or time.monotonic() < self.overlay_until:
            self._draw_overlay(p)

    def _draw_overlay(self, p):
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        parts = [os.path.basename(self.path()), f"{self.i + 1} / {len(self.files)}"]
        if self.pix:
            parts += [f"{self.pix.width()} × {self.pix.height()}",
                      f"{self.current_scale() * 100:.0f}%"]
        if self.slide.isActive():
            parts.append("▶ slideshow")
        if self.flash:
            parts.append(self.flash)
        text = "   ·   ".join(parts)
        fm = p.fontMetrics()
        w = min(self.width() - 40, fm.horizontalAdvance(text) + 36)
        rect = QRectF((self.width() - w) / 2, self.height() - 58, w, 36)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 175))
        p.drawRoundedRect(rect, 18, 18)
        p.setPen(QColor("#f2f2f2"))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter,
                   fm.elidedText(text, Qt.TextElideMode.ElideMiddle, int(w - 24)))

    # -- input
    def keyPressEvent(self, e):
        k, K = e.key(), Qt.Key
        ctrl = bool(e.modifiers() & Qt.KeyboardModifier.ControlModifier)
        if k in (K.Key_Right, K.Key_Space, K.Key_PageDown, K.Key_Down):
            self.go(self.i + 1)
        elif k in (K.Key_Left, K.Key_Backspace, K.Key_PageUp, K.Key_Up):
            self.go(self.i - 1)
        elif k == K.Key_Home:
            self.go(0)
        elif k == K.Key_End:
            self.go(len(self.files) - 1)
        elif k in (K.Key_Plus, K.Key_Equal):
            self.set_zoom(1.25)
        elif k == K.Key_Minus:
            self.set_zoom(0.8)
        elif k in (K.Key_0, K.Key_Asterisk):
            self.fit, self.zoom, self.pan = not self.fit, 1.0, QPointF(0, 0)
            self.poke_overlay()
        elif k == K.Key_1:
            self.fit, self.zoom, self.pan = False, 1.0, QPointF(0, 0)
            self.poke_overlay()
        elif k in (K.Key_F, K.Key_F11):
            self.showNormal() if self.isFullScreen() else self.showFullScreen()
        elif k == K.Key_S:
            self.toggle_slideshow()
        elif k == K.Key_I:
            self.show_info = not self.show_info
            self.update()
        elif k == K.Key_BracketRight:
            self.rotate(90)
        elif k == K.Key_BracketLeft:
            self.rotate(-90)
        elif k == K.Key_E:
            self.edit()
        elif k == K.Key_Delete:
            self.delete()
        elif ctrl and k == K.Key_C and self.pix:
            QApplication.clipboard().setPixmap(self.pix)
            self.poke_overlay("Copied")
        elif k in (K.Key_Escape, K.Key_Return, K.Key_Enter):
            if k == K.Key_Escape and self.slide.isActive():
                self.toggle_slideshow()
            else:
                self.close()
        else:
            super().keyPressEvent(e)

    def wheelEvent(self, e):
        up = e.angleDelta().y() > 0
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.set_zoom(1.25 if up else 0.8)
        else:
            self.go(self.i - 1 if up else self.i + 1)

    def mousePressEvent(self, e):
        self.drag_from = e.position()

    def mouseMoveEvent(self, e):
        self.unsetCursor()
        self.cursor_timer.start(2000)
        if self.drag_from is not None and not self.fit:
            self.pan += e.position() - self.drag_from
            self.drag_from = e.position()
            self.update()

    def mouseReleaseEvent(self, _):
        self.drag_from = None

    def mouseDoubleClickEvent(self, _):
        self.close()

    def contextMenuEvent(self, e):
        m = QMenu(self)
        menu_add(m, "Next\tSpace", lambda: self.go(self.i + 1))
        menu_add(m, "Previous\tBackspace", lambda: self.go(self.i - 1))
        m.addSeparator()
        menu_add(m, "Slideshow\tS", self.toggle_slideshow)
        menu_add(m, "Full screen\tF", lambda: self.showNormal() if self.isFullScreen()
                 else self.showFullScreen())
        m.addSeparator()
        menu_add(m, "Rotate left\t[", lambda: self.rotate(-90))
        menu_add(m, "Rotate right\t]", lambda: self.rotate(90))
        menu_add(m, "Edit…\tE", self.edit)
        menu_add(m, "Copy image\tCtrl+C", lambda: QApplication.clipboard().setPixmap(self.pix)
                 if self.pix else None)
        menu_add(m, "Set as wallpaper", self._wallpaper)
        m.addSeparator()
        menu_add(m, "Move to Trash\tDel", self.delete)
        menu_add(m, "Back to browser\tEsc", self.close)
        m.exec(e.globalPos())

    def _wallpaper(self):
        self.poke_overlay("Wallpaper set" if set_wallpaper(self.path())
                          else "Couldn't set wallpaper on this desktop")

    def closeEvent(self, e):
        self.slide.stop()
        self.closed.emit(self.path() if self.files else "")
        super().closeEvent(e)


# ======================================================================= editor
class EditCanvas(QWidget):
    selection_changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.pix, self.full = None, QSize()
        self.crop_mode, self.sel, self.aspect, self.start = False, None, None, None
        self.setMinimumSize(480, 360)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_image(self, display, full_size):
        self.pix = QPixmap.fromImage(display)
        self.full = QSize(full_size)
        self.update()

    def target(self):
        if not self.pix:
            return QRectF()
        m = 20
        s = min((self.width() - 2 * m) / self.pix.width(),
                (self.height() - 2 * m) / self.pix.height(), 1.0 * self.full.width() / self.pix.width())
        w, h = self.pix.width() * s, self.pix.height() * s
        return QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)

    def to_image(self, pos):
        t = self.target()
        x = (pos.x() - t.x()) / t.width() * self.full.width()
        y = (pos.y() - t.y()) / t.height() * self.full.height()
        return QPointF(max(0.0, min(self.full.width(), x)), max(0.0, min(self.full.height(), y)))

    def to_widget(self, r):
        t = self.target()
        sx, sy = t.width() / self.full.width(), t.height() / self.full.height()
        return QRectF(t.x() + r.x() * sx, t.y() + r.y() * sy, r.width() * sx, r.height() * sy)

    def mousePressEvent(self, e):
        if self.crop_mode and self.pix:
            self.start = self.to_image(e.position())
            self.sel = None
            self.update()

    def mouseMoveEvent(self, e):
        if self.start is None:
            return
        cur = self.to_image(e.position())
        sx, sy = self.start.x(), self.start.y()
        dx, dy = cur.x() - sx, cur.y() - sy
        maxw = self.full.width() - sx if dx >= 0 else sx
        maxh = self.full.height() - sy if dy >= 0 else sy
        w, h = abs(dx), abs(dy)
        if self.aspect:
            w = min(max(w, h * self.aspect), maxw, maxh * self.aspect)
            h = w / self.aspect
        else:
            w, h = min(w, maxw), min(h, maxh)
        x = sx if dx >= 0 else sx - w
        y = sy if dy >= 0 else sy - h
        self.sel = QRectF(x, y, w, h)
        self.update()
        self.selection_changed.emit()

    def mouseReleaseEvent(self, _):
        self.start = None
        if self.sel is not None and (self.sel.width() < 2 or self.sel.height() < 2):
            self.sel = None
            self.update()
        self.selection_changed.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(THEME["viewer"]))
        if not self.pix:
            return
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        t = self.target()
        p.drawPixmap(t, self.pix, QRectF(self.pix.rect()))
        if self.sel is not None:
            r = self.to_widget(self.sel)
            shade = QPainterPath()
            shade.addRect(t)
            hole = QPainterPath()
            hole.addRect(r)
            p.fillPath(shade.subtracted(hole), QColor(0, 0, 0, 150))
            p.setPen(QPen(QColor(255, 255, 255, 90), 1))
            for i in (1, 2):
                p.drawLine(QPointF(r.x() + r.width() * i / 3, r.y()),
                           QPointF(r.x() + r.width() * i / 3, r.bottom()))
                p.drawLine(QPointF(r.x(), r.y() + r.height() * i / 3),
                           QPointF(r.right(), r.y() + r.height() * i / 3))
            p.setPen(QPen(QColor(THEME["accent"]), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(r)


class EditorDialog(QDialog):
    saved = pyqtSignal(str)
    ASPECTS = [("Free", None), ("Original", "orig"), ("1:1", 1.0), ("4:3", 4 / 3),
               ("3:2", 3 / 2), ("16:9", 16 / 9), ("3:4", 3 / 4), ("2:3", 2 / 3), ("9:16", 9 / 16)]

    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.path = path
        self.setWindowTitle(f"Edit — {os.path.basename(path)}")
        self.resize(1280, 820)
        self.image = read_image(path)
        self.undo, self.redo, self.dirty = [], [], False
        self.proxy = None
        self.preview_timer = QTimer(self)
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self._live_preview)
        self._build()
        if self.image.isNull():
            QMessageBox.warning(self, "Edit", "This image can't be opened for editing.")
            QTimer.singleShot(0, super().reject)
            return
        self._refresh()

    # -- UI
    def _build(self):
        self.canvas = EditCanvas()
        self.canvas.selection_changed.connect(self._sel_changed)

        tools = QWidget()
        tools.setObjectName("toolsPanel")
        col = QVBoxLayout(tools)
        col.setContentsMargins(12, 6, 12, 12)
        col.setSpacing(8)

        def button(text, slot, icon_names=None):
            b = QPushButton(text)
            if icon_names:
                b.setIcon(icon(icon_names))
            b.clicked.connect(slot)
            return b

        g = QGroupBox("Rotate & flip")
        gl = QGridLayout(g)
        gl.addWidget(button("Left", lambda: self._op(lambda im: rotate_qimage(im, -90)),
                            "object-rotate-left"), 0, 0)
        gl.addWidget(button("Right", lambda: self._op(lambda im: rotate_qimage(im, 90)),
                            "object-rotate-right"), 0, 1)
        gl.addWidget(button("Flip ↔", lambda: self._op(lambda im: flip_qimage(im, True)),
                            "object-flip-horizontal"), 1, 0)
        gl.addWidget(button("Flip ↕", lambda: self._op(lambda im: flip_qimage(im, False)),
                            "object-flip-vertical"), 1, 1)
        col.addWidget(g)

        g = QGroupBox("Crop")
        gl = QGridLayout(g)
        self.aspect_box = QComboBox()
        for label, _ in self.ASPECTS:
            self.aspect_box.addItem(label)
        self.aspect_box.currentIndexChanged.connect(self._aspect_changed)
        self.crop_btn = QPushButton("Select area")
        self.crop_btn.setCheckable(True)
        self.crop_btn.toggled.connect(self._crop_mode)
        self.apply_crop_btn = button("Apply crop", self._apply_crop, "transform-crop")
        self.apply_crop_btn.setObjectName("primary")
        self.sel_label = QLabel("Drag on the image")
        self.sel_label.setObjectName("muted")
        gl.addWidget(QLabel("Ratio"), 0, 0)
        gl.addWidget(self.aspect_box, 0, 1)
        gl.addWidget(self.crop_btn, 1, 0)
        gl.addWidget(self.apply_crop_btn, 1, 1)
        gl.addWidget(self.sel_label, 2, 0, 1, 2)
        col.addWidget(g)

        g = QGroupBox("Resize")
        gl = QGridLayout(g)
        self.w_spin, self.h_spin = QSpinBox(), QSpinBox()
        for s in (self.w_spin, self.h_spin):
            s.setRange(1, 40000)
            s.setSuffix(" px")
        self.keep_aspect = QCheckBox("Keep proportions")
        self.keep_aspect.setChecked(True)
        self.w_spin.valueChanged.connect(lambda v: self._size_changed("w", v))
        self.h_spin.valueChanged.connect(lambda v: self._size_changed("h", v))
        self.pct_box = QComboBox()
        self.pct_box.addItems(["Preset…", "75%", "50%", "33%", "25%", "Long edge 3840",
                               "Long edge 1920", "Long edge 1280"])
        self.pct_box.activated.connect(self._preset_size)
        gl.addWidget(QLabel("Width"), 0, 0)
        gl.addWidget(self.w_spin, 0, 1)
        gl.addWidget(QLabel("Height"), 1, 0)
        gl.addWidget(self.h_spin, 1, 1)
        gl.addWidget(self.keep_aspect, 2, 0, 1, 2)
        gl.addWidget(self.pct_box, 3, 0)
        b = button("Apply size", self._apply_resize)
        b.setObjectName("primary")
        gl.addWidget(b, 3, 1)
        col.addWidget(g)

        g = QGroupBox("Adjust")
        gl = QGridLayout(g)
        self.sliders = {}
        for row, (key, label) in enumerate((("brightness", "Brightness"), ("contrast", "Contrast"),
                                            ("saturation", "Saturation"), ("warmth", "Warmth"))):
            sl = QSlider(Qt.Orientation.Horizontal)
            sl.setRange(-100, 100)
            val = QLabel("0")
            val.setObjectName("muted")
            val.setMinimumWidth(30)
            sl.valueChanged.connect(lambda v, lab=val: (lab.setText(str(v)),
                                                        self.preview_timer.start(40)))
            sl.sliderReleased.connect(lambda: self.preview_timer.start(0))
            self.sliders[key] = sl
            gl.addWidget(QLabel(label), row, 0)
            gl.addWidget(sl, row, 1)
            gl.addWidget(val, row, 2)
        reset = button("Reset", self._reset_sliders)
        apply_b = button("Apply", self._commit_adjust)
        apply_b.setObjectName("primary")
        gl.addWidget(reset, 4, 0)
        gl.addWidget(apply_b, 4, 1, 1, 2)
        if np is None:
            g.setEnabled(False)
            note = QLabel("Install python3-numpy to enable")
            note.setObjectName("muted")
            gl.addWidget(note, 5, 0, 1, 3)
        col.addWidget(g)

        g = QGroupBox("Effects")
        gl = QGridLayout(g)
        effects = [("Auto levels", "autolevels"), ("Sharpen", "sharpen"),
                   ("Black & white", "grayscale"), ("Sepia", "sepia"), ("Invert", "invert")]
        for n, (label, key) in enumerate(effects):
            b = button(label, lambda _=False, k=key: self._op(lambda im: filter_image(im, k)))
            b.setEnabled(np is not None or key == "grayscale")
            gl.addWidget(b, n // 2, n % 2)
        col.addWidget(g)

        g = QGroupBox("History")
        gl = QGridLayout(g)
        self.undo_btn = button("Undo", self._undo, "edit-undo")
        self.redo_btn = button("Redo", self._redo, "edit-redo")
        gl.addWidget(self.undo_btn, 0, 0)
        gl.addWidget(self.redo_btn, 0, 1)
        gl.addWidget(button("Revert to original", self._revert, "document-revert"), 1, 0, 1, 2)
        col.addWidget(g)
        col.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidget(tools)
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(320)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.info = QLabel()
        self.info.setObjectName("muted")
        self.quality = QSpinBox()
        self.quality.setRange(30, 100)
        self.quality.setValue(setting("jpeg_quality", 92, int))
        self.quality.setPrefix("Quality ")
        self.quality.setToolTip("JPEG / WebP quality when saving")
        save = button("Save", self._save, "document-save")
        save.setObjectName("primary")
        save_as = button("Save as…", self._save_as, "document-save-as")
        close = button("Close", self.reject)
        bottom = QHBoxLayout()
        bottom.setContentsMargins(14, 8, 14, 10)
        bottom.addWidget(self.info, 1)
        bottom.addWidget(self.quality)
        bottom.addWidget(close)
        bottom.addWidget(save_as)
        bottom.addWidget(save)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(0)
        top.addWidget(self.canvas, 1)
        top.addWidget(scroll)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addLayout(top, 1)
        bar = QFrame()
        bar.setLayout(bottom)
        bar.setObjectName("toolsPanel")
        lay.addWidget(bar)

        for seq, slot in (("Ctrl+Z", self._undo), ("Ctrl+Y", self._redo),
                          ("Ctrl+Shift+Z", self._redo), ("Ctrl+S", self._save)):
            a = QAction(self)
            a.setShortcut(QKeySequence(seq))
            a.triggered.connect(slot)
            self.addAction(a)

    # -- state
    def _adjust_values(self):
        return {k: s.value() for k, s in self.sliders.items()}

    def _refresh(self):
        img = self.image
        big = max(img.width(), img.height())
        self.proxy = img if big <= 1600 else img.scaled(
            1600, 1600, Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self._live_preview()
        for spin, v in ((self.w_spin, img.width()), (self.h_spin, img.height())):
            spin.blockSignals(True)
            spin.setValue(v)
            spin.blockSignals(False)
        self.undo_btn.setEnabled(bool(self.undo))
        self.redo_btn.setEnabled(bool(self.redo))
        self.info.setText(f"{img.width()} × {img.height()}" + ("   ·   edited" if self.dirty else ""))
        self.setWindowTitle(f"Edit — {os.path.basename(self.path)}" + (" *" if self.dirty else ""))
        self._sel_changed()

    def _live_preview(self):
        if self.proxy is None:
            return
        shown = adjust_image(self.proxy, **self._adjust_values())
        self.canvas.set_image(shown, self.image.size())

    def _push(self, new_image):
        if new_image is None or new_image.isNull():
            return
        self.undo.append(self.image)
        del self.undo[:-15]
        self.redo.clear()
        self.image = new_image
        self.dirty = True
        self._refresh()

    def _op(self, fn):
        self._commit_adjust()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self._push(fn(self.image))
        finally:
            QApplication.restoreOverrideCursor()

    def _commit_adjust(self):
        vals = self._adjust_values()
        if any(vals.values()):
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            try:
                new = adjust_image(self.image, **vals)
            finally:
                QApplication.restoreOverrideCursor()
            self._reset_sliders(refresh=False)
            self._push(new)

    def _reset_sliders(self, refresh=True):
        for s in self.sliders.values():
            s.setValue(0)
        if refresh:
            self._live_preview()

    def _undo(self):
        if self.undo:
            self.redo.append(self.image)
            self.image = self.undo.pop()
            self.dirty = True
            self._refresh()

    def _redo(self):
        if self.redo:
            self.undo.append(self.image)
            self.image = self.redo.pop()
            self.dirty = True
            self._refresh()

    def _revert(self):
        orig = read_image(self.path)
        if not orig.isNull():
            self._reset_sliders(refresh=False)
            self._push(orig)
            self.dirty = False
            self._refresh()

    # -- crop
    def _aspect_changed(self, i):
        a = self.ASPECTS[i][1]
        if a == "orig":
            a = self.image.width() / max(1, self.image.height())
        self.canvas.aspect = a
        self.canvas.sel = None
        self.canvas.update()
        self._sel_changed()

    def _crop_mode(self, on):
        self.canvas.crop_mode = on
        self.canvas.setCursor(Qt.CursorShape.CrossCursor if on else Qt.CursorShape.ArrowCursor)
        if not on:
            self.canvas.sel = None
            self.canvas.update()
        self._sel_changed()

    def _sel_changed(self):
        sel = self.canvas.sel
        self.apply_crop_btn.setEnabled(sel is not None)
        if sel is not None:
            self.sel_label.setText(f"Selection {int(sel.width())} × {int(sel.height())}")
        else:
            self.sel_label.setText("Click “Select area”, then drag" if not self.canvas.crop_mode
                                   else "Drag on the image")

    def _apply_crop(self):
        sel = self.canvas.sel
        if sel is None:
            return
        rect = sel.toRect().intersected(self.image.rect())
        self.canvas.sel = None
        self.crop_btn.setChecked(False)
        self._op(lambda im: im.copy(rect))

    # -- resize
    def _size_changed(self, which, v):
        if not self.keep_aspect.isChecked() or self.image.isNull():
            return
        w0, h0 = self.image.width(), self.image.height()
        other = self.h_spin if which == "w" else self.w_spin
        val = round(v * h0 / w0) if which == "w" else round(v * w0 / h0)
        other.blockSignals(True)
        other.setValue(max(1, val))
        other.blockSignals(False)

    def _preset_size(self, i):
        text = self.pct_box.itemText(i)
        w0, h0 = self.image.width(), self.image.height()
        if text.endswith("%"):
            f = int(text[:-1]) / 100
        elif text.startswith("Long edge"):
            f = int(text.split()[-1]) / max(w0, h0)
        else:
            return
        self.w_spin.blockSignals(True)
        self.h_spin.blockSignals(True)
        self.w_spin.setValue(max(1, round(w0 * f)))
        self.h_spin.setValue(max(1, round(h0 * f)))
        self.w_spin.blockSignals(False)
        self.h_spin.blockSignals(False)
        self.pct_box.setCurrentIndex(0)

    def _apply_resize(self):
        w, h = self.w_spin.value(), self.h_spin.value()
        if (w, h) == (self.image.width(), self.image.height()):
            return
        self._op(lambda im: im.scaled(w, h, Qt.AspectRatioMode.IgnoreAspectRatio,
                                      Qt.TransformationMode.SmoothTransformation))

    # -- saving
    def _write(self, dest):
        self._commit_adjust()
        if not can_write(dest):
            QMessageBox.warning(self, "Save", f"Saving as {norm_format(dest).upper()} isn't "
                                              "supported. Use Save as… and pick JPEG or PNG.")
            return False
        settings().setValue("jpeg_quality", self.quality.value())
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            ok = save_image(self.image, dest, src=self.path, quality=self.quality.value())
        finally:
            QApplication.restoreOverrideCursor()
        if not ok:
            QMessageBox.warning(self, "Save", f"Could not save {dest}")
            return False
        self.dirty = False
        self._refresh()
        self.saved.emit(dest)
        return True

    def _save(self):
        if not self.dirty and not any(self._adjust_values().values()):
            return
        ans = QMessageBox.question(self, "Save", f"Overwrite “{os.path.basename(self.path)}” "
                                                 "with your changes?")
        if ans == QMessageBox.StandardButton.Yes:
            self._write(self.path)

    def _save_as(self):
        stem, ext = os.path.splitext(self.path)
        if not can_write(self.path):
            ext = ".jpg"
        dest, _ = QFileDialog.getSaveFileName(
            self, "Save as", f"{stem}_edited{ext}",
            "Images (*.jpg *.jpeg *.png *.webp *.tif *.tiff *.bmp);;All files (*)")
        if not dest:
            return
        if not os.path.splitext(dest)[1]:
            dest += ".jpg"
        if self._write(dest):
            self.path = dest

    def reject(self):
        if self.dirty or any(self._adjust_values().values()):
            box = QMessageBox(QMessageBox.Icon.Question, "Unsaved changes",
                              "Save your changes before closing?",
                              QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
                              | QMessageBox.StandardButton.Cancel, self)
            box.exec()
            ans = box.standardButton(box.clickedButton())
            if ans in (QMessageBox.StandardButton.Cancel, QMessageBox.StandardButton.NoButton):
                return
            if ans == QMessageBox.StandardButton.Save:
                if not self._write(self.path):
                    return
        super().reject()


# ======================================================================= dialogs
class BatchRenameDialog(QDialog):
    def __init__(self, entries, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Rename {len(entries)} files")
        self.resize(560, 460)
        self.entries = entries
        self.dates = [e.get("taken") or exif_date(e["path"]) or e["mtime"] for e in entries]
        self.pattern = QLineEdit("Photo ###")
        self.start = QSpinBox()
        self.start.setRange(0, 999999)
        self.start.setValue(1)
        help_ = QLabel("# = number (### → 001), {name} = old name, "
                       "{date} = date taken (or file date)")
        help_.setObjectName("muted")
        help_.setWordWrap(True)
        self.preview = QListWidget()
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                        | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        form = QFormLayout()
        form.addRow("New name", self.pattern)
        form.addRow("Start at", self.start)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(help_)
        lay.addWidget(self.preview, 1)
        lay.addWidget(self.buttons)
        self.pattern.textChanged.connect(self._update)
        self.start.valueChanged.connect(self._update)
        self._update()

    def new_names(self):
        pat, out = self.pattern.text(), []
        multi = len(self.entries) > 1 and "#" not in pat and "{name}" not in pat
        for i, e in enumerate(self.entries):
            n = self.start.value() + i
            stem, ext = os.path.splitext(e["name"])
            s = re.sub(r"#+", lambda m, n=n: str(n).zfill(len(m.group())), pat)
            s = s.replace("{name}", stem).replace(
                "{date}", time.strftime("%Y-%m-%d", time.localtime(self.dates[i])))
            if multi:
                s = f"{s} {n}"
            out.append(s.strip() + ext.lower())
        return out

    def _update(self):
        names = self.new_names()
        self.preview.clear()
        for e, n in list(zip(self.entries, names))[:300]:
            self.preview.addItem(f"{e['name']}   →   {n}")
        ok = (len(set(names)) == len(names) and all(n and "/" not in n for n in names)
              and self.pattern.text().strip())
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(bool(ok))


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.theme = QComboBox()
        self.theme.addItems(["Dark", "Light"])
        self.theme.setCurrentIndex(0 if setting("theme", "dark") == "dark" else 1)
        self.slides = QSpinBox()
        self.slides.setRange(1, 120)
        self.slides.setSuffix(" s")
        self.slides.setValue(setting("slideshow_secs", 4, int))
        self.quality = QSpinBox()
        self.quality.setRange(30, 100)
        self.quality.setValue(setting("jpeg_quality", 92, int))
        self.confirm = QCheckBox("Ask before moving files to the Trash")
        self.confirm.setChecked(setting("confirm_delete", True, bool))
        self.cache = QCheckBox("Save thumbnails to disk (shared with the file manager)")
        self.cache.setChecked(setting("disk_cache", True, bool))
        self.fullscreen = QCheckBox("Open the viewer in full screen")
        self.fullscreen.setChecked(setting("viewer_fullscreen", False, bool))
        form = QFormLayout()
        form.addRow("Theme", self.theme)
        form.addRow("Slideshow delay", self.slides)
        form.addRow("JPEG quality", self.quality)
        form.addRow(self.confirm)
        form.addRow(self.cache)
        form.addRow(self.fullscreen)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                   | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(buttons)

    def save(self):
        s = settings()
        s.setValue("theme", "dark" if self.theme.currentIndex() == 0 else "light")
        s.setValue("slideshow_secs", self.slides.value())
        s.setValue("jpeg_quality", self.quality.value())
        s.setValue("confirm_delete", self.confirm.isChecked())
        s.setValue("disk_cache", self.cache.isChecked())
        s.setValue("viewer_fullscreen", self.fullscreen.isChecked())


SHORTCUTS_HTML = """
<h3>Browser</h3><table cellspacing=4>
<tr><td><b>Enter</b> / double-click</td><td>View image</td></tr>
<tr><td><b>Backspace</b>, <b>Alt+Up</b></td><td>Parent folder</td></tr>
<tr><td><b>Alt+Left / Alt+Right</b></td><td>Back / forward</td></tr>
<tr><td><b>Ctrl+D</b></td><td>Add / remove favourite (F2 in the sidebar renames it)</td></tr>
<tr><td><b>Ctrl+F</b></td><td>Filter by name</td></tr>
<tr><td><b>F2</b></td><td>Rename (several selected: batch rename)</td></tr>
<tr><td><b>Ctrl+E</b></td><td>Edit image</td></tr>
<tr><td><b>Ctrl+[ / Ctrl+]</b></td><td>Rotate left / right</td></tr>
<tr><td><b>Del</b></td><td>Move to Trash</td></tr>
<tr><td><b>F5</b></td><td>Slideshow &nbsp;&nbsp; <b>Ctrl+R</b> Refresh</td></tr>
<tr><td><b>Ctrl+Plus / Minus</b></td><td>Bigger / smaller thumbnails</td></tr>
<tr><td><b>F9</b></td><td>Preview pane</td></tr></table>
<h3>Viewer</h3><table cellspacing=4>
<tr><td><b>Space / Backspace</b>, wheel</td><td>Next / previous</td></tr>
<tr><td><b>+ / −</b>, Ctrl+wheel</td><td>Zoom &nbsp; <b>0</b> fit / 100% &nbsp; <b>1</b> 100%</td></tr>
<tr><td><b>F</b></td><td>Full screen</td></tr>
<tr><td><b>S</b></td><td>Slideshow</td></tr>
<tr><td><b>I</b></td><td>Info bar</td></tr>
<tr><td><b>[ / ]</b></td><td>Rotate and save</td></tr>
<tr><td><b>E</b></td><td>Edit</td></tr>
<tr><td><b>Del</b></td><td>Move to Trash</td></tr>
<tr><td><b>Ctrl+C</b></td><td>Copy image</td></tr>
<tr><td><b>Esc</b></td><td>Back to browser</td></tr></table>
"""


# ======================================================================= browser window
class Browser(QMainWindow):
    def __init__(self, start):
        super().__init__()
        self.setWindowTitle(APP)
        self.setWindowIcon(icon("hansviewer image-viewer", SP.SP_DesktopIcon))
        self.resize(1400, 880)
        self.viewer = None
        self.folder = None
        self.history, self.hpos = [], -1
        self._syncing = False

        self.model = FolderModel()
        self.model.use_cache = setting("disk_cache", True, bool)
        self.model.sort_key = setting("sort_key", "name")
        self.model.date_progress.connect(self._date_progress)
        self.model.dates_finished.connect(self._dates_finished)
        if self.model.sort_key not in ("name", "taken", "date", "size", "type"):
            self.model.sort_key = "name"
        self.model.sort_desc = setting("sort_desc", False, bool)

        self.preview_signals = JobSignals()
        self.preview_signals.image.connect(self._preview_ready)
        self.preview_timer = QTimer(self)
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self._load_preview)

        self.watcher = QFileSystemWatcher(self)
        self.watcher.directoryChanged.connect(lambda _p: self.reload_timer.start(600))
        self.reload_timer = QTimer(self)
        self.reload_timer.setSingleShot(True)
        self.reload_timer.timeout.connect(self.reload)

        self._build_widgets()
        self._build_actions()
        self._build_menus_and_toolbar()
        self._restore_layout()

        self.places_timer = QTimer(self)
        self.places_timer.timeout.connect(self.refresh_devices)
        self.places_timer.start(3000)

        start = os.path.abspath(os.path.expanduser(start))
        target = None
        if os.path.isfile(start):
            start, target = os.path.dirname(start), start
        self.navigate(start)
        if target in self.model.row_of:
            self.select_path(target)
            QTimer.singleShot(0, self.view_current)

    # ------------------------------------------------------------------ layout
    def _build_widgets(self):
        # Sidebar: favourites + devices
        self.sidebar = QTreeWidget()
        self.sidebar.setHeaderHidden(True)
        self.sidebar.setRootIsDecorated(True)
        self.sidebar.setIndentation(14)
        self.sidebar.setAnimated(True)
        self.sidebar.itemExpanded.connect(self._populate)
        self.sidebar.itemChanged.connect(self._sidebar_item_changed)
        self.sidebar.setEditTriggers(QAbstractItemView.EditTrigger.EditKeyPressed)
        self.sidebar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.sidebar.customContextMenuRequested.connect(self._sidebar_menu)
        self.sidebar.itemClicked.connect(self._sidebar_clicked)
        self.sec_fav = self._section("FAVOURITES")
        self.sec_dev = self._section("DEVICES")
        self._devices_sig = None
        self.refresh_favourites()
        self.refresh_devices()

        self.left = self.sidebar

        # Grid
        self.delegate = ThumbDelegate(setting("thumb_size", 160, int))
        self.grid = ThumbGrid()
        self.grid.setModel(self.model)
        self.grid.setItemDelegate(self.delegate)
        self.grid.setGridSize(self.delegate.cell())
        self.grid.activated.connect(lambda _i: self.view_current())
        self.grid.selectionModel().selectionChanged.connect(lambda *_: self._selection_changed())
        self.grid.selectionModel().currentChanged.connect(lambda *_: self._selection_changed())
        self.grid.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.grid.customContextMenuRequested.connect(self._grid_menu)

        self.preview = PreviewPane()
        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidget(self.preview)
        self.preview_scroll.setWidgetResizable(True)
        self.preview_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.main_split = QSplitter()
        self.main_split.addWidget(self.left)
        self.main_split.addWidget(self.grid)
        self.main_split.addWidget(self.preview_scroll)
        self.main_split.setStretchFactor(1, 1)
        self.main_split.setSizes([270, 830, 300])
        self.setCentralWidget(self.main_split)

        self.status_left = QLabel()
        self.status_right = QLabel()
        self.statusBar().addWidget(self.status_left, 1)
        self.statusBar().addPermanentWidget(self.status_right)

    def _section(self, title):
        it = QTreeWidgetItem([title])
        f = it.font(0)
        f.setBold(True)
        f.setPointSizeF(max(6.0, f.pointSizeF() * 0.8))
        it.setFont(0, f)
        it.setForeground(0, QColor(THEME["muted"]))
        it.setFlags(Qt.ItemFlag.ItemIsEnabled)
        self.sidebar.addTopLevelItem(it)
        it.setExpanded(True)
        return it

    def act(self, text, slot, shortcut=None, icon_names=None, fallback=None,
            scoped=False, checkable=False, tip=None):
        a = QAction(text, self)
        if icon_names or fallback is not None:
            a.setIcon(icon(icon_names or "", fallback))
        if shortcut:
            seqs = shortcut if isinstance(shortcut, (list, tuple)) else [shortcut]
            a.setShortcuts([QKeySequence(s) for s in seqs])
        if tip:
            a.setToolTip(tip)
        a.setCheckable(checkable)
        if checkable:
            a.toggled.connect(slot)
        else:
            a.triggered.connect(lambda _=False: slot())
        if scoped:  # only while the thumbnail grid has focus (keeps typing in boxes working)
            a.setShortcutContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            self.grid.addAction(a)
        else:
            self.addAction(a)
        return a

    def _build_actions(self):
        A = self.act
        self.a_back = A("Back", self.go_back, "Alt+Left", "go-previous", SP.SP_ArrowBack)
        self.a_fwd = A("Forward", self.go_forward, "Alt+Right", "go-next", SP.SP_ArrowForward)
        self.a_up = A("Up", self.go_up, "Alt+Up", "go-up", SP.SP_ArrowUp,
                      tip="Parent folder (Backspace)")
        self.a_parent_bs = A("Parent folder", self.go_up, "Backspace", scoped=True)
        self.a_refresh = A("Refresh", self.reload, "Ctrl+R", "view-refresh", SP.SP_BrowserReload)
        self.a_home = A("Home", lambda: self.navigate(os.path.expanduser("~")), "Alt+Home",
                        "go-home", SP.SP_DirHomeIcon)
        self.a_open = A("Open folder…", self.open_folder_dialog, "Ctrl+O", "folder-open",
                        SP.SP_DirOpenIcon)
        self.a_fav = A("Add to favourites", self.toggle_favourite, "Ctrl+D",
                       "starred bookmark-new", tip="Add / remove favourite (Ctrl+D)")
        self.a_view = A("View", self.view_current, None, "zoom-fit-best image-x-generic",
                        SP.SP_FileDialogContentsView)
        self.a_slideshow = A("Slideshow", self.slideshow, "F5",
                             "media-playback-start view-presentation", SP.SP_MediaPlay)
        self.a_edit = A("Edit…", self.edit_current, "Ctrl+E", "document-edit image-edit",
                        scoped=True)
        self.a_rot_l = A("Rotate left", lambda: self.rotate_selected(-90), "Ctrl+[",
                         "object-rotate-left", scoped=True)
        self.a_rot_r = A("Rotate right", lambda: self.rotate_selected(90), "Ctrl+]",
                         "object-rotate-right", scoped=True)
        self.a_rename = A("Rename…", self.rename_selected, "F2", "edit-rename", scoped=True)
        self.a_batch = A("Batch rename…", self.batch_rename, None, "edit-rename")
        self.a_copy_to = A("Copy to folder…", lambda: self.transfer(False), "Ctrl+Shift+C",
                           "edit-copy", scoped=True)
        self.a_move_to = A("Move to folder…", lambda: self.transfer(True), "Ctrl+Shift+M",
                           "go-jump", scoped=True)
        self.a_delete = A("Move to Trash", self.delete_selected, "Delete", "user-trash edit-delete",
                          SP.SP_TrashIcon, scoped=True)
        self.a_copy_img = A("Copy image", self.copy_image, "Ctrl+C", "edit-copy", scoped=True)
        self.a_copy_path = A("Copy path", self.copy_path, "Ctrl+Shift+P", None)
        self.a_select_all = A("Select all", self.grid.selectAll, "Ctrl+A", "edit-select-all",
                              scoped=True)
        self.a_wallpaper = A("Set as wallpaper", self.wallpaper, None, "preferences-desktop-wallpaper")
        self.a_open_with = A("Open with default app", self.open_external, None,
                             "document-open", SP.SP_DialogOpenButton)
        self.a_show_folder = A("Open folder in file manager", self.show_in_files, None,
                               "system-file-manager folder")
        self.a_settings = A("Settings…", self.open_settings, "Ctrl+,", "preferences-system",
                            SP.SP_FileDialogDetailedView)
        self.a_bigger = A("Bigger thumbnails", lambda: self.step_thumbs(+32),
                          ["Ctrl++", "Ctrl+="], "zoom-in")
        self.a_smaller = A("Smaller thumbnails", lambda: self.step_thumbs(-32), "Ctrl+-",
                           "zoom-out")
        self.a_filter = A("Filter by name", lambda: (self.filter_box.setFocus(),
                                                     self.filter_box.selectAll()), "Ctrl+F")
        self.a_preview = A("Preview pane", lambda on: (self.preview_scroll.setVisible(on),
                                                       self.preview_timer.start(50)),
                           "F9", checkable=True)
        self.a_sidebar = A("Sidebar", self.left.setVisible, "Ctrl+B", checkable=True)
        self.a_install = A(f"Add {APP} to the app menu", self.install, None, "list-add")
        self.a_shortcuts = A("Keyboard shortcuts", self.show_shortcuts, "F1", "help-contents")
        self.a_about = A(f"About {APP}", self.about, None, "help-about")
        self.a_quit = A("Quit", self.close, "Ctrl+Q", "application-exit")

    def _build_menus_and_toolbar(self):
        mb = self.menuBar()
        m = mb.addMenu("&File")
        for a in (self.a_open, self.a_home, self.a_refresh, None, self.a_open_with,
                  self.a_show_folder, None, self.a_settings, None, self.a_quit):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Edit")
        for a in (self.a_select_all, self.a_copy_img, self.a_copy_path, None, self.a_rename,
                  self.a_batch, self.a_copy_to, self.a_move_to, None, self.a_delete):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&View")
        for a in (self.a_view, self.a_slideshow, None, self.a_bigger, self.a_smaller,
                  self.a_filter, None, self.a_preview, self.a_sidebar):
            m.addSeparator() if a is None else m.addAction(a)
        sort_menu = m.addMenu("Sort by")
        self.sort_actions = {}
        for key, label in (("name", "Name"), ("taken", "Date taken (photo info)"),
                           ("date", "Date modified (file)"), ("size", "Size"), ("type", "Type")):
            a = sort_menu.addAction(label)
            a.setCheckable(True)
            a.triggered.connect(lambda _=False, k=key: self.set_sort(k, self.model.sort_desc))
            self.sort_actions[key] = a
        sort_menu.addSeparator()
        self.a_desc = sort_menu.addAction("Descending")
        self.a_desc.setCheckable(True)
        self.a_desc.triggered.connect(lambda on: self.set_sort(self.model.sort_key, on))
        m = mb.addMenu("&Image")
        for a in (self.a_edit, self.a_rot_l, self.a_rot_r, None, self.a_wallpaper):
            m.addSeparator() if a is None else m.addAction(a)
        self.fav_menu = mb.addMenu("F&avourites")
        self.fav_menu.aboutToShow.connect(self._fill_fav_menu)
        m = mb.addMenu("&Help")
        for a in (self.a_shortcuts, self.a_install, None, self.a_about):
            m.addSeparator() if a is None else m.addAction(a)

        tb = self.addToolBar("Main")
        tb.setObjectName("main_toolbar")
        tb.setMovable(False)
        tb.setIconSize(QSize(20, 20))
        for a in (self.a_back, self.a_fwd, self.a_up, self.a_home):
            tb.addAction(a)
        self.address = QLineEdit()
        self.address.setPlaceholderText("Folder path")
        self.address.returnPressed.connect(lambda: self.navigate(self.address.text()))
        self.address.setMinimumWidth(260)
        tb.addWidget(self.address)
        tb.addAction(self.a_fav)
        tb.addSeparator()
        self.filter_box = QLineEdit()
        self.filter_box.setPlaceholderText("Filter…")
        self.filter_box.setClearButtonEnabled(True)
        self.filter_box.setFixedWidth(170)
        self.filter_box.textChanged.connect(self._filter_changed)
        tb.addWidget(self.filter_box)
        self.sort_box = QComboBox()
        self.sort_keys = ["name", "taken", "date", "size", "type"]
        self.sort_box.addItems(["Name", "Date taken", "Date modified", "Size", "Type"])
        self.sort_box.setItemData(1, "From the photo's own information (EXIF); files "
                                     "without it use their file date",
                                  Qt.ItemDataRole.ToolTipRole)
        self.sort_box.setToolTip("Sort by")
        self.sort_box.activated.connect(
            lambda i: self.set_sort(self.sort_keys[i], self.model.sort_desc))
        tb.addWidget(self.sort_box)
        self.order_btn = QPushButton()
        self.order_btn.setToolTip("Ascending / descending")
        self.order_btn.setFixedWidth(36)
        self.order_btn.clicked.connect(
            lambda: self.set_sort(self.model.sort_key, not self.model.sort_desc))
        tb.addWidget(self.order_btn)
        tb.addSeparator()
        self.size_slider = QSlider(Qt.Orientation.Horizontal)
        self.size_slider.setRange(96, 256)
        self.size_slider.setSingleStep(16)
        self.size_slider.setPageStep(32)
        self.size_slider.setValue(self.delegate.size)
        self.size_slider.setFixedWidth(120)
        self.size_slider.setToolTip("Thumbnail size")
        self.size_slider.valueChanged.connect(self.set_thumb_size)
        tb.addWidget(self.size_slider)
        tb.addSeparator()
        for a in (self.a_slideshow, self.a_edit, self.a_rot_l, self.a_rot_r, self.a_delete):
            tb.addAction(a)
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)
        tb.addAction(self.a_settings)
        self._sync_sort_ui()

    def _restore_layout(self):
        s = settings()
        geo = s.value("geometry")
        if geo is not None:
            self.restoreGeometry(geo)
        state = s.value("split_main")
        if state is not None:
            self.main_split.restoreState(state)
        self.a_preview.setChecked(setting("show_preview", True, bool))
        self.a_sidebar.setChecked(setting("show_sidebar", True, bool))
        self.preview_scroll.setVisible(self.a_preview.isChecked())
        self.left.setVisible(self.a_sidebar.isChecked())

    def closeEvent(self, e):
        s = settings()
        s.setValue("geometry", self.saveGeometry())
        s.setValue("split_main", self.main_split.saveState())
        s.setValue("show_preview", self.a_preview.isChecked())
        s.setValue("show_sidebar", self.a_sidebar.isChecked())
        s.setValue("thumb_size", self.delegate.size)
        if self.folder:
            s.setValue("last_folder", self.folder)
        if self.viewer is not None:
            self.viewer.close()
        super().closeEvent(e)

    # ------------------------------------------------------------------ navigation
    def navigate(self, path, record=True, keep=None):
        path = os.path.abspath(os.path.expanduser(path.strip()))
        if not os.path.isdir(path):
            QMessageBox.warning(self, APP, f"Folder not found:\n{path}")
            self.address.setText(self.folder or "")
            return
        if record and path != self.folder:
            del self.history[self.hpos + 1:]
            self.history.append(path)
            self.hpos = len(self.history) - 1
        if self.watcher.directories():
            self.watcher.removePaths(self.watcher.directories())
        self.watcher.addPath(path)
        self.folder = path
        self.address.setText(path)
        self.model.load(path)
        self.grid.empty_text = (f"Can't open this folder: {self.model.error}" if self.model.error
                                else "No images in this folder")
        self.sync_sidebar()
        self.setWindowTitle(f"{os.path.basename(path) or path} — {APP} {VERSION}")
        self.a_back.setEnabled(self.hpos > 0)
        self.a_fwd.setEnabled(self.hpos < len(self.history) - 1)
        self._update_fav_button()
        if keep and keep in self.model.row_of:
            self.select_path(keep)
        elif self.model.items:
            self.grid.setCurrentIndex(self.model.index(0))
        self.grid.scrollTo(self.grid.currentIndex())
        self._selection_changed()

    def reload(self):
        if self.folder and os.path.isdir(self.folder):
            current = self.current_path()
            selected = set(self.selected_paths())
            self.navigate(self.folder, record=False, keep=current)
            sm = self.grid.selectionModel()
            for p in selected:
                row = self.model.row_of.get(p)
                if row is not None:
                    sm.select(self.model.index(row), sm.SelectionFlag.Select)
        elif self.folder:
            self.go_up()


    def go_back(self):
        if self.hpos > 0:
            self.hpos -= 1
            self.navigate(self.history[self.hpos], record=False)

    def go_forward(self):
        if self.hpos < len(self.history) - 1:
            self.hpos += 1
            self.navigate(self.history[self.hpos], record=False)

    def go_up(self):
        if self.folder:
            parent = os.path.dirname(self.folder.rstrip("/")) or "/"
            while not os.path.isdir(parent) and parent != "/":
                parent = os.path.dirname(parent)
            self.navigate(parent, keep=None)

    def open_folder_dialog(self):
        d = QFileDialog.getExistingDirectory(self, "Open folder", self.folder or "")
        if d:
            self.navigate(d)

    # ------------------------------------------------------------------ sidebar
    def refresh_favourites(self):
        self.sec_fav.takeChildren()
        favs = setting("favourites", [], list)
        if not favs:
            favs = [os.path.expanduser("~")]
            pics = os.path.expanduser("~/Pictures")
            if os.path.isdir(pics):
                favs.append(pics)
            settings().setValue("favourites", favs)
        self.sidebar.blockSignals(True)
        for p in favs:
            if p == os.path.expanduser("~"):
                ic = icon("user-home", SP.SP_DirHomeIcon)
            else:
                ic = icon("folder-pictures folder" if "Pictures" in p else "folder", SP.SP_DirIcon)
            it = QTreeWidgetItem([self.fav_label(p)])
            it.setIcon(0, ic)
            it.setToolTip(0, p)
            it.setData(0, Qt.ItemDataRole.UserRole, ("fav", p))
            it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
                        | Qt.ItemFlag.ItemIsEditable)
            self.sec_fav.addChild(it)
        self.sidebar.blockSignals(False)
        if self.folder:
            self.sync_sidebar()
        if hasattr(self, "a_fav"):
            self._update_fav_button()

    def refresh_devices(self):
        devs = list_devices()
        if devs == self._devices_sig:
            return
        self._devices_sig = devs
        self.sec_dev.takeChildren()
        icons = {"hd": icon("drive-harddisk", SP.SP_DriveHDIcon),
                 "net": icon("folder-remote network-server", SP.SP_DriveNetIcon),
                 "home": icon("user-home", SP.SP_DirHomeIcon)}
        for label, path, kind in devs:
            if kind == "hd" and path.startswith(("/media/", "/run/media/")):
                ic = icon("drive-removable-media media-removable", SP.SP_DriveHDIcon)
            else:
                ic = icons[kind]
            it = QTreeWidgetItem([label])
            it.setIcon(0, ic)
            it.setToolTip(0, path)
            it.setData(0, Qt.ItemDataRole.UserRole, ("dev", path))
            self._add_placeholder(it)
            self.sec_dev.addChild(it)
        if self.folder:
            self.sync_sidebar()

    # -- lazy folder tree under each device
    def _add_placeholder(self, item):
        ph = QTreeWidgetItem([""])
        ph.setData(0, Qt.ItemDataRole.UserRole, ("placeholder", ""))
        ph.setFlags(Qt.ItemFlag.NoItemFlags)
        item.addChild(ph)

    def _populate(self, item):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data or data[0] not in ("dev", "dir") or item.childCount() != 1:
            return
        first = item.child(0).data(0, Qt.ItemDataRole.UserRole)
        if not first or first[0] != "placeholder":
            return
        item.takeChildren()
        try:
            with os.scandir(data[1]) as it:
                subs = []
                for e in it:
                    try:
                        if not e.name.startswith(".") and e.is_dir():
                            subs.append(e)
                    except OSError:
                        pass
        except OSError:
            subs = []
        folder_icon = icon("folder", SP.SP_DirIcon)
        for e in sorted(subs, key=lambda e: natural_key(e.name))[:3000]:
            child = QTreeWidgetItem([e.name])
            child.setIcon(0, folder_icon)
            child.setToolTip(0, e.path)
            child.setData(0, Qt.ItemDataRole.UserRole, ("dir", e.path))
            self._add_placeholder(child)
            item.addChild(child)

    def sync_sidebar(self):
        """Expand the device tree down to the current folder and highlight it."""
        path = self.folder
        best, best_root = None, ""
        for i in range(self.sec_dev.childCount()):
            it = self.sec_dev.child(i)
            root = it.data(0, Qt.ItemDataRole.UserRole)[1]
            inside = path == root or path.startswith(root.rstrip("/") + "/")
            if inside and len(root) > len(best_root):
                best, best_root = it, root
        if best is None:
            self.sidebar.clearSelection()
            return
        item = best
        rel = os.path.relpath(path, best_root)
        for part in ([] if rel == "." else rel.split(os.sep)):
            self.sidebar.expandItem(item)  # fills in its subfolders
            nxt = None
            for i in range(item.childCount()):
                c = item.child(i)
                d = c.data(0, Qt.ItemDataRole.UserRole)
                if d and d[0] == "dir" and os.path.basename(d[1]) == part:
                    nxt = c
                    break
            if nxt is None:  # hidden or unreadable folder: stop at the closest parent
                break
            item = nxt
        self.sidebar.setCurrentItem(item)
        self.sidebar.scrollToItem(item)

    def _sidebar_clicked(self, item, _col):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if data and data[0] != "placeholder":
            self.navigate(data[1])

    def _sidebar_menu(self, pos):
        item = self.sidebar.itemAt(pos)
        data = item.data(0, Qt.ItemDataRole.UserRole) if item else None
        if not data or data[0] == "placeholder":
            return
        kind, path = data
        m = QMenu(self)
        menu_add(m, "Open", lambda: self.navigate(path))
        menu_add(m, "Open in file manager",
                 lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(path)))
        if kind == "fav":
            favs = setting("favourites", [], list)
            i = favs.index(path) if path in favs else -1
            m.addSeparator()
            up = menu_add(m, "Move up", lambda: self._move_fav(i, -1))
            up.setEnabled(i > 0)
            down = menu_add(m, "Move down", lambda: self._move_fav(i, 1))
            down.setEnabled(0 <= i < len(favs) - 1)
            menu_add(m, "Rename…\tF2", lambda: self.rename_favourite(path))
            if path in self.fav_names():
                menu_add(m, "Restore original name", lambda: (self.set_fav_name(path, ""),
                                                              self.refresh_favourites()))
            menu_add(m, "Remove from favourites", lambda: self.remove_favourite(path))
        elif kind in ("dev", "dir"):
            menu_add(m, "Add to favourites", lambda: self.add_favourite(path))
        m.exec(self.sidebar.viewport().mapToGlobal(pos))

    def _move_fav(self, i, d):
        favs = setting("favourites", [], list)
        if 0 <= i < len(favs) and 0 <= i + d < len(favs):
            favs[i], favs[i + d] = favs[i + d], favs[i]
            settings().setValue("favourites", favs)
            self.refresh_favourites()

    def add_favourite(self, path):
        favs = setting("favourites", [], list)
        if path not in favs:
            favs.append(path)
            settings().setValue("favourites", favs)
            self.refresh_favourites()
            self.statusBar().showMessage(f"Added “{os.path.basename(path) or path}” to favourites",
                                         3000)

    # -- favourite names (stored separately; the folder itself is never renamed)
    def fav_names(self):
        try:
            names = json.loads(setting("fav_names", "{}", str) or "{}")
            return names if isinstance(names, dict) else {}
        except ValueError:
            return {}

    @staticmethod
    def default_fav_label(path):
        if path == os.path.expanduser("~"):
            return "Home"
        return os.path.basename(path.rstrip("/")) or path

    def fav_label(self, path):
        return self.fav_names().get(path) or self.default_fav_label(path)

    def set_fav_name(self, path, name):
        names = self.fav_names()
        name = (name or "").strip()
        if not name or name == self.default_fav_label(path):
            names.pop(path, None)
        else:
            names[path] = name
        settings().setValue("fav_names", json.dumps(names))

    def rename_favourite(self, path):
        for i in range(self.sec_fav.childCount()):
            it = self.sec_fav.child(i)
            if it.data(0, Qt.ItemDataRole.UserRole) == ("fav", path):
                self.sidebar.setCurrentItem(it)
                self.sidebar.editItem(it, 0)  # type the new name, Enter to save
                return

    def _sidebar_item_changed(self, item, _col):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data or data[0] != "fav":
            return
        path = data[1]
        if item.text(0).strip() != self.fav_label(path):
            self.set_fav_name(path, item.text(0))
            QTimer.singleShot(0, self.refresh_favourites)  # shows the default if left empty

    def remove_favourite(self, path):
        favs = [f for f in setting("favourites", [], list) if f != path]
        settings().setValue("favourites", favs)
        self.set_fav_name(path, "")
        self.refresh_favourites()

    def toggle_favourite(self):
        if not self.folder:
            return
        if self.folder in setting("favourites", [], list):
            self.remove_favourite(self.folder)
        else:
            self.add_favourite(self.folder)

    def _update_fav_button(self):
        is_fav = self.folder in setting("favourites", [], list)
        self.a_fav.setIcon(icon("starred" if is_fav else "non-starred bookmark-new"))
        self.a_fav.setText("Remove from favourites" if is_fav else "Add to favourites")
        if self.a_fav.icon().isNull():
            self.a_fav.setText("★" if is_fav else "☆")

    def _fill_fav_menu(self):
        self.fav_menu.clear()
        self.fav_menu.addAction(self.a_fav)
        self.fav_menu.addSeparator()
        for p in setting("favourites", [], list):
            a = self.fav_menu.addAction(icon("folder", SP.SP_DirIcon), self.fav_label(p))
            a.setToolTip(p)
            a.triggered.connect(lambda _=False, p=p: self.navigate(p))

    # ------------------------------------------------------------------ grid helpers
    def current_entry(self):
        idx = self.grid.currentIndex()
        if idx.isValid() and idx.row() < len(self.model.items):
            return self.model.items[idx.row()]
        return None

    def current_path(self):
        e = self.current_entry()
        return e["path"] if e else None

    def selected_rows(self):
        rows = sorted(i.row() for i in self.grid.selectionModel().selectedIndexes())
        if not rows and self.grid.currentIndex().isValid():
            rows = [self.grid.currentIndex().row()]
        return [r for r in rows if r < len(self.model.items)]

    def selected_paths(self):
        return [self.model.items[r]["path"] for r in self.selected_rows()]

    def select_path(self, path):
        row = self.model.row_of.get(path)
        if row is not None:
            idx = self.model.index(row)
            self.grid.setCurrentIndex(idx)
            self.grid.scrollTo(idx)

    def _selection_changed(self):
        rows = self.selected_rows()
        n = len(self.model.items)
        total = len(self.model.all)
        shown = f"{n} of {total} images" if self.model.filter else f"{n} images"
        self.status_left.setText(f"{shown}  ·  {human_size(self.model.total_size())}"
                                 f"  ·  {self.folder or ''}")
        if len(rows) > 1:
            self.status_right.setText(f"{len(rows)} selected  ·  "
                                      f"{human_size(self.model.total_size(rows))}")
        elif rows:
            e = self.model.items[rows[0]]
            self.status_right.setText(f"{e['name']}  ·  {human_size(e['size'])}  ·  "
                                      f"{rows[0] + 1} / {n}")
        else:
            self.status_right.clear()
        has = bool(rows)
        for a in (self.a_edit, self.a_rot_l, self.a_rot_r, self.a_rename, self.a_delete,
                  self.a_copy_to, self.a_move_to, self.a_copy_img, self.a_copy_path,
                  self.a_wallpaper, self.a_open_with, self.a_view):
            a.setEnabled(has)
        self.a_batch.setEnabled(len(rows) > 1)
        self.a_slideshow.setEnabled(n > 0)
        self.preview_timer.start(120)

    def _load_preview(self):
        if not self.preview_scroll.isVisible():
            return
        e = self.current_entry()
        if not e:
            self.preview.clear("No image selected" if self.model.items else "")
            return
        self.preview.show_entry(e)
        QThreadPool.globalInstance().start(
            ImageJob(e["path"], self.preview_signals, max_edge=900, with_info=True), 10)

    def _preview_ready(self, path, image, info):
        e = self.current_entry()
        if e and e["path"] == path:
            self.preview.show_entry(e, image, info)

    def _filter_changed(self, text):
        keep = self.current_path()
        self.model.set_filter(text)
        if keep in self.model.row_of:
            self.select_path(keep)
        elif self.model.items:
            self.grid.setCurrentIndex(self.model.index(0))
        self._selection_changed()

    def set_sort(self, key, desc):
        keep = self.current_path()
        self.model.set_sort(key, desc)
        settings().setValue("sort_key", key)
        settings().setValue("sort_desc", desc)
        self._sync_sort_ui()
        if keep:
            self.select_path(keep)
        self._selection_changed()

    def _date_progress(self, done, total):
        if done < total and self.model.sort_key == "taken":
            self.statusBar().showMessage(f"Reading photo dates… {done} / {total}")

    def _dates_finished(self):
        self.statusBar().clearMessage()
        if self.model.sort_key != "taken":
            return
        keep = self.current_path()
        selected = set(self.selected_paths())
        self.model.set_sort("taken", self.model.sort_desc)
        if keep:
            self.select_path(keep)
        sm = self.grid.selectionModel()
        for p in selected:
            row = self.model.row_of.get(p)
            if row is not None:
                sm.select(self.model.index(row), sm.SelectionFlag.Select)
        self._selection_changed()

    def _sync_sort_ui(self):
        key, desc = self.model.sort_key, self.model.sort_desc
        self.sort_box.setCurrentIndex(self.sort_keys.index(key))
        for k, a in self.sort_actions.items():
            a.setChecked(k == key)
        self.a_desc.setChecked(desc)
        ic = icon("view-sort-descending" if desc else "view-sort-ascending")
        self.order_btn.setIcon(ic)
        self.order_btn.setText("" if not ic.isNull() else ("↓" if desc else "↑"))

    def set_thumb_size(self, v):
        v = max(96, min(256, int(round(v / 16.0) * 16)))
        self.delegate.size = v
        self.grid.setGridSize(self.delegate.cell())
        self.grid.doItemsLayout()
        self.grid.viewport().update()

    def step_thumbs(self, d):
        self.size_slider.setValue(self.delegate.size + d)

    # ------------------------------------------------------------------ viewer
    def view_current(self, slideshow=False):
        files = self.model.paths()
        if not files:
            return
        row = max(0, self.grid.currentIndex().row())
        if self.viewer is not None:
            self.viewer.close()
        self.viewer = Viewer(files, row, slideshow=slideshow)
        self.viewer.closed.connect(self._viewer_closed)
        self.viewer.changed.connect(lambda: self.reload_timer.start(300))
        if slideshow or setting("viewer_fullscreen", False, bool):
            self.viewer.showFullScreen()
        else:
            self.viewer.showMaximized()

    def slideshow(self):
        self.view_current(slideshow=True)

    def _viewer_closed(self, path):
        self.viewer = None
        self.reload()
        if path:
            self.select_path(path)
        self.activateWindow()
        self.grid.setFocus()

    # ------------------------------------------------------------------ file operations
    def edit_current(self):
        path = self.current_path()
        if not path:
            return
        dlg = EditorDialog(path, self)
        dlg.saved.connect(lambda p: (self.reload(), self.select_path(p)))
        dlg.exec()

    def rotate_selected(self, degrees):
        paths = self.selected_paths()
        failed = [p for p in paths if not rotate_file(p, degrees)]
        self.reload()
        if failed:
            QMessageBox.warning(self, "Rotate", f"Could not rotate {len(failed)} file(s) "
                                                "(read-only or unsupported format).")

    def rename_selected(self):
        rows = self.selected_rows()
        if len(rows) > 1:
            self.batch_rename()
            return
        if not rows:
            return
        e = self.model.items[rows[0]]
        name, ok = QInputDialog.getText(self, "Rename", "New name:", text=e["name"])
        name = name.strip()
        if not ok or not name or name == e["name"]:
            return
        if "/" in name:
            QMessageBox.warning(self, "Rename", "Names can't contain “/”.")
            return
        dest = os.path.join(os.path.dirname(e["path"]), name)
        if os.path.exists(dest):
            QMessageBox.warning(self, "Rename", f"“{name}” already exists.")
            return
        try:
            os.rename(e["path"], dest)
        except OSError as err:
            QMessageBox.warning(self, "Rename", str(err))
            return
        self.reload()
        self.select_path(dest)

    def batch_rename(self):
        rows = self.selected_rows()
        if len(rows) < 2:
            return
        entries = [self.model.items[r] for r in rows]
        dlg = BatchRenameDialog(entries, self)
        if not dlg.exec():
            return
        names = dlg.new_names()
        folder = self.folder
        olds = {e["path"] for e in entries}
        clashes = [n for n in names if os.path.exists(os.path.join(folder, n))
                   and os.path.join(folder, n) not in olds]
        if clashes:
            QMessageBox.warning(self, "Batch rename",
                                f"{len(clashes)} new name(s) already exist, e.g. “{clashes[0]}”.")
            return
        temps = []
        try:
            for i, e in enumerate(entries):  # two steps so names can swap safely
                tmp = os.path.join(folder, f".hansviewer-rename-{os.getpid()}-{i}")
                os.rename(e["path"], tmp)
                temps.append((tmp, os.path.join(folder, names[i]), e["path"]))
            for tmp, dest, _orig in temps:
                os.rename(tmp, dest)
        except OSError as err:
            for tmp, _dest, orig in temps:
                if os.path.exists(tmp):
                    os.rename(tmp, orig)
            QMessageBox.warning(self, "Batch rename", str(err))
        self.reload()

    def transfer(self, move):
        paths = self.selected_paths()
        if not paths:
            return
        dest = QFileDialog.getExistingDirectory(self, "Move to folder" if move else "Copy to folder",
                                                setting("last_transfer", self.folder or "", str))
        if not dest:
            return
        settings().setValue("last_transfer", dest)
        prog = QProgressDialog("Moving files…" if move else "Copying files…", "Cancel",
                               0, len(paths), self)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(400)
        errors = []
        for i, p in enumerate(paths):
            prog.setValue(i)
            if prog.wasCanceled():
                break
            target = unique_path(dest, os.path.basename(p))
            try:
                shutil.move(p, target) if move else shutil.copy2(p, target)
            except OSError as err:
                errors.append(f"{os.path.basename(p)}: {err.strerror or err}")
        prog.setValue(len(paths))
        self.reload()
        verb = "Moved" if move else "Copied"
        done = len(paths) - len(errors)
        self.statusBar().showMessage(f"{verb} {done} file(s) to {dest}", 5000)
        if errors:
            QMessageBox.warning(self, verb, "Some files failed:\n" + "\n".join(errors[:10]))

    def delete_selected(self):
        paths = self.selected_paths()
        if not paths:
            return
        if setting("confirm_delete", True, bool):
            what = f"“{os.path.basename(paths[0])}”" if len(paths) == 1 else f"{len(paths)} files"
            ans = QMessageBox.question(self, "Move to Trash", f"Move {what} to the Trash?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        rows = self.selected_rows()
        next_row = rows[0] if rows else 0
        failed = [p for p in paths if not move_to_trash(p)]
        self.navigate(self.folder, record=False)
        if self.model.items:
            idx = self.model.index(min(next_row, len(self.model.items) - 1))
            self.grid.setCurrentIndex(idx)
        if failed:
            QMessageBox.warning(self, "Move to Trash", f"Could not move {len(failed)} file(s).")

    def copy_image(self):
        path = self.current_path()
        if path:
            img = read_image(path)
            if not img.isNull():
                QApplication.clipboard().setImage(img)
                self.statusBar().showMessage("Image copied", 2000)

    def copy_path(self):
        paths = self.selected_paths()
        if paths:
            QApplication.clipboard().setText("\n".join(paths))
            self.statusBar().showMessage("Path copied", 2000)

    def wallpaper(self):
        path = self.current_path()
        if path:
            ok = set_wallpaper(path)
            self.statusBar().showMessage("Wallpaper set" if ok else
                                         "Couldn't set the wallpaper on this desktop", 4000)

    def open_external(self):
        path = self.current_path()
        if path:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def show_in_files(self):
        if self.folder:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.folder))

    def _grid_menu(self, pos):
        idx = self.grid.indexAt(pos)
        if idx.isValid() and not self.grid.selectionModel().isSelected(idx):
            self.grid.setCurrentIndex(idx)
        m = QMenu(self)
        if idx.isValid():
            for a in (self.a_view, self.a_edit, None, self.a_rot_l, self.a_rot_r, None,
                      self.a_rename, self.a_batch, self.a_copy_to, self.a_move_to, None,
                      self.a_copy_img, self.a_copy_path, self.a_open_with, self.a_wallpaper,
                      None, self.a_delete):
                m.addSeparator() if a is None else m.addAction(a)
        else:
            for a in (self.a_select_all, self.a_refresh, self.a_slideshow, self.a_fav,
                      self.a_show_folder):
                m.addAction(a)
        m.exec(self.grid.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------------ misc
    def open_settings(self):
        dlg = SettingsDialog(self)
        if dlg.exec():
            dlg.save()
            apply_theme(QApplication.instance(), setting("theme", "dark"))
            self.sec_fav.setForeground(0, QColor(THEME["muted"]))
            self.sec_dev.setForeground(0, QColor(THEME["muted"]))
            self.model.use_cache = setting("disk_cache", True, bool)
            self.grid.viewport().update()

    def install(self):
        if SYSTEM_INSTALL:
            QMessageBox.information(self, APP, f"{APP} was installed from its package and is "
                                               "already in your app menu for all users.")
            return
        try:
            target = install_desktop_entry()
        except OSError as err:
            QMessageBox.warning(self, APP, f"Could not install: {err}")
            return
        QMessageBox.information(self, APP, f"{APP} is now in your app menu (Graphics).\n\n"
                                           f"The program was copied to:\n{target}\n\n"
                                           "You can also pick it under “Open With” for images.")

    def show_shortcuts(self):
        box = QMessageBox(self)
        box.setWindowTitle("Keyboard shortcuts")
        box.setTextFormat(Qt.TextFormat.RichText)
        box.setText(SHORTCUTS_HTML)
        box.exec()

    def about(self):
        extras = []
        extras.append("numpy ✓" if np is not None else "numpy ✗ (adjustments off)")
        extras.append("Pillow ✓" if PILImage is not None else "Pillow ✗ (no EXIF)")
        QMessageBox.about(self, f"About {APP}",
                          f"<h3>{APP} {VERSION}</h3><p>A fast image browser, viewer and editor "
                          "for Linux.</p>"
                          f"<p>{' · '.join(extras)}</p>")


# ======================================================================= main
def main():
    if "--install" in sys.argv:
        if SYSTEM_INSTALL:
            print(f"{APP} is installed from its package; nothing to do.")
            return
        target = install_desktop_entry()
        print(f"Installed. {APP} is in your app menu; program copied to {target}")
        return
    QApplication.setApplicationName(APP)
    app = QApplication(sys.argv)
    app.setDesktopFileName(APP_ID)
    setup_icon_theme()
    apply_theme(app, setting("theme", "dark"))
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if args:
        start = args[0]
    else:
        start = setting("last_folder", "", str) or os.path.expanduser("~/Pictures")
    if not os.path.exists(os.path.expanduser(start)):
        start = os.path.expanduser("~")
    win = Browser(start)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
