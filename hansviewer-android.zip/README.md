# HansViewer

Photo browser, viewer and editor — for Linux (`linux/`, Python + Qt 6) and Android (`android/`, Kotlin).

Upload the zip of this folder to the GitHub repository; the "Build" workflow unpacks it,
runs `build.sh`, and publishes `HansViewer.apk` and `hansviewer_<version>_all.deb` as a release.
