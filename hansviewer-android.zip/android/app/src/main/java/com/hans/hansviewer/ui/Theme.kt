package com.hans.hansviewer.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Same palette as the desktop HansViewer
private val Dark = darkColorScheme(
    primary = Color(0xFF4C8DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF233A66),
    onPrimaryContainer = Color(0xFFDCE6FF),
    secondaryContainer = Color(0xFF2C3A55),
    onSecondaryContainer = Color(0xFFE8EAED),
    background = Color(0xFF17181B),
    onBackground = Color(0xFFE8EAED),
    surface = Color(0xFF1F2125),
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = Color(0xFF2A2D32),
    onSurfaceVariant = Color(0xFF9AA0A8),
    surfaceContainerLowest = Color(0xFF121316),
    surfaceContainerLow = Color(0xFF1C1E22),
    surfaceContainer = Color(0xFF24272C),
    surfaceContainerHigh = Color(0xFF2D3138),
    surfaceContainerHighest = Color(0xFF353941),
    outline = Color(0xFF3A3E45),
    outlineVariant = Color(0xFF2F3237),
    error = Color(0xFFFF6B6B),
)

private val Light = lightColorScheme(
    primary = Color(0xFF2F6FED),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6FF),
    onPrimaryContainer = Color(0xFF0D2B66),
    secondaryContainer = Color(0xFFDDE6F7),
    onSecondaryContainer = Color(0xFF1D2127),
    background = Color(0xFFEEF0F3),
    onBackground = Color(0xFF1D2127),
    surface = Color(0xFFFAFBFC),
    onSurface = Color(0xFF1D2127),
    surfaceVariant = Color(0xFFE4E8EE),
    onSurfaceVariant = Color(0xFF697180),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF5F6F8),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFF1F5FB),
    surfaceContainerHighest = Color(0xFFE7EBF1),
    outline = Color(0xFFC3C8D0),
    outlineVariant = Color(0xFFD9DDE3),
)

@Composable
fun HansTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
