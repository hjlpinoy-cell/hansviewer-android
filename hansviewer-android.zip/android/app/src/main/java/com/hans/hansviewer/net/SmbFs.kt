package com.hans.hansviewer.net

import android.net.Uri
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.mserref.NtStatus
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.mssmb2.SMBApiException
import com.hierynomus.security.bc.BCSecurityProvider
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import java.io.FilterInputStream
import java.io.InputStream
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.EnumSet
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Windows / NAS shares (SMB 2 and 3) for the home network. Paths start with the share name,
 * e.g. "/photo/2024/a.jpg" is the file "2024\a.jpg" on the share "photo".
 * One connection per server is kept open and reused.
 */
class SmbFs(server: Server, private val password: String?) : RemoteFs {
    private val host: String
    private val port: Int
    private val user = server.user
    private val domain = server.domain

    init {
        val u = Uri.parse(if (server.url.startsWith("smb://")) server.url else "smb://" + server.url)
        host = u.host ?: server.url.removePrefix("smb://").substringBefore('/').substringBefore(':')
        port = if (u.port > 0) u.port else 445
    }

    private val client = SMBClient(
        SmbConfig.builder()
            .withSecurityProvider(BCSecurityProvider())  // Android lacks some algorithms SMB needs
            .withTimeout(60, TimeUnit.SECONDS)
            .withSoTimeout(120, TimeUnit.SECONDS)
            .build()
    )
    @Volatile private var session: Session? = null
    private val shares = ConcurrentHashMap<String, DiskShare>()

    @Synchronized
    private fun session(): Session {
        session?.let { if (it.connection.isConnected) return it }
        shares.clear()
        val conn = try {
            client.connect(host, port)
        } catch (e: UnknownHostException) {
            throw NetError("“$host” was not found on the network")
        } catch (e: ConnectException) {
            throw NetError("“$host” does not answer (is SMB switched on, and are you on the same network?)")
        } catch (e: SocketTimeoutException) {
            throw NetError("“$host” does not answer")
        }
        val auth = if (user.isEmpty()) AuthenticationContext.guest()
        else AuthenticationContext(user, (password ?: "").toCharArray(), domain.ifEmpty { null })
        return translate { conn.authenticate(auth) }.also { session = it }
    }

    @Synchronized
    private fun share(name: String): DiskShare {
        shares[name]?.let { if (it.isConnected) return it }
        val s = translate { session().connectShare(name) }
        val disk = s as? DiskShare ?: throw NetError("“$name” is not a shared folder")
        shares[name] = disk
        return disk
    }

    /** "/photo/2024" → share "photo", path "2024" (SMB uses backslashes). */
    private fun split(path: String): Pair<String, String> {
        val parts = normPath(path).trim('/').split('/').filter { it.isNotEmpty() }
        if (parts.isEmpty()) throw NetError("Please add the share name to the server (for example “photo”)")
        return parts[0] to parts.drop(1).joinToString("\\")
    }

    private fun <T> translate(block: () -> T): T = try {
        block()
    } catch (e: SMBApiException) {
        throw NetError(
            when (e.status) {
                NtStatus.STATUS_LOGON_FAILURE ->
                    "The user name or password was not accepted"
                NtStatus.STATUS_ACCESS_DENIED -> "The NAS refused access to this folder"
                NtStatus.STATUS_BAD_NETWORK_NAME -> "There is no share with this name on the NAS"
                NtStatus.STATUS_OBJECT_NAME_NOT_FOUND, NtStatus.STATUS_OBJECT_PATH_NOT_FOUND ->
                    "This folder no longer exists on the NAS"
                else -> "The NAS answered: ${e.status}"
            }
        )
    }

    override fun list(path: String): List<RemoteEntry> {
        val (shareName, rel) = split(path)
        val base = normPath(path)
        val items = translate { share(shareName).list(rel) }
        val dirFlag = FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value
        return items.mapNotNull { f ->
            val name = f.fileName
            if (name == "." || name == "..") return@mapNotNull null
            RemoteEntry(
                name = name,
                path = normPath("$base/$name"),
                isDir = (f.fileAttributes and dirFlag) != 0L,
                size = f.endOfFile,
                modified = runCatching { f.lastWriteTime.toEpochMillis() }.getOrDefault(0L),
            )
        }
    }

    private fun openFile(path: String): com.hierynomus.smbj.share.File {
        val (shareName, rel) = split(path)
        return translate {
            share(shareName).openFile(
                rel, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL,
                SMB2CreateDisposition.FILE_OPEN, null,
            )
        }
    }

    override fun openStream(path: String): InputStream {
        val f = openFile(path)
        return object : FilterInputStream(f.inputStream) {
            override fun close() {
                runCatching { super.close() }
                runCatching { f.close() }
            }
        }
    }

    override fun openRange(path: String, offset: Long): InputStream {
        val f = openFile(path)
        return object : InputStream() {
            private var pos = offset
            private val one = ByteArray(1)
            override fun read(): Int = if (read(one, 0, 1) <= 0) -1 else one[0].toInt() and 0xff
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (len == 0) return 0
                val n = f.read(b, pos, off, minOf(len, 1 shl 20))
                if (n <= 0) return -1
                pos += n
                return n
            }
            override fun close() { runCatching { f.close() } }
        }
    }

    override fun readHead(path: String, max: Int): ByteArray {
        val f = openFile(path)
        try {
            val buf = ByteArray(max)
            var n = 0
            while (n < max) {
                val r = f.read(buf, n.toLong(), n, max - n)
                if (r <= 0) break
                n += r
            }
            return buf.copyOf(n)
        } finally {
            runCatching { f.close() }
        }
    }

    override fun close() {
        runCatching { session?.close() }
        runCatching { client.close() }
    }
}
