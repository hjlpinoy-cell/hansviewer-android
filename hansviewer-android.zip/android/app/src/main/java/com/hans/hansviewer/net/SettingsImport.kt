package com.hans.hansviewer.net

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.hans.hansviewer.Favourite
import com.hans.hansviewer.Prefs
import org.json.JSONArray
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Reads a settings file exported by HansViewer on Linux (File → Export settings):
 * WebDAV servers (with their passwords, if they were included), aliases, network favourites
 * and a few general settings. Folders on the Linux computer's own disks are skipped.
 */
object SettingsImport {
    class Parsed(val data: JSONObject) {
        val settings: JSONObject = data.getJSONObject("settings")
        val hasSecrets: Boolean = data.optString("secrets").isNotEmpty()
        val exported: String = data.optString("exported", "?")
        val computer: String = data.optString("computer", "?")
    }

    fun read(ctx: Context, uri: Uri): Parsed {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalArgumentException("Could not open the file")
        val o = JSONObject(text)
        if (o.optString("app") != "HansViewer" || o.optJSONObject("settings") == null) {
            throw IllegalArgumentException("This is not a HansViewer settings file")
        }
        return Parsed(o)
    }

    /** Same format as `openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -a` on Linux. */
    fun decrypt(b64: String, password: String): String {
        val raw = Base64.decode(b64, Base64.DEFAULT)
        require(raw.size > 16 && String(raw, 0, 8, Charsets.US_ASCII) == "Salted__") { "Unknown encryption" }
        val salt = raw.copyOfRange(8, 16)
        val spec = PBEKeySpec(password.toCharArray(), salt, 200_000, 48 * 8)
        val kb = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(kb.copyOfRange(0, 32), "AES"), IvParameterSpec(kb.copyOfRange(32, 48)))
        return String(c.doFinal(raw, 16, raw.size - 16), Charsets.UTF_8)
    }

    /** Checks the password. Returns the decrypted secrets, or null if the password is wrong. */
    fun unlock(p: Parsed, password: String): JSONObject? = runCatching {
        JSONObject(decrypt(p.data.getString("secrets"), password))
    }.getOrNull()

    private fun str(s: JSONObject, key: String): String? = s.opt(key)?.let { if (it == JSONObject.NULL) null else it.toString() }

    private fun jsonList(s: JSONObject, key: String): JSONArray? {
        val v = s.opt(key) ?: return null
        return when (v) {
            is JSONArray -> v
            is String -> runCatching { JSONArray(v) }.getOrNull()
            else -> null
        }
    }

    private fun jsonMap(s: JSONObject, key: String): JSONObject? {
        val v = s.opt(key) ?: return null
        return when (v) {
            is JSONObject -> v
            is String -> runCatching { JSONObject(v) }.getOrNull()
            else -> null
        }
    }

    private fun isIp(host: String) = host.matches(Regex("[0-9.]+")) || host.contains(':') && !host.contains('.')

    data class Result(val servers: Int, val passwords: Int, val favourites: Int)

    /** Applies the file. Servers that are already here (same address and folder) are updated. */
    fun apply(ctx: Context, prefs: Prefs, p: Parsed, secrets: JSONObject?): Result {
        RemoteRepo.init(ctx)
        val s = p.settings
        p.data.optJSONObject("android")?.let { android ->
            // a backup made by HansViewer on Android: brings back exactly that device's setup
            val (nS, nP, nF) = SettingsExport.restoreAndroid(prefs, android, secrets)
            applyGeneral(prefs, s)
            return Result(nS, nP, nF)
        }
        // ---- servers: only WebDAV ones exist on Android for now
        val existing = RemoteRepo.servers().toMutableList()
        val imported = mutableListOf<Pair<Server, JSONObject>>()
        jsonList(s, "servers")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val scheme = o.optString("scheme")
                if (scheme != "dav" && scheme != "davs" && scheme != "smb") continue
                val host = o.optString("host").trim()
                if (host.isEmpty()) continue
                val share = o.optString("share").trim('/')
                val rest = o.optString("rest").trim('/')
                if (scheme == "smb" && share.isEmpty()) continue  // a share name is needed on Android
                val root = normPath(listOf(share, rest).filter { it.isNotEmpty() }.joinToString("/"))
                val url = when (scheme) {
                    "smb" -> "smb://$host"
                    "davs" -> "https://$host"
                    else -> "http://$host"
                }
                val alias = o.optString("alias").ifEmpty {
                    o.optString("name").takeIf { n -> n.isNotEmpty() && n != host && n != "$share on $host" } ?: ""
                }
                val hostOnly = Uri.parse(url).host ?: host
                val old = existing.firstOrNull { it.url.trimEnd('/') == url && it.root == root }
                val srv = Server(
                    id = old?.id ?: RemoteRepo.newId(), alias = alias, url = url, root = root,
                    user = if (o.optBoolean("guest")) "" else o.optString("user"),
                    trustCert = old?.trustCert ?: (scheme == "davs" && isIp(hostOnly)),
                    type = if (scheme == "smb") TYPE_SMB else TYPE_WEBDAV,
                    domain = if (scheme == "smb") o.optString("domain") else "",
                )
                existing.removeAll { it.id == srv.id }
                existing += srv
                imported += srv to o
            }
        }
        RemoteRepo.saveServers(existing)
        // ---- passwords (only when the file's password was given)
        var pwCount = 0
        secrets?.optJSONArray("passwords")?.let { arr ->
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val u = Uri.parse(e.optString("uri"))
                val url = when (u.scheme) {
                    "smb" -> "smb://"
                    "davs" -> "https://"
                    else -> "http://"
                } + (u.encodedAuthority ?: "")
                val share = normPath(u.path ?: "/")
                val match = imported.firstOrNull { (srv, _) ->
                    srv.url == url && (share == "/" || srv.root == share || srv.root.startsWith("$share/")) &&
                        srv.user == e.optString("user")
                }?.first
                if (match != null) {
                    RemoteRepo.setPassword(match.id, e.optString("password"))
                    pwCount++
                }
            }
        }
        // ---- favourites on WebDAV shares: {RUNUSER}/gvfs/dav:host=H,port=P,ssl=true/path
        val favNames = jsonMap(s, "fav_names")
        val favs = prefs.favourites.toMutableList()
        var favCount = 0
        val re = Regex("""^\{RUNUSER\}/gvfs/davs?:host=([^,/]+)(?:,port=([0-9]+))?(,ssl=true)?(?:,[^/]*)?(/.*)?$""")
        val smbRe = Regex("""^\{RUNUSER\}/gvfs/smb-share:server=([^,/]+),share=([^,/]+)(?:,[^/]*)?(/.*)?$""")
        jsonList(s, "favourites")?.let { arr ->
            for (i in 0 until arr.length()) {
                val path = arr.optString(i)
                smbRe.matchEntire(path)?.let { sm ->
                    val (host, share, rest) = sm.destructured
                    val folder = normPath("/$share" + rest)
                    val srv = existing.filter { it.isSmb && it.url.trimEnd('/').equals("smb://$host", ignoreCase = true) }
                        .sortedByDescending { it.root.length }
                        .firstOrNull { folder == it.root || folder.startsWith(it.root.trimEnd('/') + "/") }
                    if (srv != null) {
                        val key = netKey(srv.id, folder)
                        if (favs.none { it.key == key }) {
                            favs += Favourite(key, favNames?.optString(path)?.ifEmpty { null })
                            favCount++
                        }
                    }
                }
                val m = re.matchEntire(path) ?: continue
                val (host, port, ssl, rest) = m.destructured
                val url = (if (ssl.isNotEmpty()) "https://" else "http://") + host + if (port.isNotEmpty()) ":$port" else ""
                val folder = normPath(rest)
                val srv = existing.filter { !it.isSmb && it.url.trimEnd('/') == url }
                    .sortedByDescending { it.root.length }
                    .firstOrNull { folder == it.root || folder.startsWith(it.root.trimEnd('/') + "/") || it.root == "/" }
                    ?: continue
                val key = netKey(srv.id, folder)
                if (favs.none { it.key == key }) {
                    favs += Favourite(key, favNames?.optString(path)?.ifEmpty { null })
                    favCount++
                }
            }
        }
        prefs.favourites = favs
        applyGeneral(prefs, s)
        return Result(imported.size, pwCount, favCount)
    }

    private fun applyGeneral(prefs: Prefs, s: JSONObject) {
        str(s, "slideshow_secs")?.toIntOrNull()?.let { prefs.slideshowSecs = it.coerceIn(1, 30) }
        str(s, "jpeg_quality")?.toIntOrNull()?.let { prefs.jpegQuality = it.coerceIn(50, 100) }
        str(s, "theme")?.let { if (it == "dark" || it == "light") prefs.theme = it }
        str(s, "confirm_delete")?.let { prefs.confirmDelete = it == "true" }
        str(s, "bright_full")?.let { prefs.brightView = it == "true" }
        str(s, "bright_level")?.toIntOrNull()?.let { prefs.brightLevel = it.coerceIn(10, 100) }
        str(s, "show_videos")?.let { prefs.showVideos = it == "true" }
        str(s, "video_download_first")?.let { prefs.videoDownloadFirst = it == "true" }
    }
}
