package com.hans.hansviewer.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.Photo
import com.hans.hansviewer.folderKey
import com.hans.hansviewer.keyRelPath
import com.hans.hansviewer.keyVolume

@Composable
fun TextInputDialog(
    title: String, initial: String, confirm: String = "OK",
    onDismiss: () -> Unit, onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun InfoDialog(title: String, rows: List<Pair<String, String>>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(rows) { (k, v) ->
                    Row {
                        Text(k, Modifier.width(110.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

/** "Photo ###" → Photo 001, Photo 002 … ; {name} = old name, {date} = date taken. */
fun batchNames(vm: AppViewModel, photos: List<Photo>, pattern: String, start: Int): List<String> {
    val multi = photos.size > 1 && '#' !in pattern && "{name}" !in pattern
    return photos.mapIndexed { i, p ->
        val n = start + i
        val stem = p.name.substringBeforeLast('.')
        var s = Regex("#+").replace(pattern) { m -> n.toString().padStart(m.value.length, '0') }
        s = s.replace("{name}", stem).replace("{date}", vm.dateText(p.takenOrModified))
        if (multi) s = "$s $n"
        s.trim() + if (p.ext.isNotEmpty()) "." + p.ext else ""
    }
}

@Composable
fun BatchRenameDialog(vm: AppViewModel, photos: List<Photo>, onDismiss: () -> Unit) {
    var pattern by remember { mutableStateOf("Photo ###") }
    var start by remember { mutableIntStateOf(1) }
    val names = batchNames(vm, photos, pattern, start)
    val valid = pattern.isNotBlank() && names.toSet().size == names.size && names.none { '/' in it }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename ${photos.size} photos") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(pattern, { pattern = it }, label = { Text("New name") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(start.toString(), { start = it.filter(Char::isDigit).take(6).toIntOrNull() ?: 0 },
                    label = { Text("Start at") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth())
                Text("# = number (### → 001), {name} = old name, {date} = date taken",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                HorizontalDivider()
                LazyColumn(Modifier.heightIn(max = 220.dp)) {
                    items(photos.indices.take(200).toList()) { i ->
                        Text("${photos[i].name}  →  ${names[i]}", style = MaterialTheme.typography.bodySmall,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { vm.batchRename(photos, names); onDismiss() }) { Text("Rename") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Pick a destination folder for Copy / Move. */
@Composable
fun FolderPickerDialog(
    vm: AppViewModel, title: String, onDismiss: () -> Unit, onPick: (volume: String, relPath: String) -> Unit,
) {
    val folders = remember(vm.photos) { vm.targetFolders() }
    var newFolder by remember { mutableStateOf(false) }
    if (newFolder) {
        TextInputDialog("New folder in Pictures", "", "Create", onDismiss = { newFolder = false }) { name ->
            val clean = name.trim().trim('/').replace(Regex("[\\\\:*?\"<>|]"), "")
            if (clean.isNotEmpty()) {
                val vol = vm.volumes.firstOrNull()?.name ?: "external_primary"
                onPick(vol, "Pictures/$clean/")
            }
            newFolder = false
        }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { newFolder = true }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.CreateNewFolder, null, tint = MaterialTheme.colorScheme.primary)
                        Text("  New folder…", color = MaterialTheme.colorScheme.primary)
                    }
                    HorizontalDivider()
                }
                items(folders) { key ->
                    val vol = keyVolume(key)
                    val rel = keyRelPath(key)
                    val volLabel = vm.volumes.firstOrNull { it.name == vol }?.label ?: vol
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(vol, rel) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(rel.trimEnd('/'), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (vm.volumes.size > 1) {
                                Text(volLabel, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Suppress("unused")
private fun keyOf(volume: String, rel: String) = folderKey(volume, rel)
