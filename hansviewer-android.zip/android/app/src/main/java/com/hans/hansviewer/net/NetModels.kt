package com.hans.hansviewer.net

import android.net.Uri
import com.hans.hansviewer.Photo

/** A WebDAV server (for example a NAS). The password is kept separately, encrypted. */
data class Server(
    val id: String,
    val alias: String,          // your own name; empty = show the real name only
    val url: String,            // e.g. https://100.112.16.113:5006
    val root: String,           // the folder it opens in, e.g. "/" or "/photo"
    val user: String,
    val trustCert: Boolean,     // accept the server's own (self-signed) certificate
    val type: String = TYPE_WEBDAV,
    val domain: String = "",    // SMB only, usually empty
) {
    val isSmb: Boolean get() = type == TYPE_SMB

    /** The real name, e.g. "100.112.16.113:5006 (WebDAV)" or "photo on 192.168.1.20 (SMB)". */
    val realName: String
        get() {
            val u = Uri.parse(url)
            val hostPort = (u.host ?: url) + if (u.port > 0) ":${u.port}" else ""
            if (isSmb) {
                val parts = root.trim('/')
                return if (parts.isEmpty()) "$hostPort (SMB)" else "${parts.replace("/", " / ")} on $hostPort (SMB)"
            }
            val folder = root.trim('/').let { if (it.isEmpty()) "" else "/$it" }
            return "$hostPort$folder (WebDAV)"
        }
    val label: String get() = alias.ifBlank { realName }
}

/** One file or folder on a server. [path] is the full path on the server, e.g. "/photo/2024/a.jpg". */
data class RemoteEntry(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,         // ms since epoch, 0 when unknown
)

const val NET_SCHEME = "hvnet"
const val TYPE_WEBDAV = "webdav"
const val TYPE_SMB = "smb"

/** What every kind of network folder can do: list a folder, read a file, read the start of a file. */
interface RemoteFs {
    fun list(path: String): List<RemoteEntry>
    fun openStream(path: String): java.io.InputStream
    fun readHead(path: String, max: Int): ByteArray
    /** Reads the file from [offset] on (for video playback and seeking). */
    fun openRange(path: String, offset: Long): java.io.InputStream
    /** Deletes a file on the server (the NAS's own recycle bin may keep it). */
    fun delete(path: String): Unit = throw NetError("Deleting isn't possible on this connection")
    /** Moves (or renames) a file on the same server; fails if [to] already exists. */
    fun move(from: String, to: String): Unit = throw NetError("Moving isn't possible on this connection")
    /** Writes a new file to the server; fails if it already exists. */
    fun upload(path: String, file: java.io.File): Unit = throw NetError("Saving isn't possible on this connection")
    fun close() {}
}

/** The server and path of a network photo, or null for a photo on the tablet. */
val Photo.netRef: Pair<String, String>? get() =
    if (uri.scheme == NET_SCHEME) (uri.authority ?: "") to normPath(uri.path ?: "/") else null
private val PHOTO_EXTS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif")

fun isPhotoName(name: String) = name.substringAfterLast('.', "").lowercase() in PHOTO_EXTS

private val VIDEO_EXTS = setOf("mp4", "m4v", "mov", "mkv", "webm", "3gp", "avi", "mts", "m2ts")

/** Settings → "Show videos" (also read by background work). */
@Volatile var SHOW_NET_VIDEOS = true

fun isVideoName(name: String) = name.substringAfterLast('.', "").lowercase() in VIDEO_EXTS

/** Photos, plus videos when they are switched on. */
fun isMediaName(name: String) = isPhotoName(name) || (SHOW_NET_VIDEOS && isVideoName(name))

/** Folder keys for network folders: "net:<server id>:<path>" (same shape as local folder keys). */
fun netKey(serverId: String, path: String) = "net:$serverId:${normPath(path)}"
fun isNetKey(key: String) = key.startsWith("net:")
fun parseNetKey(key: String): Pair<String, String>? {
    if (!isNetKey(key)) return null
    val rest = key.removePrefix("net:")
    val id = rest.substringBefore(':', "")
    if (id.isEmpty()) return null
    return id to normPath(rest.substringAfter(':', "/"))
}

/** "/a/b/" → "/a/b", "" → "/" */
fun normPath(p: String): String {
    val t = "/" + p.trim().trim('/')
    return if (t == "/") "/" else t
}

fun parentPath(p: String): String {
    val n = normPath(p)
    if (n == "/") return "/"
    return normPath(n.substringBeforeLast('/'))
}

/** A stable 64-bit id for a network photo (negative, so it never clashes with local photos). */
fun netPhotoId(serverId: String, path: String): Long {
    var h = -0x340d631b7bdddcdbL  // FNV-1a 64
    for (c in "$serverId|$path") {
        h = h xor c.code.toLong()
        h *= 0x100000001b3L
    }
    return -2L - (h and 0x3fffffffffffffffL)
}

fun netPhotoUri(serverId: String, e: RemoteEntry): Uri = Uri.Builder()
    .scheme(NET_SCHEME).authority(serverId).path(e.path)
    .appendQueryParameter("s", e.size.toString())
    .appendQueryParameter("m", e.modified.toString())
    .build()

fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "bmp" -> "image/bmp"
    "heic", "heif" -> "image/heif"
    "avif" -> "image/avif"
    "mp4", "m4v" -> "video/mp4"
    "mov" -> "video/quicktime"
    "mkv" -> "video/x-matroska"
    "webm" -> "video/webm"
    "3gp" -> "video/3gpp"
    "avi" -> "video/x-msvideo"
    "mts", "m2ts" -> "video/mp2t"
    else -> "image/*"
}

fun RemoteEntry.toPhoto(serverId: String): Photo = Photo(
    id = netPhotoId(serverId, path),
    uri = netPhotoUri(serverId, this),
    name = name,
    volume = "net:$serverId",
    relPath = parentPath(path),
    size = size,
    dateTaken = 0,
    dateModified = modified,
    width = 0,
    height = 0,
    mime = mimeFor(name),
    dataPath = null,
)

val Photo.isNet: Boolean get() = uri.scheme == NET_SCHEME
