package com.hans.hansviewer.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.Screen

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 8.dp).height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { vm.screen = Screen.Browser }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            Section("Theme") {
                for ((key, label) in listOf("dark" to "Dark", "light" to "Light")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(vm.theme == key, { vm.updateTheme(key) })
                        Text(label)
                    }
                }
            }
            Section("Slideshow: ${vm.slideshowSecs} seconds per photo") {
                Slider(vm.slideshowSecs.toFloat(), { vm.updateSlideshowSecs(it.toInt()) }, valueRange = 1f..30f, steps = 28)
            }
            Section("JPEG quality when saving: ${vm.jpegQuality}") {
                Slider(vm.jpegQuality.toFloat(), { vm.updateJpegQuality(it.toInt()) }, valueRange = 50f..100f, steps = 49)
            }
            Section("Thumbnail size: ${vm.gridSize}") {
                Slider(vm.gridSize.toFloat(), { vm.updateGridSize(it.toInt()) }, valueRange = 90f..320f)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ask before moving photos to the Recycle bin", Modifier.weight(1f))
                Switch(vm.confirmDelete, { vm.updateConfirmDelete(it) })
            }
            if (Build.VERSION.SDK_INT >= 31) {
                Section("Changing photos") {
                    val allowed = MediaStore.canManageMedia(ctx)
                    Text(
                        if (allowed) "HansViewer may rotate, rename, move and delete photos without asking each time."
                        else "Android asks for your OK each time HansViewer changes a photo. You can allow it once instead.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!allowed) {
                        Button(onClick = {
                            runCatching {
                                ctx.startActivity(Intent(Settings.ACTION_REQUEST_MANAGE_MEDIA,
                                    Uri.parse("package:" + ctx.packageName)))
                            }
                        }) { Text("Allow media management") }
                    }
                }
            }
            Section("About") {
                val version = runCatching {
                    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
                }.getOrNull() ?: ""
                Text("HansViewer for Android $version\nA photo browser, viewer and editor.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        content()
    }
}
