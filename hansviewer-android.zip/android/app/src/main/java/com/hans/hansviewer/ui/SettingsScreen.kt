package com.hans.hansviewer.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.Screen

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.startImport(uri)
    }
    var exportDialog by remember { mutableStateOf(false) }
    var exportPassword by remember { mutableStateOf<String?>(null) }
    val exportPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) vm.exportTo(uri, exportPassword)
        exportPassword = null
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 8.dp).height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { vm.screen = Screen.Browser }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        if (exportDialog) {
            ExportDialog(onDismiss = { exportDialog = false }) { pw ->
                exportDialog = false
                exportPassword = pw
                runCatching { exportPicker.launch(com.hans.hansviewer.net.SettingsExport.suggestedName()) }
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            Section("Theme") {
                for ((key, label) in listOf("dark" to "Dark", "light" to "Light")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(vm.theme == key, { vm.updateTheme(key) })
                        Text(label)
                    }
                }
            }
            Section("Slideshow: ${vm.slideshowSecs} seconds per photo") {
                Slider(vm.slideshowSecs.toFloat(), { vm.updateSlideshowSecs(it.toInt()) }, valueRange = 1f..30f, steps = 28)
            }
            Section("JPEG quality when saving: ${vm.jpegQuality}") {
                Slider(vm.jpegQuality.toFloat(), { vm.updateJpegQuality(it.toInt()) }, valueRange = 50f..100f, steps = 49)
            }
            Section("Thumbnail size: ${vm.gridSize}") {
                Slider(vm.gridSize.toFloat(), { vm.updateGridSize(it.toInt()) }, valueRange = 90f..320f)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ask before moving photos to the Recycle bin", Modifier.weight(1f))
                Switch(vm.confirmDelete, { vm.updateConfirmDelete(it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Delete permanently (instead of moving to the Recycle bin)", Modifier.weight(1f))
                Switch(vm.deletePermanently, { vm.updateDeletePermanently(it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show videos (slideshows skip them)", Modifier.weight(1f))
                Switch(vm.showVideos, { vm.updateShowVideos(it) })
            }
            if (vm.showVideos && com.hans.hansviewer.BuildConfig.NETWORK) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Network videos: download completely first")
                        Text("Off: starts as soon as it can play without stopping. On: for slow connections.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(vm.videoDownloadFirst, { vm.updateVideoDownloadFirst(it) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Brighter screen while viewing a photo", Modifier.weight(1f))
                Switch(vm.brightView, { vm.updateBrightView(it) })
            }
            if (vm.brightView) {
                Section("Brightness while viewing: ${vm.brightLevel} %") {
                    Slider(vm.brightLevel.toFloat(), { vm.updateBrightLevel(it.toInt()) }, valueRange = 10f..100f)
                }
            }
            Section("Settings from HansViewer on Linux") {
                Text(
                    "Import a file made with File → Export settings on your computer: network servers " +
                        "(with passwords, if you included them), aliases, favourites and settings.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { runCatching { importPicker.launch(arrayOf("*/*")) } }) { Text("Import settings…") }
                    Button(onClick = { exportDialog = true }) { Text("Export settings…") }
                }
                Text("Export makes a backup of this device's servers, aliases, favourites and settings.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (Build.VERSION.SDK_INT >= 31) {
                Section("Changing photos") {
                    val allowed = MediaStore.canManageMedia(ctx)
                    Text(
                        if (allowed) "HansViewer may rotate, rename, move and delete photos without asking each time."
                        else "Android asks for your OK each time HansViewer changes a photo. You can allow it once instead.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!allowed) {
                        Button(onClick = {
                            runCatching {
                                ctx.startActivity(Intent(Settings.ACTION_REQUEST_MANAGE_MEDIA,
                                    Uri.parse("package:" + ctx.packageName)))
                            }
                        }) { Text("Allow media management") }
                    }
                }
            }
            Section("About") {
                val version = runCatching {
                    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
                }.getOrNull() ?: ""
                Text("HansViewer for Android $version\nA photo browser, viewer and editor.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Asks whether to include the server passwords (encrypted with a password for the file). */
@Composable
private fun ExportDialog(onDismiss: () -> Unit, onSave: (String?) -> Unit) {
    var include by remember { mutableStateOf(false) }
    var pw1 by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Saves servers, aliases, favourites and settings to one file (e.g. to Downloads, Google " +
                    "Drive or your NAS). Thumbnails are not included.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Checkbox(include, { include = it })
                    Text("Include server passwords (encrypted)")
                }
                if (include) {
                    androidx.compose.material3.OutlinedTextField(pw1, { pw1 = it }, label = { Text("Password for the file") },
                        singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth())
                    androidx.compose.material3.OutlinedTextField(pw2, { pw2 = it }, label = { Text("Repeat the password") },
                        singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth())
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = {
                if (include) {
                    when {
                        pw1.length < 4 -> { error = "Please choose a password of at least 4 characters."; return@TextButton }
                        pw1 != pw2 -> { error = "The two passwords are not the same."; return@TextButton }
                    }
                    onSave(pw1)
                } else onSave(null)
            }) { Text("Save…") }
        },
        dismissButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        content()
    }
}
