package com.hans.hansviewer

import android.app.Application
import android.content.IntentSender
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.hans.hansviewer.net.NetError
import com.hans.hansviewer.net.RemoteEntry
import com.hans.hansviewer.net.RemoteRepo
import com.hans.hansviewer.net.netRef
import com.hans.hansviewer.net.Server
import com.hans.hansviewer.net.SettingsImport
import com.hans.hansviewer.net.ThumbWorker
import com.hans.hansviewer.net.isNet
import com.hans.hansviewer.net.isNetKey
import com.hans.hansviewer.net.isPhotoName
import com.hans.hansviewer.net.netKey
import com.hans.hansviewer.net.normPath
import com.hans.hansviewer.net.parentPath
import com.hans.hansviewer.net.parseNetKey
import com.hans.hansviewer.net.toPhoto
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface Screen {
    data object Browser : Screen
    data class Viewer(val photos: List<Photo>, val index: Int, val slideshow: Boolean) : Screen
    data class Editor(val photo: Photo) : Screen
    data object Settings : Screen
}

/** A newer build found on GitHub. */
data class UpdateInfo(val build: Long, val downloadUrl: String, val pageUrl: String)

const val UPDATE_API = "https://api.github.com/repos/hjlpinoy-cell/hansviewer-android/releases/latest"

/** A system "Allow HansViewer to modify…" prompt, and what to do once the user agrees. */
class PendingRequest(val sender: IntentSender, val onGranted: suspend () -> Unit)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val prefs = Prefs(app)

    init {
        RemoteRepo.init(app)
        com.hans.hansviewer.net.SHOW_NET_VIDEOS = prefs.showVideos
    }

    // ------------------------------------------------------------------ library
    var volumes by mutableStateOf(listOf<Volume>()); private set
    var photos by mutableStateOf(listOf<Photo>()); private set
    var tree by mutableStateOf(mapOf<String, FolderNode>()); private set
    var loading by mutableStateOf(false); private set
    var loadedOnce by mutableStateOf(false); private set

    // ------------------------------------------------------------------ browsing state
    var currentFolder by mutableStateOf(prefs.lastFolder ?: ALL_PHOTOS); private set
    var filter by mutableStateOf("")
    /** All / Photos / Videos / Timeline ("all", "photos", "videos", "timeline"). */
    var kind by mutableStateOf("all"); private set
    /** Timeline in a network folder: everything in it and its subfolders, collected in the background. */
    var timelinePhotos by mutableStateOf<List<Photo>?>(null); private set
    var timelineStatus by mutableStateOf<String?>(null); private set
    /** Timeline: why folders could not be read (shown instead of an empty "0 photos"). */
    var timelineError by mutableStateOf<String?>(null); private set
    private var timelineJob: Job? = null

    fun updateKind(k: String) {
        kind = k
        if (k == "timeline" && isRemote) startNetTimeline() else stopNetTimeline()
    }

    private fun stopNetTimeline() {
        timelineJob?.cancel()
        timelineJob = null
        timelinePhotos = null
        timelineStatus = null
        timelineError = null
    }

    /** Reads the network folder and all folders below it (remembered lists first, unless [fresh]). */
    fun startNetTimeline(fresh: Boolean = false) {
        timelineJob?.cancel()
        val key = currentFolder
        val (id, root) = parseNetKey(key) ?: return
        // a refresh keeps the Timeline on screen and swaps in the new list when it is complete
        val keepShown = fresh && !timelinePhotos.isNullOrEmpty()
        if (!keepShown) timelinePhotos = emptyList()
        timelineError = null
        timelineJob = viewModelScope.launch {
            val queue = ArrayDeque(listOf(root))
            val out = ArrayList<Photo>()
            var folders = 0
            var failed = 0
            var lastError: String? = null
            while (queue.isNotEmpty()) {
                val folder = queue.removeFirst()
                folders++
                timelineStatus = (if (keepShown) "Timeline: checking for changes… " else "Timeline: reading folders… ") +
                    "$folders · ${out.size} files"
                val entries = withContext(Dispatchers.IO) {
                    (if (fresh) null else RemoteRepo.listCached(id, folder))
                        ?: runCatching { RemoteRepo.list(id, folder) }
                            .onFailure { failed++; lastError = it.message ?: it.javaClass.simpleName }.getOrNull()
                } ?: continue
                for (e in entries) {
                    if (e.isDir) {
                        if (!e.name.startsWith(".") && !e.name.startsWith("@") && e.name != "#recycle") queue += e.path
                    } else if (com.hans.hansviewer.net.isMediaName(e.name)) {
                        out += e.toPhoto(id)
                    }
                }
                if (!keepShown && folders % 5 == 0 && currentFolder == key) timelinePhotos = out.toList()
            }
            if (currentFolder != key) return@launch
            val old = timelinePhotos
            // only replace the list when something changed, so the thumbnails don't flicker
            if (old == null || old.size != out.size || old.map { it.cacheKey }.toSet() != out.map { it.cacheKey }.toSet()) {
                timelinePhotos = out.toList()
            }
            timelineStatus = null
            if (failed > 0) {
                timelineError = (if (failed == folders) "Couldn't read this folder" else "Couldn't read $failed of $folders folders") +
                    (lastError?.let { ": $it" } ?: "")
            }
            refreshing = false
        }
    }
    /** Goes up by one when "to top" is tapped: the photo grid jumps to its start. */
    var scrollTopTick by mutableStateOf(0)
    var selection by mutableStateOf(setOf<Long>())
    var expanded by mutableStateOf(prefs.expanded)
    var screen by mutableStateOf<Screen>(Screen.Browser)
    /** The photo last shown full screen: the grid scrolls back to it and outlines it. */
    var lastViewedId by mutableStateOf<Long?>(null)
    // Where the thumbnail grid was scrolled to, so it comes back at the same place
    var gridFolder: String? = null
    var gridIndex = 0
    var gridOffset = 0
    var pending by mutableStateOf<PendingRequest?>(null)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf<String?>(null)
    var favourites by mutableStateOf(prefs.favourites); private set

    // ------------------------------------------------------------------ settings
    var theme by mutableStateOf(prefs.theme); private set
    var sortKey by mutableStateOf(prefs.sortKey); private set
    var sortDesc by mutableStateOf(prefs.sortDesc); private set
    var gridSize by mutableIntStateOf(prefs.gridSize); private set
    var slideshowSecs by mutableIntStateOf(prefs.slideshowSecs); private set
    var jpegQuality by mutableIntStateOf(prefs.jpegQuality); private set
    var confirmDelete by mutableStateOf(prefs.confirmDelete); private set
    var brightView by mutableStateOf(prefs.brightView); private set
    var brightLevel by mutableIntStateOf(prefs.brightLevel); private set
    var showVideos by mutableStateOf(prefs.showVideos); private set
    var videoDownloadFirst by mutableStateOf(prefs.videoDownloadFirst); private set
    var deletePermanently by mutableStateOf(prefs.deletePermanently); private set
    /** True while a pull-down refresh is running (shows the spinner at the top). */
    var refreshing by mutableStateOf(false); private set

    fun updateTheme(v: String) { theme = v; prefs.theme = v }
    fun updateSort(key: String, desc: Boolean) { sortKey = key; sortDesc = desc; prefs.sortKey = key; prefs.sortDesc = desc }
    fun updateGridSize(v: Int) { gridSize = v.coerceIn(90, 320); prefs.gridSize = gridSize }
    fun updateSlideshowSecs(v: Int) { slideshowSecs = v; prefs.slideshowSecs = v }
    fun updateJpegQuality(v: Int) { jpegQuality = v; prefs.jpegQuality = v }
    fun updateConfirmDelete(v: Boolean) { confirmDelete = v; prefs.confirmDelete = v }
    fun updateBrightView(v: Boolean) { brightView = v; prefs.brightView = v }
    fun updateBrightLevel(v: Int) { brightLevel = v.coerceIn(10, 100); prefs.brightLevel = brightLevel }
    fun updateShowVideos(v: Boolean) {
        showVideos = v; prefs.showVideos = v
        com.hans.hansviewer.net.SHOW_NET_VIDEOS = v
        reload()
        if (isRemote) loadRemote(currentFolder)
    }
    fun updateVideoDownloadFirst(v: Boolean) { videoDownloadFirst = v; prefs.videoDownloadFirst = v }
    fun updateDeletePermanently(v: Boolean) { deletePermanently = v; prefs.deletePermanently = v }

    /** Pull down to refresh: re-reads this folder (local photos, or asks the server again). */
    fun pullRefresh() {
        refreshing = true
        if (isRemote && kind == "timeline") startNetTimeline(fresh = true)
        else if (isRemote) loadRemote(currentFolder) else reload()
    }

    // ------------------------------------------------------------------ network folders (WebDAV)
    var servers by mutableStateOf(RemoteRepo.servers()); private set
    /** What is in the open network folder (subfolders and files). */
    var remoteEntries by mutableStateOf(listOf<RemoteEntry>()); private set
    var remoteLoading by mutableStateOf(false); private set
    var remoteError by mutableStateOf<String?>(null); private set
    private var remoteJob: Job? = null

    val isRemote: Boolean get() = isNetKey(currentFolder)

    /** Shows the folder as remembered from the last visit at once, then asks the server quietly. */
    fun loadRemote(key: String) {
        val (id, path) = parseNetKey(key) ?: return
        remoteJob?.cancel()
        val cached = RemoteRepo.listCached(id, path)
        remoteEntries = cached ?: emptyList()
        remoteError = null
        remoteLoading = true
        remoteJob = viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { RemoteRepo.list(id, path) } }
            if (currentFolder != key) return@launch
            remoteLoading = false
            refreshing = false
            result.onSuccess { remoteEntries = it }
                .onFailure { e ->
                    if (e is kotlinx.coroutines.CancellationException) return@onFailure
                    // refused or gone: the remembered list is not shown any more
                    if (e is com.hans.hansviewer.net.AccessError) remoteEntries = emptyList()
                    remoteError = (e as? NetError)?.message ?: e.message ?: "The server did not answer"
                }
        }
    }

    fun remoteSubfolders(): List<RemoteEntry> = remoteEntries
        .filter { it.isDir && !it.name.startsWith(".") && !it.name.startsWith("@") && it.name != "#recycle" }
        .sortedWith(compareBy<RemoteEntry, String>(naturalOrder) { it.name })

    fun serverOf(key: String): Server? = parseNetKey(key)?.let { (id, _) -> servers.firstOrNull { it.id == id } }

    fun openServer(s: Server) = openFolder(netKey(s.id, s.root))

    fun remoteCanGoUp(): Boolean {
        val (id, path) = parseNetKey(currentFolder) ?: return false
        val s = servers.firstOrNull { it.id == id } ?: return false
        return normPath(path) != normPath(s.root) && path != "/"
    }

    fun remoteUp(): Boolean {
        val (id, path) = parseNetKey(currentFolder) ?: return false
        val s = servers.firstOrNull { it.id == id } ?: return false
        if (normPath(path) == normPath(s.root) || path == "/") return false
        openFolder(netKey(id, parentPath(path)))
        return true
    }

    fun saveServer(s: Server, password: String?, keepPassword: Boolean) {
        RemoteRepo.upsert(s, password, keepPassword)
        servers = RemoteRepo.servers()
    }

    fun removeServer(id: String) {
        RemoteRepo.remove(id)
        servers = RemoteRepo.servers()
        saveFavs(favourites.filter { parseNetKey(it.key)?.first != id })
        if (parseNetKey(currentFolder)?.first == id) openFolder(ALL_PHOTOS)
    }

    suspend fun testServer(s: Server, password: String?): String? =
        withContext(Dispatchers.IO) { RemoteRepo.test(s, password) }

    fun makeThumbnails(key: String, subfolders: Boolean) {
        val (id, path) = parseNetKey(key) ?: return
        RemoteRepo.addToQueue(RemoteRepo.QueueItem(id, path, subfolders))
        ThumbWorker.start(ctx)
        val name = path.trimEnd('/').substringAfterLast('/').ifEmpty { "this folder" }
        RemoteRepo.progress.value = "Thumbnails: starting “$name”…"   // shown at once
        message = if (subfolders) "Making thumbnails for this folder and its subfolders (it goes first)"
        else "Making thumbnails for this folder (it goes first)"
    }

    fun stopThumbnails() { ThumbWorker.stopAll(ctx) }

    // ------------------------------------------------------------------ settings export
    fun exportTo(uri: Uri, password: String?) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching { com.hans.hansviewer.net.SettingsExport.write(ctx, prefs, uri, password) }
            }
            message = r.fold(
                { n -> "Settings saved" + if (password != null) " (with $n password(s), encrypted)" else "" },
                { "Could not save: ${it.message ?: it.javaClass.simpleName}" },
            )
        }
    }

    // ------------------------------------------------------------------ settings import
    var importing by mutableStateOf<SettingsImport.Parsed?>(null)

    fun startImport(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { SettingsImport.read(ctx, uri) } }
            r.onSuccess { importing = it }.onFailure { message = it.message ?: "Could not read the file" }
        }
    }

    /** Returns false when the file's password is wrong. */
    suspend fun finishImport(p: SettingsImport.Parsed, password: String?): Boolean {
        val secrets = if (password != null) {
            withContext(Dispatchers.Default) { SettingsImport.unlock(p, password) } ?: return false
        } else null
        val r = withContext(Dispatchers.IO) { runCatching { SettingsImport.apply(ctx, prefs, p, secrets) } }
            .getOrElse { e ->
                importing = null
                message = "Import failed: ${e.javaClass.simpleName}: ${e.message ?: ""}"
                return true
            }
        importing = null
        servers = RemoteRepo.servers()
        favourites = prefs.favourites
        theme = prefs.theme
        slideshowSecs = prefs.slideshowSecs
        jpegQuality = prefs.jpegQuality
        confirmDelete = prefs.confirmDelete
        brightView = prefs.brightView
        brightLevel = prefs.brightLevel
        showVideos = prefs.showVideos
        message = "Imported: ${r.servers} server(s), ${r.passwords} password(s), ${r.favourites} favourite(s)"
        return true
    }

    private var reloadJob: Job? = null
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) = scheduleReload()
    }

    var update by mutableStateOf<UpdateInfo?>(null)

    init {
        ctx.contentResolver.registerContentObserver(
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), true, observer)
        checkForUpdate()
        if (isNetKey(currentFolder)) {
            if (serverOf(currentFolder) != null) loadRemote(currentFolder) else currentFolder = ALL_PHOTOS
        }
    }

    /**
     * Looks for a newer build on GitHub. This only works while the repository is public;
     * when it is private GitHub answers "not found" and nothing is shown.
     */
    fun checkForUpdate(manual: Boolean = false) {
        if (!BuildConfig.UPDATE_CHECK) return  // the Play Store version updates through the Play Store
        viewModelScope.launch {
            val found = withContext(Dispatchers.IO) {
                runCatching {
                    val conn = URL(UPDATE_API).openConnection() as HttpURLConnection
                    conn.connectTimeout = 6000
                    conn.readTimeout = 6000
                    conn.setRequestProperty("Accept", "application/vnd.github+json")
                    try {
                        if (conn.responseCode != 200) return@runCatching null
                        val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                        val build = json.getString("tag_name").substringAfter("build-").toLongOrNull()
                            ?: return@runCatching null
                        val assets = json.getJSONArray("assets")
                        var apk: String? = null
                        for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.getString("name").endsWith(".apk")) apk = a.getString("browser_download_url")
                        }
                        UpdateInfo(build, apk ?: json.getString("html_url"), json.getString("html_url"))
                    } finally {
                        conn.disconnect()
                    }
                }.getOrNull()
            }
            val current = runCatching {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode
            }.getOrDefault(0L)
            if (found != null && found.build > current) {
                update = found
            } else if (manual) {
                message = if (found == null) "Couldn't check (the GitHub repository must be public)"
                else "HansViewer is up to date"
            }
        }
    }

    override fun onCleared() {
        ctx.contentResolver.unregisterContentObserver(observer)
    }

    fun scheduleReload() {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch {
            delay(700)
            reload()
        }
    }

    fun reload() {
        viewModelScope.launch {
            loading = true
            if (!loadedOnce && photos.isEmpty()) {
                // first start of this session: show the list remembered from last time at once
                val cached = withContext(Dispatchers.IO) { MediaRepo.loadCache(ctx) }
                if (cached != null && photos.isEmpty()) {
                    val t = withContext(Dispatchers.Default) { MediaRepo.buildTree(cached.first, cached.second) }
                    volumes = cached.first
                    photos = cached.second
                    tree = t
                    loadedOnce = true
                }
            }
            val videos = showVideos
            val (vols, ps) = withContext(Dispatchers.IO) {
                val v = MediaRepo.volumes(ctx)
                v to MediaRepo.loadPhotos(ctx, v, videos)
            }
            val t = withContext(Dispatchers.Default) { MediaRepo.buildTree(vols, ps) }
            volumes = vols
            photos = ps
            tree = t
            val ids = ps.mapTo(HashSet()) { it.id }
            selection = selection.filterTo(HashSet()) { it in ids }
            loading = false
            refreshing = false
            loadedOnce = true
            refreshOpenViewer()
            withContext(Dispatchers.IO) { MediaRepo.saveCache(ctx, vols, ps) }
        }
    }

    /** Keeps an open viewer in step with the library after edits or deletions. */
    private fun refreshOpenViewer() {
        val s = screen
        if (s is Screen.Viewer) {
            val byId = photos.associateBy { it.id }
            val fresh = s.photos.mapNotNull { if (it.id < 0) it else byId[it.id] }
            if (fresh.isEmpty()) screen = Screen.Browser
            else if (fresh != s.photos) screen = s.copy(photos = fresh, index = s.index.coerceAtMost(fresh.size - 1))
        }
    }

    // ------------------------------------------------------------------ folders
    fun openFolder(key: String) {
        currentFolder = key
        prefs.lastFolder = key
        selection = emptySet()
        lastViewedId = null
        filter = ""
        if (kind == "timeline" && isNetKey(key)) startNetTimeline() else stopNetTimeline()
        if (isNetKey(key)) {
            loadRemote(key)
        } else if (key != ALL_PHOTOS) {
            // open the tree down to this folder
            val vol = keyVolume(key)
            val parts = keyRelPath(key).split('/').filter { it.isNotEmpty() }
            val keys = mutableSetOf(folderKey(vol, ""))
            var p = ""
            for (part in parts.dropLast(1)) { p += "$part/"; keys += folderKey(vol, p) }
            setExpandedKeys(expanded + keys)
        }
    }

    fun toggleExpanded(key: String) =
        setExpandedKeys(if (key in expanded) expanded - key else expanded + key)

    private fun setExpandedKeys(v: Set<String>) { expanded = v; prefs.expanded = v }

    fun folderLabel(key: String): String {
        if (key == ALL_PHOTOS) return "All photos"
        parseNetKey(key)?.let { (id, path) ->
            val s = servers.firstOrNull { it.id == id } ?: return "Network folder"
            return if (normPath(path) == normPath(s.root) || path == "/") s.label else path.substringAfterLast('/')
        }
        val rel = keyRelPath(key)
        if (rel.isEmpty()) return volumes.firstOrNull { it.name == keyVolume(key) }?.label ?: "Storage"
        return rel.trimEnd('/').substringAfterLast('/')
    }

    fun visiblePhotos(): List<Photo> {
        val f = filter.trim().lowercase()
        if (kind == "timeline") {
            // everything in this folder and all folders below it, newest first, folders ignored
            val all = when {
                isNetKey(currentFolder) -> timelinePhotos ?: emptyList()
                currentFolder == ALL_PHOTOS -> photos
                else -> {
                    val vol = keyVolume(currentFolder)
                    val rel = keyRelPath(currentFolder)
                    photos.filter { it.volume == vol && it.relPath.startsWith(rel) }
                }
            }
            val named = if (f.isEmpty()) all else all.filter { f in it.name.lowercase() }
            return named.sortedWith(compareByDescending<Photo> { it.takenOrModified }.thenBy { it.name })
        }
        val inFolder = when {
            isNetKey(currentFolder) -> {
                val id = parseNetKey(currentFolder)?.first ?: ""
                remoteEntries.filter { !it.isDir && com.hans.hansviewer.net.isMediaName(it.name) }.map { it.toPhoto(id) }
            }
            currentFolder == ALL_PHOTOS -> photos
            else -> photos.filter { it.folderKey == currentFolder }
        }
        val ofKind = when (kind) {
            "photos" -> inFolder.filter { !it.isVideo }
            "videos" -> inFolder.filter { it.isVideo }
            else -> inFolder
        }
        val filtered = if (f.isEmpty()) ofKind else ofKind.filter { f in it.name.lowercase() }
        val byName = compareBy<Photo, String>(naturalOrder) { it.name }
        val cmp: Comparator<Photo> = when (sortKey) {
            "name" -> byName
            "date" -> compareBy<Photo> { it.dateModified }.then(byName)
            "size" -> compareBy<Photo> { it.size }.then(byName)
            "type" -> compareBy<Photo> { it.ext }.then(byName)
            else -> compareBy<Photo> { it.takenOrModified }.then(byName)  // "taken"
        }
        return filtered.sortedWith(if (sortDesc) cmp.reversed() else cmp)
    }

    // ------------------------------------------------------------------ favourites
    fun isFavourite(key: String) = favourites.any { it.key == key }

    private fun saveFavs(v: List<Favourite>) { favourites = v; prefs.favourites = v }

    fun toggleFavourite(key: String) {
        if (key == ALL_PHOTOS) return
        if (isFavourite(key)) saveFavs(favourites.filter { it.key != key })
        else { saveFavs(favourites + Favourite(key, null)); message = "Added to favourites" }
    }

    fun renameFavourite(key: String, label: String) = saveFavs(favourites.map {
        if (it.key == key) it.copy(label = label.trim().ifEmpty { null }?.takeIf { l -> l != folderLabel(key) }) else it
    })

    fun moveFavourite(key: String, delta: Int) {
        val i = favourites.indexOfFirst { it.key == key }
        val j = i + delta
        if (i < 0 || j !in favourites.indices) return
        val l = favourites.toMutableList()
        val t = l[i]; l[i] = l[j]; l[j] = t
        saveFavs(l)
    }

    fun favouriteLabel(f: Favourite) = f.label ?: folderLabel(f.key)

    // ------------------------------------------------------------------ viewer
    fun openViewer(list: List<Photo>, index: Int, slideshow: Boolean = false) {
        if (list.isNotEmpty()) screen = Screen.Viewer(list, index.coerceIn(0, list.size - 1), slideshow)
    }

    /** Opened from another app ("Open with HansViewer"). */
    fun openExternal(uri: Uri) {
        viewModelScope.launch {
            if (!loadedOnce) {
                reload()
                while (!loadedOnce) delay(50)
            }
            val id = runCatching { uri.lastPathSegment?.toLong() }.getOrNull()
            val match = if (uri.authority == MediaStore.AUTHORITY && id != null) photos.firstOrNull { it.id == id } else null
            if (match != null) {
                openFolder(match.folderKey)
                val list = visiblePhotos()
                openViewer(list, list.indexOfFirst { it.id == match.id })
            } else {
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "image"
                openViewer(listOf(Photo(-1, uri, name, "", "", 0, 0, System.currentTimeMillis(), 0, 0,
                    ctx.contentResolver.getType(uri) ?: "image/*", null)), 0)
            }
        }
    }

    // ------------------------------------------------------------------ file operations
    private fun withWrite(targets: List<Photo>, action: suspend () -> Unit) {
        val real = targets.filter { it.id >= 0 }
        if (real.isEmpty()) return
        runCatching { MediaRepo.writeRequest(ctx, real) }
            .onSuccess { pending = PendingRequest(it, action) }
            .onFailure { message = "Can't change these files" }
    }

    fun onRequestResult(ok: Boolean) {
        val p = pending ?: return
        pending = null
        if (ok) viewModelScope.launch { p.onGranted() }
    }

    private suspend fun work(label: String, block: suspend () -> Unit) {
        busy = label
        try {
            withContext(Dispatchers.IO) { block() }
        } finally {
            busy = null
        }
        reload()
    }

    /**
     * Moves to the Recycle bin (or deletes permanently, see Settings). Big selections are sent to
     * Android in portions of 300, because one request for thousands of files is too large for it.
     */
    fun trash(targets: List<Photo>) {
        val real = targets.filter { it.id >= 0 }
        if (real.isEmpty()) return
        removeChunks(real.chunked(300), 0, deletePermanently, 0)
    }

    private fun removeChunks(chunks: List<List<Photo>>, i: Int, permanent: Boolean, done: Int) {
        if (i >= chunks.size) {
            selection = emptySet()
            message = when {
                permanent && done == 1 -> "Deleted"
                permanent -> "$done files deleted"
                done == 1 -> "Moved to the Recycle bin"
                else -> "$done files moved to the Recycle bin"
            }
            reload()
            return
        }
        runCatching {
            if (permanent) MediaRepo.deleteRequest(ctx, chunks[i]) else MediaRepo.trashRequest(ctx, chunks[i])
        }.onSuccess {
            pending = PendingRequest(it) { removeChunks(chunks, i + 1, permanent, done + chunks[i].size) }
        }.onFailure {
            message = if (done > 0) "Stopped after $done files: Android refused the rest" else "Can't remove these files"
            if (done > 0) reload()
        }
    }

    fun rotate(targets: List<Photo>, degrees: Int) = withWrite(targets) {
        var failed = 0
        work("Rotating…") {
            for (p in targets) if (!MediaRepo.rotate(ctx, p, degrees, jpegQuality)) failed++
            MediaRepo.rescan(ctx, targets)
        }
        if (failed > 0) message = "Couldn't rotate $failed photo(s)"
    }

    fun rename(photo: Photo, newName: String) {
        val name = newName.trim()
        if (name.isEmpty() || name == photo.name) return
        if ('/' in name) { message = "Names can't contain “/”"; return }
        withWrite(listOf(photo)) {
            var ok = false
            work("Renaming…") { ok = MediaRepo.rename(ctx, photo, name) }
            if (!ok) message = "Couldn't rename (maybe the name is already used)"
        }
    }

    fun batchRename(targets: List<Photo>, names: List<String>) = withWrite(targets) {
        var failed = 0
        work("Renaming…") {
            // two steps, so names can be swapped without clashing
            targets.forEachIndexed { i, p -> MediaRepo.rename(ctx, p, "hvtmp_${i}_${p.id}.${p.ext}") }
            targets.forEachIndexed { i, p -> if (!MediaRepo.rename(ctx, p, names[i])) failed++ }
        }
        selection = emptySet()
        message = if (failed == 0) "Renamed ${targets.size} photos" else "Couldn't rename $failed photo(s)"
    }

    fun copyTo(targets: List<Photo>, volume: String, relPath: String) {
        viewModelScope.launch {
            var done = 0
            work("Copying…") { for (p in targets) if (MediaRepo.copy(ctx, p, volume, relPath) != null) done++ }
            selection = emptySet()
            message = if (done == targets.size) "Copied $done photo(s) to ${relPath.trimEnd('/')}"
            else "Copied $done of ${targets.size}. Android only allows folders inside DCIM or Pictures."
        }
    }

    fun moveTo(targets: List<Photo>, volume: String, relPath: String) {
        val same = targets.filter { it.volume == volume }
        if (same.size != targets.size) { message = "Moving between storages isn't possible — use Copy"; return }
        withWrite(same) {
            var done = 0
            work("Moving…") { for (p in same) if (MediaRepo.move(ctx, p, relPath)) done++ }
            selection = emptySet()
            message = if (done == same.size) "Moved $done photo(s) to ${relPath.trimEnd('/')}"
            else "Moved $done of ${same.size}. Android only allows folders inside DCIM or Pictures."
        }
    }

    // ------------------------------------------------------------------ files on network drives
    private suspend fun netWork(label: String, block: suspend () -> Unit) {
        busy = label
        try {
            withContext(Dispatchers.IO) { block() }
        } finally {
            busy = null
        }
        selection = emptySet()
        if (isRemote) loadRemote(currentFolder)
    }

    /** Deletes on the NAS (after the warning). The NAS's recycle bin keeps them if it is switched on. */
    fun netDelete(targets: List<Photo>) {
        viewModelScope.launch {
            var done = 0
            var error: String? = null
            netWork("Deleting…") {
                for (p in targets) {
                    val (id, path) = p.netRef ?: continue
                    runCatching { RemoteRepo.delete(id, path) }.onSuccess { done++ }
                        .onFailure { error = it.message }
                }
            }
            message = if (done == targets.size) (if (done == 1) "Deleted" else "$done files deleted")
            else "Deleted $done of ${targets.size}" + (error?.let { ": $it" } ?: "")
        }
    }

    /** Moves into another folder on the same NAS. */
    fun netMove(targets: List<Photo>, folder: String) {
        viewModelScope.launch {
            var done = 0
            var error: String? = null
            netWork("Moving…") {
                for (p in targets) {
                    val (id, path) = p.netRef ?: continue
                    runCatching { RemoteRepo.moveInto(id, path, folder) }.onSuccess { done++ }
                        .onFailure { error = it.message }
                }
            }
            message = if (done == targets.size) "Moved $done file(s) to ${folder.trimEnd('/').substringAfterLast('/')}"
            else "Moved $done of ${targets.size}" + (error?.let { ": $it" } ?: "")
        }
    }

    /** Downloads and puts them into a folder on the tablet. */
    fun netCopyToTablet(targets: List<Photo>, volume: String, relPath: String) {
        viewModelScope.launch {
            var done = 0
            netWork("Copying to the tablet…") {
                for (p in targets) {
                    runCatching {
                        val f = RemoteRepo.download(p.uri)
                        MediaRepo.importFile(ctx, f, p.name, p.mime, volume, relPath)
                    }.getOrNull()?.let { done++ }
                }
            }
            message = if (done == targets.size) "Copied $done file(s) to ${relPath.trimEnd('/')}"
            else "Copied $done of ${targets.size}. Android only allows folders inside DCIM or Pictures."
            reload()
        }
    }

    /** Downloads (or uses the copies already here) and opens the Share menu. */
    fun netShare(targets: List<Photo>) {
        viewModelScope.launch {
            val uris = ArrayList<Uri>()
            netWork("Preparing to share…") {
                val dir = java.io.File(ctx.cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }   // last time's copies
                for (p in targets) {
                    runCatching {
                        val f = RemoteRepo.download(p.uri)
                        val named = java.io.File(dir, p.name)
                        f.copyTo(named, overwrite = true)
                        uris += androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", named)
                    }
                }
            }
            if (uris.isEmpty()) { message = "Couldn't download the files to share"; return@launch }
            val intent = if (uris.size == 1) {
                android.content.Intent(android.content.Intent.ACTION_SEND).setType(targets[0].mime)
                    .putExtra(android.content.Intent.EXTRA_STREAM, uris[0])
            } else {
                android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).setType("*/*")
                    .putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, uris)
            }
            intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            runCatching {
                ctx.startActivity(android.content.Intent.createChooser(intent, "Share")
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    /** Folders photos can be copied/moved into (Android allows DCIM/ and Pictures/ only). */
    fun targetFolders(): List<String> {
        val out = sortedSetOf<String>(naturalOrder)
        for (p in photos) if (p.relPath.startsWith("DCIM/") || p.relPath.startsWith("Pictures/")) out += p.folderKey
        for (v in volumes) {
            out += folderKey(v.name, "Pictures/")
            out += folderKey(v.name, "DCIM/")
        }
        return out.toList()
    }

    fun saveEdit(photo: Photo, ops: List<EditOp>, overwrite: Boolean, stripGps: Boolean = false, done: (Boolean) -> Unit) {
        if (photo.isNet) {   // network photo: the edited copy is saved next to it on the NAS
            viewModelScope.launch {
                var saved: String? = null
                var error: String? = null
                busy = "Saving…"
                try {
                    withContext(Dispatchers.IO) {
                        runCatching {
                            val (id, path) = requireNotNull(photo.netRef)
                            val src = RemoteRepo.download(photo.uri)
                            val full = MediaRepo.decode(ctx, Uri.fromFile(src), MediaRepo.MAX_EDIT_PIXELS)
                            val edited = applyOps(full, ops, forPreview = false)
                            val tmp = MediaRepo.encodeEdited(ctx, photo, src, edited, jpegQuality, stripGps)
                            try {
                                val suffix = if (ops.any { it is EditOp.Blur }) "blurred" else "edited"
                                val name = "${photo.name.substringBeforeLast('.')}_$suffix.${MediaRepo.extFor(photo)}"
                                saved = RemoteRepo.uploadInto(id, com.hans.hansviewer.net.parentPath(path), name, tmp)
                            } finally {
                                tmp.delete()
                            }
                        }.onFailure { error = it.message ?: it.javaClass.simpleName }
                    }
                } finally {
                    busy = null
                }
                message = saved?.let { "Saved “$it” on the network drive" + if (stripGps) " (without location)" else "" }
                    ?: "Couldn't save: $error"
                if (saved != null && isRemote) loadRemote(currentFolder)
                done(saved != null)
            }
            return
        }
        val job: suspend () -> Unit = {
            var result: Uri? = null
            work("Saving…") {
                val full = MediaRepo.decode(ctx, photo.uri, MediaRepo.MAX_EDIT_PIXELS)
                val edited = applyOps(full, ops, forPreview = false)
                val suffix = if (ops.any { it is EditOp.Blur }) "blurred" else "edited"
                result = MediaRepo.saveEdited(ctx, photo, edited, overwrite, jpegQuality, suffix, stripGps && !overwrite)
                if (overwrite && result != null) MediaRepo.rescan(ctx, listOf(photo))
            }
            message = when {
                result == null -> "Couldn't save the picture"
                overwrite -> "Saved"
                else -> "Saved a copy next to the original" + if (stripGps) " (without location)" else ""
            }
            done(result != null)
        }
        if (overwrite) withWrite(listOf(photo), job) else viewModelScope.launch { job() }
    }

    fun dateText(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
}
