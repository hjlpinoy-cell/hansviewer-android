package com.hans.hansviewer

import android.app.Application
import android.content.IntentSender
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface Screen {
    data object Browser : Screen
    data class Viewer(val photos: List<Photo>, val index: Int, val slideshow: Boolean) : Screen
    data class Editor(val photo: Photo) : Screen
    data object Settings : Screen
}

/** A newer build found on GitHub. */
data class UpdateInfo(val build: Long, val downloadUrl: String, val pageUrl: String)

const val UPDATE_API = "https://api.github.com/repos/hjlpinoy-cell/hansviewer-android/releases/latest"

/** A system "Allow HansViewer to modify…" prompt, and what to do once the user agrees. */
class PendingRequest(val sender: IntentSender, val onGranted: suspend () -> Unit)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val prefs = Prefs(app)

    // ------------------------------------------------------------------ library
    var volumes by mutableStateOf(listOf<Volume>()); private set
    var photos by mutableStateOf(listOf<Photo>()); private set
    var tree by mutableStateOf(mapOf<String, FolderNode>()); private set
    var loading by mutableStateOf(false); private set
    var loadedOnce by mutableStateOf(false); private set

    // ------------------------------------------------------------------ browsing state
    var currentFolder by mutableStateOf(prefs.lastFolder ?: ALL_PHOTOS); private set
    var filter by mutableStateOf("")
    var selection by mutableStateOf(setOf<Long>())
    var expanded by mutableStateOf(prefs.expanded)
    var screen by mutableStateOf<Screen>(Screen.Browser)
    /** The photo last shown full screen: the grid scrolls back to it and outlines it. */
    var lastViewedId by mutableStateOf<Long?>(null)
    // Where the thumbnail grid was scrolled to, so it comes back at the same place
    var gridFolder: String? = null
    var gridIndex = 0
    var gridOffset = 0
    var pending by mutableStateOf<PendingRequest?>(null)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf<String?>(null)
    var favourites by mutableStateOf(prefs.favourites); private set

    // ------------------------------------------------------------------ settings
    var theme by mutableStateOf(prefs.theme); private set
    var sortKey by mutableStateOf(prefs.sortKey); private set
    var sortDesc by mutableStateOf(prefs.sortDesc); private set
    var gridSize by mutableIntStateOf(prefs.gridSize); private set
    var slideshowSecs by mutableIntStateOf(prefs.slideshowSecs); private set
    var jpegQuality by mutableIntStateOf(prefs.jpegQuality); private set
    var confirmDelete by mutableStateOf(prefs.confirmDelete); private set

    fun updateTheme(v: String) { theme = v; prefs.theme = v }
    fun updateSort(key: String, desc: Boolean) { sortKey = key; sortDesc = desc; prefs.sortKey = key; prefs.sortDesc = desc }
    fun updateGridSize(v: Int) { gridSize = v.coerceIn(90, 320); prefs.gridSize = gridSize }
    fun updateSlideshowSecs(v: Int) { slideshowSecs = v; prefs.slideshowSecs = v }
    fun updateJpegQuality(v: Int) { jpegQuality = v; prefs.jpegQuality = v }
    fun updateConfirmDelete(v: Boolean) { confirmDelete = v; prefs.confirmDelete = v }

    private var reloadJob: Job? = null
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) = scheduleReload()
    }

    var update by mutableStateOf<UpdateInfo?>(null)

    init {
        ctx.contentResolver.registerContentObserver(
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), true, observer)
        checkForUpdate()
    }

    /**
     * Looks for a newer build on GitHub. This only works while the repository is public;
     * when it is private GitHub answers "not found" and nothing is shown.
     */
    fun checkForUpdate(manual: Boolean = false) {
        if (!BuildConfig.UPDATE_CHECK) return  // the Play Store version updates through the Play Store
        viewModelScope.launch {
            val found = withContext(Dispatchers.IO) {
                runCatching {
                    val conn = URL(UPDATE_API).openConnection() as HttpURLConnection
                    conn.connectTimeout = 6000
                    conn.readTimeout = 6000
                    conn.setRequestProperty("Accept", "application/vnd.github+json")
                    try {
                        if (conn.responseCode != 200) return@runCatching null
                        val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                        val build = json.getString("tag_name").substringAfter("build-").toLongOrNull()
                            ?: return@runCatching null
                        val assets = json.getJSONArray("assets")
                        var apk: String? = null
                        for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.getString("name").endsWith(".apk")) apk = a.getString("browser_download_url")
                        }
                        UpdateInfo(build, apk ?: json.getString("html_url"), json.getString("html_url"))
                    } finally {
                        conn.disconnect()
                    }
                }.getOrNull()
            }
            val current = runCatching {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode
            }.getOrDefault(0L)
            if (found != null && found.build > current) {
                update = found
            } else if (manual) {
                message = if (found == null) "Couldn't check (the GitHub repository must be public)"
                else "HansViewer is up to date"
            }
        }
    }

    override fun onCleared() {
        ctx.contentResolver.unregisterContentObserver(observer)
    }

    fun scheduleReload() {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch {
            delay(700)
            reload()
        }
    }

    fun reload() {
        viewModelScope.launch {
            loading = true
            val (vols, ps) = withContext(Dispatchers.IO) {
                val v = MediaRepo.volumes(ctx)
                v to MediaRepo.loadPhotos(ctx, v)
            }
            val t = withContext(Dispatchers.Default) { MediaRepo.buildTree(vols, ps) }
            volumes = vols
            photos = ps
            tree = t
            val ids = ps.mapTo(HashSet()) { it.id }
            selection = selection.filterTo(HashSet()) { it in ids }
            loading = false
            loadedOnce = true
            refreshOpenViewer()
        }
    }

    /** Keeps an open viewer in step with the library after edits or deletions. */
    private fun refreshOpenViewer() {
        val s = screen
        if (s is Screen.Viewer) {
            val byId = photos.associateBy { it.id }
            val fresh = s.photos.mapNotNull { if (it.id < 0) it else byId[it.id] }
            if (fresh.isEmpty()) screen = Screen.Browser
            else if (fresh != s.photos) screen = s.copy(photos = fresh, index = s.index.coerceAtMost(fresh.size - 1))
        }
    }

    // ------------------------------------------------------------------ folders
    fun openFolder(key: String) {
        currentFolder = key
        prefs.lastFolder = key
        selection = emptySet()
        lastViewedId = null
        filter = ""
        if (key != ALL_PHOTOS) {
            // open the tree down to this folder
            val vol = keyVolume(key)
            val parts = keyRelPath(key).split('/').filter { it.isNotEmpty() }
            val keys = mutableSetOf(folderKey(vol, ""))
            var p = ""
            for (part in parts.dropLast(1)) { p += "$part/"; keys += folderKey(vol, p) }
            setExpandedKeys(expanded + keys)
        }
    }

    fun toggleExpanded(key: String) =
        setExpandedKeys(if (key in expanded) expanded - key else expanded + key)

    private fun setExpandedKeys(v: Set<String>) { expanded = v; prefs.expanded = v }

    fun folderLabel(key: String): String {
        if (key == ALL_PHOTOS) return "All photos"
        val rel = keyRelPath(key)
        if (rel.isEmpty()) return volumes.firstOrNull { it.name == keyVolume(key) }?.label ?: "Storage"
        return rel.trimEnd('/').substringAfterLast('/')
    }

    fun visiblePhotos(): List<Photo> {
        val f = filter.trim().lowercase()
        val inFolder = if (currentFolder == ALL_PHOTOS) photos else photos.filter { it.folderKey == currentFolder }
        val filtered = if (f.isEmpty()) inFolder else inFolder.filter { f in it.name.lowercase() }
        val byName = compareBy<Photo, String>(naturalOrder) { it.name }
        val cmp: Comparator<Photo> = when (sortKey) {
            "name" -> byName
            "date" -> compareBy<Photo> { it.dateModified }.then(byName)
            "size" -> compareBy<Photo> { it.size }.then(byName)
            "type" -> compareBy<Photo> { it.ext }.then(byName)
            else -> compareBy<Photo> { it.takenOrModified }.then(byName)  // "taken"
        }
        return filtered.sortedWith(if (sortDesc) cmp.reversed() else cmp)
    }

    // ------------------------------------------------------------------ favourites
    fun isFavourite(key: String) = favourites.any { it.key == key }

    private fun saveFavs(v: List<Favourite>) { favourites = v; prefs.favourites = v }

    fun toggleFavourite(key: String) {
        if (key == ALL_PHOTOS) return
        if (isFavourite(key)) saveFavs(favourites.filter { it.key != key })
        else { saveFavs(favourites + Favourite(key, null)); message = "Added to favourites" }
    }

    fun renameFavourite(key: String, label: String) = saveFavs(favourites.map {
        if (it.key == key) it.copy(label = label.trim().ifEmpty { null }?.takeIf { l -> l != folderLabel(key) }) else it
    })

    fun moveFavourite(key: String, delta: Int) {
        val i = favourites.indexOfFirst { it.key == key }
        val j = i + delta
        if (i < 0 || j !in favourites.indices) return
        val l = favourites.toMutableList()
        val t = l[i]; l[i] = l[j]; l[j] = t
        saveFavs(l)
    }

    fun favouriteLabel(f: Favourite) = f.label ?: folderLabel(f.key)

    // ------------------------------------------------------------------ viewer
    fun openViewer(list: List<Photo>, index: Int, slideshow: Boolean = false) {
        if (list.isNotEmpty()) screen = Screen.Viewer(list, index.coerceIn(0, list.size - 1), slideshow)
    }

    /** Opened from another app ("Open with HansViewer"). */
    fun openExternal(uri: Uri) {
        viewModelScope.launch {
            if (!loadedOnce) {
                reload()
                while (!loadedOnce) delay(50)
            }
            val id = runCatching { uri.lastPathSegment?.toLong() }.getOrNull()
            val match = if (uri.authority == MediaStore.AUTHORITY && id != null) photos.firstOrNull { it.id == id } else null
            if (match != null) {
                openFolder(match.folderKey)
                val list = visiblePhotos()
                openViewer(list, list.indexOfFirst { it.id == match.id })
            } else {
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "image"
                openViewer(listOf(Photo(-1, uri, name, "", "", 0, 0, System.currentTimeMillis(), 0, 0,
                    ctx.contentResolver.getType(uri) ?: "image/*", null)), 0)
            }
        }
    }

    // ------------------------------------------------------------------ file operations
    private fun withWrite(targets: List<Photo>, action: suspend () -> Unit) {
        val real = targets.filter { it.id >= 0 }
        if (real.isEmpty()) return
        runCatching { MediaRepo.writeRequest(ctx, real) }
            .onSuccess { pending = PendingRequest(it, action) }
            .onFailure { message = "Can't change these files" }
    }

    fun onRequestResult(ok: Boolean) {
        val p = pending ?: return
        pending = null
        if (ok) viewModelScope.launch { p.onGranted() }
    }

    private suspend fun work(label: String, block: suspend () -> Unit) {
        busy = label
        try {
            withContext(Dispatchers.IO) { block() }
        } finally {
            busy = null
        }
        reload()
    }

    fun trash(targets: List<Photo>) {
        val real = targets.filter { it.id >= 0 }
        if (real.isEmpty()) return
        runCatching { MediaRepo.trashRequest(ctx, real) }
            .onSuccess {
                pending = PendingRequest(it) {
                    selection = emptySet()
                    message = if (real.size == 1) "Moved to the Recycle bin" else "${real.size} photos moved to the Recycle bin"
                    reload()
                }
            }
            .onFailure { message = "Can't move these files to the Recycle bin" }
    }

    fun rotate(targets: List<Photo>, degrees: Int) = withWrite(targets) {
        var failed = 0
        work("Rotating…") {
            for (p in targets) if (!MediaRepo.rotate(ctx, p, degrees, jpegQuality)) failed++
            MediaRepo.rescan(ctx, targets)
        }
        if (failed > 0) message = "Couldn't rotate $failed photo(s)"
    }

    fun rename(photo: Photo, newName: String) {
        val name = newName.trim()
        if (name.isEmpty() || name == photo.name) return
        if ('/' in name) { message = "Names can't contain “/”"; return }
        withWrite(listOf(photo)) {
            var ok = false
            work("Renaming…") { ok = MediaRepo.rename(ctx, photo, name) }
            if (!ok) message = "Couldn't rename (maybe the name is already used)"
        }
    }

    fun batchRename(targets: List<Photo>, names: List<String>) = withWrite(targets) {
        var failed = 0
        work("Renaming…") {
            // two steps, so names can be swapped without clashing
            targets.forEachIndexed { i, p -> MediaRepo.rename(ctx, p, "hvtmp_${i}_${p.id}.${p.ext}") }
            targets.forEachIndexed { i, p -> if (!MediaRepo.rename(ctx, p, names[i])) failed++ }
        }
        selection = emptySet()
        message = if (failed == 0) "Renamed ${targets.size} photos" else "Couldn't rename $failed photo(s)"
    }

    fun copyTo(targets: List<Photo>, volume: String, relPath: String) {
        viewModelScope.launch {
            var done = 0
            work("Copying…") { for (p in targets) if (MediaRepo.copy(ctx, p, volume, relPath) != null) done++ }
            selection = emptySet()
            message = if (done == targets.size) "Copied $done photo(s) to ${relPath.trimEnd('/')}"
            else "Copied $done of ${targets.size}. Android only allows folders inside DCIM or Pictures."
        }
    }

    fun moveTo(targets: List<Photo>, volume: String, relPath: String) {
        val same = targets.filter { it.volume == volume }
        if (same.size != targets.size) { message = "Moving between storages isn't possible — use Copy"; return }
        withWrite(same) {
            var done = 0
            work("Moving…") { for (p in same) if (MediaRepo.move(ctx, p, relPath)) done++ }
            selection = emptySet()
            message = if (done == same.size) "Moved $done photo(s) to ${relPath.trimEnd('/')}"
            else "Moved $done of ${same.size}. Android only allows folders inside DCIM or Pictures."
        }
    }

    /** Folders photos can be copied/moved into (Android allows DCIM/ and Pictures/ only). */
    fun targetFolders(): List<String> {
        val out = sortedSetOf<String>(naturalOrder)
        for (p in photos) if (p.relPath.startsWith("DCIM/") || p.relPath.startsWith("Pictures/")) out += p.folderKey
        for (v in volumes) {
            out += folderKey(v.name, "Pictures/")
            out += folderKey(v.name, "DCIM/")
        }
        return out.toList()
    }

    fun saveEdit(photo: Photo, ops: List<EditOp>, overwrite: Boolean, done: (Boolean) -> Unit) {
        val job: suspend () -> Unit = {
            var result: Uri? = null
            work("Saving…") {
                val full = MediaRepo.decode(ctx, photo.uri, MediaRepo.MAX_EDIT_PIXELS)
                val edited = applyOps(full, ops, forPreview = false)
                result = MediaRepo.saveEdited(ctx, photo, edited, overwrite, jpegQuality)
                if (overwrite && result != null) MediaRepo.rescan(ctx, listOf(photo))
            }
            message = when {
                result == null -> "Couldn't save the picture"
                overwrite -> "Saved"
                else -> "Saved a copy next to the original"
            }
            done(result != null)
        }
        if (overwrite) withWrite(listOf(photo), job) else viewModelScope.launch { job() }
    }

    fun dateText(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
}
