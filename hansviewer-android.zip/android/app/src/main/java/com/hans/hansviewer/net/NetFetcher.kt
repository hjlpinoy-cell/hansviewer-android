package com.hans.hansviewer.net

import android.net.Uri
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import okio.Path.Companion.toOkioPath

/**
 * Lets the image library show network photos ("hvnet://…" addresses): the photo is downloaded
 * once, kept on the device, and decoded at screen size from there.
 */
class NetFetcher(private val uri: Uri) : Fetcher {
    override suspend fun fetch(): FetchResult {
        val file = RemoteRepo.download(uri)
        return SourceResult(
            source = ImageSource(file = file.toOkioPath()),
            mimeType = null,
            dataSource = DataSource.NETWORK,
        )
    }

    class Factory : Fetcher.Factory<Uri> {
        override fun create(data: Uri, options: Options, imageLoader: ImageLoader): Fetcher? =
            if (data.scheme == NET_SCHEME) NetFetcher(data) else null
    }
}
