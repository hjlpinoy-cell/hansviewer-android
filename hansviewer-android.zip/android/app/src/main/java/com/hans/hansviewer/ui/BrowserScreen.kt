package com.hans.hansviewer.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.Download
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.VerticalAlignTop
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.hans.hansviewer.ALL_PHOTOS
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.FolderNode
import com.hans.hansviewer.Photo
import com.hans.hansviewer.Screen
import com.hans.hansviewer.net.RemoteRepo
import com.hans.hansviewer.net.Server
import com.hans.hansviewer.net.isNet
import kotlinx.coroutines.launch

@Composable
fun BrowserScreen(vm: AppViewModel) {
    val wide = LocalConfiguration.current.screenWidthDp >= 700
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val visible = remember(vm.photos, vm.currentFolder, vm.filter, vm.kind, vm.sortKey, vm.sortDesc, vm.remoteEntries,
        vm.timelinePhotos) {
        vm.visiblePhotos()
    }
    // in a network folder, Back goes up one folder
    BackHandler(enabled = vm.selection.isEmpty() && vm.isRemote && vm.remoteCanGoUp()) { vm.remoteUp() }
    BackHandler(enabled = vm.selection.isNotEmpty()) { vm.selection = emptySet() }

    if (wide) {
        Row(Modifier.fillMaxSize()) {
            Surface(Modifier.width(300.dp).fillMaxHeight(), color = MaterialTheme.colorScheme.surface) {
                Sidebar(vm) {}
            }
            VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            MainPane(vm, visible, onMenu = null)
        }
    } else {
        ModalNavigationDrawer(
            drawerState = drawer,
            drawerContent = {
                ModalDrawerSheet(Modifier.width(300.dp)) { Sidebar(vm) { scope.launch { drawer.close() } } }
            },
        ) {
            MainPane(vm, visible, onMenu = { scope.launch { drawer.open() } })
        }
    }
}

// ====================================================================== sidebar
private data class TreeRow(val node: FolderNode, val depth: Int)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Sidebar(vm: AppViewModel, onPicked: () -> Unit) {
    val rows = remember(vm.tree, vm.expanded) {
        val out = mutableListOf<TreeRow>()
        fun walk(n: FolderNode, depth: Int) {
            out += TreeRow(n, depth)
            if (n.key in vm.expanded) n.children.values.forEach { walk(it, depth + 1) }
        }
        vm.tree.values.forEach { walk(it, 0) }
        out
    }
    var renameFav by remember { mutableStateOf<String?>(null) }
    var serverDialog by remember { mutableStateOf<Pair<Boolean, Server?>?>(null) }

    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val scope = rememberCoroutineScope()
    val showTop by remember { androidx.compose.runtime.derivedStateOf { listState.firstVisibleItemIndex > 3 } }
    Box(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 12.dp)) {
        item {
            Row(Modifier.padding(start = 20.dp, bottom = 12.dp), verticalAlignment = Alignment.Bottom) {
                Text("HansViewer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(com.hans.hansviewer.BuildConfig.VERSION_NAME, Modifier.padding(start = 8.dp, bottom = 3.dp),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            SidebarRow(Icons.Filled.PhotoLibrary, "All photos", vm.photos.size, 0,
                selected = vm.currentFolder == ALL_PHOTOS, expandable = false, expanded = false,
                onToggle = {}, onClick = { vm.openFolder(ALL_PHOTOS); onPicked() })
        }
        item { SectionTitle("FAVOURITES") }
        if (vm.favourites.isEmpty()) {
            item {
                Text("Open a folder and tap ☆ to add it here", Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(vm.favourites, key = { "fav:" + it.key }) { fav ->
            var menu by remember { mutableStateOf(false) }
            Box {
                SidebarRow(Icons.Filled.Star, vm.favouriteLabel(fav),
                    vm.photos.count { it.folderKey == fav.key }, 0,
                    selected = vm.currentFolder == fav.key, expandable = false, expanded = false,
                    onToggle = {}, onClick = { vm.openFolder(fav.key); onPicked() }, onLongClick = { menu = true })
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Rename…") }, { menu = false; renameFav = fav.key })
                    DropdownMenuItem({ Text("Move up") }, { menu = false; vm.moveFavourite(fav.key, -1) })
                    DropdownMenuItem({ Text("Move down") }, { menu = false; vm.moveFavourite(fav.key, 1) })
                    DropdownMenuItem({ Text("Remove from favourites") }, { menu = false; vm.toggleFavourite(fav.key) })
                }
            }
        }
        item { SectionTitle("DEVICES") }
        items(rows, key = { "dev:" + it.node.key }) { row ->
            val n = row.node
            var menu by remember { mutableStateOf(false) }
            val icon = when {
                row.depth > 0 -> Icons.Filled.Folder
                vm.volumes.firstOrNull { it.name == n.volume }?.removable == true ->
                    if (n.name.contains("usb", true)) Icons.Filled.Usb else Icons.Filled.SdCard
                else -> Icons.Filled.PhoneAndroid
            }
            Box {
                SidebarRow(icon, if (row.depth == 0) vm.folderLabel(n.key) else n.name, n.total, row.depth,
                    selected = vm.currentFolder == n.key, expandable = n.children.isNotEmpty(),
                    expanded = n.key in vm.expanded, onToggle = { vm.toggleExpanded(n.key) },
                    onClick = { vm.openFolder(n.key); onPicked() }, onLongClick = { menu = true })
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(
                        { Text(if (vm.isFavourite(n.key)) "Remove from favourites" else "Add to favourites") },
                        { menu = false; vm.toggleFavourite(n.key) })
                }
            }
        }
        if (com.hans.hansviewer.BuildConfig.NETWORK) {
            networkSection(vm, onPicked) { s -> serverDialog = true to s }
        }
    }
    // back to the top of the sidebar (favourites) without long scrolling
    if (showTop) {
        androidx.compose.material3.SmallFloatingActionButton(
            onClick = { scope.launch { listState.animateScrollToItem(0) } },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        ) { Icon(Icons.Filled.KeyboardArrowUp, "Back to top") }
    }
    }
    serverDialog?.let { (_, s) -> ServerDialog(vm, s) { serverDialog = null } }
    renameFav?.let { key ->
        val current = vm.favourites.firstOrNull { it.key == key }?.let { vm.favouriteLabel(it) } ?: ""
        TextInputDialog("Rename favourite", current, "Rename", onDismiss = { renameFav = null }) {
            vm.renameFavourite(key, it)
            renameFav = null
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp),
        style = MaterialTheme.typography.labelSmall, letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SidebarRow(
    icon: ImageVector, label: String, count: Int, depth: Int, selected: Boolean,
    expandable: Boolean, expanded: Boolean, onToggle: () -> Unit, onClick: () -> Unit,
    onLongClick: () -> Unit = {},
) {
    val bg = if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 1.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = (4 + depth * 14).dp, end = 12.dp)
            .height(42.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) {
            if (expandable) {
                IconButton(onClick = onToggle, modifier = Modifier.size(32.dp)) {
                    Icon(if (expanded) Icons.Filled.ExpandMore else Icons.Filled.ChevronRight, "Expand",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Icon(icon, null, Modifier.size(20.dp),
            tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        Text(label, Modifier.weight(1f).padding(start = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium)
        if (count > 0) {
            Text(count.toString(), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ====================================================================== main pane
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun MainPane(vm: AppViewModel, visible: List<Photo>, onMenu: (() -> Unit)?) {
    var renaming by remember { mutableStateOf<Photo?>(null) }
    var batch by remember { mutableStateOf<List<Photo>?>(null) }
    var picker by remember { mutableStateOf<String?>(null) }  // "copy" or "move"
    var confirmTrash by remember { mutableStateOf<List<Photo>?>(null) }
    var confirmNetDelete by remember { mutableStateOf<List<Photo>?>(null) }
    var netMove by remember { mutableStateOf<List<Photo>?>(null) }
    val selected = visible.filter { it.id in vm.selection }

    Column(Modifier.fillMaxSize()) {
        if (vm.selection.isEmpty()) {
            TopBar(vm, visible, onMenu)
        } else {
            SelectionBar(
                vm, selected, visible,
                onRename = { if (selected.size == 1) renaming = selected[0] else batch = selected },
                onCopy = { picker = if (vm.isRemote) "netcopy" else "copy" },
                onMove = { if (vm.isRemote) netMove = selected else picker = "move" },
                onTrash = {
                    when {
                        vm.isRemote -> confirmNetDelete = selected   // on the NAS: always ask first
                        vm.confirmDelete -> confirmTrash = selected
                        else -> vm.trash(selected)
                    }
                },
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        vm.update?.let { up -> UpdateBanner(vm, up) }
        // pull the grid down to refresh it
        androidx.compose.material3.pulltorefresh.PullToRefreshBox(
            isRefreshing = vm.refreshing,
            onRefresh = { vm.pullRefresh() },
            modifier = Modifier.weight(1f).fillMaxWidth().background(MaterialTheme.colorScheme.background),
        ) {
            when {
                vm.isRemote -> key(vm.currentFolder) { PhotoGrid(vm, visible, remote = true) }
                !vm.loadedOnce -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                visible.isEmpty() -> Text(
                    if (vm.filter.isNotBlank()) "No photos match “${vm.filter}”" else "No photos in this folder",
                    Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurfaceVariant)
                else -> key(vm.currentFolder) { PhotoGrid(vm, visible) }
            }
        }
        if (com.hans.hansviewer.BuildConfig.NETWORK) ThumbStatus(vm)
    }

    renaming?.let { p ->
        TextInputDialog("Rename", p.name, "Rename", onDismiss = { renaming = null }) {
            vm.rename(p, it); renaming = null; vm.selection = emptySet()
        }
    }
    batch?.let { BatchRenameDialog(vm, it) { batch = null } }
    picker?.let { mode ->
        val title = when (mode) { "copy" -> "Copy to folder"; "netcopy" -> "Copy to the tablet"; else -> "Move to folder" }
        FolderPickerDialog(vm, title, { picker = null }) { vol, rel ->
            picker = null
            when (mode) {
                "copy" -> vm.copyTo(selected, vol, rel)
                "netcopy" -> vm.netCopyToTablet(selected, vol, rel)
                else -> vm.moveTo(selected, vol, rel)
            }
        }
    }
    confirmNetDelete?.let { list ->
        val what = if (list.size == 1) "“${list[0].name}”" else "${list.size} files"
        ConfirmDialog(
            "Delete on the NAS",
            "Delete $what on the network drive? If the NAS's recycle bin is switched on for this share, " +
                "you can get them back from there; otherwise they are gone for good.",
            "Delete", onDismiss = { confirmNetDelete = null },
        ) { vm.netDelete(list); confirmNetDelete = null }
    }
    netMove?.let { list ->
        val (id, path) = com.hans.hansviewer.net.parseNetKey(vm.currentFolder) ?: ("" to "/")
        val root = vm.serverOf(vm.currentFolder)?.root ?: "/"
        NetFolderPickerDialog(id, path, root, onDismiss = { netMove = null }) { folder ->
            netMove = null
            vm.netMove(list, folder)
        }
    }
    confirmTrash?.let { list ->
        val what = if (list.size == 1) "“${list[0].name}”" else "${list.size} files"
        ConfirmDialog(
            if (vm.deletePermanently) "Delete permanently" else "Move to Recycle bin",
            if (vm.deletePermanently) "Delete $what permanently? This can't be undone."
            else "Move $what to the Recycle bin?",
            if (vm.deletePermanently) "Delete" else "Move", onDismiss = { confirmTrash = null },
        ) { vm.trash(list); confirmTrash = null }
    }
}

@Composable
private fun TopBar(vm: AppViewModel, visible: List<Photo>, onMenu: (() -> Unit)?) {
    val ctx = LocalContext.current
    var searching by remember { mutableStateOf(vm.filter.isNotEmpty()) }
    var sortMenu by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 8.dp).height(64.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onMenu != null) IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, "Folders") }
        Column(Modifier.weight(1f).padding(start = 8.dp)) {
            Text(vm.folderLabel(vm.currentFolder), style = MaterialTheme.typography.titleMedium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            val folders = if (vm.isRemote) vm.remoteSubfolders().size else 0
            Text("${visible.size} photos" + if (folders > 0) "  ·  $folders folders" else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false,
                overflow = TextOverflow.Ellipsis)
        }
        // the buttons scroll sideways when the screen is too narrow for all of them
        Box(Modifier.weight(2f), contentAlignment = Alignment.CenterEnd) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        if (searching) {
            OutlinedTextField(
                vm.filter, { vm.filter = it }, singleLine = true, placeholder = { Text("Filter by name") },
                modifier = Modifier.width(220.dp),
                trailingIcon = {
                    IconButton(onClick = { vm.filter = ""; searching = false }) { Icon(Icons.Filled.Close, "Clear") }
                },
            )
        } else {
            IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Filter") }
        }
        // back to the start of the folder (easier than the scroll bar)
        IconButton(onClick = { vm.scrollTopTick += 1 }, enabled = visible.isNotEmpty()) {
            Icon(Icons.Filled.VerticalAlignTop, "To top")
        }
        if (vm.showVideos) {
            // All / Photos / Videos
            Box {
                var kindMenu by remember { mutableStateOf(false) }
                TextButton(onClick = { kindMenu = true }) {
                    Text(when (vm.kind) { "photos" -> "Photos"; "videos" -> "Videos"; "timeline" -> "Timeline"; else -> "All" })
                }
                DropdownMenu(kindMenu, { kindMenu = false }) {
                    for ((key, label) in listOf("all" to "All", "photos" to "Photos", "videos" to "Videos",
                        "timeline" to "Timeline (incl. subfolders)")) {
                        DropdownMenuItem(
                            { Text(label) },
                            { vm.updateKind(key); kindMenu = false },
                            leadingIcon = { RadioButton(vm.kind == key, null) },
                        )
                    }
                }
            }
        }
        Box {
            IconButton(onClick = { sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Sort") }
            DropdownMenu(sortMenu, { sortMenu = false }) {
                for ((key, label) in listOf("taken" to "Date taken (photo info)", "date" to "Date modified (file)",
                    "name" to "Name", "size" to "Size", "type" to "Type")) {
                    DropdownMenuItem(
                        { Text(label) },
                        { vm.updateSort(key, vm.sortDesc); sortMenu = false },
                        leadingIcon = { RadioButton(vm.sortKey == key, null) },
                    )
                }
                HorizontalDivider()
                DropdownMenuItem(
                    { Text("Newest / largest first") },
                    { vm.updateSort(vm.sortKey, !vm.sortDesc); sortMenu = false },
                    leadingIcon = { Checkbox(vm.sortDesc, null) },
                )
            }
        }
        if (vm.currentFolder != ALL_PHOTOS) {
            val fav = vm.isFavourite(vm.currentFolder)
            IconButton(onClick = { vm.toggleFavourite(vm.currentFolder) }) {
                Icon(if (fav) Icons.Filled.Star else Icons.Filled.StarBorder,
                    if (fav) "Remove favourite" else "Add favourite",
                    tint = if (fav) Color(0xFFFFC94D) else MaterialTheme.colorScheme.onSurface)
            }
        }
        IconButton(onClick = { vm.openViewer(visible, 0, slideshow = true) }, enabled = visible.isNotEmpty()) {
            Icon(Icons.Filled.PlayArrow, "Slideshow")
        }
        Box {
            IconButton(onClick = { more = true }) { Icon(Icons.Filled.MoreVert, "More") }
            DropdownMenu(more, { more = false }) {
                DropdownMenuItem({ Text("Bigger thumbnails") }, { vm.updateGridSize(vm.gridSize + 30) })
                DropdownMenuItem({ Text("Smaller thumbnails") }, { vm.updateGridSize(vm.gridSize - 30) })
                DropdownMenuItem({ Text("Select all") }, { vm.selection = visible.map { it.id }.toSet(); more = false })
                DropdownMenuItem({ Text("Refresh") }, {
                    if (vm.isRemote) vm.loadRemote(vm.currentFolder) else vm.reload()
                    more = false
                })
                if (vm.isRemote) {
                    DropdownMenuItem({ Text("Make thumbnails for this folder") }, {
                        more = false; vm.makeThumbnails(vm.currentFolder, subfolders = false)
                    })
                    DropdownMenuItem({ Text("Make thumbnails incl. subfolders") }, {
                        more = false; vm.makeThumbnails(vm.currentFolder, subfolders = true)
                    })
                }
                HorizontalDivider()
                if (Build.VERSION.SDK_INT >= 31 && !MediaStore.canManageMedia(ctx)) {
                    DropdownMenuItem({ Text("Stop asking before every change…") }, {
                        more = false
                        runCatching {
                            ctx.startActivity(Intent(Settings.ACTION_REQUEST_MANAGE_MEDIA,
                                Uri.parse("package:" + ctx.packageName)))
                        }
                    })
                }
                if (com.hans.hansviewer.BuildConfig.UPDATE_CHECK) {
                    DropdownMenuItem({ Text("Check for updates") }, { more = false; vm.checkForUpdate(manual = true) })
                }
                DropdownMenuItem({ Text("Settings") }, { more = false; vm.screen = Screen.Settings })
            }
        }
        }
        }
    }
}

@Composable
private fun SelectionBar(
    vm: AppViewModel, selected: List<Photo>, visible: List<Photo>,
    onRename: () -> Unit, onCopy: () -> Unit, onMove: () -> Unit, onTrash: () -> Unit,
) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp).height(64.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = { vm.selection = emptySet() }) { Icon(Icons.Filled.Close, "Done") }
        Text("${selected.size}", Modifier.padding(horizontal = 4.dp), style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer)
        // The action buttons scroll sideways when the screen is too narrow for all of them
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { vm.selection = visible.map { it.id }.toSet() }) { Icon(Icons.Filled.SelectAll, "Select all") }
        if (vm.isRemote) {
            // network drive: share, copy to the tablet, move on the NAS, delete on the NAS
            IconButton(onClick = { vm.netShare(selected) }) { Icon(Icons.Filled.Share, "Share") }
            IconButton(onClick = onCopy) { Icon(Icons.Filled.Download, "Copy to the tablet") }
            IconButton(onClick = onMove) { Icon(Icons.AutoMirrored.Filled.DriveFileMove, "Move to") }
            IconButton(onClick = onTrash) { Icon(Icons.Filled.Delete, "Delete") }
        } else {
        IconButton(onClick = { vm.rotate(selected, -90) }) { Icon(Icons.AutoMirrored.Filled.RotateLeft, "Rotate left") }
        IconButton(onClick = { vm.rotate(selected, 90) }) { Icon(Icons.AutoMirrored.Filled.RotateRight, "Rotate right") }
        IconButton(onClick = { sharePhotos(ctx, selected) }) { Icon(Icons.Filled.Share, "Share") }
        IconButton(onClick = onRename) { Icon(Icons.Filled.DriveFileRenameOutline, "Rename") }
        IconButton(onClick = onCopy) { Icon(Icons.Filled.ContentCopy, "Copy to") }
        IconButton(onClick = onMove) { Icon(Icons.AutoMirrored.Filled.DriveFileMove, "Move to") }
        IconButton(onClick = onTrash) { Icon(Icons.Filled.Delete, "Recycle bin") }
        }
        }
        }
    }
}

// ====================================================================== grid
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhotoGrid(vm: AppViewModel, visible: List<Photo>, remote: Boolean = false) {
    val ctx = LocalContext.current
    var seenTopTick by remember { mutableStateOf(vm.scrollTopTick) }
    val tick by RemoteRepo.thumbTick.collectAsState()
    val sameFolder = vm.gridFolder == vm.currentFolder
    val state = rememberLazyGridState(
        initialFirstVisibleItemIndex = if (sameFolder) vm.gridIndex else 0,
        initialFirstVisibleItemScrollOffset = if (sameFolder) vm.gridOffset else 0,
    )
    // Keep track of the scroll position while browsing
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex to state.firstVisibleItemScrollOffset }.collect { (i, o) ->
            vm.gridFolder = vm.currentFolder
            vm.gridIndex = i
            vm.gridOffset = o
        }
    }
    // Back from the full-screen viewer: make sure the photo just viewed is on screen
    LaunchedEffect(Unit) {
        val id = vm.lastViewedId ?: return@LaunchedEffect
        val found = visible.indexOfFirst { it.id == id }
        if (found < 0) return@LaunchedEffect
        val index = found + if (remote) 1 else 0  // the folder list sits above the photos
        snapshotFlow { state.layoutInfo.visibleItemsInfo }.first { it.isNotEmpty() }
        val info = state.layoutInfo
        val item = info.visibleItemsInfo.firstOrNull { it.index == index }
        val fullyVisible = item != null && item.offset.y >= info.viewportStartOffset &&
            item.offset.y + item.size.height <= info.viewportEndOffset
        if (!fullyVisible) {
            // place it about a third down the screen rather than at the very top
            val rowHeight = info.visibleItemsInfo.first().size.height
            state.scrollToItem(index, -(info.viewportSize.height / 3 - rowHeight / 2).coerceAtLeast(0))
        }
    }
    val header = if (remote) 1 else 0
    LaunchedEffect(vm.scrollTopTick) {
        if (vm.scrollTopTick != seenTopTick) {
            seenTopTick = vm.scrollTopTick
            state.scrollToItem(0)
        }
    }
    Box(Modifier.fillMaxSize()) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(vm.gridSize.dp),
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        val timeline = vm.kind == "timeline"
        if (timeline && vm.timelineError != null) {
            item(key = "tlerror", span = { GridItemSpan(maxLineSpan) }) {
                Text(vm.timelineError ?: "", Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (timeline && vm.timelineStatus != null) {
            item(key = "tlstatus", span = { GridItemSpan(maxLineSpan) }) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    Text(vm.timelineStatus ?: "", Modifier.padding(start = 10.dp), style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (remote && !timeline) {
            item(key = "folders", span = { GridItemSpan(maxLineSpan) }) { RemoteFolders(vm) }
            if (visible.isEmpty() && !vm.remoteLoading && vm.remoteError == null) {
                item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        if (vm.filter.isNotBlank()) "No photos match “${vm.filter}”" else "No photos in this folder",
                        Modifier.padding(vertical = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        val card: @Composable (Int, Photo) -> Unit = { index, p ->
            val selected = p.id in vm.selection
            PhotoCard(
                p, selected, current = p.id == vm.lastViewedId, tick = tick,
                onClick = {
                    if (vm.selection.isNotEmpty()) vm.selection = if (selected) vm.selection - p.id else vm.selection + p.id
                    else vm.openViewer(visible, index)
                },
                onLongClick = { vm.selection = if (selected) vm.selection - p.id else vm.selection + p.id },
                canSelect = true,
                onOtherPlayer = if (p.isVideo) ({
                    if (!com.hans.hansviewer.net.LocalStream.openInOtherPlayer(ctx, p)) {
                        vm.message = "No other video player found on this phone"
                    }
                }) else null,
            )
        }
        if (timeline) {
            // Timeline: a heading for each month, newest first
            for ((label, range) in monthGroups(visible)) {
                item(key = "month:${range.first}:$label", span = { GridItemSpan(maxLineSpan) }) {
                    Text(label, Modifier.padding(top = 10.dp, bottom = 2.dp), style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold)
                }
                items(range.count(), key = { i -> visible[range.first + i].id }) { i ->
                    card(range.first + i, visible[range.first + i])
                }
            }
        } else {
            itemsIndexed(visible, key = { _, p -> p.id }) { index, p -> card(index, p) }
        }
    }
    FastScroller(
        state, visible.size + header,
        label = { i -> visible.getOrNull(i - header)?.let { scrollLabel(vm, it) } ?: "" },
        modifier = Modifier.align(Alignment.TopEnd),
    )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhotoCard(
    p: Photo, selected: Boolean, current: Boolean, tick: Int = 0, onClick: () -> Unit, onLongClick: () -> Unit,
    canSelect: Boolean = true, onOtherPlayer: (() -> Unit)? = null,
) {
    val ctx = LocalContext.current
    var videoMenu by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    val accent = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .clip(shape)
            .background(
                when {
                    selected -> accent.copy(alpha = 0.22f)
                    current -> accent.copy(alpha = 0.12f)
                    else -> MaterialTheme.colorScheme.surfaceContainer
                },
            )
            // selected = solid frame; the photo just viewed = the same frame, so it is easy to spot
            .then(if (selected || current) Modifier.border(2.dp, accent, shape) else Modifier)
            // long press on a video: "Play in other player" (and Select, for videos on the phone)
            .combinedClickable(onClick = onClick, onLongClick = { if (onOtherPlayer != null) videoMenu = true else onLongClick() })
            .padding(6.dp),
    ) {
        if (onOtherPlayer != null) {
            DropdownMenu(videoMenu, { videoMenu = false }) {
                DropdownMenuItem({ Text("Play in other player") }, { videoMenu = false; onOtherPlayer() })
                if (canSelect) DropdownMenuItem({ Text("Select") }, { videoMenu = false; onLongClick() })
            }
        }
        Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
            if (p.isNet) {
                // network photo: only a thumbnail made earlier is shown (made when viewed, or by
                // "Make thumbnails"); nothing is downloaded just for browsing
                val thumb = remember(p.cacheKey, tick) { RemoteRepo.thumbFor(p.uri) }
                if (thumb != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(thumb)
                            .memoryCacheKey("thumb:" + p.cacheKey).crossfade(true).build(),
                        contentDescription = p.name,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(4.dp)),
                    )
                } else {
                    Icon(Icons.Filled.Image, null, Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f))
                    // SMB on the home network: the tiles on screen get their thumbnails by themselves
                    if (RemoteRepo.isAutoThumb(p.uri)) {
                        LaunchedEffect(p.cacheKey) { runCatching { RemoteRepo.ensureThumb(p.uri) } }
                    }
                }
            } else {
                AsyncImage(
                    // Android's own ready-made thumbnail: much faster than shrinking the whole photo
                    model = ImageRequest.Builder(ctx).data(com.hans.hansviewer.MediaThumb(p.uri, 320))
                        .memoryCacheKey("mt:" + p.cacheKey).crossfade(true).build(),
                    contentDescription = p.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(4.dp)),
                )
            }
            if (p.isVideo) {
                val length = remember(p.cacheKey, tick) {
                    if (p.duration > 0) p.duration else RemoteRepo.durationFor(p.uri)
                }
                Row(
                    Modifier.align(Alignment.BottomStart).padding(4.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.PlayArrow, null, Modifier.size(14.dp), tint = Color.White)
                    if (length > 0) {
                        Text(com.hans.hansviewer.formatDuration(length), color = Color.White,
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (selected) {
                Icon(Icons.Filled.CheckCircle, null, tint = accent,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(24.dp)
                        .background(Color.White, CircleShape))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(p.name, Modifier.fillMaxWidth(), maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall)
        if (p.width > 0 && !p.isVideo) {
            Text("${p.width} × ${p.height}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun UpdateBanner(vm: AppViewModel, up: com.hans.hansviewer.UpdateInfo) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("A new HansViewer version is available (build ${up.build})", Modifier.weight(1f),
            color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.bodyMedium)
        androidx.compose.material3.TextButton(onClick = {
            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(up.downloadUrl))) }
        }) { Text("Download", color = MaterialTheme.colorScheme.onPrimary) }
        IconButton(onClick = { vm.update = null }) {
            Icon(Icons.Filled.Close, "Later", tint = MaterialTheme.colorScheme.onPrimary)
        }
    }
}

fun sharePhotos(ctx: android.content.Context, photos: List<Photo>) {
    if (photos.isEmpty()) return
    val intent = if (photos.size == 1) {
        Intent(Intent.ACTION_SEND).setType(photos[0].mime).putExtra(Intent.EXTRA_STREAM, photos[0].uri)
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).setType("image/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(photos.map { it.uri }))
    }
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(intent, "Share")) }
}


/** The text shown next to the scroll handle: the date, the first letter, the size or the type. */
private fun scrollLabel(vm: AppViewModel, p: Photo): String = when (vm.sortKey) {
    "name" -> p.name.take(1).uppercase()
    "size" -> com.hans.hansviewer.humanSize(p.size)
    "type" -> p.ext.uppercase()
    "date" -> java.text.SimpleDateFormat("MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(p.dateModified))
    else -> java.text.SimpleDateFormat("MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(p.takenOrModified))
}

/** A handle on the right edge: drag it to move quickly through a big folder. */
@Composable
private fun FastScroller(
    state: androidx.compose.foundation.lazy.grid.LazyGridState, count: Int, label: (Int) -> String, modifier: Modifier,
) {
    if (count < 40) return
    val scope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableStateOf(0f) }
    val visibleCount = state.layoutInfo.visibleItemsInfo.size.coerceAtLeast(1)
    val frac = if (dragging) dragFrac
    else (state.firstVisibleItemIndex.toFloat() / (count - visibleCount).coerceAtLeast(1)).coerceIn(0f, 1f)
    fun indexAt(f: Float) = (f * (count - 1)).toInt().coerceIn(0, count - 1)
    val accent = MaterialTheme.colorScheme.primary
    // stays clearly visible for 3 seconds after scrolling, so there is time to grab it
    var active by remember { mutableStateOf(false) }
    LaunchedEffect(state.isScrollInProgress, dragging) {
        if (state.isScrollInProgress || dragging) active = true
        else { kotlinx.coroutines.delay(3000); active = false }
    }
    androidx.compose.foundation.layout.BoxWithConstraints(
        modifier
            .fillMaxHeight()
            .width(44.dp)
            .pointerInput(count) {
                // a tap anywhere on the track jumps there
                detectTapGestures(onTap = { o ->
                    val f = (o.y / size.height).coerceIn(0f, 1f)
                    scope.launch { state.scrollToItem(indexAt(f)) }
                })
            }
            .pointerInput(count) {
                detectVerticalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        dragFrac = (o.y / size.height).coerceIn(0f, 1f)
                        scope.launch { state.scrollToItem(indexAt(dragFrac)) }
                    },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        dragFrac = (change.position.y / size.height).coerceIn(0f, 1f)
                        scope.launch { state.scrollToItem(indexAt(dragFrac)) }
                    },
                )
            },
    ) {
        val thumb = 72.dp
        val y = (maxHeight - thumb) * frac
        Box(
            Modifier.align(Alignment.TopEnd).offset(y = y).padding(end = 3.dp)
                .size(width = if (dragging || active) 16.dp else 10.dp, height = thumb)
                .background(accent.copy(alpha = if (dragging || active) 0.95f else 0.5f), RoundedCornerShape(6.dp)),
        )
        if (dragging) {
            val text = label(indexAt(dragFrac))
            if (text.isNotEmpty()) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = (-30).dp, y = y + 12.dp)
                        .background(accent, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(text, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge,
                        maxLines = 1, softWrap = false)
                }
            }
        }
    }
}


/** Picks a folder on the same network drive (for "Move to"). */
@Composable
private fun NetFolderPickerDialog(
    serverId: String, start: String, root: String, onDismiss: () -> Unit, onPick: (String) -> Unit,
) {
    var path by remember { mutableStateOf(start) }
    var folders by remember { mutableStateOf<List<com.hans.hansviewer.net.RemoteEntry>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(path) {
        folders = null
        error = null
        runCatching { RemoteRepo.foldersIn(serverId, path) }
            .onSuccess { folders = it }.onFailure { error = it.message ?: "The server did not answer" }
    }
    val atTop = com.hans.hansviewer.net.normPath(path) == com.hans.hansviewer.net.normPath(root) || path == "/"
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Move to folder") },
        text = {
            Column {
                Text(path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (!atTop) {
                    TextButton(onClick = { path = com.hans.hansviewer.net.parentPath(path) }) { Text("↑  Up one folder") }
                }
                when {
                    error != null -> Text(error ?: "", color = MaterialTheme.colorScheme.error)
                    folders == null -> CircularProgressIndicator(Modifier.padding(16.dp))
                    folders!!.isEmpty() -> Text("No folders inside", Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else -> LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(folders!!) { f ->
                            Text("📁  " + f.name, Modifier.fillMaxWidth().clickable { path = f.path }
                                .padding(vertical = 12.dp, horizontal = 8.dp))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(path) }) { Text("Move here") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}


/** Consecutive runs of photos from the same month: ("October 2026", 0..41), … (list sorted newest first). */
private fun monthGroups(photos: List<Photo>): List<Pair<String, IntRange>> {
    val fmt = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault())
    val out = ArrayList<Pair<String, IntRange>>()
    var start = 0
    var current: String? = null
    photos.forEachIndexed { i, p ->
        val label = if (p.takenOrModified > 0) fmt.format(java.util.Date(p.takenOrModified)) else "Unknown date"
        if (label != current) {
            current?.let { out += it to (start until i) }
            current = label
            start = i
        }
    }
    current?.let { out += it to (start until photos.size) }
    return out
}
