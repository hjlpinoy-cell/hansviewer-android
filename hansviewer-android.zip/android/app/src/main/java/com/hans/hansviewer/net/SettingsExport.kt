package com.hans.hansviewer.net

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Base64
import com.hans.hansviewer.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * File → Export settings on Android: the same .hansviewer file format as on Linux.
 * The general settings are readable by both versions; servers, aliases and favourites of this
 * device are kept in an "android" part, so a backup brings back exactly this device's setup.
 * Passwords are only included when asked for, encrypted with the password chosen for the file.
 */
object SettingsExport {

    fun suggestedName(): String {
        val model = Build.MODEL.replace(Regex("[^A-Za-z0-9-]+"), "-").trim('-').ifEmpty { "android" }
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        return "hansviewer-settings-$model-$day.hansviewer"
    }

    /** Same format as `openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -a` (Linux can read it). */
    fun encrypt(plain: String, password: String): String {
        val salt = ByteArray(8).also { SecureRandom().nextBytes(it) }
        val spec = PBEKeySpec(password.toCharArray(), salt, 200_000, 48 * 8)
        val kb = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(kb.copyOfRange(0, 32), "AES"), IvParameterSpec(kb.copyOfRange(32, 48)))
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString("Salted__".toByteArray(Charsets.US_ASCII) + salt + ct, Base64.NO_WRAP)
    }

    /** Writes the file. Returns how many passwords were included. */
    fun write(ctx: Context, prefs: Prefs, uri: Uri, password: String?): Int {
        RemoteRepo.init(ctx)
        val version = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull()
        // general settings, with the same names as on Linux
        val settings = JSONObject()
            .put("slideshow_secs", prefs.slideshowSecs.toString())
            .put("jpeg_quality", prefs.jpegQuality.toString())
            .put("theme", prefs.theme)
            .put("confirm_delete", prefs.confirmDelete.toString())
            .put("bright_full", prefs.brightView.toString())
            .put("bright_level", prefs.brightLevel.toString())
            .put("show_videos", prefs.showVideos.toString())
            .put("video_download_first", prefs.videoDownloadFirst.toString())
        val servers = JSONArray()
        for (s in RemoteRepo.servers()) {
            servers.put(JSONObject().put("id", s.id).put("alias", s.alias).put("url", s.url).put("root", s.root)
                .put("user", s.user).put("trust", s.trustCert).put("type", s.type).put("domain", s.domain))
        }
        val favs = JSONArray()
        prefs.favourites.forEach { favs.put(JSONObject().put("key", it.key).put("label", it.label ?: "")) }
        val android = JSONObject()
            .put("servers", servers)
            .put("favourites", favs)
            .put("grid_size", prefs.gridSize)
            .put("sort_key", prefs.sortKey)
            .put("sort_desc", prefs.sortDesc)
            .put("delete_permanently", prefs.deletePermanently)
        val data = JSONObject()
            .put("app", "HansViewer")
            .put("format", 1)
            .put("version", "Android ${version ?: ""}".trim())
            .put("exported", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
            .put("computer", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
            .put("settings", settings)
            .put("android", android)
        var count = 0
        if (password != null) {
            val list = JSONArray()
            for (s in RemoteRepo.servers()) {
                val pw = RemoteRepo.password(s.id) ?: continue
                list.put(JSONObject().put("id", s.id).put("password", pw))
                count++
            }
            data.put("secrets", encrypt(JSONObject().put("android_passwords", list).toString(), password))
            data.put("secrets_info", JSONObject().put("passwords", count).put("clouds", 0))
        }
        val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("Could not write the file")
        out.use { it.write(data.toString(1).toByteArray(Charsets.UTF_8)) }
        return count
    }

    /** Restores the "android" part of a file made by HansViewer on Android. Returns (servers, favourites). */
    fun restoreAndroid(prefs: Prefs, android: JSONObject, secrets: JSONObject?): Triple<Int, Int, Int> {
        val list = RemoteRepo.servers().associateBy { it.id }.toMutableMap()
        var nServers = 0
        android.optJSONArray("servers")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val id = o.optString("id").ifEmpty { RemoteRepo.newId() }
                list[id] = Server(id, o.optString("alias"), o.optString("url"), o.optString("root", "/"),
                    o.optString("user"), o.optBoolean("trust"), o.optString("type", TYPE_WEBDAV).ifEmpty { TYPE_WEBDAV },
                    o.optString("domain"))
                nServers++
            }
        }
        RemoteRepo.saveServers(list.values.toList())
        var nPw = 0
        secrets?.optJSONArray("android_passwords")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                if (list.containsKey(o.optString("id"))) {
                    RemoteRepo.setPassword(o.optString("id"), o.optString("password"))
                    nPw++
                }
            }
        }
        val favs = prefs.favourites.toMutableList()
        var nFav = 0
        android.optJSONArray("favourites")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val key = o.optString("key")
                if (key.isNotEmpty() && favs.none { it.key == key }) {
                    favs += com.hans.hansviewer.Favourite(key, o.optString("label").ifEmpty { null })
                    nFav++
                }
            }
        }
        prefs.favourites = favs
        if (android.has("grid_size")) prefs.gridSize = android.optInt("grid_size", prefs.gridSize)
        if (android.has("sort_key")) prefs.sortKey = android.optString("sort_key", prefs.sortKey)
        if (android.has("sort_desc")) prefs.sortDesc = android.optBoolean("sort_desc", prefs.sortDesc)
        if (android.has("delete_permanently")) prefs.deletePermanently = android.optBoolean("delete_permanently")
        return Triple(nServers, nPw, nFav)
    }
}
