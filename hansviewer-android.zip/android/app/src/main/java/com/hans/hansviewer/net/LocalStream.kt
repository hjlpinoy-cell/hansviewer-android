package com.hans.hansviewer.net

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.hans.hansviewer.Photo
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * "Play in other player" for network videos: a tiny web server on the phone itself (127.0.0.1,
 * not reachable from outside) hands the video to the other app (e.g. VLC) while it is read from
 * the NAS, so it can start at once and jump to any position.
 */
object LocalStream {
    private var server: ServerSocket? = null
    private val videos = ConcurrentHashMap<String, Uri>()

    @Synchronized
    private fun port(): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        val s = ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"))
        server = s
        thread(name = "local-stream", isDaemon = true) {
            while (!s.isClosed) {
                val c = runCatching { s.accept() }.getOrNull() ?: break
                thread(name = "local-stream-client", isDaemon = true) { serve(c) }
            }
        }
        return s.localPort
    }

    /** The address the other app plays from. */
    fun urlFor(uri: Uri, name: String): String {
        val token = UUID.randomUUID().toString().substring(0, 12)
        videos[token] = uri
        return "http://127.0.0.1:${port()}/$token/${Uri.encode(name)}"
    }

    private fun serve(c: Socket) {
        c.use { sock ->
            runCatching {
                sock.soTimeout = 60_000
                val reader = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.ISO_8859_1))
                val request = reader.readLine() ?: return
                val parts = request.split(" ")
                val method = parts.getOrNull(0) ?: "GET"
                val path = parts.getOrNull(1) ?: "/"
                var range: String? = null
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    if (line.lowercase().startsWith("range:")) range = line.substringAfter(':').trim()
                }
                val out = sock.getOutputStream()
                val token = path.trimStart('/').substringBefore('/')
                val uri = videos[token]
                if (uri == null) {
                    out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                    return
                }
                val name = Uri.decode(path.substringAfterLast('/'))
                val total = uri.getQueryParameter("s")?.toLongOrNull() ?: 0L
                var start = 0L
                var end = total - 1
                val m = range?.let { Regex("""bytes=(\d*)-(\d*)""").find(it) }
                if (m != null) {
                    val (a, b) = m.destructured
                    if (a.isNotEmpty()) start = a.toLong()
                    if (b.isNotEmpty()) end = minOf(b.toLong(), total - 1)
                    if (a.isEmpty() && b.isNotEmpty()) { start = (total - b.toLong()).coerceAtLeast(0); end = total - 1 }
                }
                val length = (end - start + 1).coerceAtLeast(0)
                val head = StringBuilder()
                head.append(if (m != null) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n")
                head.append("Content-Type: ${mimeFor(name)}\r\n")
                head.append("Accept-Ranges: bytes\r\n")
                head.append("Content-Length: $length\r\n")
                if (m != null) head.append("Content-Range: bytes $start-$end/$total\r\n")
                head.append("Connection: close\r\n\r\n")
                out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
                if (method == "HEAD" || length == 0L) return
                val (input, _) = RemoteRepo.openRange(uri, start)
                input.use {
                    val buf = ByteArray(256 * 1024)
                    var left = length
                    while (left > 0) {
                        val n = it.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n <= 0) break
                        out.write(buf, 0, n)
                        left -= n
                    }
                }
                out.flush()
            }
        }
    }

    /** Opens a video in another app: phone videos directly, network videos through the server above. */
    fun openInOtherPlayer(ctx: Context, photo: Photo): Boolean {
        val intent = Intent(Intent.ACTION_VIEW)
        if (photo.uri.scheme == NET_SCHEME) {
            intent.setDataAndType(Uri.parse(urlFor(photo.uri, photo.name)), mimeFor(photo.name))
        } else {
            intent.setDataAndType(photo.uri, photo.mime.ifEmpty { "video/*" })
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Play with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(chooser)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }
}
