package com.hans.hansviewer

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.storage.StorageManager
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

const val ALL_PHOTOS = "*all*"

data class Photo(
    val id: Long,
    val uri: Uri,
    val name: String,
    val volume: String,
    val relPath: String,        // e.g. "DCIM/Camera/"
    val size: Long,
    val dateTaken: Long,        // ms since epoch, 0 when the photo has no capture date
    val dateModified: Long,     // ms since epoch
    val width: Int,
    val height: Int,
    val mime: String,
    val dataPath: String?,
) {
    val folderKey: String get() = folderKey(volume, relPath)
    val takenOrModified: Long get() = if (dateTaken > 0) dateTaken else dateModified
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
    val isJpeg: Boolean get() = mime == "image/jpeg" || ext == "jpg" || ext == "jpeg"
    /** Changes whenever the file changes, so image caches never show an old version. */
    val cacheKey: String get() = "$uri#$dateModified#$size"
}

fun folderKey(volume: String, relPath: String) = "$volume:$relPath"
fun keyVolume(key: String) = key.substringBefore(':')
fun keyRelPath(key: String) = key.substringAfter(':', "")

data class Volume(val name: String, val label: String, val removable: Boolean)

class FolderNode(val volume: String, val relPath: String, val name: String) {
    val children = sortedMapOf<String, FolderNode>(naturalOrder)
    var direct = 0
    var total = 0
    val key: String get() = folderKey(volume, relPath)
}

/** Sorts "img2" before "img10", like a person would (fast: no text patterns, no copies). */
val naturalOrder: Comparator<String> = Comparator { a, b ->
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        val ca = a[i]
        val cb = b[j]
        if (ca.isDigit() && cb.isDigit()) {
            // compare whole numbers: skip leading zeros, then the longer number is bigger
            var si = i
            while (si < a.length && a[si] == '0') si++
            var sj = j
            while (sj < b.length && b[sj] == '0') sj++
            var ei = si
            while (ei < a.length && a[ei].isDigit()) ei++
            var ej = sj
            while (ej < b.length && b[ej].isDigit()) ej++
            val la = ei - si
            val lb = ej - sj
            if (la != lb) return@Comparator la - lb
            for (k in 0 until la) {
                val d = a[si + k] - b[sj + k]
                if (d != 0) return@Comparator d
            }
            i = ei
            j = ej
        } else {
            val d = ca.lowercaseChar() - cb.lowercaseChar()
            if (d != 0) return@Comparator d
            i++
            j++
        }
    }
    (a.length - i) - (b.length - j)
}

object MediaRepo {

    fun volumes(ctx: Context): List<Volume> {
        val names = MediaStore.getExternalVolumeNames(ctx)
        val sm = ctx.getSystemService(StorageManager::class.java)
        val out = mutableListOf<Volume>()
        for (sv in sm.storageVolumes) {
            val n = sv.mediaStoreVolumeName ?: continue
            if (n in names && out.none { it.name == n }) {
                out += Volume(n, sv.getDescription(ctx), sv.isRemovable)
            }
        }
        for (n in names) {
            if (out.none { it.name == n }) {
                val primary = n == MediaStore.VOLUME_EXTERNAL_PRIMARY
                out += Volume(n, if (primary) "Internal storage" else n, !primary)
            }
        }
        return out.sortedBy { if (it.name == MediaStore.VOLUME_EXTERNAL_PRIMARY) 0 else 1 }
    }

    fun loadPhotos(ctx: Context, volumes: List<Volume>): List<Photo> {
        val out = ArrayList<Photo>()
        val proj = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.ORIENTATION,
            MediaStore.Images.Media.DATA,
        )
        for (vol in volumes) {
            val base = MediaStore.Images.Media.getContentUri(vol.name)
            runCatching {
                ctx.contentResolver.query(base, proj, null, null, null)?.use { c ->
                    val iId = c.getColumnIndexOrThrow(proj[0])
                    val iName = c.getColumnIndexOrThrow(proj[1])
                    val iRel = c.getColumnIndexOrThrow(proj[2])
                    val iSize = c.getColumnIndexOrThrow(proj[3])
                    val iTaken = c.getColumnIndexOrThrow(proj[4])
                    val iMod = c.getColumnIndexOrThrow(proj[5])
                    val iW = c.getColumnIndexOrThrow(proj[6])
                    val iH = c.getColumnIndexOrThrow(proj[7])
                    val iMime = c.getColumnIndexOrThrow(proj[8])
                    val iOri = c.getColumnIndexOrThrow(proj[9])
                    val iData = c.getColumnIndexOrThrow(proj[10])
                    while (c.moveToNext()) {
                        val id = c.getLong(iId)
                        val ori = c.getInt(iOri)
                        var w = c.getInt(iW)
                        var h = c.getInt(iH)
                        if (ori == 90 || ori == 270) {
                            val t = w; w = h; h = t
                        }
                        out += Photo(
                            id = id,
                            uri = ContentUris.withAppendedId(base, id),
                            name = c.getString(iName) ?: "image",
                            volume = vol.name,
                            relPath = c.getString(iRel) ?: "",
                            size = c.getLong(iSize),
                            dateTaken = c.getLong(iTaken),
                            dateModified = c.getLong(iMod) * 1000L,
                            width = w,
                            height = h,
                            mime = c.getString(iMime) ?: "image/*",
                            dataPath = c.getString(iData),
                        )
                    }
                }
            }
        }
        return out
    }

    fun buildTree(volumes: List<Volume>, photos: List<Photo>): Map<String, FolderNode> {
        val roots = LinkedHashMap<String, FolderNode>()
        volumes.forEach { roots[it.name] = FolderNode(it.name, "", it.label) }
        for (p in photos) {
            val root = roots.getOrPut(p.volume) { FolderNode(p.volume, "", p.volume) }
            root.total++
            var node = root
            var path = ""
            for (part in p.relPath.split('/').filter { it.isNotEmpty() }) {
                path += "$part/"
                val parentPath = path
                node = node.children.getOrPut(part) { FolderNode(p.volume, parentPath, part) }
                node.total++
            }
            node.direct++
        }
        return roots
    }

    // ------------------------------------------------------------------ remembered photo list
    /**
     * The photo list from the last start, so HansViewer can show your photos at once while it
     * asks Android for the current list in the background (73 000 photos take a while to read).
     */
    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "photo-list.bin")

    fun saveCache(ctx: Context, volumes: List<Volume>, photos: List<Photo>) {
        runCatching {
            val f = cacheFile(ctx)
            val tmp = File(f.path + ".tmp")
            java.io.DataOutputStream(java.io.BufferedOutputStream(tmp.outputStream(), 1 shl 16)).use { out ->
                out.writeInt(CACHE_VERSION)
                out.writeInt(volumes.size)
                for (v in volumes) { out.writeUTF(v.name); out.writeUTF(v.label); out.writeBoolean(v.removable) }
                val table = LinkedHashMap<String, Int>()
                fun idx(t: String) = table.getOrPut(t) { table.size }
                val rows = photos.map { p -> Triple(idx(p.volume), idx(p.relPath), idx(p.mime)) }
                out.writeInt(table.size)
                for (t in table.keys) out.writeUTF(t)
                out.writeInt(photos.size)
                photos.forEachIndexed { i, p ->
                    val (v, r, m) = rows[i]
                    out.writeLong(p.id); out.writeUTF(p.name); out.writeInt(v); out.writeInt(r)
                    out.writeLong(p.size); out.writeLong(p.dateTaken); out.writeLong(p.dateModified)
                    out.writeInt(p.width); out.writeInt(p.height); out.writeInt(m)
                    out.writeUTF(p.dataPath ?: "")
                }
            }
            tmp.renameTo(f)
        }
    }

    fun loadCache(ctx: Context): Pair<List<Volume>, List<Photo>>? = runCatching {
        val f = cacheFile(ctx)
        if (!f.exists()) return@runCatching null
        java.io.DataInputStream(java.io.BufferedInputStream(f.inputStream(), 1 shl 16)).use { inp ->
            if (inp.readInt() != CACHE_VERSION) return@runCatching null
            val vols = List(inp.readInt()) { Volume(inp.readUTF(), inp.readUTF(), inp.readBoolean()) }
            val table = List(inp.readInt()) { inp.readUTF() }
            val bases = HashMap<String, Uri>()
            val n = inp.readInt()
            val out = ArrayList<Photo>(n)
            repeat(n) {
                val id = inp.readLong()
                val name = inp.readUTF()
                val vol = table[inp.readInt()]
                val rel = table[inp.readInt()]
                val size = inp.readLong()
                val taken = inp.readLong()
                val mod = inp.readLong()
                val w = inp.readInt()
                val h = inp.readInt()
                val mime = table[inp.readInt()]
                val data = inp.readUTF().ifEmpty { null }
                val base = bases.getOrPut(vol) { MediaStore.Images.Media.getContentUri(vol) }
                out += Photo(id, ContentUris.withAppendedId(base, id), name, vol, rel, size, taken, mod, w, h, mime, data)
            }
            vols to out
        }
    }.getOrNull()

    private const val CACHE_VERSION = 1

    // ------------------------------------------------------------------ permission requests
    fun writeRequest(ctx: Context, photos: List<Photo>): IntentSender =
        MediaStore.createWriteRequest(ctx.contentResolver, photos.map { it.uri }).intentSender

    fun trashRequest(ctx: Context, photos: List<Photo>): IntentSender =
        MediaStore.createTrashRequest(ctx.contentResolver, photos.map { it.uri }, true).intentSender

    // ------------------------------------------------------------------ file operations
    fun rename(ctx: Context, photo: Photo, newName: String): Boolean = runCatching {
        val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, newName) }
        ctx.contentResolver.update(photo.uri, v, null, null) > 0
    }.getOrDefault(false)

    fun move(ctx: Context, photo: Photo, relPath: String): Boolean = runCatching {
        val v = ContentValues().apply { put(MediaStore.Images.Media.RELATIVE_PATH, relPath) }
        ctx.contentResolver.update(photo.uri, v, null, null) > 0
    }.getOrDefault(false)

    /** Copies a photo into a folder. Folders must be inside DCIM/ or Pictures/ (an Android rule). */
    fun copy(ctx: Context, photo: Photo, volume: String, relPath: String): Uri? {
        val cr = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, photo.name)
            put(MediaStore.Images.Media.MIME_TYPE, photo.mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, relPath)
            if (photo.dateTaken > 0) put(MediaStore.Images.Media.DATE_TAKEN, photo.dateTaken)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val dest = runCatching {
            cr.insert(MediaStore.Images.Media.getContentUri(volume), values)
        }.getOrNull() ?: return null
        return try {
            cr.openInputStream(photo.uri).use { input ->
                cr.openOutputStream(dest, "w").use { output ->
                    requireNotNull(input).copyTo(requireNotNull(output))
                }
            }
            cr.update(dest, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) },
                null, null)
            dest
        } catch (e: Exception) {
            runCatching { cr.delete(dest, null, null) }
            null
        }
    }

    /** JPEGs are rotated losslessly by changing the orientation tag; others are re-encoded. */
    fun rotate(ctx: Context, photo: Photo, degrees: Int, quality: Int): Boolean = runCatching {
        if (photo.isJpeg) {
            ctx.contentResolver.openFileDescriptor(photo.uri, "rw").use { pfd ->
                val exif = ExifInterface(requireNotNull(pfd).fileDescriptor)
                exif.rotate(degrees)
                exif.saveAttributes()
            }
        } else {
            val bmp = decode(ctx, photo.uri, MAX_EDIT_PIXELS)
            val m = Matrix().apply { postRotate(degrees.toFloat()) }
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            writeBitmap(ctx, photo, rotated, photo.uri, quality)
        }
        true
    }.getOrDefault(false)

    /** Saves an edited picture, either over the original or as a new "_edited" copy. */
    fun saveEdited(ctx: Context, photo: Photo, bitmap: Bitmap, overwrite: Boolean, quality: Int): Uri? {
        if (overwrite && formatFor(photo) != null) {
            return if (writeBitmap(ctx, photo, bitmap, photo.uri, quality)) photo.uri else null
        }
        val cr = ctx.contentResolver
        val fmt = formatFor(photo) ?: Bitmap.CompressFormat.JPEG
        val ext = when (fmt) {
            Bitmap.CompressFormat.PNG -> "png"
            Bitmap.CompressFormat.JPEG -> "jpg"
            else -> "webp"
        }
        val mime = when (ext) { "png" -> "image/png"; "jpg" -> "image/jpeg"; else -> "image/webp" }
        val stem = photo.name.substringBeforeLast('.')
        val rel = if (photo.relPath.startsWith("DCIM/") || photo.relPath.startsWith("Pictures/"))
            photo.relPath else "Pictures/HansViewer/"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "${stem}_edited.$ext")
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, rel)
            if (photo.dateTaken > 0) put(MediaStore.Images.Media.DATE_TAKEN, photo.dateTaken)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val dest = runCatching {
            cr.insert(MediaStore.Images.Media.getContentUri(photo.volume), values)
        }.getOrNull() ?: return null
        val ok = writeBitmap(ctx, photo, bitmap, dest, quality, fmt)
        if (!ok) {
            runCatching { cr.delete(dest, null, null) }
            return null
        }
        cr.update(dest, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
        return dest
    }

    private fun formatFor(photo: Photo): Bitmap.CompressFormat? = when {
        photo.isJpeg -> Bitmap.CompressFormat.JPEG
        photo.mime == "image/png" -> Bitmap.CompressFormat.PNG
        photo.mime == "image/webp" -> Bitmap.CompressFormat.WEBP_LOSSY
        else -> null
    }

    /** Encodes to a temp file (copying the camera's EXIF data), then writes it to [dest]. */
    private fun writeBitmap(
        ctx: Context, src: Photo, bitmap: Bitmap, dest: Uri, quality: Int,
        format: Bitmap.CompressFormat? = null,
    ): Boolean {
        val fmt = format ?: formatFor(src) ?: Bitmap.CompressFormat.JPEG
        val tmp = File.createTempFile("hv", ".tmp", ctx.cacheDir)
        try {
            tmp.outputStream().use { bitmap.compress(fmt, quality, it) }
            if (fmt == Bitmap.CompressFormat.JPEG) copyExif(ctx, src, tmp, bitmap.width, bitmap.height)
            ctx.contentResolver.openOutputStream(dest, "wt").use { out ->
                tmp.inputStream().use { it.copyTo(requireNotNull(out)) }
            }
            return true
        } catch (e: Exception) {
            return false
        } finally {
            tmp.delete()
        }
    }

    private val EXIF_TAGS = listOf(
        ExifInterface.TAG_DATETIME, ExifInterface.TAG_DATETIME_ORIGINAL,
        ExifInterface.TAG_DATETIME_DIGITIZED, ExifInterface.TAG_OFFSET_TIME_ORIGINAL,
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_LENS_MODEL,
        ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_F_NUMBER,
        ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, ExifInterface.TAG_FOCAL_LENGTH,
        ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, ExifInterface.TAG_FLASH,
        ExifInterface.TAG_WHITE_BALANCE, ExifInterface.TAG_EXPOSURE_BIAS_VALUE,
        ExifInterface.TAG_GPS_LATITUDE, ExifInterface.TAG_GPS_LATITUDE_REF,
        ExifInterface.TAG_GPS_LONGITUDE, ExifInterface.TAG_GPS_LONGITUDE_REF,
        ExifInterface.TAG_GPS_ALTITUDE, ExifInterface.TAG_GPS_ALTITUDE_REF,
        ExifInterface.TAG_ARTIST, ExifInterface.TAG_COPYRIGHT, ExifInterface.TAG_IMAGE_DESCRIPTION,
        ExifInterface.TAG_SOFTWARE,
    )

    private fun copyExif(ctx: Context, src: Photo, file: File, w: Int, h: Int) {
        runCatching {
            val from = ctx.contentResolver.openInputStream(src.uri).use { ExifInterface(requireNotNull(it)) }
            val to = ExifInterface(file.absolutePath)
            for (t in EXIF_TAGS) from.getAttribute(t)?.let { to.setAttribute(t, it) }
            to.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
            to.setAttribute(ExifInterface.TAG_PIXEL_X_DIMENSION, w.toString())
            to.setAttribute(ExifInterface.TAG_PIXEL_Y_DIMENSION, h.toString())
            to.saveAttributes()
        }
    }

    /** Asks Android to re-read changed files so sizes, dates and thumbnails update. */
    suspend fun rescan(ctx: Context, photos: List<Photo>) {
        val paths = photos.mapNotNull { it.dataPath }.toTypedArray()
        if (paths.isEmpty()) return
        withTimeoutOrNull(5000) {
            suspendCancellableCoroutine { cont ->
                var left = paths.size
                MediaScannerConnection.scanFile(ctx, paths, null) { _, _ ->
                    left--
                    if (left <= 0 && cont.isActive) cont.resume(Unit)
                }
            }
        }
    }

    // ------------------------------------------------------------------ decoding
    const val MAX_EDIT_PIXELS = 32_000_000L

    /** Decodes upright (EXIF rotation applied), halving the size until it fits [maxPixels]. */
    fun decode(ctx: Context, uri: Uri, maxPixels: Long): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            var sample = 1
            while (info.size.width.toLong() / sample * (info.size.height.toLong() / sample) > maxPixels) {
                sample *= 2
            }
            if (sample > 1) dec.setTargetSampleSize(sample)
        }
    }

    fun decodeForScreen(ctx: Context, uri: Uri, maxEdge: Int): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            var sample = 1
            while (maxOf(info.size.width, info.size.height) / (sample * 2) >= maxEdge) sample *= 2
            if (sample > 1) dec.setTargetSampleSize(sample)
        }
    }

    // ------------------------------------------------------------------ photo information
    fun info(ctx: Context, photo: Photo): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        if (photo.width > 0) {
            val mp = photo.width.toLong() * photo.height / 1_000_000.0
            out += "Dimensions" to "${photo.width} × ${photo.height}  (${"%.1f".format(mp)} MP)"
        }
        out += "File size" to humanSize(photo.size)
        if (photo.dateTaken > 0) out += "Taken" to fmt.format(Date(photo.dateTaken))
        out += "Modified" to fmt.format(Date(photo.dateModified))
        out += "Type" to photo.mime
        out += "Folder" to photo.relPath.ifEmpty { "/" }
        runCatching {
            val stream = if (photo.uri.scheme == com.hans.hansviewer.net.NET_SCHEME)
                com.hans.hansviewer.net.RemoteRepo.cachedFile(photo.uri)?.inputStream()
            else ctx.contentResolver.openInputStream(photo.uri)
            val ex = stream.use { ExifInterface(requireNotNull(it)) }
            val make = ex.getAttribute(ExifInterface.TAG_MAKE)?.trim().orEmpty()
            val model = ex.getAttribute(ExifInterface.TAG_MODEL)?.trim().orEmpty()
            if (model.isNotEmpty()) out += "Camera" to if (model.startsWith(make)) model else "$make $model".trim()
            ex.getAttribute(ExifInterface.TAG_LENS_MODEL)?.let { out += "Lens" to it.trim() }
            ex.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0).takeIf { it > 0 }?.let {
                out += "Exposure" to if (it < 1) "1/${Math.round(1 / it)} s" else "${"%.1f".format(it)} s"
            }
            ex.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0).takeIf { it > 0 }?.let {
                out += "Aperture" to "f/${"%.1f".format(it)}"
            }
            ex.getAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY)?.let { out += "ISO" to it }
            ex.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0).takeIf { it > 0 }?.let {
                out += "Focal length" to "${Math.round(it)} mm"
            }
            ex.latLong?.let { out += "Location" to "%.5f, %.5f".format(it[0], it[1]) }
        }
        return out
    }
}

fun humanSize(n: Long): String {
    if (n < 1024) return "$n bytes"
    var v = n / 1024.0
    for (unit in listOf("KB", "MB", "GB")) {
        if (v < 1024 || unit == "GB") return "%.1f %s".format(v, unit)
        v /= 1024
    }
    return "$n bytes"
}
