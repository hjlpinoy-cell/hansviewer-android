package com.hans.hansviewer.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.net.RemoteRepo
import com.hans.hansviewer.net.Server
import com.hans.hansviewer.net.SettingsImport
import com.hans.hansviewer.net.TYPE_SMB
import com.hans.hansviewer.net.TYPE_WEBDAV
import com.hans.hansviewer.net.normPath
import com.hans.hansviewer.net.parseNetKey
import kotlinx.coroutines.launch

/** The NETWORK section of the sidebar: saved servers and "Connect to server…". */
@OptIn(ExperimentalFoundationApi::class)
fun LazyListScope.networkSection(vm: AppViewModel, onPicked: () -> Unit, onEdit: (Server?) -> Unit) {
    item {
        Text("NETWORK", Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    items(vm.servers, key = { "srv:" + it.id }) { s ->
        var menu by remember { mutableStateOf(false) }
        var alias by remember { mutableStateOf(false) }
        val selected = parseNetKey(vm.currentFolder)?.first == s.id
        Box {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 1.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                    .combinedClickable(onClick = { vm.openServer(s); onPicked() }, onLongClick = { menu = true })
                    .padding(start = 36.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Dns, null, Modifier.size(20.dp),
                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(s.label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    if (s.alias.isNotBlank()) {
                        // look B: your alias first, the real name below it in small grey text
                        Text(s.realName, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem({ Text("Open") }, { menu = false; vm.openServer(s); onPicked() })
                DropdownMenuItem({ Text("Set alias…") }, { menu = false; alias = true })
                DropdownMenuItem({ Text("Edit connection…") }, { menu = false; onEdit(s) })
                DropdownMenuItem({ Text("Make thumbnails incl. subfolders") }, {
                    menu = false; vm.makeThumbnails(com.hans.hansviewer.net.netKey(s.id, s.root), subfolders = true)
                })
                DropdownMenuItem({ Text("Remove from sidebar") }, { menu = false; vm.removeServer(s.id) })
            }
        }
        if (alias) {
            TextInputDialog("Alias for ${s.realName}", s.alias, "Save", onDismiss = { alias = false }) {
                vm.saveServer(s.copy(alias = it.trim()), null, keepPassword = true)
                alias = false
            }
        }
    }
    item {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 1.dp)
                .clip(RoundedCornerShape(8.dp))
                .combinedClickable(onClick = { onEdit(null) })
                .padding(start = 36.dp, end = 12.dp)
                .height(42.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Add, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
            Text("Connect to server…", Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}

/** Cloud services that offer WebDAV: ready-made addresses (no app registration needed). */
private data class CloudPreset(val name: String, val url: String, val hint: String)

private val CLOUD_PRESETS = listOf(
    CloudPreset("pCloud (USA)", "https://webdav.pcloud.com",
        "Sign in with your pCloud e-mail and password."),
    CloudPreset("pCloud (Europe)", "https://ewebdav.pcloud.com",
        "For pCloud accounts stored in Europe. Sign in with your pCloud e-mail and password."),
    CloudPreset("Koofr", "https://app.koofr.net/dav/Koofr",
        "Use your Koofr e-mail and an app password (Koofr web → Preferences → Password → App passwords)."),
    CloudPreset("Yandex Disk", "https://webdav.yandex.com",
        "Use your Yandex login and an app password (Yandex ID → Security → App passwords → Files)."),
    CloudPreset("Nextcloud", "https://YOUR-SERVER/remote.php/dav/files/YOUR-USER",
        "Replace YOUR-SERVER and YOUR-USER. An app password is recommended (Settings → Security)."),
    CloudPreset("ownCloud", "https://YOUR-SERVER/remote.php/webdav",
        "Replace YOUR-SERVER with your ownCloud address."),
)

/** Add or edit a server: WebDAV (also from outside) or SMB (home network). Tried before saving. */
@Composable
fun ServerDialog(vm: AppViewModel, existing: Server?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var smb by remember { mutableStateOf(existing?.isSmb ?: false) }
    var address by remember {
        mutableStateOf(
            when {
                existing == null -> ""
                existing.isSmb -> existing.url.removePrefix("smb://")
                else -> existing.url
            }
        )
    }
    var folder by remember { mutableStateOf(existing?.root?.trim('/') ?: "") }
    var user by remember { mutableStateOf(existing?.user ?: "") }
    var domain by remember { mutableStateOf(existing?.domain ?: "") }
    var password by remember { mutableStateOf("") }
    var alias by remember { mutableStateOf(existing?.alias ?: "") }
    var trust by remember { mutableStateOf(existing?.trustCert ?: false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var presetMenu by remember { mutableStateOf(false) }
    var presetHint by remember { mutableStateOf<String?>(null) }
    val hasPassword = remember { existing != null && RemoteRepo.password(existing.id) != null }

    fun build(): Server? {
        var a = address.trim().trimEnd('/')
        if (smb) {
            a = a.removePrefix("smb://").removePrefix("\\\\").substringBefore('/')
            if (a.isEmpty() || folder.isBlank()) return null
            return Server(existing?.id ?: RemoteRepo.newId(), alias.trim(), "smb://$a",
                normPath(folder.replace('\\', '/')), user.trim(), false, TYPE_SMB, domain.trim())
        }
        if (a.isEmpty() || a == "https:" || a == "http:") return null
        if (!a.startsWith("http://") && !a.startsWith("https://")) a = "https://$a"
        return Server(existing?.id ?: RemoteRepo.newId(), alias.trim(), a, normPath(folder), user.trim(), trust,
            TYPE_WEBDAV, "")
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(if (existing == null) "Connect to server" else "Edit connection") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(!smb, { smb = false })
                    Text("WebDAV  ", Modifier.padding(end = 8.dp))
                    RadioButton(smb, { smb = true })
                    Text("SMB (home network)")
                }
                if (smb) {
                    OutlinedTextField(address, { address = it }, label = { Text("NAS name or address, e.g. 192.168.1.20") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                    OutlinedTextField(folder, { folder = it }, label = { Text("Share (and folder), e.g. photo") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                } else {
                    Box {
                        TextButton(onClick = { presetMenu = true }) { Text("Cloud service with WebDAV…") }
                        DropdownMenu(presetMenu, { presetMenu = false }) {
                            for (pr in CLOUD_PRESETS) {
                                DropdownMenuItem({ Text(pr.name) }, {
                                    presetMenu = false
                                    address = pr.url
                                    folder = ""
                                    trust = false
                                    if (alias.isBlank()) alias = pr.name.substringBefore(" (")
                                    presetHint = pr.hint
                                })
                            }
                        }
                    }
                    presetHint?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                    OutlinedTextField(address, { address = it }, label = { Text("Address, e.g. https://192.168.1.5:5006") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                    OutlinedTextField(folder, { folder = it }, label = { Text("Folder (optional), e.g. photo") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(user, { user = it }, label = { Text("User name (empty = guest)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it },
                    label = { Text(if (hasPassword) "Password (empty = keep the saved one)" else "Password") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                if (smb) {
                    OutlinedTextField(domain, { domain = it }, label = { Text("Domain / workgroup (usually empty)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(alias, { alias = it }, label = { Text("Alias (your own name, optional)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                if (!smb) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(trust, { trust = it })
                        Text("Trust this server's certificate (for a NAS with its own certificate)",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text("The password is stored encrypted on this device.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (busy) Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("  Connecting…")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val s = build()
                if (s == null) {
                    error = if (smb) "Please enter the NAS address and the share name." else "Please enter the server's address."
                    return@TextButton
                }
                val keep = existing != null && password.isEmpty() && hasPassword
                val pw = if (keep) RemoteRepo.password(s.id) else password
                busy = true
                error = null
                scope.launch {
                    val problem = vm.testServer(s, pw)
                    busy = false
                    if (problem == null) {
                        vm.saveServer(s, password, keepPassword = keep)
                        onDismiss()
                        vm.openServer(s)
                    } else {
                        error = problem
                    }
                }
            }) { Text("Connect") }
        },
        dismissButton = {
            Row {
                if (build() != null) {
                    TextButton(enabled = !busy, onClick = {
                        val s = build() ?: return@TextButton
                        val keep = existing != null && password.isEmpty() && hasPassword
                        vm.saveServer(s, password, keepPassword = keep)
                        onDismiss()
                    }) { Text("Save without trying") }
                }
                TextButton(enabled = !busy, onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}

/** Subfolders of the open network folder, shown above the photos. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RemoteFolders(vm: AppViewModel) {
    val subs = vm.remoteSubfolders()
    val server = vm.serverOf(vm.currentFolder)
    val path = parseNetKey(vm.currentFolder)?.second ?: "/"
    val atRoot = server == null || normPath(path) == normPath(server.root)
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Text(
            (server?.label ?: "") + if (atRoot) "" else "  ›  " + path.removePrefix(normPath(server?.root ?: "/")).trim('/')
                .replace("/", "  ›  "),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
        )
        if (!atRoot || subs.isNotEmpty()) {
            FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!atRoot) {
                    AssistChip(onClick = { vm.remoteUp() }, label = { Text("Up") },
                        leadingIcon = { Icon(Icons.Filled.ArrowUpward, null, Modifier.size(18.dp)) })
                }
                for (f in subs) {
                    AssistChip(
                        onClick = { vm.openFolder(com.hans.hansviewer.net.netKey(server?.id ?: "", f.path)) },
                        label = {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 240.dp))
                        },
                        leadingIcon = { Icon(Icons.Filled.Folder, null, Modifier.size(18.dp)) },
                    )
                }
            }
        }
        when {
            vm.remoteError != null -> Text(vm.remoteError ?: "", Modifier.padding(top = 8.dp),
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            vm.remoteLoading -> Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                Text(
                    if (vm.remoteEntries.isEmpty()) "  Reading the folder… (a big folder can take a minute the first time)"
                    else "  Checking for changes…",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** "Thumbnails: folder — 120 / 900" with Pause and Stop, while "Make thumbnails" is working. */
@Composable
fun ThumbStatus(vm: AppViewModel) {
    val text by RemoteRepo.progress.collectAsState()
    val t = text ?: return
    var paused by remember { mutableStateOf(RemoteRepo.thumbsPaused) }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(t, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
        TextButton(onClick = { paused = !paused; RemoteRepo.thumbsPaused = paused }) {
            Text(if (paused) "Resume" else "Pause")
        }
        TextButton(onClick = { vm.stopThumbnails() }) { Text("Stop") }
    }
}

/** Import of a settings file exported by HansViewer on Linux. */
@Composable
fun ImportDialog(vm: AppViewModel, p: SettingsImport.Parsed) {
    val scope = rememberCoroutineScope()
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!busy) vm.importing = null },
        title = { Text("Import settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Exported on ${p.exported} from “${p.computer}”.\n\nYour network servers, aliases, network " +
                    "favourites and settings will be taken over. Folders on the computer's own disks are skipped.")
                if (p.hasSecrets) {
                    Text("The file contains encrypted passwords. Enter the file's password to import them too " +
                        "(or leave it empty to import without passwords).",
                        style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(password, { password = it }, label = { Text("Password for the file") },
                        singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth())
                }
                if (busy) Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("  Importing…")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                busy = true
                error = null
                scope.launch {
                    val ok = vm.finishImport(p, if (p.hasSecrets && password.isNotEmpty()) password else null)
                    busy = false
                    if (!ok) error = "Wrong password, please try again."
                }
            }) { Text("Import") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = { vm.importing = null }) { Text("Cancel") } },
    )
}
