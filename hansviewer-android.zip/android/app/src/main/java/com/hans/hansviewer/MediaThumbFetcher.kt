package com.hans.hansviewer

import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.util.Size
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A grid tile for a photo on this device: uses the small thumbnail Android already keeps. */
data class MediaThumb(val uri: Uri, val edge: Int)

class MediaThumbFetcher(private val ctx: Context, private val data: MediaThumb) : Fetcher {
    override suspend fun fetch(): FetchResult = withContext(Dispatchers.IO) {
        val bmp = runCatching {
            ctx.contentResolver.loadThumbnail(data.uri, Size(data.edge, data.edge), null)
        }.getOrNull() ?: MediaRepo.decodeForScreen(ctx, data.uri, data.edge)  // no ready thumbnail: make one
        DrawableResult(
            drawable = BitmapDrawable(ctx.resources, bmp),
            isSampled = true,
            dataSource = DataSource.DISK,
        )
    }

    class Factory(private val ctx: Context) : Fetcher.Factory<MediaThumb> {
        override fun create(data: MediaThumb, options: Options, imageLoader: ImageLoader): Fetcher =
            MediaThumbFetcher(ctx.applicationContext, data)
    }
}
