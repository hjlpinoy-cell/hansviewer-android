package com.hans.hansviewer.net

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Everything about network folders: the saved servers, remembered folder lists, downloaded
 * photos and thumbnails. Thumbnails are only made for photos you view, or by "Make thumbnails",
 * because reading every photo over the internet just to browse would be far too slow.
 */
object RemoteRepo {
    private lateinit var app: Context
    private lateinit var secrets: Secrets
    private val clients = ConcurrentHashMap<String, RemoteFs>()
    private val listLocks = ConcurrentHashMap<String, Mutex>()
    private val fileLocks = ConcurrentHashMap<String, Mutex>()

    /** Goes up by one whenever a new thumbnail is ready, so the grid can show it. */
    val thumbTick = MutableStateFlow(0)
    /** "Make thumbnails" progress for the status line, or null when idle. */
    val progress = MutableStateFlow<String?>(null)
    /** True while the viewer shows a network photo: background thumbnails wait meanwhile. */
    @Volatile var viewerBusy = false
    @Volatile var thumbsPaused = false

    private const val PHOTO_CACHE_MAX = 1_000_000_000L   // downloaded photos kept: up to 1 GB
    private const val THUMB_EDGE = 320
    private var downloads = 0

    fun init(context: Context) {
        if (::app.isInitialized) return
        app = context.applicationContext
        secrets = Secrets(app)
        // folder lists from before they were kept per connection
        runCatching { File(app.filesDir, "netlists").listFiles()?.filter { it.isFile }?.forEach { it.delete() } }
    }

    private val prefs get() = app.getSharedPreferences("hansviewer", Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ servers
    @Volatile private var serverCache: List<Server>? = null

    fun servers(): List<Server> = serverCache ?: loadServers().also { serverCache = it }

    private fun loadServers(): List<Server> = runCatching {
        val a = JSONArray(prefs.getString("net_servers", "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Server(o.getString("id"), o.optString("alias"), o.getString("url"), o.optString("root", "/"),
                o.optString("user"), o.optBoolean("trust", false),
                o.optString("type", TYPE_WEBDAV).ifEmpty { TYPE_WEBDAV }, o.optString("domain"))
        }
    }.getOrDefault(emptyList())

    fun saveServers(list: List<Server>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("alias", it.alias).put("url", it.url)
                .put("root", it.root).put("user", it.user).put("trust", it.trustCert)
                .put("type", it.type).put("domain", it.domain))
        }
        prefs.edit().putString("net_servers", a.toString()).apply()
        serverCache = list
        dropClients()
    }

    fun server(id: String): Server? = servers().firstOrNull { it.id == id }

    fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    fun password(id: String): String? = secrets.get("pw_$id")
    fun setPassword(id: String, pw: String?) { secrets.put("pw_$id", pw); clients.remove(id)?.close() }

    private fun dropClients() {
        val old = clients.values.toList()
        clients.clear()
        old.forEach { runCatching { it.close() } }
    }

    private fun makeFs(s: Server, password: String?): RemoteFs =
        if (s.isSmb) SmbFs(s, password) else WebDav(s, password)

    fun upsert(s: Server, password: String?, keepPassword: Boolean) {
        val list = servers().filter { it.id != s.id } + s
        saveServers(list)
        if (!keepPassword) setPassword(s.id, password)
    }

    /** Removes a connection with everything belonging to it: password, remembered lists, open jobs. */
    fun remove(id: String) {
        saveServers(servers().filter { it.id != id })
        setPassword(id, null)
        runCatching { File(app.filesDir, "netlists/$id").deleteRecursively() }
        saveQueue(queue().filterNot { it.serverId == id })
    }

    private fun fs(id: String): RemoteFs {
        clients[id]?.let { return it }
        val s = server(id) ?: throw NetError("This server is no longer in the list")
        return makeFs(s, password(id)).also { clients[id] = it }
    }

    /** Runs [block] with the server's connection; a broken connection is opened again once. */
    private fun <T> withFs(id: String, block: (RemoteFs) -> T): T = try {
        block(fs(id))
    } catch (e: NetError) {
        throw e
    } catch (e: Exception) {
        clients.remove(id)?.let { runCatching { it.close() } }
        try {
            block(fs(id))
        } catch (e2: NetError) {
            throw e2
        } catch (e2: Exception) {
            throw NetError(e2.message ?: e2.javaClass.simpleName)
        }
    }

    /** Tries a server's settings before saving them. Returns an error message, or null when it works. */
    fun test(s: Server, password: String?): String? {
        val fs = makeFs(s, password)
        // at most 40 seconds: a NAS that doesn't answer gets a clear message instead of endless waiting
        val result = java.util.concurrent.atomic.AtomicReference<String?>("\u0000")
        val t = Thread {
            result.set(try {
                fs.list(s.root)
                null
            } catch (e: Throwable) {
                e.message ?: e.javaClass.simpleName
            })
        }
        t.isDaemon = true
        t.start()
        t.join(40_000)
        val r = result.get()
        if (r == "\u0000") {
            Thread { runCatching { fs.close() } }.start()
            return "The NAS did not answer within 40 seconds. Check the address, and that this device is on the same network."
        }
        runCatching { fs.close() }
        return r
    }

    // ------------------------------------------------------------------ folder lists
    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** Remembered folder lists, one folder per connection (so removing a connection removes them). */
    private fun listFile(id: String, path: String) =
        File(app.filesDir, "netlists/$id/${md5("$id|${normPath(path)}")}.json")

    /** Forgets a remembered folder list (after the server refused it or it no longer exists). */
    fun forgetList(id: String, path: String) { runCatching { listFile(id, path).delete() } }

    /** The folder as it was on the last visit (shown at once), or null. */
    fun listCached(id: String, path: String): List<RemoteEntry>? = runCatching {
        val o = JSONObject(listFile(id, path).readText())
        val a = o.getJSONArray("e")
        (0 until a.length()).map { i ->
            val e = a.getJSONArray(i)
            val name = e.getString(0)
            RemoteEntry(name, normPath(normPath(path) + "/" + name), e.getBoolean(1), e.getLong(2), e.getLong(3))
        }
    }.getOrNull()

    private fun saveList(id: String, path: String, entries: List<RemoteEntry>) {
        runCatching {
            val a = JSONArray()
            entries.forEach { a.put(JSONArray().put(it.name).put(it.isDir).put(it.size).put(it.modified)) }
            val f = listFile(id, path)
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            tmp.writeText(JSONObject().put("t", System.currentTimeMillis()).put("e", a).toString())
            tmp.renameTo(f)
        }
    }

    /** Reads a folder from the server (one request at a time per folder) and remembers it. */
    suspend fun list(id: String, path: String): List<RemoteEntry> {
        val key = "$id|${normPath(path)}"
        val lock = listLocks.getOrPut(key) { Mutex() }
        return lock.withLock {
            withContext(Dispatchers.IO) {
                val entries = try {
                    withFs(id) { it.list(path) }
                } catch (e: AccessError) {
                    forgetList(id, path)   // don't keep showing what may no longer be allowed
                    throw e
                }
                saveList(id, path, entries)
                // thumbnails made before: make them findable from the other connections as well
                for (e in entries) {
                    if (!e.isDir) share(thumbFile(id, e.path, e.size, e.modified), e.path, e.size)
                }
                entries
            }
        }
    }

    // ------------------------------------------------------------------ photos and thumbnails
    private fun fileKey(id: String, path: String, size: Long, modified: Long) = md5("$id|$path|$size|$modified")

    fun thumbFile(id: String, path: String, size: Long, modified: Long) =
        File(app.filesDir, "netthumbs/${fileKey(id, path, size, modified)}.jpg")

    /**
     * The same photo on another connection (e.g. your external NAS by WebDAV and the local NAS by
     * SMB, holding copies): same share, folders, name and size share one thumbnail.
     */
    private fun sharedFile(path: String, size: Long) =
        File(app.filesDir, "netthumbs/shared/${md5("shared|${normPath(path).lowercase()}|$size")}.jpg")

    /** The thumbnail of this photo: made on this connection, or for the same photo on another one. */
    fun existingThumb(id: String, path: String, size: Long, modified: Long): File? {
        thumbFile(id, path, size, modified).let { if (it.exists()) return it }
        if (size <= 0) return null
        return sharedFile(path, size).takeIf { it.exists() }
    }

    /** Makes a thumbnail findable from the other connections too (a link, no extra space). */
    private fun share(own: File, path: String, size: Long) {
        if (size <= 0 || !own.exists()) return
        val shared = sharedFile(path, size)
        if (shared.exists()) return
        runCatching {
            shared.parentFile?.mkdirs()
            try {
                android.system.Os.link(own.path, shared.path)
            } catch (e: Exception) {
                own.copyTo(shared, overwrite = true)
            }
            val len = File(own.path + ".len")
            if (len.exists()) len.copyTo(File(shared.path + ".len"), overwrite = true)
        }
    }

    private fun photoFile(id: String, path: String, size: Long, modified: Long) =
        File(app.cacheDir, "netphotos/${fileKey(id, path, size, modified)}.${path.substringAfterLast('.', "img")}")

    private data class Ref(val id: String, val path: String, val size: Long, val modified: Long)

    private fun ref(uri: Uri) = Ref(
        uri.authority ?: "", normPath(uri.path ?: "/"),
        uri.getQueryParameter("s")?.toLongOrNull() ?: 0L, uri.getQueryParameter("m")?.toLongOrNull() ?: 0L,
    )

    fun thumbFor(uri: Uri): File? {
        if (uri.scheme != NET_SCHEME) return null
        val r = ref(uri)
        return existingThumb(r.id, r.path, r.size, r.modified)
    }

    fun hasThumb(id: String, e: RemoteEntry) = existingThumb(id, e.path, e.size, e.modified) != null

    /** A downloaded copy, if this photo was already fetched. */
    fun cachedFile(uri: Uri): File? {
        if (uri.scheme != NET_SCHEME) return null
        val r = ref(uri)
        return photoFile(r.id, r.path, r.size, r.modified).takeIf { it.exists() }
    }

    /** Downloads a photo (or returns the copy already here) and makes its thumbnail. */
    suspend fun download(uri: Uri): File {
        val r = ref(uri)
        val f = photoFile(r.id, r.path, r.size, r.modified)
        val lock = fileLocks.getOrPut(f.name) { Mutex() }
        return lock.withLock {
            withContext(Dispatchers.IO) {
                if (!f.exists()) {
                    f.parentFile?.mkdirs()
                    val tmp = File(f.path + ".part")
                    withFs(r.id) { fs ->
                        fs.openStream(r.path).use { input ->
                            tmp.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
                        }
                    }
                    if (!tmp.renameTo(f)) throw NetError("Could not store the photo")
                    if (++downloads % 20 == 0) trimPhotoCache()
                } else {
                    f.setLastModified(System.currentTimeMillis())  // recently used: kept longer
                }
                val t = thumbFile(r.id, r.path, r.size, r.modified)
                if (!t.exists() && thumbFromFile(f, t)) {
                    share(t, r.path, r.size)
                    thumbTick.value += 1
                }
                f
            }
        }
    }

    private fun trimPhotoCache() {
        val files = File(app.cacheDir, "netphotos").listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        if (total <= PHOTO_CACHE_MAX) return
        for (f in files.sortedBy { it.lastModified() }) {
            total -= f.length()
            f.delete()
            if (total <= PHOTO_CACHE_MAX * 9 / 10) break
        }
    }

    private fun orientation(exif: ExifInterface) =
        exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)

    private fun rotate(b: Bitmap, ori: Int): Bitmap {
        val m = Matrix()
        when (ori) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    private fun saveThumb(b: Bitmap, dest: File): Boolean = runCatching {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".tmp")
        tmp.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        tmp.renameTo(dest)
    }.getOrDefault(false)

    /** A small thumbnail from a downloaded photo (decoded at reduced size, turned upright). */
    fun thumbFromFile(src: File, dest: File): Boolean = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(src.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= THUMB_EDGE) sample *= 2
        val b = BitmapFactory.decodeFile(src.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return@runCatching false
        val upright = rotate(b, orientation(ExifInterface(src.path)))
        val scale = THUMB_EDGE.toFloat() / maxOf(upright.width, upright.height)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(
            upright, (upright.width * scale).toInt().coerceAtLeast(1), (upright.height * scale).toInt().coerceAtLeast(1), true
        ) else upright
        saveThumb(small, dest)
    }.getOrDefault(false)

    /**
     * For "Make thumbnails": first tries the small preview the camera stores inside the photo
     * (only the first 128 KB are fetched), and downloads the whole photo only when there is none.
     */
    suspend fun makeThumb(id: String, e: RemoteEntry): Boolean = withContext(Dispatchers.IO) {
        val dest = thumbFile(id, e.path, e.size, e.modified)
        if (existingThumb(id, e.path, e.size, e.modified) != null) return@withContext true
        if (isVideoName(e.name)) {
            // only the parts needed are read; a video that takes too long is skipped
            val ok = withTimeoutOrNull(120_000) { runInterruptible { videoThumb(id, e, dest) } } ?: false
            if (ok) {
                share(dest, e.path, e.size)
                thumbTick.value += 1
            }
            return@withContext ok
        }
        // the preview the camera stores in the photo: usually in the first 64 KB, else a bit more
        fun preview(limit: Int): Boolean = runCatching {
            val head = withFs(id) { it.readHead(e.path, limit) }
            val exif = ExifInterface(ByteArrayInputStream(head))
            val b = exif.thumbnailBitmap ?: return@runCatching false
            if (maxOf(b.width, b.height) < 120) return@runCatching false
            saveThumb(rotate(b, orientation(exif)), dest)
        }.getOrDefault(false)
        val quick = preview(64 * 1024) || (e.size > 64 * 1024 && preview(256 * 1024))
        if (quick) share(dest, e.path, e.size)
        val ok = quick || runCatching {
            val uri = netPhotoUri(id, e)
            download(uri)
            dest.exists()
        }.getOrDefault(false)
        if (ok) thumbTick.value += 1
        ok
    }

    // ------------------------------------------------------------------ network videos
    /** Reads a network file from [offset] on (video playback). Returns the stream and the file size. */
    fun openRange(uri: Uri, offset: Long): Pair<java.io.InputStream, Long> {
        val r = ref(uri)
        return withFs(r.id) { it.openRange(r.path, offset) } to r.size
    }

    /** The length (ms) of a network video, once its thumbnail was made; 0 when unknown. */
    fun durationFor(uri: Uri): Long {
        if (uri.scheme != NET_SCHEME) return 0
        val r = ref(uri)
        val thumb = existingThumb(r.id, r.path, r.size, r.modified) ?: return 0
        val f = File(thumb.path + ".len")
        return runCatching { f.readText().trim().toLong() }.getOrDefault(0L)
    }

    /** Lets Android's frame reader see a network video, fetching it in 512 KB blocks. */
    private class NetMediaSource(val id: String, val path: String, val total: Long) : android.media.MediaDataSource() {
        private val blocks = object : LinkedHashMap<Long, ByteArray>(16, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ByteArray>?) = size > 12
        }

        private fun block(index: Long): ByteArray = blocks.getOrPut(index) {
            val start = index * BLOCK
            val want = minOf(BLOCK.toLong(), total - start).toInt()
            val buf = ByteArray(want)
            RemoteRepo.withFsPublic(id) { fs ->
                fs.openRange(path, start).use { input ->
                    var n = 0
                    while (n < want) {
                        val r = input.read(buf, n, want - n)
                        if (r <= 0) break
                        n += r
                    }
                }
            }
            buf
        }

        override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
            if (position >= total) return -1
            var done = 0
            var pos = position
            while (done < size && pos < total) {
                val b = block(pos / BLOCK)
                val inBlock = (pos % BLOCK).toInt()
                if (inBlock >= b.size) break
                val n = minOf(size - done, b.size - inBlock)
                System.arraycopy(b, inBlock, buffer, offset + done, n)
                done += n
                pos += n
            }
            return if (done == 0) -1 else done
        }

        override fun getSize(): Long = total
        override fun close() { blocks.clear() }

        companion object { const val BLOCK = 512 * 1024 }
    }

    internal fun <T> withFsPublic(id: String, block: (RemoteFs) -> T): T = withFs(id, block)

    /** A still picture (and the length) of a network video, reading only the parts needed. */
    private fun videoThumb(id: String, e: RemoteEntry, dest: File): Boolean = runCatching {
        val mmr = android.media.MediaMetadataRetriever()
        try {
            mmr.setDataSource(NetMediaSource(id, e.path, e.size))
            val length = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val at = if (length > 3000) 1_000_000L else 0L
            val frame = mmr.getScaledFrameAtTime(at, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                THUMB_EDGE, THUMB_EDGE) ?: return@runCatching false
            val ok = saveThumb(frame, dest)
            if (ok && length > 0) File(dest.path + ".len").writeText(length.toString())
            ok
        } finally {
            runCatching { mmr.release() }
        }
    }.getOrDefault(false)

    private fun videoFile(r: Ref) =
        File(app.cacheDir, "netvideos/${fileKey(r.id, r.path, r.size, r.modified)}.${r.path.substringAfterLast('.', "mp4")}")

    /** Settings → "Download completely first": fetches the whole video, reporting progress (0..1). */
    suspend fun downloadVideo(uri: Uri, progress: (Float) -> Unit): File = withContext(Dispatchers.IO) {
        val scope = this
        val r = ref(uri)
        val f = videoFile(r)
        if (f.exists() && f.length() == r.size) {
            f.setLastModified(System.currentTimeMillis())
            return@withContext f
        }
        f.parentFile?.mkdirs()
        trimVideoCache()
        val tmp = File(f.path + ".part")
        withFs(r.id) { fs ->
            fs.openStream(r.path).use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(256 * 1024)
                    var have = 0L
                    while (true) {
                        scope.ensureActive()
                        val n = input.read(buf)
                        if (n <= 0) break
                        out.write(buf, 0, n)
                        have += n
                        if (r.size > 0) progress(have.toFloat() / r.size)
                    }
                }
            }
        }
        if (!tmp.renameTo(f)) throw NetError("Could not store the video")
        f
    }

    private fun trimVideoCache() {
        val files = File(app.cacheDir, "netvideos").listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        for (f in files.sortedBy { it.lastModified() }) {
            if (total <= 2_000_000_000L) break
            total -= f.length()
            f.delete()
        }
    }

    /** True for photos on SMB shares: on the home network their thumbnails are made while browsing. */
    fun isAutoThumb(uri: Uri): Boolean {
        if (uri.scheme != NET_SCHEME) return false
        return server(uri.authority ?: "")?.isSmb == true
    }

    private val autoGate = Semaphore(3)

    /** Makes the thumbnail of a photo on screen (SMB). Cancelled when the tile scrolls away. */
    suspend fun ensureThumb(uri: Uri) {
        val r = ref(uri)
        if (existingThumb(r.id, r.path, r.size, r.modified) != null) return
        autoGate.withPermit {
            makeThumb(r.id, RemoteEntry(r.path.substringAfterLast('/'), r.path, false, r.size, r.modified))
        }
    }

    // ------------------------------------------------------------------ changing files on the NAS
    suspend fun delete(id: String, path: String) = withContext(Dispatchers.IO) { withFs(id) { it.delete(path) } }

    /** Moves a file into [folder] on the same server. Returns the new path. */
    suspend fun moveInto(id: String, path: String, folder: String): String = withContext(Dispatchers.IO) {
        val to = normPath(normPath(folder) + "/" + path.substringAfterLast('/'))
        if (to != normPath(path)) withFs(id) { it.move(path, to) }
        to
    }

    /** Saves [file] into [folder] as [name] (or name_2, name_3… if taken). Returns the name used. */
    suspend fun uploadInto(id: String, folder: String, name: String, file: File): String = withContext(Dispatchers.IO) {
        val taken = runCatching { list(id, folder) }.getOrNull()?.map { it.name.lowercase() }?.toSet() ?: emptySet()
        val stem = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var candidate = name
        var n = 2
        while (candidate.lowercase() in taken) {
            candidate = "${stem}_$n" + if (ext.isNotEmpty()) ".$ext" else ""
            n++
        }
        withFs(id) { it.upload(normPath(normPath(folder) + "/" + candidate), file) }
        candidate
    }

    /** All folders inside [path] on a server (for "Move to"). */
    suspend fun foldersIn(id: String, path: String): List<RemoteEntry> =
        list(id, path).filter { it.isDir && !it.name.startsWith(".") && !it.name.startsWith("@") && it.name != "#recycle" }
            .sortedBy { it.name.lowercase() }

    // ------------------------------------------------------------------ "Make thumbnails" list
    data class QueueItem(val serverId: String, val path: String, val subfolders: Boolean)

    @Synchronized
    fun queue(): List<QueueItem> = runCatching {
        val a = JSONArray(prefs.getString("net_thumb_queue", "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            QueueItem(o.getString("id"), o.getString("path"), o.optBoolean("sub"))
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun saveQueue(items: List<QueueItem>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("id", it.serverId).put("path", it.path).put("sub", it.subfolders)) }
        prefs.edit().putString("net_thumb_queue", a.toString()).commit()
    }

    /** The folder asked for last goes first; a folder being worked on continues afterwards. */
    @Synchronized
    fun addToQueue(item: QueueItem) {
        val q = queue()
        val old = q.firstOrNull { it.serverId == item.serverId && it.path == item.path }
        val merged = item.copy(subfolders = item.subfolders || old?.subfolders == true)
        saveQueue(listOf(merged) + q.filterNot { it.serverId == item.serverId && it.path == item.path })
    }

    /** Files that could not be read in the folder being worked on (shown in the status line). */
    @Volatile var thumbErrors = 0
}
