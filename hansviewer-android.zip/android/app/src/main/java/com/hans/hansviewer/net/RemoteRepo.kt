package com.hans.hansviewer.net

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Everything about network folders: the saved servers, remembered folder lists, downloaded
 * photos and thumbnails. Thumbnails are only made for photos you view, or by "Make thumbnails",
 * because reading every photo over the internet just to browse would be far too slow.
 */
object RemoteRepo {
    private lateinit var app: Context
    private lateinit var secrets: Secrets
    private val clients = ConcurrentHashMap<String, WebDav>()
    private val listLocks = ConcurrentHashMap<String, Mutex>()
    private val fileLocks = ConcurrentHashMap<String, Mutex>()

    /** Goes up by one whenever a new thumbnail is ready, so the grid can show it. */
    val thumbTick = MutableStateFlow(0)
    /** "Make thumbnails" progress for the status line, or null when idle. */
    val progress = MutableStateFlow<String?>(null)
    /** True while the viewer shows a network photo: background thumbnails wait meanwhile. */
    @Volatile var viewerBusy = false
    @Volatile var thumbsPaused = false

    private const val PHOTO_CACHE_MAX = 1_000_000_000L   // downloaded photos kept: up to 1 GB
    private const val THUMB_EDGE = 320
    private var downloads = 0

    fun init(context: Context) {
        if (::app.isInitialized) return
        app = context.applicationContext
        secrets = Secrets(app)
    }

    private val prefs get() = app.getSharedPreferences("hansviewer", Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ servers
    fun servers(): List<Server> = runCatching {
        val a = JSONArray(prefs.getString("net_servers", "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Server(o.getString("id"), o.optString("alias"), o.getString("url"), o.optString("root", "/"),
                o.optString("user"), o.optBoolean("trust", false))
        }
    }.getOrDefault(emptyList())

    fun saveServers(list: List<Server>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("alias", it.alias).put("url", it.url)
                .put("root", it.root).put("user", it.user).put("trust", it.trustCert))
        }
        prefs.edit().putString("net_servers", a.toString()).apply()
        clients.clear()
    }

    fun server(id: String): Server? = servers().firstOrNull { it.id == id }

    fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    fun password(id: String): String? = secrets.get("pw_$id")
    fun setPassword(id: String, pw: String?) { secrets.put("pw_$id", pw); clients.remove(id) }

    fun upsert(s: Server, password: String?, keepPassword: Boolean) {
        val list = servers().filter { it.id != s.id } + s
        saveServers(list)
        if (!keepPassword) setPassword(s.id, password)
    }

    fun remove(id: String) {
        saveServers(servers().filter { it.id != id })
        setPassword(id, null)
    }

    private fun dav(id: String): WebDav {
        clients[id]?.let { return it }
        val s = server(id) ?: throw NetError("This server is no longer in the list")
        return WebDav(s, password(id)).also { clients[id] = it }
    }

    /** Tries a server's settings before saving them. Returns an error message, or null when it works. */
    fun test(s: Server, password: String?): String? = runCatching {
        WebDav(s, password).list(s.root)
        null
    }.getOrElse { it.message ?: "Could not connect" }

    // ------------------------------------------------------------------ folder lists
    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun listFile(id: String, path: String) =
        File(app.filesDir, "netlists/${md5("$id|${normPath(path)}")}.json")

    /** The folder as it was on the last visit (shown at once), or null. */
    fun listCached(id: String, path: String): List<RemoteEntry>? = runCatching {
        val o = JSONObject(listFile(id, path).readText())
        val a = o.getJSONArray("e")
        (0 until a.length()).map { i ->
            val e = a.getJSONArray(i)
            val name = e.getString(0)
            RemoteEntry(name, normPath(normPath(path) + "/" + name), e.getBoolean(1), e.getLong(2), e.getLong(3))
        }
    }.getOrNull()

    private fun saveList(id: String, path: String, entries: List<RemoteEntry>) {
        runCatching {
            val a = JSONArray()
            entries.forEach { a.put(JSONArray().put(it.name).put(it.isDir).put(it.size).put(it.modified)) }
            val f = listFile(id, path)
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            tmp.writeText(JSONObject().put("t", System.currentTimeMillis()).put("e", a).toString())
            tmp.renameTo(f)
        }
    }

    /** Reads a folder from the server (one request at a time per folder) and remembers it. */
    suspend fun list(id: String, path: String): List<RemoteEntry> {
        val key = "$id|${normPath(path)}"
        val lock = listLocks.getOrPut(key) { Mutex() }
        return lock.withLock {
            withContext(Dispatchers.IO) {
                val entries = dav(id).list(path)
                saveList(id, path, entries)
                entries
            }
        }
    }

    // ------------------------------------------------------------------ photos and thumbnails
    private fun fileKey(id: String, path: String, size: Long, modified: Long) = md5("$id|$path|$size|$modified")

    fun thumbFile(id: String, path: String, size: Long, modified: Long) =
        File(app.filesDir, "netthumbs/${fileKey(id, path, size, modified)}.jpg")

    private fun photoFile(id: String, path: String, size: Long, modified: Long) =
        File(app.cacheDir, "netphotos/${fileKey(id, path, size, modified)}.${path.substringAfterLast('.', "img")}")

    private data class Ref(val id: String, val path: String, val size: Long, val modified: Long)

    private fun ref(uri: Uri) = Ref(
        uri.authority ?: "", normPath(uri.path ?: "/"),
        uri.getQueryParameter("s")?.toLongOrNull() ?: 0L, uri.getQueryParameter("m")?.toLongOrNull() ?: 0L,
    )

    fun thumbFor(uri: Uri): File? {
        if (uri.scheme != NET_SCHEME) return null
        val r = ref(uri)
        return thumbFile(r.id, r.path, r.size, r.modified).takeIf { it.exists() }
    }

    fun hasThumb(id: String, e: RemoteEntry) = thumbFile(id, e.path, e.size, e.modified).exists()

    /** A downloaded copy, if this photo was already fetched. */
    fun cachedFile(uri: Uri): File? {
        if (uri.scheme != NET_SCHEME) return null
        val r = ref(uri)
        return photoFile(r.id, r.path, r.size, r.modified).takeIf { it.exists() }
    }

    /** Downloads a photo (or returns the copy already here) and makes its thumbnail. */
    suspend fun download(uri: Uri): File {
        val r = ref(uri)
        val f = photoFile(r.id, r.path, r.size, r.modified)
        val lock = fileLocks.getOrPut(f.name) { Mutex() }
        return lock.withLock {
            withContext(Dispatchers.IO) {
                if (!f.exists()) {
                    f.parentFile?.mkdirs()
                    val tmp = File(f.path + ".part")
                    dav(r.id).open(r.path).use { resp ->
                        val body = resp.body ?: throw NetError("The server sent no data")
                        tmp.outputStream().use { out -> body.byteStream().use { it.copyTo(out, 256 * 1024) } }
                    }
                    if (!tmp.renameTo(f)) throw NetError("Could not store the photo")
                    if (++downloads % 20 == 0) trimPhotoCache()
                } else {
                    f.setLastModified(System.currentTimeMillis())  // recently used: kept longer
                }
                val t = thumbFile(r.id, r.path, r.size, r.modified)
                if (!t.exists() && thumbFromFile(f, t)) thumbTick.value += 1
                f
            }
        }
    }

    private fun trimPhotoCache() {
        val files = File(app.cacheDir, "netphotos").listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        if (total <= PHOTO_CACHE_MAX) return
        for (f in files.sortedBy { it.lastModified() }) {
            total -= f.length()
            f.delete()
            if (total <= PHOTO_CACHE_MAX * 9 / 10) break
        }
    }

    private fun orientation(exif: ExifInterface) =
        exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)

    private fun rotate(b: Bitmap, ori: Int): Bitmap {
        val m = Matrix()
        when (ori) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    private fun saveThumb(b: Bitmap, dest: File): Boolean = runCatching {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".tmp")
        tmp.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        tmp.renameTo(dest)
    }.getOrDefault(false)

    /** A small thumbnail from a downloaded photo (decoded at reduced size, turned upright). */
    fun thumbFromFile(src: File, dest: File): Boolean = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(src.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= THUMB_EDGE) sample *= 2
        val b = BitmapFactory.decodeFile(src.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return@runCatching false
        val upright = rotate(b, orientation(ExifInterface(src.path)))
        val scale = THUMB_EDGE.toFloat() / maxOf(upright.width, upright.height)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(
            upright, (upright.width * scale).toInt().coerceAtLeast(1), (upright.height * scale).toInt().coerceAtLeast(1), true
        ) else upright
        saveThumb(small, dest)
    }.getOrDefault(false)

    /**
     * For "Make thumbnails": first tries the small preview the camera stores inside the photo
     * (only the first 128 KB are fetched), and downloads the whole photo only when there is none.
     */
    suspend fun makeThumb(id: String, e: RemoteEntry): Boolean = withContext(Dispatchers.IO) {
        val dest = thumbFile(id, e.path, e.size, e.modified)
        if (dest.exists()) return@withContext true
        val quick = runCatching {
            val head = dav(id).open(e.path, maxBytes = 128 * 1024L).use { it.body?.bytes() } ?: return@runCatching false
            val exif = ExifInterface(ByteArrayInputStream(head))
            val b = exif.thumbnailBitmap ?: return@runCatching false
            if (maxOf(b.width, b.height) < 120) return@runCatching false
            saveThumb(rotate(b, orientation(exif)), dest)
        }.getOrDefault(false)
        val ok = quick || runCatching {
            val uri = netPhotoUri(id, e)
            download(uri)
            dest.exists()
        }.getOrDefault(false)
        if (ok) thumbTick.value += 1
        ok
    }

    // ------------------------------------------------------------------ "Make thumbnails" list
    data class QueueItem(val serverId: String, val path: String, val subfolders: Boolean)

    @Synchronized
    fun queue(): List<QueueItem> = runCatching {
        val a = JSONArray(prefs.getString("net_thumb_queue", "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            QueueItem(o.getString("id"), o.getString("path"), o.optBoolean("sub"))
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun saveQueue(items: List<QueueItem>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("id", it.serverId).put("path", it.path).put("sub", it.subfolders)) }
        prefs.edit().putString("net_thumb_queue", a.toString()).commit()
    }

    @Synchronized
    fun addToQueue(item: QueueItem) {
        val q = queue()
        if (q.none { it.serverId == item.serverId && it.path == item.path && (it.subfolders || !item.subfolders) }) {
            saveQueue(q.filterNot { it.serverId == item.serverId && it.path == item.path } + item)
        }
    }
}
