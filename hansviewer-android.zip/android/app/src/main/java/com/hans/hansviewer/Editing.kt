package com.hans.hansviewer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Edits are kept as a list of operations instead of pixel copies. The screen preview applies
 * them to a small image; saving applies the same list to the full-size photo. This keeps memory
 * low and makes undo instant.
 */
sealed interface EditOp {
    data class Rotate(val degrees: Int) : EditOp
    data class Flip(val horizontal: Boolean) : EditOp
    /** Normalised 0..1 rectangle of the image as it looks at this step. */
    data class Crop(val l: Float, val t: Float, val r: Float, val b: Float) : EditOp
    data class Resize(val fx: Float, val fy: Float) : EditOp
    class Colour(val m: FloatArray) : EditOp
    /** Blurs or pixelates one area (normalised 0..1 of the image at this step), e.g. a number plate. */
    data class Blur(val l: Float, val t: Float, val r: Float, val b: Float, val pixelate: Boolean, val strength: Int) : EditOp
}

fun applyOps(src: Bitmap, ops: List<EditOp>, forPreview: Boolean): Bitmap {
    var b = src
    for (op in ops) {
        if (forPreview && op is EditOp.Resize) continue  // resizing doesn't change how it looks
        b = applyOp(b, op)
    }
    return b
}

fun applyOp(b: Bitmap, op: EditOp): Bitmap = when (op) {
    is EditOp.Rotate -> {
        val m = Matrix().apply { postRotate(op.degrees.toFloat()) }
        Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }
    is EditOp.Flip -> {
        val m = Matrix().apply { if (op.horizontal) preScale(-1f, 1f) else preScale(1f, -1f) }
        Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }
    is EditOp.Crop -> {
        val x = (op.l * b.width).roundToInt().coerceIn(0, b.width - 1)
        val y = (op.t * b.height).roundToInt().coerceIn(0, b.height - 1)
        val w = ((op.r - op.l) * b.width).roundToInt().coerceIn(1, b.width - x)
        val h = ((op.b - op.t) * b.height).roundToInt().coerceIn(1, b.height - y)
        Bitmap.createBitmap(b, x, y, w, h)
    }
    is EditOp.Resize -> Bitmap.createScaledBitmap(
        b, max(1, (b.width * op.fx).roundToInt()), max(1, (b.height * op.fy).roundToInt()), true)
    is EditOp.Colour -> {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(op.m) }
        Canvas(out).drawBitmap(b, 0f, 0f, paint)
        out
    }
    is EditOp.Blur -> blurArea(b, op)
}

/**
 * Blurs or pixelates one rectangle. The strength (1..100) is relative to the size of the area, so
 * the small preview and the saved full-size photo look the same. Same method as on the desktop.
 */
fun blurArea(b: Bitmap, op: EditOp.Blur): Bitmap {
    val x = (op.l * b.width).roundToInt().coerceIn(0, b.width - 1)
    val y = (op.t * b.height).roundToInt().coerceIn(0, b.height - 1)
    val w = ((op.r - op.l) * b.width).roundToInt().coerceIn(1, b.width - x)
    val h = ((op.b - op.t) * b.height).roundToInt().coerceIn(1, b.height - y)
    if (w < 2 || h < 2) return b
    val out = b.copy(Bitmap.Config.ARGB_8888, true)
    var part = Bitmap.createBitmap(out, x, y, w, h)
    val block = max(2f, minOf(w, h) * (0.04f + 0.36f * op.strength.coerceIn(1, 100) / 100f))
    val sw = max(1, (w / block).roundToInt())
    val sh = max(1, (h / block).roundToInt())
    if (op.pixelate) {
        val small = Bitmap.createScaledBitmap(part, sw, sh, true)
        part = Bitmap.createScaledBitmap(small, w, h, false)
    } else {
        for (k in 0 until 3) {   // repeated down/up scaling: a soft blur with no detail left
            val f = 1f + 0.35f * k
            val small = Bitmap.createScaledBitmap(part, max(1, (sw * f).roundToInt()), max(1, (sh * f).roundToInt()), true)
            part = Bitmap.createScaledBitmap(small, w, h, true)
        }
    }
    Canvas(out).drawBitmap(part, x.toFloat(), y.toFloat(), null)
    return out
}

/** Size of the finished picture, worked out without touching any pixels. */
fun dimsAfter(w0: Int, h0: Int, ops: List<EditOp>): Pair<Int, Int> {
    var w = w0
    var h = h0
    for (op in ops) when (op) {
        is EditOp.Rotate -> if (op.degrees % 180 != 0) { val t = w; w = h; h = t }
        is EditOp.Crop -> {
            w = max(1, ((op.r - op.l) * w).roundToInt())
            h = max(1, ((op.b - op.t) * h).roundToInt())
        }
        is EditOp.Resize -> {
            w = max(1, (w * op.fx).roundToInt())
            h = max(1, (h * op.fy).roundToInt())
        }
        else -> Unit
    }
    return w to h
}

/** Brightness, contrast, saturation and warmth, each -100..100 (same maths as the desktop app). */
fun adjustMatrix(brightness: Float, contrast: Float, saturation: Float, warmth: Float): FloatArray {
    val cm = ColorMatrix()
    if (saturation != 0f) cm.setSaturation(1f + saturation / 100f)
    if (contrast != 0f) {
        val c = contrast * 2.55f
        val f = (259f * (c + 255f)) / (255f * (259f - c))
        val t = 128f * (1f - f)
        cm.postConcat(ColorMatrix(floatArrayOf(f, 0f, 0f, 0f, t, 0f, f, 0f, 0f, t, 0f, 0f, f, 0f, t, 0f, 0f, 0f, 1f, 0f)))
    }
    if (brightness != 0f) {
        val t = brightness * 1.5f
        cm.postConcat(ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, t, 0f, 1f, 0f, 0f, t, 0f, 0f, 1f, 0f, t, 0f, 0f, 0f, 1f, 0f)))
    }
    if (warmth != 0f) {
        val t = warmth * 0.5f
        cm.postConcat(ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, t, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, -t, 0f, 0f, 0f, 1f, 0f)))
    }
    return cm.array.copyOf()
}

val GRAYSCALE: FloatArray = ColorMatrix().apply { setSaturation(0f) }.array.copyOf()
val SEPIA = floatArrayOf(
    0.393f, 0.769f, 0.189f, 0f, 0f,
    0.349f, 0.686f, 0.168f, 0f, 0f,
    0.272f, 0.534f, 0.131f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f)
val INVERT = floatArrayOf(
    -1f, 0f, 0f, 0f, 255f,
    0f, -1f, 0f, 0f, 255f,
    0f, 0f, -1f, 0f, 255f,
    0f, 0f, 0f, 1f, 0f)

/** Stretches each colour channel so the darkest/brightest 0.5% become black/white. */
fun autoLevelsMatrix(b: Bitmap): FloatArray {
    val small = if (max(b.width, b.height) > 400) {
        val s = 400f / max(b.width, b.height)
        Bitmap.createScaledBitmap(b, max(1, (b.width * s).toInt()), max(1, (b.height * s).toInt()), true)
    } else b
    val px = IntArray(small.width * small.height)
    small.getPixels(px, 0, small.width, 0, 0, small.width, small.height)
    val hist = Array(3) { IntArray(256) }
    for (p in px) {
        hist[0][(p shr 16) and 0xff]++
        hist[1][(p shr 8) and 0xff]++
        hist[2][p and 0xff]++
    }
    val cut = (px.size * 0.005).toInt()
    val scale = FloatArray(3)
    val shift = FloatArray(3)
    for (ch in 0..2) {
        var acc = 0
        var lo = 0
        while (lo < 255 && acc + hist[ch][lo] <= cut) { acc += hist[ch][lo]; lo++ }
        acc = 0
        var hi = 255
        while (hi > 0 && acc + hist[ch][hi] <= cut) { acc += hist[ch][hi]; hi-- }
        val range = max(1, hi - lo).toFloat()
        scale[ch] = 255f / range
        shift[ch] = -lo * scale[ch]
    }
    return floatArrayOf(
        scale[0], 0f, 0f, 0f, shift[0],
        0f, scale[1], 0f, 0f, shift[1],
        0f, 0f, scale[2], 0f, shift[2],
        0f, 0f, 0f, 1f, 0f)
}
