package com.hans.hansviewer.net

import android.net.Uri
import android.util.Xml
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.InputStream
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class NetError(message: String) : IOException(message)

/**
 * A small WebDAV client: lists a folder with one request (PROPFIND, depth 1) and downloads files.
 * Big folders can take the server a minute or two the first time, so the time limits are generous.
 */
class WebDav(private val server: Server, password: String?) : RemoteFs {
    private val auth: String? =
        if (server.user.isNotEmpty()) Credentials.basic(server.user, password ?: "", Charsets.UTF_8) else null
    private val basePath: String = normPath(Uri.parse(server.url).path ?: "/")
    private val client: OkHttpClient = buildClient(server.trustCert)

    /** The full address of a path on the server, with each part properly encoded. */
    fun urlFor(path: String, folder: Boolean = false): String {
        val base = server.url.trimEnd('/').let { u ->
            // the server address may already contain a folder (e.g. https://host/webdav)
            val p = Uri.parse(u)
            "${p.scheme}://${p.encodedAuthority}"
        }
        val full = normPath(if (basePath == "/") path else basePath + normPath(path))
        val encoded = full.split('/').joinToString("/") { if (it.isEmpty()) "" else Uri.encode(it) }
        return base + encoded + if (folder && !encoded.endsWith("/")) "/" else ""
    }

    private fun request(url: String) = Request.Builder().url(url).apply {
        auth?.let { header("Authorization", it) }
        header("User-Agent", "HansViewer")
    }

    private fun check(r: Response) {
        if (r.isSuccessful) return
        val code = r.code
        r.close()
        throw NetError(
            when (code) {
                401 -> "The user name or password was not accepted"
                403 -> "The server refused access to this folder"
                404 -> "This folder no longer exists on the server"
                405 -> "This address is not a WebDAV folder"
                else -> "The server answered with error $code"
            }
        )
    }

    /** The contents of a folder (one request, like the file manager). */
    override fun list(path: String): List<RemoteEntry> {
        val body = PROPFIND_BODY.toRequestBody("application/xml; charset=utf-8".toMediaType())
        val req = request(urlFor(path, folder = true))
            .method("PROPFIND", body)
            .header("Depth", "1")
            .build()
        val resp = try {
            client.newCall(req).execute()
        } catch (e: javax.net.ssl.SSLException) {
            throw NetError("The server's certificate was not accepted. Edit the server and tick " +
                "“Trust this server's certificate”.")
        }
        check(resp)
        resp.use { r ->
            val stream = r.body?.byteStream() ?: return emptyList()
            return parse(stream, normPath(path))
        }
    }

    private fun parse(stream: InputStream, self: String): List<RemoteEntry> {
        val out = ArrayList<RemoteEntry>()
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
        parser.setInput(stream, null)
        val dateFmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("GMT")
        }
        var href: String? = null
        var isDir = false
        var size = 0L
        var modified = 0L
        var field: String? = null
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "response" -> { href = null; isDir = false; size = 0L; modified = 0L }
                    "collection" -> isDir = true
                    "href", "getcontentlength", "getlastmodified" -> field = parser.name
                }
                XmlPullParser.TEXT -> {
                    val t = parser.text?.trim().orEmpty()
                    when (field) {
                        "href" -> href = (href ?: "") + t
                        "getcontentlength" -> size = t.toLongOrNull() ?: 0L
                        "getlastmodified" -> modified = runCatching { dateFmt.parse(t)?.time }.getOrNull() ?: 0L
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == field) field = null
                    if (parser.name == "response") {
                        val h = href
                        if (h != null) {
                            val path = hrefToPath(h)
                            if (path != self && path != "/") {
                                val name = path.substringAfterLast('/')
                                if (name.isNotEmpty()) out += RemoteEntry(name, path, isDir, size, modified)
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }
        return out
    }

    private fun hrefToPath(href: String): String {
        val raw = if (href.startsWith("http://") || href.startsWith("https://")) {
            Uri.parse(href).encodedPath ?: href
        } else href
        var p = normPath(Uri.decode(raw))
        if (basePath != "/" && (p == basePath || p.startsWith("$basePath/"))) {
            p = normPath(p.removePrefix(basePath))
        }
        return p
    }

    /** Opens a file for reading. With [maxBytes], only the beginning is fetched (for EXIF previews). */
    fun open(path: String, maxBytes: Long? = null): Response {
        val req = request(urlFor(path)).apply {
            if (maxBytes != null) header("Range", "bytes=0-${maxBytes - 1}")
        }.get().build()
        val resp = client.newCall(req).execute()
        check(resp)
        return resp
    }

    override fun openStream(path: String): InputStream {
        val r = open(path)
        val body = r.body ?: run { r.close(); throw NetError("The server sent no data") }
        return object : java.io.FilterInputStream(body.byteStream()) {
            override fun close() {
                runCatching { super.close() }
                r.close()
            }
        }
    }

    override fun openRange(path: String, offset: Long): InputStream {
        val req = request(urlFor(path)).apply {
            if (offset > 0) header("Range", "bytes=$offset-")
        }.get().build()
        val r = client.newCall(req).execute()
        check(r)
        val body = r.body ?: run { r.close(); throw NetError("The server sent no data") }
        val stream = body.byteStream()
        if (offset > 0 && r.code != 206) stream.skip(offset)  // server ignored the range: skip ahead
        return object : java.io.FilterInputStream(stream) {
            override fun close() {
                runCatching { super.close() }
                r.close()
            }
        }
    }

    override fun readHead(path: String, max: Int): ByteArray =
        open(path, max.toLong()).use { it.body?.bytes() ?: ByteArray(0) }

    companion object {
        private const val PROPFIND_BODY = """<?xml version="1.0" encoding="utf-8"?>
<d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getcontentlength/><d:getlastmodified/></d:prop></d:propfind>"""

        private val plain: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(300, TimeUnit.SECONDS)  // a big folder can take the server minutes
                .writeTimeout(60, TimeUnit.SECONDS)
                .build()
        }

        private val trusting: OkHttpClient by lazy {
            val trustAll = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ssl = SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(trustAll), SecureRandom()) }
            plain.newBuilder()
                .sslSocketFactory(ssl.socketFactory, trustAll)
                .hostnameVerifier { _, _ -> true }
                .build()
        }

        fun buildClient(trustCert: Boolean): OkHttpClient = if (trustCert) trusting else plain
    }
}
