package com.hans.hansviewer

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.hans.hansviewer.net.NetFetcher
import com.hans.hansviewer.net.RemoteRepo

class HansApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        RemoteRepo.init(this)
    }

    /** The image library also understands network photos. */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components { add(NetFetcher.Factory()) }
        .crossfade(true)
        .build()
}
