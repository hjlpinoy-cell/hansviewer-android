package com.hans.hansviewer

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.hans.hansviewer.net.NetFetcher
import com.hans.hansviewer.net.RemoteRepo

class HansApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        installCrashReport()
        RemoteRepo.init(this)
    }

    /** If HansViewer ever closes because of an error, the details are kept and shown at the next start. */
    private fun installCrashReport() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull()
                val text = buildString {
                    append("HansViewer ").append(version ?: "?").append("  ·  Android ")
                        .append(android.os.Build.VERSION.RELEASE).append("  ·  ").append(android.os.Build.MODEL)
                        .append("\n").append(java.util.Date().toString()).append("  ·  thread ").append(thread.name)
                        .append("\n\n").append(android.util.Log.getStackTraceString(error))
                }
                java.io.File(filesDir, CRASH_FILE).writeText(text)
            }
            previous?.uncaughtException(thread, error)
        }
    }

    companion object {
        const val CRASH_FILE = "last-crash.txt"
    }

    /** The image library also understands network photos. */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components {
            add(NetFetcher.Factory())
            add(MediaThumbFetcher.Factory(this@HansApp))
        }
        .crossfade(true)
        .build()
}
