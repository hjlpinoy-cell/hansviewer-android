package com.hans.hansviewer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A favourite folder. [label] is the user's own name for it, or null for the folder's name. */
data class Favourite(val key: String, val label: String?)

/** Small wrapper around SharedPreferences for everything HansViewer remembers. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("hansviewer", Context.MODE_PRIVATE)

    private fun str(key: String, def: String) = sp.getString(key, def) ?: def
    private fun put(key: String, v: String?) = sp.edit().putString(key, v).apply()
    private fun putInt(key: String, v: Int) = sp.edit().putInt(key, v).apply()
    private fun putBool(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()

    var theme: String
        get() = str("theme", "dark")
        set(v) = put("theme", v)

    var sortKey: String
        get() = str("sort_key", "taken")
        set(v) = put("sort_key", v)

    var sortDesc: Boolean
        get() = sp.getBoolean("sort_desc", true)
        set(v) = putBool("sort_desc", v)

    var gridSize: Int
        get() = sp.getInt("grid_size", 150)
        set(v) = putInt("grid_size", v)

    var slideshowSecs: Int
        get() = sp.getInt("slideshow_secs", 4)
        set(v) = putInt("slideshow_secs", v)

    var jpegQuality: Int
        get() = sp.getInt("jpeg_quality", 92)
        set(v) = putInt("jpeg_quality", v)

    var confirmDelete: Boolean
        get() = sp.getBoolean("confirm_delete", true)
        set(v) = putBool("confirm_delete", v)

    /** Brighter screen while a photo is open in the viewer. */
    var brightView: Boolean
        get() = sp.getBoolean("bright_view", true)
        set(v) = putBool("bright_view", v)

    var brightLevel: Int
        get() = sp.getInt("bright_level", 99)
        set(v) = putInt("bright_level", v)

    var showVideos: Boolean
        get() = sp.getBoolean("show_videos", true)
        set(v) = putBool("show_videos", v)

    /** Network videos: download completely before playing (for slow connections). */
    var videoDownloadFirst: Boolean
        get() = sp.getBoolean("video_download_first", false)
        set(v) = putBool("video_download_first", v)

    /** true = delete permanently, false = move to Android's Recycle bin. */
    var deletePermanently: Boolean
        get() = sp.getBoolean("delete_permanently", false)
        set(v) = putBool("delete_permanently", v)

    var lastFolder: String?
        get() = sp.getString("last_folder", null)
        set(v) = put("last_folder", v)

    var favourites: List<Favourite>
        get() = runCatching {
            val a = JSONArray(str("favourites", "[]"))
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Favourite(o.getString("key"), o.optString("label").ifEmpty { null })
            }
        }.getOrDefault(emptyList())
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("key", it.key).put("label", it.label ?: "")) }
            put("favourites", a.toString())
        }

    var expanded: Set<String>
        get() = sp.getStringSet("expanded", emptySet())?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("expanded", v).apply()
}
