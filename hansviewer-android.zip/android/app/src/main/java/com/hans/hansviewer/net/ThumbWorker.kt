package com.hans.hansviewer.net

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import java.util.concurrent.atomic.AtomicInteger

/**
 * "Make thumbnails" in the background: keeps going when you leave the folder or close the app,
 * and continues after a restart (Android decides the exact moment, and waits for a connection).
 * Three photos are fetched at a time; it pauses while you view network photos.
 */
class ThumbWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        RemoteRepo.init(applicationContext)
        try {
            while (!isStopped) {
                val item = RemoteRepo.queue().firstOrNull() ?: break
                val server = RemoteRepo.server(item.serverId)
                if (server == null) {
                    drop(item)
                    continue
                }
                val name = item.path.substringAfterLast('/').ifEmpty { server.label }
                RemoteRepo.progress.value = "Reading “$name”…"
                val entries = runCatching { RemoteRepo.list(item.serverId, item.path) }.getOrNull()
                    ?: RemoteRepo.listCached(item.serverId, item.path)
                if (entries == null) {
                    RemoteRepo.progress.value = "Waiting for “${server.label}”…"
                    return Result.retry()  // not reachable now: Android tries again later
                }
                if (item.subfolders) {
                    // each subfolder becomes its own entry (also with its subfolders)
                    val subs = entries.filter { it.isDir && !it.name.startsWith(".") && !it.name.startsWith("@") }
                    val q = RemoteRepo.queue().toMutableList()
                    val at = q.indexOf(item).coerceAtLeast(0)
                    q.addAll(at + 1, subs.map { RemoteRepo.QueueItem(item.serverId, it.path, true) }
                        .filter { s -> q.none { it.serverId == s.serverId && it.path == s.path } })
                    q[q.indexOf(item).coerceAtLeast(0)] = item.copy(subfolders = false)
                    RemoteRepo.saveQueue(q)
                }
                val todo = entries.filter { !it.isDir && isPhotoName(it.name) && !RemoteRepo.hasThumb(item.serverId, it) }
                val total = entries.count { !it.isDir && isPhotoName(it.name) }
                val done = AtomicInteger(total - todo.size)
                val left = RemoteRepo.queue().size
                fun report() {
                    val more = if (left > 1) "  (+${left - 1} more)" else ""
                    val state = when {
                        RemoteRepo.thumbsPaused -> "  · paused"
                        RemoteRepo.viewerBusy -> "  · waits while you view"
                        else -> ""
                    }
                    RemoteRepo.progress.value = "Thumbnails: $name — ${done.get()} / $total$more$state"
                }
                report()
                val gate = Semaphore(3)
                coroutineScope {
                    for (e in todo) {
                        if (isStopped) break
                        while ((RemoteRepo.viewerBusy || RemoteRepo.thumbsPaused) && !isStopped) {
                            report()
                            delay(1000)
                        }
                        gate.acquire()
                        launch {
                            try {
                                RemoteRepo.makeThumb(item.serverId, e)
                                done.incrementAndGet()
                                report()
                            } finally {
                                gate.release()
                            }
                        }
                    }
                }
                if (isStopped) return Result.retry()
                drop(item)
            }
        } finally {
            if (RemoteRepo.queue().isEmpty()) RemoteRepo.progress.value = null
        }
        return Result.success()
    }

    private fun drop(item: RemoteRepo.QueueItem) {
        RemoteRepo.saveQueue(RemoteRepo.queue().filterNot { it.serverId == item.serverId && it.path == item.path })
    }

    companion object {
        private const val NAME = "net-thumbnails"

        fun start(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<ThumbWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(NAME, ExistingWorkPolicy.KEEP, req)
        }

        fun stopAll(ctx: Context) {
            RemoteRepo.saveQueue(emptyList())
            WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
            RemoteRepo.progress.value = null
        }
    }
}
