package com.hans.hansviewer.net

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import java.util.concurrent.atomic.AtomicInteger

/**
 * "Make thumbnails" in the background: keeps going when you leave the folder or close the app,
 * and continues after a restart (Android decides the exact moment, and waits for a connection).
 * Three photos are fetched at a time; it pauses while you view network photos.
 */
class ThumbWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        RemoteRepo.init(applicationContext)
        try {
            while (!isStopped) {
                val item = RemoteRepo.queue().firstOrNull() ?: break
                val server = RemoteRepo.server(item.serverId)
                if (server == null) {
                    drop(item)
                    continue
                }
                val name = item.path.substringAfterLast('/').ifEmpty { server.label }
                RemoteRepo.progress.value = "Reading “$name”…"
                val entries = runCatching { RemoteRepo.list(item.serverId, item.path) }.getOrNull()
                    ?: RemoteRepo.listCached(item.serverId, item.path)
                if (entries == null) {
                    RemoteRepo.progress.value = "Waiting for “${server.label}”…"
                    return Result.retry()  // not reachable now: Android tries again later
                }
                if (item.subfolders) {
                    // each subfolder becomes its own entry (also with its subfolders)
                    val subs = entries.filter { it.isDir && !it.name.startsWith(".") && !it.name.startsWith("@") }
                    val q = RemoteRepo.queue().toMutableList()
                    val at = q.indexOf(item).coerceAtLeast(0)
                    q.addAll(at + 1, subs.map { RemoteRepo.QueueItem(item.serverId, it.path, true) }
                        .filter { s -> q.none { it.serverId == s.serverId && it.path == s.path } })
                    q[q.indexOf(item).coerceAtLeast(0)] = item.copy(subfolders = false)
                    RemoteRepo.saveQueue(q)
                }
                // photos first, videos last (a video needs much more reading)
                val todo = entries.filter { !it.isDir && isMediaName(it.name) && !RemoteRepo.hasThumb(item.serverId, it) }
                    .sortedBy { isVideoName(it.name) }
                val total = entries.count { !it.isDir && isMediaName(it.name) }
                val done = AtomicInteger(total - todo.size)
                RemoteRepo.thumbErrors = 0
                fun sameAsHead(): Boolean {
                    val head = RemoteRepo.queue().firstOrNull() ?: return false
                    return head.serverId == item.serverId && head.path == item.path
                }
                fun report() {
                    val waiting = (RemoteRepo.queue().size - 1).coerceAtLeast(0)
                    val pct = if (total > 0) " (${done.get() * 100 / total} %)" else ""
                    val more = if (waiting > 0) "  · $waiting folder${if (waiting == 1) "" else "s"} waiting" else ""
                    val errors = RemoteRepo.thumbErrors.let { if (it > 0) "  · $it unreadable" else "" }
                    val state = when {
                        RemoteRepo.thumbsPaused -> "  · paused"
                        RemoteRepo.viewerBusy -> "  · waits while you view"
                        else -> ""
                    }
                    RemoteRepo.progress.value = "Thumbnails: $name — ${done.get()} / $total$pct$more$errors$state"
                }
                report()
                var abandoned = false
                val gate = Semaphore(3)
                coroutineScope {
                    for (e in todo) {
                        if (isStopped) break
                        while ((RemoteRepo.viewerBusy || RemoteRepo.thumbsPaused) && !isStopped) {
                            report()
                            delay(1000)
                        }
                        if (!sameAsHead()) {   // a folder asked for later goes first; this one waits
                            abandoned = true
                            break
                        }
                        gate.acquire()
                        launch {
                            try {
                                if (!RemoteRepo.makeThumb(item.serverId, e)) RemoteRepo.thumbErrors++
                            } catch (c: kotlinx.coroutines.CancellationException) {
                                throw c
                            } catch (x: Exception) {
                                RemoteRepo.thumbErrors++   // one unreadable file doesn't stop the others
                            } finally {
                                done.incrementAndGet()
                                report()
                                gate.release()
                            }
                        }
                    }
                }
                if (abandoned) continue
                if (isStopped) return Result.retry()
                drop(item)
            }
        } finally {
            if (RemoteRepo.queue().isEmpty()) RemoteRepo.progress.value = null
        }
        return Result.success()
    }

    private fun drop(item: RemoteRepo.QueueItem) {
        RemoteRepo.saveQueue(RemoteRepo.queue().filterNot { it.serverId == item.serverId && it.path == item.path })
    }

    companion object {
        private const val NAME = "net-thumbnails"

        fun start(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<ThumbWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(NAME, ExistingWorkPolicy.KEEP, req)
        }

        fun stopAll(ctx: Context) {
            RemoteRepo.saveQueue(emptyList())
            WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
            RemoteRepo.progress.value = null
        }
    }
}
