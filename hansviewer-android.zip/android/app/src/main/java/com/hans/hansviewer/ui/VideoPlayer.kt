@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.hans.hansviewer.ui

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.MediaThumb
import com.hans.hansviewer.Photo
import com.hans.hansviewer.formatDuration
import com.hans.hansviewer.net.RemoteRepo
import com.hans.hansviewer.net.isNet
import kotlinx.coroutines.delay
import java.io.File
import java.io.InputStream

/** Reads network videos (WebDAV or SMB) for the player, from any position (for seeking). */
class NetDataSource : BaseDataSource(true) {
    private var stream: InputStream? = null
    private var uri: Uri? = null
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val (input, total) = RemoteRepo.openRange(dataSpec.uri, dataSpec.position)
        stream = input
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) dataSpec.length
        else (total - dataSpec.position).coerceAtLeast(0)
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val n = stream?.read(buffer, offset, minOf(length.toLong(), remaining).toInt()) ?: -1
        if (n < 0) return C.RESULT_END_OF_INPUT
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        runCatching { stream?.close() }
        stream = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }
}

/** One player engine for the app: big buffer, and network videos kept on the device (up to 2 GB). */
object VideoEngine {
    private var cache: SimpleCache? = null

    @Synchronized
    private fun cache(ctx: Context): SimpleCache = cache ?: SimpleCache(
        File(ctx.cacheDir, "videocache"),
        LeastRecentlyUsedCacheEvictor(2_000_000_000L),
        StandaloneDatabaseProvider(ctx),
    ).also { cache = it }

    /** Up to 2 minutes are loaded ahead (normally 30-50 s), so short slow-downs don't stop the video. */
    const val MAX_AHEAD_MS = 120_000

    fun newPlayer(ctx: Context): ExoPlayer {
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, MAX_AHEAD_MS, 3_000, 8_000)
            .setTargetBufferBytes(160 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        return ExoPlayer.Builder(ctx).setLoadControl(load).build()
    }

    fun mediaSource(ctx: Context, uri: Uri): ProgressiveMediaSource {
        val item = MediaItem.fromUri(uri)
        val factory = if (uri.scheme == com.hans.hansviewer.net.NET_SCHEME) {
            CacheDataSource.Factory()
                .setCache(cache(ctx))
                .setUpstreamDataSourceFactory { NetDataSource() }
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        } else {
            DefaultDataSource.Factory(ctx)
        }
        return ProgressiveMediaSource.Factory(factory).createMediaSource(item)
    }
}

/**
 * One video page in the viewer. Only the video on screen plays; the others show their preview.
 * Network videos start as soon as enough has arrived to play to the end without stopping.
 */
@Composable
fun VideoPage(vm: AppViewModel, photo: Photo, isCurrent: Boolean, chrome: Boolean, onTap: () -> Unit) {
    val ctx = LocalContext.current
    // a video only starts when you tap its play button, not when you swipe to it
    var started by remember(photo.cacheKey) { mutableStateOf(false) }
    LaunchedEffect(isCurrent) { if (!isCurrent) started = false }
    if (!isCurrent || !started) {
        Box(
            Modifier.fillMaxSize().background(Color.Black)
                .pointerInput(photo.cacheKey) { detectTapGestures(onTap = { onTap() }) },
        ) {
            VideoPoster(ctx, photo)
            IconButton(
                onClick = { if (isCurrent) started = true },
                modifier = Modifier.align(Alignment.Center).size(88.dp),
            ) {
                Icon(Icons.Filled.PlayArrow, "Play", Modifier.size(72.dp)
                    .background(Color(0x66000000), CircleShape).padding(12.dp), tint = Color.White)
            }
        }
    } else {
        PlayingVideo(vm, photo, chrome, onTap)
    }
}

@Composable
private fun PlayingVideo(vm: AppViewModel, photo: Photo, chrome: Boolean, onTap: () -> Unit) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val player = remember(photo.cacheKey) { VideoEngine.newPlayer(ctx) }
        var playing by remember { mutableStateOf(false) }
        var position by remember { mutableLongStateOf(0L) }
        // the length is known before playing when the thumbnail was made (network videos)
        var duration by remember { mutableLongStateOf(photo.duration.takeIf { it > 0 } ?: RemoteRepo.durationFor(photo.uri)) }
        var buffered by remember { mutableFloatStateOf(0f) }
        var status by remember { mutableStateOf<String?>(null) }
        var muted by remember { mutableStateOf(false) }
        var waiting by remember { mutableStateOf(photo.isNet) }
        var seeking by remember { mutableStateOf<Float?>(null) }

        DisposableEffect(photo.cacheKey) {
            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                override fun onPlayerError(error: PlaybackException) {
                    status = "Can't play this video (${error.errorCodeName})"
                }
            }
            player.addListener(listener)
            onDispose {
                player.removeListener(listener)
                player.release()
            }
        }
        // what to play: the file itself, or (network, "download completely first") the downloaded copy
        LaunchedEffect(photo.cacheKey) {
            if (photo.isNet && vm.videoDownloadFirst) {
                status = "Downloading… 0 %"
                val t0 = System.currentTimeMillis()
                val file = runCatching {
                    RemoteRepo.downloadVideo(photo.uri) { f ->
                        val secs = (System.currentTimeMillis() - t0) / 1000.0
                        val speed = if (secs > 1.0) f * photo.size / secs else 0.0
                        val rate = if (speed > 0) " · %.1f MB/s".format(speed / 1048576) else ""
                        val eta = if (speed > 0) "\nready in about ${fmtWait((1 - f) * photo.size / speed)}" else ""
                        status = "Downloading… ${(f * 100).toInt()} %$rate$eta"
                    }
                }.getOrElse { e ->
                    status = "Download failed: ${e.message ?: e.javaClass.simpleName}"
                    return@LaunchedEffect
                }
                status = null
                waiting = false
                player.setMediaSource(VideoEngine.mediaSource(ctx, Uri.fromFile(file)))
                player.prepare()
                player.play()
            } else {
                player.setMediaSource(VideoEngine.mediaSource(ctx, photo.uri))
                player.prepare()
                if (!photo.isNet) player.play()
            }
            if (photo.isNet && RemoteRepo.thumbFor(photo.uri) == null) {
                runCatching { RemoteRepo.ensureThumb(photo.uri) }  // so the grid shows it next time
            }
        }
        // position, buffer and the smart start for network videos
        LaunchedEffect(photo.cacheKey) {
            val t0 = System.currentTimeMillis()
            while (true) {
                delay(400)
                position = player.currentPosition
                if (player.duration != C.TIME_UNSET && player.duration > 0) duration = player.duration
                buffered = if (duration > 0) (player.bufferedPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f
                if (waiting && !vm.videoDownloadFirst) {
                    val secs = (System.currentTimeMillis() - t0) / 1000.0
                    val have = buffered * photo.size                    // bytes loaded so far
                    val speed = if (secs > 1.0) have / secs else 0.0
                    val ahead = player.bufferedPosition - player.currentPosition
                    val pct = (buffered * 100).toInt()
                    val rate = if (speed > 0) " · %.1f MB/s".format(speed / 1048576) else ""
                    if (duration <= 0) {
                        status = "Buffering…"
                    } else {
                        val needSecs = if (speed > 0) (photo.size - have) / speed else Double.MAX_VALUE
                        val wait = needSecs - duration / 1000.0 * 0.9
                        when {
                            buffered >= 0.999f || wait <= 0 && ahead >= 3000 ||
                                ahead >= VideoEngine.MAX_AHEAD_MS - 5000 -> {
                                waiting = false
                                status = null
                                player.play()
                            }
                            speed > 0 -> status = "Buffering… $pct %$rate\nstarts in about ${fmtWait(wait.coerceAtLeast(1.0))}"
                            else -> status = "Buffering… $pct %"
                        }
                    }
                }
            }
        }

        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false  // HansViewer's own buttons; swipes go to the photo pager
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = player
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
        // while a network video buffers: its thumbnail (darkened) instead of a black screen
        if (waiting && photo.isNet) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                VideoPoster(ctx, photo)
                Box(Modifier.fillMaxSize().background(Color(0x88000000)))
            }
        }
        // taps show / hide the bars (the pager still gets sideways swipes)
        Box(Modifier.fillMaxSize().pointerInput(photo.cacheKey) { detectTapGestures(onTap = { onTap() }) })

        status?.let {
            Column(
                Modifier.align(Alignment.Center).padding(24.dp)
                    .background(Color(0xBB000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 22.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(it, color = Color.White, style = MaterialTheme.typography.titleMedium,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                if (waiting) {
                    Text("Tap ▶ to play now", color = Color(0xBBFFFFFF), style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        if (chrome || !playing) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, bottom = 104.dp)
                    .background(Color(0x99000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Box(Modifier.fillMaxWidth().height(30.dp), contentAlignment = Alignment.Center) {
                    // the part already loaded, under the slider
                    LinearProgressIndicator(
                        progress = { buffered },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp).height(3.dp),
                        color = Color(0x88FFFFFF), trackColor = Color(0x33FFFFFF),
                    )
                    Slider(
                        value = seeking ?: if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                        onValueChange = { seeking = it },
                        onValueChangeFinished = {
                            seeking?.let { player.seekTo((it * duration).toLong()) }
                            seeking = null
                        },
                        colors = SliderDefaults.colors(activeTrackColor = Color(0xFF6CA8FF),
                            inactiveTrackColor = Color.Transparent, thumbColor = Color.White),
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // 10 seconds back / forward, next to Play
                    IconButton(onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)) }) {
                        Icon(Icons.Filled.Replay10, "10 seconds back", tint = Color.White)
                    }
                    IconButton(onClick = {
                        if (waiting) { waiting = false; status = null; player.play() }
                        else if (player.isPlaying) player.pause() else player.play()
                    }) {
                        Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play / pause", tint = Color.White)
                    }
                    IconButton(onClick = {
                        val end = if (duration > 0) duration else Long.MAX_VALUE
                        player.seekTo((player.currentPosition + 10_000).coerceAtMost(end))
                    }) {
                        Icon(Icons.Filled.Forward10, "10 seconds forward", tint = Color.White)
                    }
                    Text("${formatDuration(position).ifEmpty { "0:00" }} / ${formatDuration(duration).ifEmpty { "0:00" }}",
                        color = Color.White, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        player.pause()
                        if (!com.hans.hansviewer.net.LocalStream.openInOtherPlayer(ctx, photo)) {
                            vm.message = "No other video player found on this phone"
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, "Play in other player", tint = Color.White)
                    }
                    IconButton(onClick = { muted = !muted; player.volume = if (muted) 0f else 1f }) {
                        Icon(if (muted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            "Sound", tint = Color.White)
                    }
                }
            }
        }
    }
}

/** "8 s", "2 min 05 s" */
fun fmtWait(secs: Double): String {
    val s = kotlin.math.ceil(secs).toLong().coerceAtLeast(1)
    return if (s < 60) "$s s" else "${s / 60} min ${"%02d".format(s % 60)} s"
}

@Composable
private fun VideoPoster(ctx: Context, photo: Photo) {
    val model: Any? = if (photo.isNet) RemoteRepo.thumbFor(photo.uri) else MediaThumb(photo.uri, 512)
    if (model != null) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(model).memoryCacheKey("poster:" + photo.cacheKey).build(),
            contentDescription = photo.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    }
}
