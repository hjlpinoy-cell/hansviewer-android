package com.hans.hansviewer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.hans.hansviewer.ui.BrowserScreen
import com.hans.hansviewer.ui.EditorScreen
import com.hans.hansviewer.ui.HansTheme
import com.hans.hansviewer.ui.ImportDialog
import com.hans.hansviewer.ui.SettingsScreen
import com.hans.hansviewer.ui.ViewerScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        handle(intent)
        setContent {
            HansTheme(dark = vm.theme == "dark") { App(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val data = i?.data
        if (i?.action == Intent.ACTION_VIEW && data != null) vm.openExternal(data)
    }
}

fun mediaPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
fun App(vm: AppViewModel) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, mediaPermission()) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    LaunchedEffect(granted) { if (granted) vm.reload() }

    // System prompts such as "Allow HansViewer to modify this photo?"
    val requestLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        vm.onRequestResult(it.resultCode == Activity.RESULT_OK)
    }
    val pending = vm.pending
    LaunchedEffect(pending) {
        if (pending != null) {
            runCatching { requestLauncher.launch(IntentSenderRequest.Builder(pending.sender).build()) }
                .onFailure { vm.onRequestResult(false) }
        }
    }

    val snackbar = remember { SnackbarHostState() }
    val msg = vm.message
    LaunchedEffect(msg) {
        if (msg != null) {
            vm.message = null
            snackbar.showSnackbar(msg)
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize()) {
            if (!granted) {
                Welcome { permLauncher.launch(mediaPermission()) }
            } else {
                when (val s = vm.screen) {
                    is Screen.Browser -> Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing)) { BrowserScreen(vm) }
                    is Screen.Viewer -> ViewerScreen(vm, s)
                    is Screen.Editor -> Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing)) { EditorScreen(vm, s.photo) }
                    is Screen.Settings -> Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing)) { SettingsScreen(vm) }
                }
                BackHandler(enabled = vm.screen is Screen.Settings) { vm.screen = Screen.Browser }
                vm.importing?.let { ImportDialog(vm, it) }
            }
            CrashReport()
            vm.busy?.let { label ->
                Box(
                    Modifier.fillMaxSize().background(Color(0x99000000)),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text(label, color = Color.White)
                    }
                }
            }
            SnackbarHost(
                snackbar,
                Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(16.dp),
            ) { Snackbar(it) }
        }
    }
}

@Composable
private fun Welcome(onAllow: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.widthIn(max = 460.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Text("Welcome to HansViewer", style = MaterialTheme.typography.headlineSmall)
            Text(
                "To show your photos, HansViewer needs permission to read the pictures on this tablet, " +
                    "its SD card and any USB stick.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = onAllow) { Text("Allow access to photos") }
            val ctx = LocalContext.current
            androidx.compose.material3.TextButton(onClick = {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:" + ctx.packageName)))
            }) { Text("Nothing happens? Open app settings → Permissions → Photos") }
        }
    }
}

/** Shows what went wrong if HansViewer closed unexpectedly last time, so it can be sent on. */
@Composable
private fun CrashReport() {
    val ctx = LocalContext.current
    val file = remember { java.io.File(ctx.filesDir, HansApp.CRASH_FILE) }
    var text by remember { mutableStateOf(runCatching { if (file.exists()) file.readText() else null }.getOrNull()) }
    val t = text ?: return
    fun close() { file.delete(); text = null }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { close() },
        title = { Text("HansViewer closed unexpectedly") },
        text = {
            Column(Modifier.heightIn(max = 420.dp)) {
                Text("Please copy this report and send it to Claude:", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                androidx.compose.foundation.text.selection.SelectionContainer {
                    Text(t, style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()))
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = {
                val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("HansViewer report", t))
                close()
            }) { Text("Copy and close") }
        },
        dismissButton = { androidx.compose.material3.TextButton(onClick = { close() }) { Text("Close") } },
    )
}
