plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val buildNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
// Secret Play Store upload key; only present in the GitHub build (from repository secrets)
val uploadKeyFile = System.getenv("UPLOAD_KEYSTORE_FILE")?.takeIf { File(it).exists() }

android {
    namespace = "com.hans.hansviewer"
    compileSdk = 36

    defaultConfig {
        minSdk = 30
        targetSdk = 36
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
    }

    signingConfigs {
        create("hans") {
            // Fixed key for the GitHub version, so each build installs as an update
            storeFile = file("hansviewer.jks")
            storePassword = "hansviewer"
            keyAlias = "hansviewer"
            keyPassword = "hansviewer"
        }
        if (uploadKeyFile != null) {
            create("upload") {
                storeFile = file(uploadKeyFile)
                storePassword = System.getenv("UPLOAD_KEY_PASSWORD")
                keyAlias = "upload"
                keyPassword = System.getenv("UPLOAD_KEY_PASSWORD")
            }
        }
    }

    flavorDimensions += "store"
    productFlavors {
        // Downloaded from GitHub releases; can tell the user about new GitHub builds
        create("github") {
            dimension = "store"
            applicationId = "com.hans.hansviewer"
            buildConfigField("boolean", "UPDATE_CHECK", "true")
            // network folders (WebDAV); the Play version will get them after its store forms are updated
            buildConfigField("boolean", "NETWORK", "true")
            signingConfig = signingConfigs.getByName("hans")
        }
        // Google Play Store version: updates only through the Play Store, no internet use
        create("play") {
            dimension = "store"
            applicationId = "com.hansviewer.app"
            buildConfigField("boolean", "UPDATE_CHECK", "false")
            buildConfigField("boolean", "NETWORK", "false")
            signingConfig = signingConfigs.findByName("upload") ?: signingConfigs.getByName("hans")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        resources {
            // duplicate info files inside the SMB library's helpers
            excludes += setOf(
                "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.md",
                "META-INF/versions/9/OSGI-INF/MANIFEST.MF",
            )
        }
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.hierynomus:smbj:0.13.0")  // SMB shares (NAS) on the home network
}
