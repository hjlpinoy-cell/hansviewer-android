# Keep line numbers so crash reports are readable
-keepattributes SourceFile,LineNumberTable
