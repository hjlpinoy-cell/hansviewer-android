package com.hans.hansviewer.ui

import android.app.Activity
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.MediaRepo
import com.hans.hansviewer.Photo
import com.hans.hansviewer.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val VIEW_SIZE = 3000

private fun viewRequest(ctx: Context, p: Photo) = ImageRequest.Builder(ctx).data(p.uri)
    .size(VIEW_SIZE).memoryCacheKey("view:" + p.cacheKey).diskCacheKey(p.cacheKey).build()

@Composable
fun ViewerScreen(vm: AppViewModel, state: Screen.Viewer) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val photos = state.photos
    val index = state.index.coerceIn(0, photos.size - 1)
    val photo = photos[index]
    var chrome by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(state.slideshow) }
    var info by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var confirmTrash by remember { mutableStateOf(false) }

    fun go(i: Int, wrap: Boolean = false) {
        val n = photos.size
        val j = if (wrap) ((i % n) + n) % n else i.coerceIn(0, n - 1)
        if (j != index) vm.screen = state.copy(index = j, slideshow = playing)
    }
    fun close() { vm.screen = Screen.Browser }

    // Full screen: hide the status and navigation bars while viewing
    DisposableEffect(Unit) {
        val window = (view.context as Activity).window
        val ctl = WindowCompat.getInsetsController(window, view)
        ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { ctl.show(WindowInsetsCompat.Type.systemBars()) }
    }
    DisposableEffect(playing) {
        view.keepScreenOn = playing
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(playing, index) {
        if (playing) {
            chrome = false
            delay(vm.slideshowSecs * 1000L)
            go(index + 1, wrap = true)
        }
    }
    // Load the neighbours in the background so swiping is instant
    LaunchedEffect(index, photos) {
        for (j in listOf(index + 1, index - 1)) {
            photos.getOrNull(j)?.let { ctx.imageLoader.enqueue(viewRequest(ctx, it)) }
        }
    }
    BackHandler { if (playing) playing = false else close() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        ZoomableImage(
            ctx, photo,
            onTap = { chrome = !chrome; if (playing) playing = false },
            onSwipe = { dir -> go(index + dir) },
        )

        if (chrome) {
            // top bar
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = ::close) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    Text(photo.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium)
                    val dims = if (photo.width > 0) "   ·   ${photo.width} × ${photo.height}" else ""
                    Text("${index + 1} / ${photos.size}$dims", color = Color(0xFFBBBBBB),
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            // previous / next arrows for tablets
            if (index > 0) {
                RoundButton(Modifier.align(Alignment.CenterStart).padding(12.dp), { go(index - 1) }) {
                    Icon(Icons.Filled.ChevronLeft, "Previous", tint = Color.White)
                }
            }
            if (index < photos.size - 1) {
                RoundButton(Modifier.align(Alignment.CenterEnd).padding(12.dp), { go(index + 1) }) {
                    Icon(Icons.Filled.ChevronRight, "Next", tint = Color.White)
                }
            }
            // bottom actions
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                val editable = photo.id >= 0
                ActionIcon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Slideshow") {
                    playing = !playing
                }
                if (editable) {
                    ActionIcon(Icons.AutoMirrored.Filled.RotateLeft, "Rotate left") { vm.rotate(listOf(photo), -90) }
                    ActionIcon(Icons.AutoMirrored.Filled.RotateRight, "Rotate right") { vm.rotate(listOf(photo), 90) }
                    ActionIcon(Icons.Filled.Edit, "Edit") { vm.screen = Screen.Editor(photo) }
                }
                ActionIcon(Icons.Filled.Info, "Info") { info = emptyList() }
                ActionIcon(Icons.Filled.Share, "Share") { sharePhotos(ctx, listOf(photo)) }
                ActionIcon(Icons.Filled.Wallpaper, "Wallpaper") { setWallpaper(ctx, photo) }
                if (editable) {
                    ActionIcon(Icons.Filled.Delete, "Recycle bin") {
                        if (vm.confirmDelete) confirmTrash = true else vm.trash(listOf(photo))
                    }
                }
            }
        }
    }

    info?.let { rows ->
        LaunchedEffect(photo.id) {
            if (rows.isEmpty()) info = withContext(Dispatchers.IO) { MediaRepo.info(ctx, photo) }
        }
        InfoDialog(photo.name, rows) { info = null }
    }
    if (confirmTrash) {
        ConfirmDialog("Move to Recycle bin", "Move “${photo.name}” to the Recycle bin?", "Move",
            onDismiss = { confirmTrash = false }) {
            confirmTrash = false
            vm.trash(listOf(photo))
        }
    }
}

@Composable
private fun RoundButton(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    IconButton(onClick = onClick, modifier = modifier.size(48.dp).background(Color(0x66000000), CircleShape)) {
        content()
    }
}

@Composable
private fun ActionIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick) { Icon(icon, label, tint = Color.White) }
        Text(label, color = Color(0xFFCCCCCC), style = MaterialTheme.typography.labelSmall)
    }
}

/** Pinch to zoom, drag to pan, double-tap to zoom, swipe sideways for the next photo. */
@Composable
private fun ZoomableImage(ctx: Context, photo: Photo, onTap: () -> Unit, onSwipe: (Int) -> Unit) {
    var scale by remember(photo.cacheKey) { mutableFloatStateOf(1f) }
    var offset by remember(photo.cacheKey) { mutableStateOf(Offset.Zero) }
    var swipe by remember(photo.cacheKey) { mutableFloatStateOf(0f) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(photo.cacheKey) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var multi = false
                    var dragX = 0f
                    do {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed >= 2) multi = true
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        if (multi || scale > 1.01f) {
                            scale = (scale * zoom).coerceIn(1f, 8f)
                            val maxX = size.width * (scale - 1f) / 2f
                            val maxY = size.height * (scale - 1f) / 2f
                            offset = Offset(
                                (offset.x + pan.x).coerceIn(-maxX, maxX),
                                (offset.y + pan.y).coerceIn(-maxY, maxY),
                            )
                        } else {
                            dragX += pan.x
                            swipe = dragX
                        }
                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                    } while (event.changes.any { it.pressed })
                    if (!multi && scale <= 1.01f) {
                        val limit = size.width * 0.15f
                        if (dragX < -limit) onSwipe(1) else if (dragX > limit) onSwipe(-1)
                    }
                    swipe = 0f
                    if (scale <= 1.01f) {
                        scale = 1f
                        offset = Offset.Zero
                    }
                }
            }
            .pointerInput(photo.cacheKey) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { pos ->
                        if (scale > 1.01f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.5f
                            val c = Offset(size.width / 2f, size.height / 2f)
                            val maxX = size.width * (scale - 1f) / 2f
                            val maxY = size.height * (scale - 1f) / 2f
                            val o = (c - pos) * (scale - 1f)
                            offset = Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
                        }
                    },
                )
            },
    ) {
        AsyncImage(
            model = viewRequest(ctx, photo),
            contentDescription = photo.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x + swipe
                translationY = offset.y
            },
        )
    }
}

private fun setWallpaper(ctx: Context, photo: Photo) {
    val ok = runCatching {
        ctx.startActivity(WallpaperManager.getInstance(ctx).getCropAndSetWallpaperIntent(photo.uri))
    }.isSuccess
    if (!ok) {
        val i = Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(photo.uri, photo.mime)
            .putExtra("mimeType", photo.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { ctx.startActivity(Intent.createChooser(i, "Set as wallpaper")) }
    }
}
