package com.hans.hansviewer.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.RotateLeft
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.hans.hansviewer.AppViewModel
import com.hans.hansviewer.EditOp
import com.hans.hansviewer.GRAYSCALE
import com.hans.hansviewer.INVERT
import com.hans.hansviewer.MediaRepo
import com.hans.hansviewer.Photo
import com.hans.hansviewer.SEPIA
import com.hans.hansviewer.Screen
import com.hans.hansviewer.adjustMatrix
import com.hans.hansviewer.applyOps
import com.hans.hansviewer.autoLevelsMatrix
import com.hans.hansviewer.dimsAfter
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val RATIOS = listOf<Pair<String, Float?>>(
    "Free" to null, "Original" to -1f, "1:1" to 1f, "4:3" to 4f / 3f, "3:2" to 1.5f,
    "16:9" to 16f / 9f, "3:4" to 0.75f, "2:3" to 2f / 3f, "9:16" to 9f / 16f,
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AppViewModel, photo: Photo) {
    val ctx = LocalContext.current
    val wide = LocalConfiguration.current.screenWidthDp >= 700
    var base by remember { mutableStateOf<Bitmap?>(null) }
    var failed by remember { mutableStateOf(false) }
    val ops = remember { mutableStateListOf<EditOp>() }
    val redo = remember { mutableStateListOf<EditOp>() }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var saturation by remember { mutableFloatStateOf(0f) }
    var warmth by remember { mutableFloatStateOf(0f) }
    var cropMode by remember { mutableStateOf(false) }
    var ratioIndex by remember { mutableStateOf(0) }
    var crop by remember { mutableStateOf(Rect(0f, 0f, 1f, 1f)) }
    var confirmExit by remember { mutableStateOf(false) }
    var confirmOverwrite by remember { mutableStateOf(false) }

    LaunchedEffect(photo.cacheKey) {
        base = withContext(Dispatchers.IO) { runCatching { MediaRepo.decodeForScreen(ctx, photo.uri, 2048) }.getOrNull() }
        if (base == null) failed = true
    }
    val opsNow = ops.toList()
    LaunchedEffect(base, opsNow) {
        val b = base ?: return@LaunchedEffect
        preview = withContext(Dispatchers.Default) { applyOps(b, opsNow, forPreview = true) }
    }

    val adjusting = brightness != 0f || contrast != 0f || saturation != 0f || warmth != 0f
    val dirty = ops.isNotEmpty() || adjusting
    val w0 = if (photo.width > 0) photo.width else base?.width ?: 0
    val h0 = if (photo.height > 0) photo.height else base?.height ?: 0
    val (outW, outH) = dimsAfter(w0, h0, opsNow)

    fun resetSliders() { brightness = 0f; contrast = 0f; saturation = 0f; warmth = 0f }
    fun commitAdjust() {
        if (adjusting) {
            ops += EditOp.Colour(adjustMatrix(brightness, contrast, saturation, warmth))
            redo.clear()
            resetSliders()
        }
    }
    fun push(op: EditOp) { commitAdjust(); ops += op; redo.clear() }
    fun leave() { vm.screen = Screen.Browser }
    fun save(overwrite: Boolean) {
        commitAdjust()
        vm.saveEdit(photo, ops.toList(), overwrite) { ok -> if (ok) leave() }
    }

    // ratio in normalised units of the current preview (width / height)
    val p = preview
    fun normRatio(): Float? {
        val r = RATIOS[ratioIndex].second ?: return null
        val px = if (r < 0) (outW.toFloat() / max(1, outH)) else r
        return if (p == null) px else px * p.height / p.width.toFloat()
    }
    fun resetCrop() {
        val k = normRatio()
        crop = if (k == null) Rect(0f, 0f, 1f, 1f) else {
            var w = 1f
            var h = 1f / k
            if (h > 1f) { h = 1f; w = k }
            Rect((1f - w) / 2f, (1f - h) / 2f, (1f + w) / 2f, (1f + h) / 2f)
        }
    }

    BackHandler { if (dirty) confirmExit = true else leave() }

    Column(Modifier.fillMaxSize()) {
        // ---- top bar
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 8.dp).height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { if (dirty) confirmExit = true else leave() }) { Icon(Icons.Filled.Close, "Close") }
            Column(Modifier.weight(1f).padding(start = 4.dp)) {
                Text("Edit — ${photo.name}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium)
                Text("$outW × $outH" + if (dirty) "   ·   edited" else "", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = { save(false) }, enabled = dirty) { Text("Save copy") }
            Spacer8()
            Button(onClick = { confirmOverwrite = true }, enabled = dirty) { Text("Save") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        val canvas: @Composable (Modifier) -> Unit = { mod ->
            Box(mod.background(Color(0xFF0E0F11)), contentAlignment = Alignment.Center) {
                when {
                    failed -> Text("This picture can't be edited", color = Color.White)
                    p == null -> CircularProgressIndicator()
                    else -> CropCanvas(
                        p, crop, cropMode, normRatio(),
                        if (adjusting) ColorFilter.colorMatrix(ColorMatrix(adjustMatrix(brightness, contrast, saturation, warmth))) else null,
                    ) { crop = it }
                }
            }
        }
        val tools: @Composable (Modifier) -> Unit = { mod ->
            Surface(mod, color = MaterialTheme.colorScheme.surface) {
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    ToolSection("Rotate & flip") {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ToolButton("Left", Icons.AutoMirrored.Filled.RotateLeft) { push(EditOp.Rotate(-90)) }
                            ToolButton("Right", Icons.AutoMirrored.Filled.RotateRight) { push(EditOp.Rotate(90)) }
                            ToolButton("Flip ↔", Icons.Filled.Flip) { push(EditOp.Flip(true)) }
                            ToolButton("Flip ↕", Icons.Filled.Flip) { push(EditOp.Flip(false)) }
                        }
                    }
                    ToolSection("Crop") {
                        if (!cropMode) {
                            ToolButton("Select area", Icons.Filled.Crop) { commitAdjust(); cropMode = true; resetCrop() }
                        } else {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                RATIOS.forEachIndexed { i, (label, _) ->
                                    FilterChip(ratioIndex == i, { ratioIndex = i; resetCrop() }, { Text(label) })
                                }
                            }
                            Text("Drag inside to move, drag a corner to resize, or drag outside for a new area.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { cropMode = false }) { Text("Cancel") }
                                Button(onClick = {
                                    val c = crop
                                    if (c.width > 0.01f && c.height > 0.01f) push(EditOp.Crop(c.left, c.top, c.right, c.bottom))
                                    cropMode = false
                                }) { Text("Apply crop") }
                            }
                        }
                    }
                    ToolSection("Resize  ($outW × $outH)") {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (pct in listOf(75, 50, 25)) {
                                ToolButton("$pct%") { push(EditOp.Resize(pct / 100f, pct / 100f)) }
                            }
                            for (edge in listOf(3840, 1920, 1280)) {
                                val longest = max(outW, outH)
                                if (longest > edge) {
                                    ToolButton("Long edge $edge") {
                                        val f = edge / longest.toFloat()
                                        push(EditOp.Resize(f, f))
                                    }
                                }
                            }
                        }
                    }
                    ToolSection("Adjust") {
                        AdjustSlider("Brightness", brightness) { brightness = it }
                        AdjustSlider("Contrast", contrast) { contrast = it }
                        AdjustSlider("Saturation", saturation) { saturation = it }
                        AdjustSlider("Warmth", warmth) { warmth = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = ::resetSliders, enabled = adjusting) { Text("Reset") }
                            Button(onClick = ::commitAdjust, enabled = adjusting) { Text("Apply") }
                        }
                    }
                    ToolSection("Effects") {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ToolButton("Auto levels") { p?.let { push(EditOp.Colour(autoLevelsMatrix(it))) } }
                            ToolButton("Black & white") { push(EditOp.Colour(GRAYSCALE)) }
                            ToolButton("Sepia") { push(EditOp.Colour(SEPIA)) }
                            ToolButton("Invert") { push(EditOp.Colour(INVERT)) }
                        }
                    }
                    ToolSection("History") {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ToolButton("Undo", Icons.AutoMirrored.Filled.Undo, enabled = ops.isNotEmpty()) {
                                resetSliders(); redo += ops.removeAt(ops.lastIndex)
                            }
                            ToolButton("Redo", Icons.AutoMirrored.Filled.Redo, enabled = redo.isNotEmpty()) {
                                ops += redo.removeAt(redo.lastIndex)
                            }
                            ToolButton("Revert to original", enabled = dirty) {
                                ops.clear(); redo.clear(); resetSliders(); cropMode = false
                            }
                        }
                    }
                }
            }
        }
        if (wide) {
            Row(Modifier.fillMaxSize()) {
                canvas(Modifier.weight(1f).fillMaxHeight())
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                tools(Modifier.width(340.dp).fillMaxHeight())
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                canvas(Modifier.weight(1f).fillMaxWidth())
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                tools(Modifier.height(300.dp).fillMaxWidth())
            }
        }
    }

    if (confirmExit) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Unsaved changes") },
            text = { Text("Do you want to keep your changes?") },
            confirmButton = { TextButton(onClick = { confirmExit = false; save(false) }) { Text("Save copy") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmExit = false; leave() }) { Text("Discard") }
                    TextButton(onClick = { confirmExit = false }) { Text("Cancel") }
                }
            },
        )
    }
    if (confirmOverwrite) {
        ConfirmDialog("Save", "Replace the original “${photo.name}” with your changes? " +
            "Choose Save copy instead to keep the original.", "Replace",
            onDismiss = { confirmOverwrite = false }) {
            confirmOverwrite = false
            save(true)
        }
    }
}

@Composable
private fun Spacer8() = Box(Modifier.width(8.dp))

@Composable
private fun ToolSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
private fun ToolButton(
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    enabled: Boolean = true, onClick: () -> Unit,
) {
    FilledTonalButton(onClick = onClick, enabled = enabled) {
        if (icon != null) {
            Icon(icon, null, Modifier.padding(end = 6.dp))
        }
        Text(label)
    }
}

@Composable
private fun AdjustSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(value.toInt().toString(), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value, onChange, valueRange = -100f..100f)
    }
}

/** Shows the picture; in crop mode draws the selection and lets the user change it. */
@Composable
private fun CropCanvas(
    bmp: Bitmap, crop: Rect, cropMode: Boolean, ratio: Float?, filter: ColorFilter?, onCrop: (Rect) -> Unit,
) {
    var box by remember { mutableStateOf(IntSize.Zero) }
    val image = remember(bmp) { bmp.asImageBitmap() }
    val fit = if (box.width == 0) 1f else min(box.width / bmp.width.toFloat(), box.height / bmp.height.toFloat())
    val dw = bmp.width * fit
    val dh = bmp.height * fit
    val left = (box.width - dw) / 2f
    val top = (box.height - dh) / 2f

    fun toNorm(o: Offset) = Offset(((o.x - left) / dw).coerceIn(0f, 1f), ((o.y - top) / dh).coerceIn(0f, 1f))

    fun rectFrom(a: Offset, q: Offset): Rect {
        val dx = q.x - a.x
        val dy = q.y - a.y
        val maxW = if (dx >= 0) 1f - a.x else a.x
        val maxH = if (dy >= 0) 1f - a.y else a.y
        var w = abs(dx)
        var h = abs(dy)
        if (ratio != null) {
            w = minOf(max(w, h * ratio), maxW, maxH * ratio)
            h = w / ratio
        } else {
            w = min(w, maxW)
            h = min(h, maxH)
        }
        val x = if (dx >= 0) a.x else a.x - w
        val y = if (dy >= 0) a.y else a.y - h
        return Rect(x, y, x + w, y + h)
    }

    Box(Modifier.fillMaxSize().padding(16.dp).onSizeChanged { box = it }) {
        Image(image, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit, colorFilter = filter)
        if (cropMode && box.width > 0) {
            var current by remember { mutableStateOf(crop) }
            current = crop
            Canvas(
                Modifier.fillMaxSize().pointerInput(ratio, box, bmp) {
                    var mode = 0  // 1 = resize/new from anchor, 2 = move
                    var anchor = Offset.Zero
                    var last = Offset.Zero
                    detectDragGestures(
                        onDragStart = { pos ->
                            val c = current
                            val corners = listOf(
                                Offset(c.left, c.top) to Offset(c.right, c.bottom),
                                Offset(c.right, c.top) to Offset(c.left, c.bottom),
                                Offset(c.left, c.bottom) to Offset(c.right, c.top),
                                Offset(c.right, c.bottom) to Offset(c.left, c.top),
                            )
                            val hit = corners.minByOrNull { (corner, _) ->
                                hypot(left + corner.x * dw - pos.x, top + corner.y * dh - pos.y)
                            }!!
                            val dist = hypot(left + hit.first.x * dw - pos.x, top + hit.first.y * dh - pos.y)
                            val n = toNorm(pos)
                            when {
                                dist < 48.dp.toPx() -> { mode = 1; anchor = hit.second }
                                c.contains(n) -> { mode = 2; last = n }
                                else -> { mode = 1; anchor = n }
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val n = toNorm(change.position)
                            if (mode == 1) {
                                onCrop(rectFrom(anchor, n))
                            } else if (mode == 2) {
                                val c = current
                                val dx = (n.x - last.x).coerceIn(-c.left, 1f - c.right)
                                val dy = (n.y - last.y).coerceIn(-c.top, 1f - c.bottom)
                                onCrop(c.translate(dx, dy))
                                last = n
                            }
                        },
                    )
                },
            ) {
                val r = Rect(left + crop.left * dw, top + crop.top * dh, left + crop.right * dw, top + crop.bottom * dh)
                val shade = Color(0x99000000)
                drawRect(shade, Offset(left, top), Size(dw, r.top - top))
                drawRect(shade, Offset(left, r.bottom), Size(dw, top + dh - r.bottom))
                drawRect(shade, Offset(left, r.top), Size(r.left - left, r.height))
                drawRect(shade, Offset(r.right, r.top), Size(left + dw - r.right, r.height))
                val thin = Color(0x88FFFFFF)
                for (i in 1..2) {
                    val x = r.left + r.width * i / 3f
                    val y = r.top + r.height * i / 3f
                    drawLine(thin, Offset(x, r.top), Offset(x, r.bottom), 1.dp.toPx())
                    drawLine(thin, Offset(r.left, y), Offset(r.right, y), 1.dp.toPx())
                }
                drawRect(Color.White, r.topLeft, r.size, style = Stroke(2.dp.toPx()))
                val hs = 14.dp.toPx()
                for (c in listOf(r.topLeft, r.topRight, r.bottomLeft, r.bottomRight)) {
                    drawRect(Color.White, Offset(c.x - hs / 2, c.y - hs / 2), Size(hs, hs))
                }
            }
        }
    }
}
