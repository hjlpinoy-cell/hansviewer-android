#!/bin/bash
# Builds HansViewer into the folder given as $1:
#   hansviewer_<version>_all.deb  Linux package
#   HansViewer-1.0.<build>.apk    Android, for direct install (GitHub version)
#   HansViewer-play.aab           Android App Bundle for the Google Play Store
#                                 (only when the secret upload key is available)
set -euo pipefail
OUT="${1:-$PWD/out}"
mkdir -p "$OUT"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "=== Linux .deb"
bash "$HERE/linux/build-deb.sh" "$OUT"

echo "=== Android .apk (GitHub version)"
cd "$HERE/android"
gradle --no-daemon assembleGithubRelease
cp app/build/outputs/apk/github/release/app-github-release.apk "$OUT/HansViewer-1.0.${GITHUB_RUN_NUMBER:-1}.apk"

if [ -n "${UPLOAD_KEYSTORE_FILE:-}" ] && [ -f "$UPLOAD_KEYSTORE_FILE" ]; then
  echo "=== Android .aab (Play Store version)"
  gradle --no-daemon bundlePlayRelease
  cp app/build/outputs/bundle/playRelease/app-play-release.aab "$OUT/HansViewer-play.aab"
else
  echo "=== No Play Store upload key set up yet - skipping the .aab"
fi

ls -l "$OUT"
