#!/bin/bash
# Builds both versions of HansViewer into the folder given as $1:
#   HansViewer.apk               (Android, needs Java 17 + Gradle + Android SDK)
#   hansviewer_<version>_all.deb (Linux)
set -euo pipefail
OUT="${1:-$PWD/out}"
mkdir -p "$OUT"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "=== Linux .deb"
bash "$HERE/linux/build-deb.sh" "$OUT"

echo "=== Android .apk"
(cd "$HERE/android" && gradle --no-daemon assembleRelease)
cp "$HERE/android/app/build/outputs/apk/release/app-release.apk" "$OUT/HansViewer.apk"

ls -l "$OUT"
